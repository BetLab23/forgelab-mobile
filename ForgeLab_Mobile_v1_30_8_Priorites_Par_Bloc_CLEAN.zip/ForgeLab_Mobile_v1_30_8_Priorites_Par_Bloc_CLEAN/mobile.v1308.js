const URL='https://ocakkunttbjmlvljekbu.supabase.co/rest/v1',KEY='sb_publishable_qgTkkrzwbyWthC_zwWHKcw_PWyrwFKx';
const DAYS=['Lun','Mar','Mer','Jeu','Ven','Sam','Dim'];let state={week:1,tab:'series',block:'main',blockName:'Bloc actif',blockDuration:13,nutritionContext:'maintenance',priorities:[],series:[]},poll;
const CARDIO_QUALITIES=['🟢 Base aérobie','🟠 Seuil','🔴 Haute intensité / VO₂max','⚫ Conditioning'];
const CARDIO_ENGINES=['Run','SkiErg','Bike','Rower'];
const CARDIO_FORMATS=['Continu','Intervalles'];
const CARDIO_TYPES=CARDIO_ENGINES;
const CARDIO_INTENSITIES=CARDIO_QUALITIES;
let authSession=null,currentUser=null,authMode='login';
const AUTH_BASE=URL.replace('/rest/v1','');


/* ===== ForgeLab v1.25.1 — migration orthographique des données déjà enregistrées ===== */
const FL_ORTHO_MIGRATION_V1251={
  'Élévation en Y':'Élévations en Y',
  'Élévation frontale haltères':'Élévations frontales haltères',
  'Élévation latérale assise':'Élévations latérales assises',
  'Élévation latérale debout':'Élévations latérales debout',
  'Élévation latérale':'Élévations latérales',
  'Elevation en Y':'Élévations en Y',
  'Elevation frontale haltères':'Élévations frontales haltères',
  'Elevation latérale assise':'Élévations latérales assises',
  'Elevation latérale debout':'Élévations latérales debout',
  'Elevation latérale':'Élévations latérales',
  'Extension du cou':'Extensions du cou',
  'Extension cou':'Extensions du cou',
  'Flexion du cou':'Flexions du cou',
  'Flexion cou':'Flexions du cou',
  'Flexion latérale du cou':'Flexions latérales du cou',
  'Flexion latérale cou':'Flexions latérales du cou',
  'Flexion latérale obliques':'Flexion latérale des obliques',
  'Extension mollets debout barre':'Extensions des mollets debout à la barre',
  'Extension mollets debout haltères':'Extensions des mollets debout avec haltères',
  'Extension mollets unilatérale haltère':'Extension unilatérale des mollets avec haltère',
  'Extension mollets assis':'Extensions des mollets assis',
  'Flexion avant bras barre':'Flexions des avant-bras à la barre',
  'Flexion avant bras haltères':'Flexions des avant-bras avec haltères',
  'Extension avant bras barre':'Extensions des avant-bras à la barre',
  'Extension avant bras haltères':'Extensions des avant-bras avec haltères',
  'Squat sumo Dumbbells':'Squat sumo avec haltères'
};
function flMigrateOrthoValueV1251(value){
  if(typeof value==='string')return FL_ORTHO_MIGRATION_V1251[value]||value;
  if(Array.isArray(value))return value.map(flMigrateOrthoValueV1251);
  if(value&&typeof value==='object'){
    Object.keys(value).forEach(k=>{value[k]=flMigrateOrthoValueV1251(value[k])});
  }
  return value;
}
function flMigrateExistingOrthoV1251(){
  const marker='forgelabMigration:orthographe:v1251';
  if(localStorage.getItem(marker)==='1')return;
  const entries=[];
  for(let i=0;i<localStorage.length;i++){
    const k=localStorage.key(i);
    if(k&&k.toLowerCase().startsWith('forgelab'))entries.push([k,localStorage.getItem(k)]);
  }
  entries.forEach(([k,raw])=>{
    if(raw==null)return;
    let parsed;
    try{parsed=JSON.parse(raw)}catch(_){parsed=raw}
    const next=flMigrateOrthoValueV1251(parsed);
    const out=typeof parsed==='string'&&!(/^\s*[\[{\"]/.test(raw))?String(next):JSON.stringify(next);
    if(out!==raw)localStorage.setItem(k,out);
  });
  localStorage.setItem(marker,'1');
}
flMigrateExistingOrthoV1251();

const EMAILS_KEY='forgelabMobileKnownEmails';
function roman(n){const map=[[1000,'M'],[900,'CM'],[500,'D'],[400,'CD'],[100,'C'],[90,'XC'],[50,'L'],[40,'XL'],[10,'X'],[9,'IX'],[5,'V'],[4,'IV'],[1,'I']];let out='';n=Math.max(1,Math.floor(+n||1));for(const [v,r] of map)while(n>=v){out+=r;n-=v}return out}
function draftRegistryKey(){return `forgelabProgrammingDraftRegistry:${currentUser?.id||'guest'}`}
function draftRegistry(){try{return JSON.parse(localStorage.getItem(draftRegistryKey())||'[]').filter(x=>x&&x.id)}catch(_){return[]}}
function saveDraftRegistry(x){localStorage.setItem(draftRegistryKey(),JSON.stringify(x))}
function selectedDraftKey(){return `forgelabProgrammingSelectedDraft:${currentUser?.id||'guest'}`}
function selectedDraftId(){return localStorage.getItem(selectedDraftKey())||''}
function setSelectedDraftId(id){if(id)localStorage.setItem(selectedDraftKey(),id);else localStorage.removeItem(selectedDraftKey())}
function ensureLegacyProgrammingDraftRegistered(){if(draftRegistry().length||!localStorage.getItem(`forgelabMobileProgrammingDraft:${currentUser?.id||'guest'}`))return;const id='draft-legacy';const m=(()=>{try{return JSON.parse(localStorage.getItem(`forgelabMobileProgrammingMeta:${currentUser?.id||'guest'}:draft`)||'null')}catch(_){return null}})()||{name:'Brouillon',duration:14,rhythm:4};saveDraftRegistry([{id,name:m.name||'Brouillon'}]);setSelectedDraftId(id);localStorage.setItem(`forgelabMobileProgrammingDraft:${currentUser?.id||'guest'}:${id}`,localStorage.getItem(`forgelabMobileProgrammingDraft:${currentUser?.id||'guest'}`));localStorage.setItem(`forgelabMobileProgrammingMeta:${currentUser?.id||'guest'}:draft:${id}`,JSON.stringify(m))}

/* v1.26.1 — récupération non destructive des brouillons orphelins */
function recoverOrphanProgrammingDrafts(){
 const uid=currentUser?.id||'guest', sources=[uid]; if(uid!=='guest')sources.push('guest');
 const existing=draftRegistry(), byId=new Map(existing.map(x=>[x.id,x])); let changed=false;
 const copyIfMissing=(src,dst)=>{const v=localStorage.getItem(src);if(v!=null&&localStorage.getItem(dst)==null){localStorage.setItem(dst,v);changed=true}};
 const ids=new Set();
 for(let i=0;i<localStorage.length;i++){
  const k=localStorage.key(i)||'';
  for(const srcUid of sources){
   let m=k.match(new RegExp('^forgelabMobileProgrammingDraft:'+srcUid.replace(/[.*+?^${}()|[\\]\\]/g,'\\$&')+':(draft-[^:]+|draft-legacy|default)(?::|$)'));
   if(!m)m=k.match(new RegExp('^forgelabFullProgram:'+srcUid.replace(/[.*+?^${}()|[\\]\\]/g,'\\$&')+':draft:(draft-[^:]+|draft-legacy|default)$'));
   if(!m)m=k.match(new RegExp('^forgelabProgramBlock:'+srcUid.replace(/[.*+?^${}()|[\\]\\]/g,'\\$&')+':draft:(draft-[^:]+|draft-legacy|default):'));
   if(!m)m=k.match(new RegExp('^forgelabMobileProgrammingMeta:'+srcUid.replace(/[.*+?^${}()|[\\]\\]/g,'\\$&')+':draft:(draft-[^:]+|draft-legacy|default)$'));
   if(m)ids.add(srcUid+'|'+m[1]);
  }
 }
 for(const token of ids){
  const [srcUid,id]=token.split('|'); const dstId=id==='default'?'draft-recovered-default':id;
  if(srcUid!==uid){
   const pairs=[
    [`forgelabMobileProgrammingDraft:${srcUid}:${id}`,`forgelabMobileProgrammingDraft:${uid}:${dstId}`],
    [`forgelabMobileProgrammingMeta:${srcUid}:draft:${id}`,`forgelabMobileProgrammingMeta:${uid}:draft:${dstId}`],
    [`forgelabFullProgram:${srcUid}:draft:${id}`,`forgelabFullProgram:${uid}:draft:${dstId}`]
   ]; pairs.forEach(x=>copyIfMissing(...x));
   const bp=`forgelabProgramBlock:${srcUid}:draft:${id}:`,bd=`forgelabProgramBlock:${uid}:draft:${dstId}:`;
   const keys=[];for(let j=0;j<localStorage.length;j++){const k=localStorage.key(j);if(k&&k.startsWith(bp))keys.push(k)}
   keys.forEach(k=>copyIfMissing(k,bd+k.slice(bp.length)));
  }
  const base=`forgelabMobileProgrammingDraft:${uid}:${dstId}`;
  if(!localStorage.getItem(base)){
   const phasePrefixes=[`forgelabMobileProgrammingDraft:${uid}:${dstId}:phase:`,`forgelabProgramBlock:${uid}:draft:${dstId}:`];
   let candidate=null;
   for(let j=0;j<localStorage.length&&!candidate;j++){const k=localStorage.key(j)||'';if(phasePrefixes.some(p=>k.startsWith(p))&&k.includes(':phase:'))candidate=localStorage.getItem(k)}
   if(candidate){localStorage.setItem(base,candidate);changed=true}
  }
  const hasAny=localStorage.getItem(base)||localStorage.getItem(`forgelabFullProgram:${uid}:draft:${dstId}`)||(()=>{const p=`forgelabProgramBlock:${uid}:draft:${dstId}:`;for(let j=0;j<localStorage.length;j++){if((localStorage.key(j)||'').startsWith(p))return true}return false})();
  if(hasAny&&!byId.has(dstId)){
   let name='Brouillon récupéré';
   try{const fp=JSON.parse(localStorage.getItem(`forgelabFullProgram:${uid}:draft:${dstId}`)||'null');if(fp?.name)name=fp.name}catch(_){ }
   try{const m=JSON.parse(localStorage.getItem(`forgelabMobileProgrammingMeta:${uid}:draft:${dstId}`)||'null');if(name==='Brouillon récupéré'&&m?.name)name=m.name}catch(_){ }
   byId.set(dstId,{id:dstId,name});changed=true;
  }
 }
 if(changed)saveDraftRegistry([...byId.values()]);
 return changed;
}


function knownEmails(){try{return JSON.parse(localStorage.getItem(EMAILS_KEY)||'[]').filter(Boolean)}catch(_){return[]}}
function rememberEmail(email){email=String(email||'').trim().toLowerCase();if(!email)return;const all=[email,...knownEmails().filter(x=>x!==email)].slice(0,8);localStorage.setItem(EMAILS_KEY,JSON.stringify(all))}
function disabledKey(){return `forgelabMobileDisabled:${currentUser?.id||'guest'}${priorityMode()==='draft'?':draft:'+selectedPriorityDraftId():''}`}
function legacyDisabledMuscles(){try{return new Set(JSON.parse(localStorage.getItem(disabledKey())||'[]'))}catch(_){return new Set()}}
function legacyMuscleOrder(){try{return JSON.parse(localStorage.getItem(muscleOrderKey())||'[]').filter(Boolean)}catch(_){return[]}}
function priorityActiveProgram(){
  try{const x=JSON.parse(localStorage.getItem(`forgelabFullProgram:${currentUser?.id||'guest'}:active`)||'null');if(x&&Array.isArray(x.blocks)&&x.blocks.length)return x}catch(_){}
  return {name:state.blockName||'Programme actif',totalDuration:Number(state.blockDuration||14),blocks:[{id:'bloc-1',name:'Bloc 1',from:1,to:Number(state.blockDuration||14),blockIndex:1,deload:false}]};
}
function priorityFirstBlockId(){const fp=priorityActiveProgram();return (fp.blocks||[]).find(b=>!b.deload)?.id||fp.blocks?.[0]?.id||'bloc-1'}
function priorityCurrentBlockId(){const fp=priorityActiveProgram(),week=Math.max(1,Number(state.week)||1);return (fp.blocks||[]).find(b=>week>=Number(b.from||1)&&week<=Number(b.to||b.from||1))?.id||priorityFirstBlockId()}
function prioritySelectedBlockKey(){return `forgelabPrioritySelectedBlock:${currentUser?.id||'guest'}`}
function prioritySelectedBlockId(){
  const fp=priorityActiveProgram(),saved=localStorage.getItem(prioritySelectedBlockKey()),ids=new Set((fp.blocks||[]).map(b=>b.id));
  if(saved&&ids.has(saved))return saved;
  const id=priorityCurrentBlockId();if(id)localStorage.setItem(prioritySelectedBlockKey(),id);return id;
}
function setPrioritySelectedBlockId(id){if(id)localStorage.setItem(prioritySelectedBlockKey(),id);drawPriorities()}
function priorityBlockSnapshotKey(id){return `forgelabPriorityByBlock:${currentUser?.id||'guest'}:active:${id}`}
function priorityBaseSnapshot(){return {priorities:JSON.parse(JSON.stringify(state.priorities||[])),disabled:[...legacyDisabledMuscles()],order:legacyMuscleOrder(),updatedAt:null}}
function priorityReadStoredSnapshot(id){try{const x=JSON.parse(localStorage.getItem(priorityBlockSnapshotKey(id))||'null');if(x&&Array.isArray(x.priorities))return x}catch(_){}return null}
function prioritySnapshotForBlock(id=priorityCurrentBlockId()){
  const stored=priorityReadStoredSnapshot(id);if(stored)return {...stored,inherited:false};
  const first=priorityFirstBlockId();
  if(id&&id!==first){const source=priorityReadStoredSnapshot(first)||priorityBaseSnapshot();return {priorities:JSON.parse(JSON.stringify(source.priorities||[])),disabled:[...(source.disabled||[])],order:[...(source.order||[])],updatedAt:null,inherited:true,inheritedFrom:first}}
  return {...priorityBaseSnapshot(),inherited:false,legacy:true};
}
function ensurePriorityBlockSnapshot(id){
  if(!id||priorityReadStoredSnapshot(id))return prioritySnapshotForBlock(id);
  const snap=prioritySnapshotForBlock(id);delete snap.inherited;delete snap.legacy;delete snap.inheritedFrom;snap.updatedAt=new Date().toISOString();localStorage.setItem(priorityBlockSnapshotKey(id),JSON.stringify(snap));return snap
}
function savePriorityBlockSnapshot(id,snap){if(!id)return;snap={priorities:JSON.parse(JSON.stringify(snap.priorities||[])),disabled:[...(snap.disabled||[])],order:[...(snap.order||[])],updatedAt:new Date().toISOString()};localStorage.setItem(priorityBlockSnapshotKey(id),JSON.stringify(snap))}
function priorityContextBlockId(){
  if(priorityMode()!=='active')return '';
  if(state.tab==='priorities'&&prioritiesScreen==='editor')return prioritySelectedBlockId();
  if(state.tab==='programming'&&typeof programmingScreen!=='undefined'&&programmingScreen==='editor'&&programmingMode()==='active'){
    try{return selectedFullBlock()?.id||priorityCurrentBlockId()}catch(_){return priorityCurrentBlockId()}
  }
  return priorityCurrentBlockId();
}
function effectivePriorities(blockId=priorityContextBlockId()){return priorityMode()==='active'&&blockId?prioritySnapshotForBlock(blockId).priorities:(state.priorities||[])}
function disabledMuscles(){if(priorityMode()==='active'){const id=priorityContextBlockId();if(id)return new Set(prioritySnapshotForBlock(id).disabled||[])}return legacyDisabledMuscles()}
function setMuscleEnabled(muscleKey,enabled){
  if(priorityMode()==='active'){
    const id=priorityContextBlockId();if(id){const snap=ensurePriorityBlockSnapshot(id),off=new Set(snap.disabled||[]);enabled?off.delete(muscleKey):off.add(muscleKey);snap.disabled=[...off];savePriorityBlockSnapshot(id,snap);drawPriorities();return}
  }
  const off=legacyDisabledMuscles();enabled?off.delete(muscleKey):off.add(muscleKey);localStorage.setItem(disabledKey(),JSON.stringify([...off]));draw()
}
function muscleOrderKey(){return `forgelabMobileMuscleOrder:${currentUser?.id||'guest'}${priorityMode()==='draft'?':draft:'+selectedPriorityDraftId():''}`}
function muscleOrder(){if(priorityMode()==='active'){const id=priorityContextBlockId();if(id)return prioritySnapshotForBlock(id).order||[]}return legacyMuscleOrder()}
function orderedPriorities(){
  const list=effectivePriorities(),rank={P0:0,P1:1,P2:2},order=muscleOrder(),pos=new Map(order.map((k,i)=>[k,i]));
  const original=new Map(list.map((p,i)=>[p.muscle_key,i]));
  return [...list].sort((a,b)=>{const pr=(rank[a.priority]??9)-(rank[b.priority]??9);if(pr)return pr;const ai=pos.has(a.muscle_key)?pos.get(a.muscle_key):9999+(original.get(a.muscle_key)||0),bi=pos.has(b.muscle_key)?pos.get(b.muscle_key):9999+(original.get(b.muscle_key)||0);return ai-bi})
}
function saveMuscleOrder(keys){
  if(priorityMode()==='active'){const id=priorityContextBlockId();if(id){const snap=ensurePriorityBlockSnapshot(id);snap.order=[...keys];savePriorityBlockSnapshot(id,snap);return}}
  localStorage.setItem(muscleOrderKey(),JSON.stringify(keys))
}
function programmingKey(){return `forgelabMobileProgramming:${currentUser?.id||'guest'}`}
function programmingDraftKey(){return `forgelabMobileProgrammingDraft:${currentUser?.id||'guest'}:${selectedDraftId()||'default'}`}
function programmingModeKey(){return `forgelabMobileProgrammingMode:${currentUser?.id||'guest'}`}
function programmingMetaKey(mode=programmingMode()){return `forgelabMobileProgrammingMeta:${currentUser?.id||'guest'}:${mode==='draft'?'draft:'+(selectedDraftId()||'default'):'active'}`}
function programmingMeta(mode=programmingMode()){
  try{const x=JSON.parse(localStorage.getItem(programmingMetaKey(mode))||'null');if(x)return x}catch(_){}
  return {name:mode==='draft'?'Nouveau bloc':(state.blockName||'Bloc actif'),duration:Number(state.blockDuration||14),rhythm:4}
}
function saveProgrammingMeta(meta,mode=programmingMode()){localStorage.setItem(programmingMetaKey(mode),JSON.stringify(meta))}
function phaseRanges(meta){const n=Math.max(1,Number(meta.duration||14)),r=Math.max(3,Math.min(6,Number(meta.rhythm||4))),out=[];let w=1,c=1;while(w<=n){const end=Math.min(n,w+r-1);out.push({label:`Cycle ${roman(c)}`,from:w,to:end,deload:false});w=end+1;if(w<=n){out.push({label:'Deload',from:w,to:w,deload:true});w++}c++}return out}
function phaseId(q){return `s${q.from}-${q.to}${q.deload?'-d':''}`}
function selectedPhaseKey(mode=programmingMode()){return `forgelabMobileProgrammingSelectedPhase:${currentUser?.id||'guest'}:${mode}${mode==='draft'?':'+(selectedDraftId()||'default'):''}`}
function selectedPhaseId(meta=programmingMeta(),mode=programmingMode()){const phases=phaseRanges(meta),saved=localStorage.getItem(selectedPhaseKey(mode));return phases.some(q=>phaseId(q)===saved)?saved:phaseId(phases[0])}
function setSelectedPhase(id){localStorage.setItem(selectedPhaseKey(),id);drawProgramming()}
function phaseProgrammingKey(id,mode=programmingMode()){return `${mode==='draft'?programmingDraftKey():programmingKey()}:phase:${id}`}
function cloneProgrammingData(p){return JSON.parse(JSON.stringify(p||blankProgramming()))}
function ensurePhaseProgramming(meta=programmingMeta(),mode=programmingMode()){const phases=phaseRanges(meta),first=phaseId(phases[0]);phases.forEach((q,i)=>{const id=phaseId(q),k=phaseProgrammingKey(id,mode);if(!localStorage.getItem(k)){let src;if(i===0)src=programmingDataFromKey(mode==='draft'?programmingDraftKey():programmingKey());else src=programmingDataFromKey(phaseProgrammingKey(first,mode));localStorage.setItem(k,JSON.stringify(src))}});return phases}
function copyPreviousPhase(){const meta=programmingMeta(),ph=ensurePhaseProgramming(meta),id=selectedPhaseId(meta),i=ph.findIndex(q=>phaseId(q)===id);if(i<=0)return;const src=programmingDataFromKey(phaseProgrammingKey(phaseId(ph[i-1])));localStorage.setItem(phaseProgrammingKey(id),JSON.stringify(cloneProgrammingData(src)));drawProgramming()}
function programmingMode(){return localStorage.getItem(programmingModeKey())==='draft'?'draft':'active'}
function setProgrammingMode(mode){localStorage.setItem(programmingModeKey(),mode==='draft'?'draft':'active');drawProgramming()}
function programmingStorageKey(){const mode=programmingMode(),meta=programmingMeta(mode);ensurePhaseProgramming(meta,mode);return phaseProgrammingKey(selectedPhaseId(meta,mode),mode)}
function hasProgrammingDraft(){return !!(selectedDraftId()&&localStorage.getItem(programmingDraftKey()))}
function createProgrammingDraft(copyActive=true){const programName=(prompt('Nom du programme :','Nouveau programme')||'').trim();if(!programName)return;const id='draft-'+Date.now().toString(36);const regs=draftRegistry();regs.push({id,name:programName});saveDraftRegistry(regs);setSelectedDraftId(id);const duration=14,rhythm=4,src=copyActive?programmingDataFromKey(programmingKey()):blankProgramming();localStorage.setItem(programmingDraftKey(),JSON.stringify(src));saveProgrammingMeta({name:'Bloc I',duration,rhythm},'draft');localStorage.setItem(programmingModeKey(),'draft');ensureDraftProgramCardio();const fp={name:programName,selected:'bloc-1',blocks:[{id:'bloc-1',name:'Bloc I'}]};localStorage.setItem(fullProgramKey(),JSON.stringify(fp));saveCurrentIntoBlock('bloc-1');programmingScreen='editor';drawProgramming()}
function activateProgrammingDraft(){if(!hasProgrammingDraft())return;if(!confirm('Activer ce brouillon ? Le programme actif sera remplacé.'))return;saveCurrentIntoBlock();const fp=fullProgram();localStorage.setItem(programmingKey(),localStorage.getItem(programmingDraftKey())||JSON.stringify(blankProgramming()));saveProgrammingMeta(programmingMeta('draft'),'active');state.blockName=fp.name||state.blockName;localStorage.setItem(programmingModeKey(),'active');programmingScreen='chooser';drawProgramming()}
function deleteProgrammingDraft(){const id=selectedDraftId();if(!id||!confirm('Supprimer ce brouillon ? Le programme actif ne sera pas modifié.'))return;saveDraftRegistry(draftRegistry().filter(x=>x.id!==id));const pref=[`forgelabMobileProgrammingDraft:${currentUser?.id||'guest'}:${id}`,`forgelabMobileProgrammingMeta:${currentUser?.id||'guest'}:draft:${id}`,`forgelabFullProgram:${currentUser?.id||'guest'}:draft:${id}`,`forgelabProgramBlock:${currentUser?.id||'guest'}:draft:${id}:`];for(let i=localStorage.length-1;i>=0;i--){const k=localStorage.key(i);if(k&&pref.some(x=>k===x||k.startsWith(x)))localStorage.removeItem(k)}setSelectedDraftId('');programmingScreen='chooser';drawProgramming()}
function deleteProgrammingDraftById(id){if(!id)return;const d=draftRegistry().find(x=>x.id===id);if(!confirm(`Supprimer le brouillon « ${d?.name||'Programme'} » ?\n\nLe programme actif ne sera pas modifié.`))return;saveDraftRegistry(draftRegistry().filter(x=>x.id!==id));const uidKey=currentUser?.id||'guest',pref=[`forgelabMobileProgrammingDraft:${uidKey}:${id}`,`forgelabMobileProgrammingMeta:${uidKey}:draft:${id}`,`forgelabFullProgram:${uidKey}:draft:${id}`,`forgelabProgramBlock:${uidKey}:draft:${id}:`,`forgelabMobileProgrammingSelectedPhase:${uidKey}:draft:${id}`];for(let i=localStorage.length-1;i>=0;i--){const k=localStorage.key(i);if(k&&pref.some(x=>k===x||k.startsWith(x)))localStorage.removeItem(k)}if(selectedDraftId()===id)setSelectedDraftId('');programmingScreen='chooser';drawProgramming()}
function programmingPresetKey(){return `forgelabMobileProgrammingPresets:${currentUser?.id||'guest'}`}
const PC_PROGRAMMING_IMPORT_V169={"Lun":[{"id":"47b888ba-8484-4a34-95c3-ed854f5a4137","muscle_key":"Deltoïde latéral","muscle_name":"Deltoïde latéral","sets":4},{"id":"e2843dc6-6d8b-4cc2-8979-0c9b38421f7f","muscle_key":"Trapèzes moyens","muscle_name":"Trapèzes moyens","sets":4},{"id":"6f78cd77-7234-426c-9963-c7495c566d71","muscle_key":"Pectoraux","muscle_name":"Pectoraux","sets":4},{"id":"ebd9e2bc-1bbc-4440-8f6c-7d9a46f965dc","muscle_key":"Abdominaux","muscle_name":"Abdominaux","sets":4},{"id":"d1b00296-9092-4e63-bd7f-a30917b76eba","muscle_key":"Cou","muscle_name":"Cou","sets":4}],"Mar":[{"id":"8354c8a0-75d3-4a97-91e5-fa0cc9c8ad17","muscle_key":"Adducteurs","muscle_name":"Adducteurs","sets":4},{"id":"b4fcf4c2-a24d-4734-ad4d-5420cf2ef0e6","muscle_key":"Quadriceps","muscle_name":"Quadriceps","sets":3},{"id":"c3d420b4-9848-49f1-9f45-d99c67489361","muscle_key":"Ischios","muscle_name":"Ischios","sets":4},{"id":"55abadd6-07da-47d3-ae46-2c26e152152c","muscle_key":"Fessiers","muscle_name":"Fessiers","sets":3},{"id":"45721ab5-d8f4-491f-ab05-dfa01113e2bb","muscle_key":"Mollets","muscle_name":"Mollets","sets":3}],"Mer":[{"id":"b993a249-9db0-48d9-b8ed-f04b37e8cd43","muscle_key":"Deltoïde latéral","muscle_name":"Deltoïde latéral","sets":4},{"id":"235610c4-751b-410a-970c-f2e04b30fc2c","muscle_key":"Trapèzes moyens","muscle_name":"Trapèzes moyens","sets":4},{"id":"a1b730c2-f4fd-40d6-bd08-7a66b73f06f2","muscle_key":"Dos","muscle_name":"Dos","sets":4},{"id":"bbfd74f5-d3e7-46e1-9168-fec0157b8e55","muscle_key":"Trapèzes supérieurs","muscle_name":"Trapèzes supérieurs","sets":4},{"id":"1cb9bbdd-f926-411c-9322-688c9988980d","muscle_key":"Abdominaux","muscle_name":"Abdominaux","sets":4}],"Jeu":[{"id":"64d655c1-85b3-4afd-abc7-7ffaf5251d06","muscle_key":"Adducteurs","muscle_name":"Adducteurs","sets":4},{"id":"f478d3d4-de8c-494d-acd8-74069294ea39","muscle_key":"Quadriceps","muscle_name":"Quadriceps","sets":3},{"id":"e3c54e79-e085-4f37-9837-8bb01b161f73","muscle_key":"Ischios","muscle_name":"Ischios","sets":4},{"id":"ae9e5431-e3b8-4307-9347-b742af54a864","muscle_key":"Fessiers","muscle_name":"Fessiers","sets":3},{"id":"455a2400-b16e-4260-b380-e8870db2ff32","muscle_key":"Mollets","muscle_name":"Mollets","sets":3}],"Ven":[{"id":"25de6897-62a3-4e56-a5f4-d3dea948257c","muscle_key":"Deltoïde latéral","muscle_name":"Deltoïde latéral","sets":4},{"id":"717fbb21-7b59-462c-956e-605beba2492c","muscle_key":"Trapèzes moyens","muscle_name":"Trapèzes moyens","sets":4},{"id":"5fdbe360-2dcb-41d6-8d15-e498aecf243c","muscle_key":"Pectoraux","muscle_name":"Pectoraux","sets":4},{"id":"a9aa911c-58c0-46ce-9704-5d53cde551ec","muscle_key":"Dos","muscle_name":"Dos","sets":4},{"id":"5cc2487f-932b-4006-b60e-ddb53d1ba8fd","muscle_key":"Trapèzes supérieurs","muscle_name":"Trapèzes supérieurs","sets":4}],"Sam":[{"id":"904114ff-2c99-4dad-b9c3-b097098c0db2","muscle_key":"Biceps","muscle_name":"Biceps","sets":4},{"id":"afe086b2-c754-415a-8162-53a707aed30c","muscle_key":"Triceps","muscle_name":"Triceps","sets":6},{"id":"e802f043-da09-4e0c-9e5f-49e13be7af2d","muscle_key":"Cou","muscle_name":"Cou","sets":4},{"id":"8364ebdb-9e8c-4a95-a57f-5ce78a77df6d","muscle_key":"Avant-bras","muscle_name":"Avant-bras","sets":3}],"Dim":[]};
function importPcProgrammingV169(){
  if(!currentUser?.id)return;
  const marker=`forgelabMobileProgrammingImport:v1123:${currentUser.id}`;
  if(localStorage.getItem(marker)==='1')return;
  localStorage.setItem(programmingKey(),JSON.stringify(PC_PROGRAMMING_IMPORT_V169));
  localStorage.setItem(marker,'1');
}
function newProgramId(){return 'pr_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,8)}
function programOpenExerciseKey(){return `forgelabMobileProgrammingOpenExercise:${currentUser?.id||'guest'}:${programmingMode()}:${selectedPhaseId(programmingMeta(),programmingMode())}`}
function programOpenExerciseId(){return localStorage.getItem(programOpenExerciseKey())||''}
function setProgramOpenExerciseId(id){if(id)localStorage.setItem(programOpenExerciseKey(),id);else localStorage.removeItem(programOpenExerciseKey())}
function exerciseLibraryKey(){return `forgelabMobileExerciseLibrary:${currentUser?.id||'guest'}`}
function loadCustomExerciseLibrary(){try{return JSON.parse(localStorage.getItem(exerciseLibraryKey())||'{}')}catch(_){return {}}}
function exerciseOptionsFor(muscle){const custom=loadCustomExerciseLibrary()[muscle]||[];return [...new Set([...(JOURNAL_LIBRARY[muscle]||[]),...custom])]}
function rememberExercise(muscle,name){const lib=loadCustomExerciseLibrary();lib[muscle]=[...new Set([...(lib[muscle]||[]),name])];localStorage.setItem(exerciseLibraryKey(),JSON.stringify(lib))}
function blankProgramming(){return Object.fromEntries(DAYS.map(d=>[d,[]]))}
function programCardioKey(mode=programmingMode()){return `forgelabProgrammingCardio:${currentUser?.id||'guest'}:${mode==='draft'?'draft:'+(selectedDraftId()||'default'):'active'}`}
function blankProgramCardio(){return Object.fromEntries(DAYS.map(d=>[d,[]]))}
function programCardioData(mode=programmingMode()){try{const raw=JSON.parse(localStorage.getItem(programCardioKey(mode))||'null'),out=blankProgramCardio();if(raw&&typeof raw==='object')DAYS.forEach(d=>{out[d]=Array.isArray(raw[d])?raw[d].map(x=>({id:x.id||cardioModalityId(),quality:String(x.quality||CARDIO_QUALITIES[0]),engine:String(x.engine||CARDIO_ENGINES[0]),format:String(x.format||CARDIO_FORMATS[0]),duration:Math.max(0,Number(x.duration||0))})):[]});return out}catch(_){return blankProgramCardio()}}
function saveProgramCardio(x,redraw=true){localStorage.setItem(programCardioKey(),JSON.stringify(x));if(redraw&&state.tab==='programming')drawProgramming()}
function ensureDraftProgramCardio(){if(programmingMode()!=='draft'||localStorage.getItem(programCardioKey('draft')))return;const active=localStorage.getItem(programCardioKey('active'));localStorage.setItem(programCardioKey('draft'),active||JSON.stringify(blankProgramCardio()))}
function programmingDataFromKey(key){
  try{
    const raw=JSON.parse(localStorage.getItem(key)||'null');
    const out=blankProgramming();
    if(raw&&typeof raw==='object')DAYS.forEach(d=>{
      out[d]=Array.isArray(raw[d])?raw[d].map(x=>({id:x.id||newProgramId(),muscle_key:String(x.muscle_key||x.muscle||''),muscle_name:String(x.muscle_name||x.muscle||x.muscle_key||''),sets:Math.max(0,Number(x.sets||0)),exercises:Array.isArray(x.exercises)?x.exercises.map(e=>({id:e.id||newProgramId(),name:String(e.name||''),sets:Math.max(0,Number(e.sets||0)),rest:Math.max(15,Number(e.rest||90))})).filter(e=>e.name):[]})).filter(x=>x.muscle_key):[];
    });
    return out;
  }catch(_){return blankProgramming()}
}
function programmingData(){return programmingDataFromKey(programmingStorageKey())}
function saveProgramming(p,redraw=true){localStorage.setItem(programmingStorageKey(),JSON.stringify(p));if(redraw&&state.tab==='programming')drawProgramming()}
function programmingPresets(){try{return JSON.parse(localStorage.getItem(programmingPresetKey())||'[]').filter(x=>x&&x.name&&x.programming)}catch(_){return[]}}
function saveProgrammingPresets(x){localStorage.setItem(programmingPresetKey(),JSON.stringify(x))}
function programPriority(muscleKey){return effectivePriorities().find(p=>p.muscle_key===muscleKey)?.priority||'P2'}
function programRange(muscleKey){const p=effectivePriorities().find(x=>x.muscle_key===muscleKey);return p?pRange(p):[0,0]}
function programTotals(p=programmingData()){
  const out={};activePriorities().forEach(x=>out[x.muscle_key]={sets:0,freq:0});
  DAYS.forEach(d=>(p[d]||[]).forEach(x=>{out[x.muscle_key] ||= {sets:0,freq:0};out[x.muscle_key].sets+=Number(x.sets||0);if(Number(x.sets||0)>0)out[x.muscle_key].freq++}));
  return out;
}
function distributeProgramTotal(total,n){const b=Math.floor(total/n),r=total%n;return Array.from({length:n},(_,i)=>b+(i<r?1:0))}
function autoProgramming(){
  const out=blankProgramming(),p1Patterns=[['Mar','Jeu'],['Lun','Jeu'],['Mar','Ven'],['Mer','Sam']],p2Days=['Mar','Jeu','Sam','Dim'];let p1=0,p2=0;
  activePriorities().forEach(m=>{
    const priority=m.priority||'P2',target=Math.max(0,Number(m.target_min||0));let days;
    if(priority==='P0')days=['Lun','Mer','Ven'];else if(priority==='P1')days=p1Patterns[p1++%p1Patterns.length];else days=[p2Days[p2++%p2Days.length]];
    const split=distributeProgramTotal(target,days.length);
    days.forEach((d,i)=>{if(split[i]>0)out[d].push({id:newProgramId(),muscle_key:m.muscle_key,muscle_name:m.muscle_name,sets:split[i]})});
  });
  saveProgramming(out);
}
function activePriorities(){const off=disabledMuscles();return orderedPriorities().filter(p=>!off.has(p.muscle_key))}
function cardioKey(){return `forgelabMobileCardio:${currentUser?.id||'guest'}${priorityMode()==='draft'?':draft:'+selectedPriorityDraftId():''}`}
function cardioModalityId(){return 'cm_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7)}
function defaultCardio(){return {
  enabled:true,
  priority:'P1',
  modalities:[{id:'cardio_default',quality:'🟢 Base aérobie',engine:'Run',format:'Continu',target:2}],
  weeks:{},
  sessions:[{
    id:'cardio_benchmark_run_20260909',
    date:'2026-09-09',
    quality:'🟢 Base aérobie',
    engine:'Run',
    format:'Continu',
    duration:40,
    pace:'7:13',
    avgHr:145,
    rpe:2,
    benchmark:true
  }]
}}
function cardioNormalizeModality(m,i=0){
  const legacy=String(m?.type||'');
  let engine=m?.engine||'Run',quality=m?.quality||'🟢 Base aérobie',format=m?.format||'Continu';
  if(!m?.engine){
    if(/ski/i.test(legacy))engine='SkiErg';
    else if(/rameur|row/i.test(legacy))engine='Rower';
    else if(/vélo|bike/i.test(legacy))engine='Bike';
    else engine='Run';
  }
  if(!m?.quality){
    if(/hiit|intervalles/i.test(legacy))quality='🔴 Haute intensité / VO₂max';
    else if(/burpee|corde|circuit|sled|farmer/i.test(legacy))quality='⚫ Conditioning';
  }
  if(!m?.format && /intervalles/i.test(legacy))format='Intervalles';
  return {
    id:m?.id||('cardio_'+i),
    quality:CARDIO_QUALITIES.includes(quality)?quality:CARDIO_QUALITIES[0],
    engine:CARDIO_ENGINES.includes(engine)?engine:CARDIO_ENGINES[0],
    format:CARDIO_FORMATS.includes(format)?format:CARDIO_FORMATS[0],
    target:Math.max(0,Math.min(14,parseInt(m?.target,10)||0))
  }
}
function cardioData(){
  try{
    const x=JSON.parse(localStorage.getItem(cardioKey())||'null');
    if(!x||typeof x!=='object')return defaultCardio();
    const d={...defaultCardio(),...x,weeks:x.weeks||{},sessions:Array.isArray(x.sessions)?x.sessions:defaultCardio().sessions};
    if(!Array.isArray(d.modalities)||!d.modalities.length)d.modalities=[cardioNormalizeModality({id:'cardio_default',type:x.type,target:Number.isFinite(+x.target)?Math.max(0,+x.target):2},0)];
    d.modalities=d.modalities.map(cardioNormalizeModality);
    Object.keys(d.weeks||{}).forEach(k=>{
      const w=d.weeks[k];
      if(Array.isArray(w)){
        const first=d.modalities[0].id,days={};
        w.filter(x=>x&&x.done).forEach(x=>{const day=Math.max(1,Math.min(7,+x.day||1));days[day]=(days[day]||0)+1});
        d.weeks[k]={[first]:days};
      }
    });
    if(!d.sessions.some(s=>s?.id==='cardio_benchmark_run_20260909'))d.sessions.unshift(defaultCardio().sessions[0]);
    return d
  }catch(_){return defaultCardio()}
}
function saveCardio(data){localStorage.setItem(cardioKey(),JSON.stringify(data))}
function cardioWeek(){const d=cardioData(),k=String(state.week);if(!d.weeks[k]||Array.isArray(d.weeks[k]))d.weeks[k]={};return {data:d,week:d.weeks[k]}}
function cardioModalityTotal(modalityId){const {week}=cardioWeek(),days=week[modalityId]||{};return Object.values(days).reduce((a,n)=>a+(+n||0),0)}
function cardioTotalDone(){const d=cardioData();return d.modalities.reduce((a,m)=>a+cardioModalityTotal(m.id),0)}
function cardioTotalTarget(){const d=cardioData();return d.modalities.reduce((a,m)=>a+(+m.target||0),0)}
function cardioQualityOptions(selected){return CARDIO_QUALITIES.map(x=>`<option ${x===selected?'selected':''}>${esc(x)}</option>`).join('')}
function cardioEngineOptions(selected){return CARDIO_ENGINES.map(x=>`<option ${x===selected?'selected':''}>${esc(x)}</option>`).join('')}
function cardioFormatOptions(selected){return CARDIO_FORMATS.map(x=>`<option ${x===selected?'selected':''}>${esc(x)}</option>`).join('')}
function cardioTypeOptions(selected){return cardioEngineOptions(selected)}
function cardioIntensityOptions(selected){return cardioQualityOptions(selected)}
function cardioBaseRunSessions(){
  return cardioData().sessions.filter(s=>s.quality==='🟢 Base aérobie'&&s.engine==='Run').sort((a,b)=>String(a.date||'').localeCompare(String(b.date||'')));
}
function paceToSeconds(p){
  const m=String(p||'').trim().match(/^(\d{1,2}):([0-5]\d)$/);
  return m?(+m[1]*60 + +m[2]):null
}
function cardioComparable(a,b){return Math.abs((+a.avgHr||0)-(+b.avgHr||0))<=5 && Math.abs((+a.rpe||0)-(+b.rpe||0))<=1}
function cardioSaveBaseRunSession(payload){
  const d=cardioData();
  d.sessions=Array.isArray(d.sessions)?d.sessions:[];
  d.sessions.push({
    id:'cardio_'+Date.now()+'_'+Math.random().toString(36).slice(2,6),
    date:payload.date,
    quality:'🟢 Base aérobie',
    engine:'Run',
    format:'Continu',
    duration:Math.max(1,+payload.duration||0),
    distanceKm:Math.max(0,+payload.distanceKm||0),
    pace:String(payload.pace||'').trim(),
    avgHr:Math.max(1,+payload.avgHr||0),
    rpe:Math.max(1,Math.min(10,+payload.rpe||0))
  });
  saveCardio(d);
}

const JOURNAL_LIBRARY={"Cou": ["Extensions du cou", "Flexions du cou", "Flexions latérales du cou"], "Trapèzes supérieurs": ["Shrug haltères debout", "Shrug haltères assis", "Shrug barre", "Shrug haltères buste incliné", "Élévations en Y", "Farmer carry", "Tirage menton barre", "Rowing barre buste penché"], "Deltoïde antérieur": ["Développé militaire haltères assis", "Développé militaire haltères debout", "Développé militaire barre", "Développé Arnold assis", "Développé Arnold debout", "Élévations frontales haltères"], "Deltoïde latéral": ["Élévations latérales assises", "Élévations latérales debout"], "Deltoïde postérieur": ["Oiseau buste penché"], "Biceps": ["Curl haltères", "Curl barre", "Curl incliné", "Curl pupitre", "Curl marteau", "Traction supination"], "Triceps": ["Barre au front", "Extension haltères au front", "Dips", "Kickback", "Pompes diamant"], "Pectoraux": ["Développé couché haltères", "Développé couché barre", "Développé incliné haltères", "Développé incliné barre", "Développé décliné haltères", "Développé décliné barre", "Écarté couché haltères", "Écarté incliné haltères", "Écarté décliné haltères", "Pompes", "Pompes pieds surélevés", "Landmine Chest Press"], "Abdominaux": ["Crunch lesté", "Ab Wheel", "Relevé de jambes suspendu", "Relevé de genoux suspendu", "Flexion latérale des obliques", "Rotation oblique Landmine"], "Dos": ["Rowing barre buste penché", "Rowing haltère buste penché", "Rowing haltères banc incliné", "Tirage bûcheron", "Traction pronation", "Traction prise neutre", "Rowing Landmine"], "Quadriceps": ["Leg extension", "Back squat", "Front squat", "Squat sumo haltère/kettlebell", "Fentes avant", "Air squat", "Fentes arrière"], "Ischios": ["Leg curl assis", "Leg curl allongé avec haltère", "Soulevé de terre jambes tendues barre", "Soulevé de terre jambes tendues haltères"], "Fessiers": ["Hip thrust", "Fentes arrière", "Soulevé de terre jambes semi-tendues"], "Mollets": ["Extensions des mollets debout à la barre", "Extensions des mollets debout avec haltères", "Extension unilatérale des mollets avec haltère", "Extensions des mollets assis"], "Avant-bras": ["Flexions des avant-bras à la barre", "Flexions des avant-bras avec haltères", "Extensions des avant-bras à la barre", "Extensions des avant-bras avec haltères", "Bobine Andrieux", "Farmer carry"], "Trapèzes moyens": ["Rowing buste penché (coudes écartés)"], "Adducteurs": ["Copenhagen Plank", "Deadlift sumo", "Squat sumo barre", "Squat sumo avec haltères"]};
let journalDraft=null;
const jKey=()=>`forgelabMobileJournal:${currentUser?.id||'guest'}`;
const jDraftKey=()=>`forgelabMobileJournalDrafts:${currentUser?.id||'guest'}`;
const jCloudStampKey=()=>`forgelabMobileJournalCloudStamp:${currentUser?.id||'guest'}`;
const jCloudDirtyKey=()=>`forgelabMobileJournalCloudDirty:${currentUser?.id||'guest'}`;

const jLoad=()=>{try{return JSON.parse(localStorage.getItem(jKey())||'[]')}catch(_){return[]}};
const jDraftLoad=()=>{try{return JSON.parse(localStorage.getItem(jDraftKey())||'[]')}catch(_){return[]}};
const jRawSave=x=>localStorage.setItem(jKey(),JSON.stringify(Array.isArray(x)?x:[]));
const jDraftRawSave=x=>localStorage.setItem(jDraftKey(),JSON.stringify(Array.isArray(x)?x:[]));

let journalCloudTimer=null,journalCloudBusy=false,journalCloudAvailable=true;

function journalCloudMarkDirty(){
  if(currentUser?.id)localStorage.setItem(jCloudDirtyKey(),'1');
}
function journalCloudQueue(){
  if(!currentUser?.id||!journalCloudAvailable)return;
  clearTimeout(journalCloudTimer);
  journalCloudTimer=setTimeout(()=>pushJournalCloud(),450);
}
const jSave=x=>{jRawSave(x);journalCloudMarkDirty();journalCloudQueue()};
const jDraftSave=x=>{jDraftRawSave(x);journalCloudMarkDirty();journalCloudQueue()};

function jMergeById(cloud=[],local=[]){
  const m=new Map();
  [...cloud,...local].forEach(x=>{if(x&&x.id)m.set(x.id,x)});
  return [...m.values()];
}
async function pushJournalCloud(){
  if(!currentUser?.id||journalCloudBusy||!journalCloudAvailable)return;
  journalCloudBusy=true;
  try{
    const now=new Date().toISOString();
    await req('/forgelab_journal_state?on_conflict=user_id',{
      method:'POST',
      headers:{Prefer:'resolution=merge-duplicates,return=minimal'},
      body:JSON.stringify({
        user_id:uid(),
        sessions:jLoad(),
        drafts:jDraftLoad(),
        updated_at:now
      })
    });
    localStorage.setItem(jCloudStampKey(),now);
    localStorage.removeItem(jCloudDirtyKey());
  }catch(e){
    // Si la migration SQL n'est pas encore installée, le Carnet continue
    // à fonctionner localement sans bloquer le reste de ForgeLab.
    console.warn('Synchronisation Carnet indisponible',e);
    if(String(e?.message||'').includes('forgelab_journal_state'))journalCloudAvailable=false;
  }finally{
    journalCloudBusy=false;
  }
}
async function syncJournalCloud(){
  if(!currentUser?.id||journalCloudBusy||!journalCloudAvailable)return false;
  journalCloudBusy=true;
  try{
    const rows=await req(`/forgelab_journal_state?select=user_id,sessions,drafts,updated_at&user_id=eq.${encodeURIComponent(uid())}&limit=1`);
    const row=rows?.[0]||null;
    const localSessions=jLoad(),localDrafts=jDraftLoad();
    const dirty=localStorage.getItem(jCloudDirtyKey())==='1';
    const stamp=localStorage.getItem(jCloudStampKey());

    if(!row){
      // Première utilisation du cloud : on envoie automatiquement les séances
      // déjà présentes dans Safari / ce contexte.
      if(localSessions.length||localDrafts.length){
        const now=new Date().toISOString();
        await req('/forgelab_journal_state?on_conflict=user_id',{
          method:'POST',
          headers:{Prefer:'resolution=merge-duplicates,return=minimal'},
          body:JSON.stringify({user_id:uid(),sessions:localSessions,drafts:localDrafts,updated_at:now})
        });
        localStorage.setItem(jCloudStampKey(),now);
        localStorage.removeItem(jCloudDirtyKey());
      }
      return true;
    }

    const cloudSessions=Array.isArray(row.sessions)?row.sessions:[];
    const cloudDrafts=Array.isArray(row.drafts)?row.drafts:[];

    if(!stamp){
      // Migration depuis l'ancien stockage local : union sans perte.
      const mergedSessions=jMergeById(cloudSessions,localSessions);
      const mergedDrafts=jMergeById(cloudDrafts,localDrafts);
      jRawSave(mergedSessions);
      jDraftRawSave(mergedDrafts);
      const now=new Date().toISOString();
      await req('/forgelab_journal_state?on_conflict=user_id',{
        method:'POST',
        headers:{Prefer:'resolution=merge-duplicates,return=minimal'},
        body:JSON.stringify({user_id:uid(),sessions:mergedSessions,drafts:mergedDrafts,updated_at:now})
      });
      localStorage.setItem(jCloudStampKey(),now);
      localStorage.removeItem(jCloudDirtyKey());
      return true;
    }

    if(dirty){
      // Modifications locales en attente : elles restent prioritaires.
      const now=new Date().toISOString();
      await req('/forgelab_journal_state?on_conflict=user_id',{
        method:'POST',
        headers:{Prefer:'resolution=merge-duplicates,return=minimal'},
        body:JSON.stringify({user_id:uid(),sessions:localSessions,drafts:localDrafts,updated_at:now})
      });
      localStorage.setItem(jCloudStampKey(),now);
      localStorage.removeItem(jCloudDirtyKey());
      return true;
    }

    // Aucun changement local : Supabase devient la référence et alimente
    // Safari comme la PWA écran d'accueil.
    const cloudTime=Date.parse(row.updated_at||0)||0;
    const localTime=Date.parse(stamp||0)||0;
    if(cloudTime>=localTime){
      jRawSave(cloudSessions);
      jDraftRawSave(cloudDrafts);
      localStorage.setItem(jCloudStampKey(),row.updated_at||new Date().toISOString());
    }
    return true;
  }catch(e){
    console.warn('Synchronisation Carnet indisponible',e);
    if(String(e?.message||'').includes('forgelab_journal_state'))journalCloudAvailable=false;
    return false;
  }finally{
    journalCloudBusy=false;
  }
}

function jCalendarDateForDay(day,week=state.week){
  // Date strictement rattachée au programme actif et à sa propre S1.
  const start=forgeActiveProgramStartDate();
  start.setDate(start.getDate()+(Math.max(1,+week||1)-1)*7+(Math.max(1,+day||1)-1));
  const p=n=>String(n).padStart(2,'0');
  return `${start.getFullYear()}-${p(start.getMonth()+1)}-${p(start.getDate())}`;
}
function jActiveProgramForWeek(week){
  const uidKey=currentUser?.id||'guest';
  let fp=null;try{fp=JSON.parse(localStorage.getItem(`forgelabFullProgram:${uidKey}:active`)||'null')}catch(_){}
  const blocks=Array.isArray(fp?.blocks)?fp.blocks:[];
  const block=blocks.find(b=>+week>=+(b.from||1)&&+week<=+(b.to||0))||blocks.find(b=>!b.deload)||blocks[0]||null;
  let data=blankProgramming();
  if(block){
    const pre=`forgelabProgramBlock:${uidKey}:active:${block.id}:phase:active:`;
    const candidates=[];
    for(let i=0;i<localStorage.length;i++){
      const k=localStorage.key(i);if(k&&k.startsWith(pre))candidates.push(k);
    }
    // Les blocs ForgeLab utilisent actuellement une trame journalière commune à leurs semaines.
    for(const k of candidates.sort()){
      try{const x=programmingDataFromKey(k);if(DAYS.some(d=>(x[d]||[]).length)){data=x;break}}catch(_){}
    }
  }
  // Compatibilité avec les programmes actifs antérieurs au multi-blocs.
  if(!DAYS.some(d=>(data[d]||[]).length)){
    const meta=programmingMeta('active'),phase=phaseRanges(meta).find(q=>+week>=q.from&&+week<=q.to)||phaseRanges(meta)[0];
    if(phase)data=programmingDataFromKey(phaseProgrammingKey(phaseId(phase),'active'));
  }
  return {programName:fp?.name||state.blockName||'Programme ForgeLab',blockName:block?.name||state.blockName||'Bloc actif',block,data};
}
function jProgrammedMuscleForDay(week,day,muscleKey){
  const ctx=jActiveProgramForWeek(week),dayName=DAYS[Math.max(1,+day||1)-1];
  const row=(ctx.data?.[dayName]||[]).find(x=>x.muscle_key===muscleKey);
  return {ctx,row};
}
function jMuscleLabel(key){
  return state.priorities.find(p=>p.muscle_key===key)?.muscle_name || key;
}
function jDraftId(week,day){return `auto_${state.block||'main'}_S${week}_J${day}`}


function jMuscleKeyFromSessionExercise(e){
  if(e?.muscleKey)return e.muscleKey;
  const byName=state.priorities.find(p=>String(p.muscle_name||'').trim().toLocaleLowerCase('fr')===String(e?.muscle||'').trim().toLocaleLowerCase('fr'));
  return byName?.muscle_key||null;
}
function jFilledSetCount(e){
  return (e?.sets||[]).filter(s=>(+s.reps||0)>0 || (+s.kg||0)>0).length;
}
function jSeriesRequirementsFromHistory(){
  const required=new Map();
  const sessions=jLoad().filter(s=>s?.draftId && /^auto_.+_S\d+_J\d+$/.test(s.draftId));

  sessions.forEach(s=>{
    const m=String(s.draftId).match(/^auto_(.+)_S(\d+)_J(\d+)$/);
    if(!m)return;
    const block=m[1]||'main',week=+m[2],day=+m[3];
    if(block!==(state.block||'main') && block!=='main')return;

    (s.exercises||[]).forEach(e=>{
      const muscleKey=jMuscleKeyFromSessionExercise(e);
      if(!muscleKey)return;
      const count=jFilledSetCount(e);
      if(count<=0)return;
      const k=`${week}|${muscleKey}|${day}`;
      required.set(k,(required.get(k)||0)+count);
    });
  });
  return required;
}
async function repairSeriesFromCarnet(cloudRows){
  // v1.21.9 : fonction conservée uniquement pour compatibilité interne.
  // Le Carnet n'est plus autorisé à restaurer ou modifier Séries.
  return Array.isArray(cloudRows)?cloudRows:[];
}

function jSeriesBaselineForDraft(id){
  const sessions=jLoad()
    .filter(s=>s.draftId===id)
    .sort((a,b)=>String(b.validatedAt||b.updatedAt||b.createdAt||b.date||'').localeCompare(String(a.validatedAt||a.updatedAt||a.createdAt||a.date||'')));
  const last=sessions[0];
  if(!last)return new Map();

  // Les nouvelles validations mémorisent le cumul exact de l'onglet Séries.
  if(last.seriesSnapshot&&typeof last.seriesSnapshot==='object'){
    return new Map(Object.entries(last.seriesSnapshot).map(([k,v])=>[k,Math.max(0,+v||0)]));
  }

  // Compatibilité immédiate avec les séances déjà validées avant v1.21.9 :
  // le nombre de lignes du brouillon validé sert de référence.
  const out=new Map();
  (last.exercises||[]).forEach(e=>{
    const key=e.muscleKey||e.muscle;
    if(key)out.set(key,(out.get(key)||0)+(e.sets||[]).length);
  });
  return out;
}

function syncJournalDraftFromSeries(week,day){
  // Isolation forte : un brouillon = bloc actif + semaine + jour.
  // Aucune lecture d'une autre semaine n'entre dans le calcul ci-dessous.
  week=+week; day=+day;
  const id=jDraftId(week,day);
  const baseline=jSeriesBaselineForDraft(id);
  const currentRows=state.series
    .filter(x=>+x.week===week && +x.day===day && (+x.series||0)>0)
    .map(x=>({...x,series:Math.max(0,(+x.series||0)-(baseline.get(x.muscle_key)||0))}))
    .filter(x=>(+x.series||0)>0);
  let drafts=jDraftLoad();
  const idx=drafts.findIndex(x=>x.id===id);

  if(!currentRows.length){
    if(idx>=0){
      const d=drafts[idx];
      const touched=(d.sessionName||'').trim() || (d.notes||'').trim() ||
        (d.exercises||[]).some(e=>(e.sets||[]).some(s=>(+s.kg||0)||(+s.reps||0)));
      if(!touched){drafts.splice(idx,1);jDraftSave(drafts)}
    }
    return;
  }

  const programCtx=jActiveProgramForWeek(week);
  let d=idx>=0?drafts[idx]:{
    id,source:'series',status:'draft',block:state.block||'main',week,day,
    sessionName:`${DAYS[day-1]} · ${programCtx.blockName}`,
    programName:programCtx.programName,blockName:programCtx.blockName,
    date:jCalendarDateForDay(day,week),duration:0,notes:'',createdAt:new Date().toISOString(),exercises:[]
  };
  d.programName=programCtx.programName;d.blockName=programCtx.blockName;
  // La date reste celle de Sx/Jx même si le brouillon est ouvert plusieurs semaines plus tard.
  if(!d.date)d.date=jCalendarDateForDay(day,week);
  d.hiddenMuscles=d.hiddenMuscles&&typeof d.hiddenMuscles==='object'?d.hiddenMuscles:{};

  currentRows.forEach(r=>{
    const hiddenAt=+d.hiddenMuscles[r.muscle_key]||0;
    if(hiddenAt && hiddenAt!==+r.series)delete d.hiddenMuscles[r.muscle_key];
  });

  const previous=Array.isArray(d.exercises)?d.exercises:[];
  const prevByProgramId=new Map(previous.filter(e=>e.programExerciseId).map(e=>[e.programExerciseId,e]));
  const prevByName=new Map(previous.filter(e=>e.name).map(e=>[`${e.muscleKey||e.muscle}|${e.name}`,e]));
  const next=[];

  currentRows
    .filter(r=>!(r.muscle_key in d.hiddenMuscles))
    .sort((a,b)=>(+a.journalEnteredAt||0)-(+b.journalEnteredAt||0))
    .forEach(r=>{
      const key=r.muscle_key,total=Math.max(0,+r.series||0);
      const {row:planned}=jProgrammedMuscleForDay(week,day,key);
      const plan=Array.isArray(planned?.exercises)?planned.exercises.filter(e=>e.name&&+e.sets>0):[];
      let remaining=total;

      if(plan.length){
        plan.forEach((pe,pi)=>{
          if(remaining<=0)return;
          let count=Math.min(remaining,Math.max(0,+pe.sets||0));
          // Si Séries dépasse le volume programmé, l'excédent reste sur le dernier exercice prévu.
          if(pi===plan.length-1)count=remaining;
          if(count<=0)return;
          const old=prevByProgramId.get(pe.id)||prevByName.get(`${key}|${pe.name}`);
          const sets=Array.isArray(old?.sets)?old.sets.map(x=>({...x})):[];
          while(sets.length<count)sets.push({kg:0,reps:0});
          while(sets.length>count && !(+sets.at(-1)?.kg||0) && !(+sets.at(-1)?.reps||0))sets.pop();
          next.push({
            id:old?.id||jId(),programExerciseId:pe.id,muscleKey:key,muscle:jMuscleLabel(key),
            name:pe.name,rest:+pe.rest||90,journalEnteredAt:+r.journalEnteredAt||Date.now(),sets
          });
          remaining-=count;
        });
      }else{
        // Pas d'exercice associé dans Programmation : on garde le comportement manuel de secours.
        const old=previous.find(e=>(e.muscleKey||e.muscle)===key);
        const sets=Array.isArray(old?.sets)?old.sets.map(x=>({...x})):[];
        while(sets.length<total)sets.push({kg:0,reps:0});
        while(sets.length>total && !(+sets.at(-1)?.kg||0) && !(+sets.at(-1)?.reps||0))sets.pop();
        next.push({id:old?.id||jId(),muscleKey:key,muscle:jMuscleLabel(key),name:old?.name||'',journalEnteredAt:+r.journalEnteredAt||Date.now(),sets});
      }
    });

  // Conserve les exercices ajoutés manuellement et déjà renseignés, sans les recopier vers une autre semaine.
  previous.filter(e=>!e.programExerciseId && (e.sets||[]).some(s=>(+s.kg||0)||(+s.reps||0)))
    .forEach(e=>{if(!next.some(n=>n.id===e.id))next.push(e)});

  d.exercises=next;
  d.updatedAt=new Date().toISOString();
  if(idx>=0)drafts[idx]=d;else drafts.push(d);
  jDraftSave(drafts);
}
function jDraftRemove(id){
  jDraftRawSave(jDraftLoad().filter(x=>x.id!==id));
  journalCloudMarkDirty();
  journalCloudQueue();
}
function jDeleteDraft(id){
  const d=jDraftLoad().find(x=>x.id===id);
  const name=(d?.sessionName||'').trim();
  if(!confirm(name?`Supprimer définitivement « ${name} » ?`:'Supprimer définitivement ce brouillon ?'))return;
  jDraftRemove(id);
  if(journalDraft?.id===id)journalDraft=null;
  pushJournalCloud();
  drawJournal();
}

function jDraftToJournal(d){
  return {
    ...JSON.parse(JSON.stringify(d)),
    id:jId(),
    source:'series',
    status:'session',
    draftId:d.id
  };
}

const jId=()=>`j_${Date.now()}_${Math.random().toString(36).slice(2,7)}`;
const jToday=()=>{const d=new Date(),p=n=>String(n).padStart(2,'0');return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}`};
const jSetTonnage=x=>((+x?.kg||0)*(+x?.reps||0))+(Array.isArray(x?.drops)?x.drops.reduce((n,d)=>n+(+d.kg||0)*(+d.reps||0),0):0);
const jTon=s=>(s.exercises||[]).reduce((a,e)=>a+(e.sets||[]).reduce((b,x)=>b+jSetTonnage(x),0),0);
const jSets=s=>(s.exercises||[]).reduce((a,e)=>a+(e.sets||[]).filter(x=>(+x.kg||0)||(+x.reps||0)).length,0);
const jDate=x=>x?x.split('-').reverse().join('/'):'—';
const jFmt=n=>new Intl.NumberFormat('fr-FR',{maximumFractionDigits:1}).format(+n||0);
function jSetLabel(x){const base=`${jFmt(x?.kg)} kg × ${+x?.reps||0}`;const drops=(x?.drops||[]).map(d=>`${jFmt(d.kg)} kg × ${+d.reps||0}`).join(' → ');return drops?`${base} → ${drops}`:base}
function jPrev(s){
 const all=jLoad().filter(x=>x.id!==s.id);
 const sessionName=(s.sessionName||'').trim().toLocaleLowerCase('fr');
 if(sessionName){
  return all.filter(x=>(x.sessionName||'').trim().toLocaleLowerCase('fr')===sessionName).sort((a,b)=>(b.date||'').localeCompare(a.date||''))[0]||null;
 }
 // Compatibilité des anciennes séances sans nom : comparaison par liste d'exercices.
 const names=(s.exercises||[]).map(e=>e.name).filter(Boolean).sort().join('|');if(!names)return null;
 return all.filter(x=>!(x.sessionName||'').trim()&&(x.exercises||[]).map(e=>e.name).filter(Boolean).sort().join('|')===names).sort((a,b)=>(b.date||'').localeCompare(a.date||''))[0]||null
}
function jMuscles(sel=''){return Object.keys(JOURNAL_LIBRARY).map(x=>`<option ${x===sel?'selected':''}>${esc(x)}</option>`).join('')}
function jExercises(m,sel=''){const opts=[...new Set([...exerciseOptionsFor(m),...(sel?[sel]:[])])];return `<option value="" ${!sel?'selected':''}>Choisir un exercice…</option>`+opts.map(x=>`<option ${x===sel?'selected':''}>${esc(x)}</option>`).join('')}
function jHistoryTime(s){
 const stamp=s?.validatedAt||s?.updatedAt||s?.createdAt||'';
 const parsed=Date.parse(stamp);
 return Number.isFinite(parsed)?parsed:0;
}
function jHistorySort(a,b){
 const byDate=String(b?.date||'').localeCompare(String(a?.date||''));
 if(byDate)return byDate;
 // Même journée : séance la plus récente en premier.
 return jHistoryTime(b)-jHistoryTime(a);
}
function jExportPdf(sessions,from='',to=''){
 const rows=[...(sessions||[])].sort((a,b)=>String(a.date||'').localeCompare(String(b.date||''))||jHistoryTime(a)-jHistoryTime(b));
 if(!rows.length){alert('Aucune séance à exporter.');return}
 const first=from||rows[0]?.date||'',last=to||rows.at(-1)?.date||'';
 const totalSets=rows.reduce((n,s)=>n+jSets(s),0),totalMin=rows.reduce((n,s)=>n+(+s.duration||0),0),totalTon=rows.reduce((n,s)=>n+jTon(s),0);
 const detail=rows.map(s=>`<section class="session"><div class="sessionHead"><div><small>${jDate(s.date)}</small><h2>${esc(s.sessionName||'Séance sans nom')}</h2></div><div class="sessionStats"><b>${s.duration||0}<i>min</i></b><b>${jSets(s)}<i>séries</i></b><b>${jFmt(jTon(s))}<i>kg</i></b></div></div>${(s.exercises||[]).map(e=>`<div class="exercise"><strong>${esc(e.muscle||'')} · ${esc(e.name||'Exercice')}</strong><span>${(e.sets||[]).map(jSetLabel).join(' · ')}</span></div>`).join('')}${s.notes?`<div class="notes"><b>Observations</b>${esc(s.notes)}</div>`:''}</section>`).join('');
 const html=`<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>ForgeLab · Carnet</title><style>@page{size:A4;margin:16mm 12mm 12mm}*{box-sizing:border-box}body{margin:0;background:#0d0b08;color:#eee4d2;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif}main{max-width:900px;margin:auto;padding:32px 28px 28px}.brand{text-align:center;border-bottom:1px solid #8c6a35;padding-top:10px;padding-bottom:18px;margin-bottom:20px}.laurel{display:block;width:88px;height:auto;margin:4px auto 9px;filter:drop-shadow(0 3px 10px rgba(217,182,111,.16))}.brand h1{margin:3px 0 0;font:700 27px Georgia,serif;letter-spacing:.16em;color:#f1d59b}.brand p{margin:5px 0 0;font-size:9px;letter-spacing:.2em;color:#a98a57}.period{text-align:center;color:#bda779;font-size:12px;margin-top:10px}.summary{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:18px 0}.summary div,.session{border:1px solid #5b472b;background:#17120c;border-radius:12px}.summary div{text-align:center;padding:12px 6px}.summary b{display:block;color:#edcf91;font-size:20px}.summary small{font-size:8px;text-transform:uppercase;color:#968b79}.session{padding:14px;margin:0 0 12px;break-inside:avoid}.sessionHead{display:flex;justify-content:space-between;gap:14px;align-items:center}.sessionHead small{color:#b99050}.session h2{margin:3px 0 8px;font:700 18px Georgia,serif}.sessionStats{display:flex;gap:12px;text-align:center}.sessionStats b{color:#e5c37f}.sessionStats i{display:block;color:#8f8678;font:8px sans-serif;text-transform:uppercase}.exercise{display:flex;justify-content:space-between;gap:15px;padding:8px 0;border-top:1px solid #2f281e;font-size:10px}.exercise span{text-align:right;color:#c9b58d}.notes{margin-top:8px;padding:9px;background:#100d09;border-left:2px solid #a87d3f;font-size:10px;white-space:pre-wrap}.notes b{display:block;color:#d8b775;margin-bottom:3px}.foot{text-align:center;color:#8d7752;font-size:9px;letter-spacing:.16em;margin-top:20px}@media print{body{background:#0d0b08!important;-webkit-print-color-adjust:exact;print-color-adjust:exact}main{padding:0}.session{break-inside:avoid}}</style></head><body><main><header class="brand"><img class="laurel" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAATAAAAEJCAYAAAATjnuWAAEAAElEQVR4nHS9d9xlN3E3/pV0zrnl6dubt9q767o27hU3TDe9t5BgSF4wIaGEJA7J+wskJEAILSGYhARD6NVUg8G9d3u93vX2+vR6y2mSfn9II+nc9Xv9WT+3nKMjzYxmvjMajViSJAAAMAYGgDEGDQ1oBq01uPkSWmvzm9ZgTENrBsYYAA2AAYD5zVxuvtUMYBpKa4ABDMxeaX9nDNAa2nQA0NrdCw3XPv3un+caOP759jk6+J6u19BBDwDNbH/tpYwJ1y+tJBjniATD3HwLm1b3v+vP33X1jb+5azd+8rvtrFZLLK2CcWiAmw5Aa/NPcECDAVr5cdr/M0ZjgqGRo6EGGINUfjy9L+IF7LMBbcfPg9/pZ+2eU3kRTxFeQ39t+wEBNfEIAOPc0hSAVuaZnFOzbryMM3CYvgSctAymbtjnOr4EsqABxjgYAKUlNADOeI88MmitKnx3dFX2me5Znia9tPTP83KmlO2nNs8lAefc0kfByTjTtl0GJ2n0HMaod2FHYOnN0emkeN7p6555+0vP3vL9n92Pu546zBYPD6EsJUqlwIRwNFFK23a1k2vPv+pcDfln+lzlv2kQAAdoLvm2lB0DC6YSq8iKGx+4pT0RmJmmtQJzNIXTJVoDnMPNG9Bc0BqWZeaRjOa2ct8RDRlj4NwKHaMfjaSBMfMAGq9jOgON1nWE3rPgO2YbJcFwekf7DuhAedFk9L+zoK1A6WhmCUq/V5WX1ixQFJ7AGjRZNTSDFyVtJ4zVZMT4OEnAGDA338KLLt2ov/m1d9746mtPhi5SaK0hBHf9Z1ZbEY1CIXGTnpFi145W1G8A8Hxg0HbCc+avYW68XoETw0mAOLi7htS3G792es60Z+lK13uB7xV8uO/dwByfiIcautI/Q2MAgLKKi3khps+GFjAK2/EJVqiDsTo+MpK84/pHijvkg+0qwHQwzmDSMeZoQLLllJcOhgs/fxkzfDE89MbK8C24xinT0Nh4e0OTneQS0ECR48oXnon//NIf4vIzlump2TnEUYQ4igODXlXGGl7pevYEPNREE/+7k1G6LlQkbsREbe6+0zqkFckxt8rL36uVpzPNXZLJkC/uu5CXltqsRw5YQLtQl/BwMqlAaEIEQ+/D7wg9HK/p/SR1CAE8mGyEw0KtTsIUKCsWcApOHYX0NW0yVIhHE8XdWrGq1GSASNw4uLOS9VqCoijRbnXwvj+4WP/bP7wK529bjv27DmDfoYlbwnECxvp6cfQ0FCLsB3eWqcKuHhpUvqhMfD8ZjqNBOHy63nK6d9ykpBUhoOCRVUNB6I8+E0uC9ph9hlMsXi4IBTEGaBUo0KA9NymPGzddFPTH8f746xhjDsFW0ZQ1Dp5YjnCebjqQ5YCm7jGOq5XfQvk/To4JqVV7CaW8zAAMSpvJTp/HZ1oX7Nt/FJvPW4UvffyVePVlJ+rJ2VmIiCNJBAhFUb+cYg+H5xSW7zspaj/3/GwOBm0Umn/rFGQoY9QWI7cl+J6MHylLZ/iYl6yqJ+D5obWGUqoqCowmt9Eh4S3mOm0UWGjtvAUKlJl9zxmvfE+/2TfQTngded1v3oLo4PsA0pJV4h559D7DuR6uz/DtBySpKFQHHqrf6eptri+1eoxWuwOmMnz8L16pP/kXL8fieoH82DHMTrbQSdXNxKjef0rRyLRlsJ1AnNtOMMcgFYwhREGCM0QRRxILJHECwYx1U0FfHZLs5ZF5mrvu+EntBctPcO9CIviOJoeGBmfMusZVBedcCWfEbH+0rlyvHerxfSXF4XlLk82P0TIz4B2hgOpEIERJiJyFvHXj9S4dod1eJAdUFW3EBeq1BPUkQS2JEUc8UBLeUDtaO1qYecAZ924lya3S9NahHqVMnybn0tmjB8ehjhzDprWD+OLfvRLXveJ0PTMzA6UU6knkFV4FiVTliGjlee/l381jq6GqtPIG73h+ObGw13gsHFKxwlNLLAZm/cVqu5UXgRFNYSirTDk7bk4zEO00IhcrAatMdG61XyhU+rgBPsfAAWOByGJpA+8VCZdtS+nA8oGe490Yp6wQPib0vQNUQQTQBuiElsDRnSwsKTSl3ASjyVxPapiemcfa5YMrbvjQ6479wStPQzl3DFOT8zjhhBHMtTLMd7Ivggkio0UJVbcx8GbAWXWy0bWEZrkQiCKByAQEIKVEXkp0ujlkmUNEMZIk7kG5Rih0MMF5YD29kmIOM/daURDNEaDE8DptFA+5pXS9trIR0tdNBPQIMEx4BfYZxxlJeOEkOaj2IXDRuVEeSlUFOVS+5A4yzgHLX4c36BrH8xDd2T5wFrQq0E1TlLIEwBDHEWq1BEkcIYoEtNYopUJZKpRSenlkXnYZyJX2SEQrFRDb9k1piChCmmbYPzoNXjLMTrUwPDiAf/7oy7BqWb/+3E33szRuoFaL0e3kMOiXOm95ZYgFH48iEfco0c/f5zACjAU09fMilAlnlCq6AJXXcbIWKnH3ezV8Qe1TeKEKeDzBAtEAAESA0XK6gpICjR38jyx/gIJdhyjw6mAoESFUJrrSoP9j5SYU8F5hJ8EMlZgTcHs9BYu93+NBg+9Pj3Wx39dqNUzPzOHkdUs//8mPv/P6a6/ejPTIXsy3Oqj3NcEQYXy8g/l2ARYlti3ew2zAKVcwMyEqk9WMgTODypQCsrJEq50CqnBsioTAikXNgaWLl/5mcqb7otHphdk4igOLT8rYs7ZXefgfCNkQ7WjCM3DO/T09ygEAmGbOsKgeWjvBBCkGXrWUgRLT4ff2vUNBjpVExBDo2Xs475EH304oL84IKm37w6C0AlgY/ICjgxU6P0U0wJkGwFHkBRaPNPkZm5fIvNPGgSNz107Md2+ebpEC4oiT2Ci1WgytFLTWkFJBMztHwPx7DWgoPyZUeSUigSIHDhyaQqurUe8fxMTEDJYtG8Jf/p8rMTjQ0J+88XY239Hoq8XoZhkohkhCrwFwzWxMi4bEwoFX+K2dQvLGroIHAiXmDbYHNcQzr390RQZCGakaOP8gFj6oItc+pgggnNIu5gwAUYB8/Q0h8UHhyWq8y8kRWbSK8vIISWnfSRI+WtgJn+mCfa7ZIGBIA638DYSe7g8YR6OuaHgErhjzJKolNczMzOO0zasv/szH/+D6ay7biHT0ILpZDh7XwBmDKhhGp7pIS42kzgNrSySzWMPxWrtfGOeIOIfgEYpSYqHVhVIlACCOI2xdt+TMk09a+eiGdUtwwvIhLBuOsGbFEKJGHz7y99+fOTw2w+q1BFKSRSLk5IUqFExo67Y6S4IK/UlgSbjI7aPvFEyMwyBIv9LqqBhYhedaIfX8AxizSCTo73FK1jHL8pdpaIUAHVo5oNVKN1ZW6Xd1rgYThOQsGINS1C+vzGguRYKhUxbYsmGl/JfP/jlqbAFjB8d+OjXZwoGj0zh0ZAq7nx3Hjr0TH991dPpvCFXFSYJGvQYhGMpSQkpCrIDWCmZlNpR0zw/BDaofm2hhYraL1cvqaC0kmJ7pYGBA4k/efhFqtVh//N9+PzzZkXPNWoIszewcMmNVRAPdM16rqDSs5wM/VaqAIOiSx8OwEdNw0lt6VY2Su94pIQ03YicrVrYcWwMlyGBd5Cr68ohd2W56YBARYqCZF1onM0e1ExwnM6pqjf0DSXkRJRgA5ZBPaLGJXuhpxxPDCDwF9oKxeqtJ4wruC4FJ6Peb21n1OgYkUYzZuQVsWb/09M/843V3XXPReswfPYC8LBAlDahuF0k9QburMDbTBQDr7qnKs0CG2UqPhonLxEmCSHDkRYmZmXlAK6xZvmj49FPXzpyxeTW2bV2BDWuXYPXKAQwlHLFOwVgXSZLgltt3Y+e+cVav14Klczu2HiXkLCeCtIhAuXiUcrwScZbYGi4e0hBEb4AI3st3srqVKUlWtMIf+GsDher5zJzRsT+48Zjn+liP7w2c++efaSecC3Uxt3II13dN3n8P0gCUUmjUa9ixd5xNHjisL3/xNpy0vA6U5uJOXmJ6NsWRsbkbdu8du+HxJw/j4ScO4tGdo2xmfgHgHIP9TSRJhKIooWQBaAltES0ChUk0Nu6rwNRM55aJ6fY169f0AxAQUYTZmRTNAeCdrz4HkZazN/zb7Wy6naGvEaHIc89D4r2y7jDJIeNuzBWeB3LhdELAO+9Chug6XF2tXg+nR0Ba28igkzuSHwN4nH11v5NMW1nnhne97qdfDeWIOLMwm8Q9UBbhiocHO8GSrNOq4SIAnBWoEsgjpQAQ9Wj1qjKk9949I2Fjtv1AILSdxDxYGg8RUo9yAzTiKEa708WaFcOLPvUP73zimktOwPyRg8hLDYgEeVlAMiCuxZicncXEbApAgEcCWgKMKYO8yDWDT6kRIkIUxcizHDOdDgb7GrjqkpP1VZechrNPWY2NJwxhcZ9AI9ZQqkRRtNCZ6aDdbSOKgemZEp/44i2YnMvQN9AHVcqANl4x+wkRvrySYYFkOv5qR0hnHT3B7R9NVtMoemcPA75W+As4FA7qoVYBEoNF5PRcEkpyJe19ZIFJIpyb0mMsA8UYonJCZNbW21hr5RGVe54LQCqlEMcCE1Mt/NXf/zd+sOHDWFQv0E0XAK0guMKygRhrFg/i/JNH8Oqrt+DIRIad+2f0A4/sxW/u2oEHtx9ipVSoNxqII4Gy0ICdZwR1aPSa3CcRYbadvXVsuj3OkhqYiKHBIOIY7fkOdL2LN197Moqi0H/773ex+UwhERxlKS0Z/Zj8WMP0DkMXFdDIm/bqnAP8XOv1uphmwcIMAh4HsU7tjam5x/4vMBSV2Br8W+bkjdkZrip8J4AFABEYwMGhKPHQwXEKTJMoILDEtjOae4VnH28GwivoKAza+UUDe4dDa5aUymjeXvki5en6xIIJE1hsQpCBt2QZytwqoYaCiBLkRYG+Wox/+Os3T73s8i1YOHYERVEiSmIUeQGtAckYBI8xPZtiar4LsAiccUiUTpGSEtFKg3NjNbOiQKvdwZLhQbzqRVfoF129DeedvASrlzahVYqiu4Buq42ZdhdlWUJLBaUVopghivpxx4O7cd/OWdbsa0IqiV7k4zjJAChSNtUUgnDBA4BNPrVBf+7b0kFzzrqSBXeohay5TU6EXZnUAYRhNp2B2nf89f0xMSqLyoVHgwxhn7lXln6+V16hMg3bJ+RLffVGK1Tqwa0BRPQoFShLhcGhJu59cpT97Gd36T+87oWoz+TotlpI0wytmXkwDoiIo97XwLoVfThx7RpcfdFavPHas/D7+/boH/3qMfzuvl0sBVCv1cCFQKlKAw6YnyvWa4aIBRba6cTkdAtABCYSI61lAcE52q02VKnx5hdvQauV6v/71ftZgQicC4c6mRtHMG8oyTcw6n7Bw8+yKpmJb36K+cUST7dw+oV0dF6S1aYVDB/wlXRRAJXcPUxrm+4TKBlWjY1FWtE88LGO0KiHS/HhY45bzbAdoqAp6Httrbx9kFOBFe1LxFIu9UcriwCp727UAYmdDx6iCG/x3fdkmc2IIDiHVgpZVuBvb3ijfsPLnofWxFEUhUScxCjLAlASXPjUhtGpBUzNpZ9mkQBjhLhszg80tFYQIgYY0G63IRjH21/1fP3G116Gs05ZgWVDHHlrBgszo2h3OpCygJIlZFFAKwXOOQQHms0aRie6+N9fbk8hBLjgUKUKdLxHRs4wOIVNY6QYVhDf6EG1x60iBgi51/gocikCO+2Rt2en1saoMDCXfa162nfIz8ocWTNanCMrrpRBJkyT0jx+BTxE6mQgSRzg0BdzSDC41MlTdVGAyEttCdTrNXz6a7fc8Pwrz/r45tVNlHkKEcdgvAslC0hVotPqotvOEQmBerOJk9f3YfPa5+Hqi0/Eb+/aob/+gwdw/1NHGJhArR5BSRPMF8zkDDGLTCIRoZt2MD3bAXSEOE6gtUSZmbFwLtBe6KJRV3jry0/FselUf/57j7MkiaueDo2BQAChrdCQeULZ67UTE2+TPG04Z263QXX1MVwZrLqFzBo1TUFvANruzuGEzlzfQjTHfKDeygAQgBv4PDtOsJsUidfK8AoteEDo73pr7+nBjLQF1ju04qHW1sf9Y+TS0CO0DzAHkucgqtYG7tNEChdcw3tpPvoVM4FuN8U73nC5/pO3X4aiPY6s20EcCygpocoSJpCsITiDAHDk2BxmFtK/iCKbQuGSFQ1TkzhGludIu11cfu4p+qZ/+4D+1N+9Di++eCWGojlMHjmA8YlJpFkOBg0lS+RpF0WeQckSSpaIIqCQEX522048vnu60eyrQ2nDJA6zqsZ7AlReWXt0GsYgQ5RVQW+O7Z6vWin4lU57JfNKJUR2zCEIFsSfzOTgggcrhyQDcAJqvvOx0l6E5GWht98erfkvwjchoutBrNr33fU7JCX1lejJGMpSodlXx66D7U/8+42/QZc1Ua/XASkRJxFEJGBShIzpUDxCp5NhcmwCCzNjWL8EeOcrT8G///2r8JF3XKyHG0DWzRAJYVCTFSMwgzjjmCPLJQ4cnkGRlqjVE3CmEUUCSikopcCZQKuTImZdXPeaM/CiC9frPC/c6rYntHkfoiMeuHiGFuH8CmhHSLmH7tTu/2seE47TSnml5JrwytIpr4AvcPJl27APMPDA88wDHutJaG09TGu1Km6HrmpVEkCzimBjCxoBIayddv6fCajCXU9D9C+aGIQmiHjGgjA3sPBfKMHeStAStQLtmwoBG10VRRGyLMe5p66d+ej1L0Ufm0O6MIM4EpBSQsocGso4MRqIhUBeKhw4OodWp1BxFEFqDm1zwRhjSGo1LLS66E8Ebnj/6/V/fvl9eNPLtmAQ05g4tBezk1MoZQnOgFJKdDttZN0OpJQQnCMWHIJrcB5hx7MT+NYvnvo44xEYEwY99MqAoyMpgupgQyr3oiwSBM65tW7wAuto6XlAnlqoWMx7ew8QPN9cK7WyaJpQG7eI1UwWDoYKeGae7+5L7RWp7v2d81AEgkkXfBfKGOfWGHuZc8rbBWsDOmgKQzDIUmF4sB//9cP72B13PgM+MAwem+0zURIjimNESYJSSmTdzOxbjATyPMfU5ATmpidw0soEH3rXxfi3j12rz928eKbbTaEBm09mOqShISIOzRj2HJjC6GQLjf4mwBhEkkAzYVJZbG5eu93FskGNP33jWdi0auBdRVFCCHGc3NNEV+TSVZCOmbvhq2Icer7nrDqZdChj9pmMCEy0JHfO6gZekc6gDTBA0+o+YYNAzwQ6xxhZw29OKItiF1rD7s3VcF6sE1SPuPwyp3Jd8Xd5C+c1ewCklB+QowhpzECJMoe0zJ4stzoC66raO9xGaKWdKxJqf3qu4AJlqSGh8MH3v274pJUNtKbHLXOAsshQ5oVVugwaCnEkMLeQYv+xOWS5BhcMSgNKm0zrei3B3PwCTlqzZOtX//V6/bG/eCU2DnUxuf8ZzE1NmPgWFGRZoNvpoLMwj7IoASaQxDVEUQKlGEQUY3ZB4X9+8hh2H5r/m6RWNxaX6MNDdldfWiuPxBzaDTiodZB86mlCwkZ07g2Oezr2CvlziHnQsLZy5K+ysUcVIGPmc9AqK5Ikh8Hd9M7E7kwczyglbUMWzD/TIkJoIw+0e4T6rGy+FiFDgFWo6pCE1cxKavAoQjvT+Pt//QmOTuRo9g8CWoFDIBIJYi5Qs8nGaTdDN8sNywSHLCSmJ6egshlce/k6fOGvXzT80vPX6jTNIKVGHEfQVqFzrRBFAofH5m/Zd3gGUT2GAkMc11Cv1aFhEsIZZ9Dg6HbbOP3EAfzRq8+4UUoJJbVRYoRqEBp4OGNESi2UA9ohYGhUvdfT3xtOHciMdjzT7powb9BdR5LAaPvlcyA89zyfNdeL1mhtWhu5Zr6zBAkDi8cZpVOQdQqHZJtSHnbSr71LrU6LOrhYFVC3csQsgmLhd9RGGAwM7q/MJ9Ja5Pb4fsVRhDTt4g9fd7m++rKTUbYnAWmC8aXMoWQOpaVx8TQApZAkMY5OtnBgdAESDJyRNROI4gTTM3M455S1x77+73+64/VvPh9ydi+mjx4CmILiGmWZI+t20VmYR7fTglYKURKjVk8QRQJMa/CIo9AxfnH7Htx8514WNxqQ1pBQkJcHyLaCWEJjQopA9/DDuQNeaOFgvPYxtOB+pcyiAmPWheXcJb4yO8NpMYBcCZIXTvtKAwRNSN185RVXpX/a9CVEQOErHJtRcVZGAznwhjZAU/Z5UobtWrc8oKWP25itX/ScIi8wONCPux87wL7wH79CIRpIGjUoBfAoBgOH4By1RgTOgbSTIs1SaC3BmIKIgTxrY3piDKeeOIDPfOQFeNs1W7QqUhRSI4oiGEdJIYkZpmbbrz062YKuxQA4ooij3ldDlCTGN2AMXHCUSoMhx0su3Yirzluj0zwDtyiM9cgLp3Gihy/+Dc1ENx9DHtHcYoxQO5zh8IjJNxeGnkJk7R3NYF478KTcKjS1SXFX6qrTPfY9r2pqO8jQ6oaC5iaPt7IIbSWhqopmDbQrKT/tPpAudfc4JOFGyQN0BtCl3uAbSxBmkSulKzk+0ICIInSzDMsXD/Lr3vEiDEYddNotUI5MkeZQZem3UCkFKI16FOPZ/TM4ONpaywU3yhoaSRTHs9NzOP/UE/R/fe5PVlxw1SloH9iFojUH0YghlUaWZuh2OpifnUe73UXEOeqNut3jGNlkTY04jvHI9lF85QePXtMtGEQUuZU6B7UtfQhJOYHqQUMOTWhKWAyWsgkTkxKiB1g6cQp+Vl5eEAM2m7ZcX4JeBIKvNfGXlItHhpU+275a4P+cyKy3D9TEcUo6QOY+/he4IvAxt+Nia87TgFO0sKixVBLNRhP/dtNt7OZfPIpkaAnimIGVEjyOoTUHU0AtAeKIodvN0e5k0EwBTEJzoxgnp+axbHGMv3//FXjTC07WZZpCKwXBGbTUiHiEqdl0Ye/+KbDS7MoolYSIOJoNs5Jpus3BGUeeZVg6JPCOa8/Con6zsh6RK1mhccBOR1dvfEzKlEXrVBmFVWNmId0d5YhOQTEEQnq9MkM/+NQWX8XCeV2Akx3n7jmGOFUWGEw3ph6hYj5w6wZe+UAdYzZg67+utuQJ6KYbozi/V4yKkVa2hLUDcI91ghreb/6p455GYzDXasbAeIQsy/DO1z9fbt04gLw9BaUZFDhkWUJKCVrAMOBLI44EijzHo08fwZGp7qE4jgEl0YgZWvMzxSkbF3/lc598O06/dD3ae3ZA513oSCDtdtFqtzE3M4/Z6VmUZYF6PUG9HkNwAFJDl4aJcSPB7kOz+Pw3H8SB8fZvmo0alJR22pvsbUdc7WnkLJ6jmacdEarqVnEnxC6Q7trqsdY8QK+Bha4YO6+xKoqmip48f92L7g2QT9VVCVBAj3KG5bV/hiGCCmWXMVDiJYJ+GiTpdyeEHocz3D39IXShGYMsTeC+Kxn+8pM/vv6xxw+iuXgpCq4gVQnGbb0uSNQSjSRiyNIcc3NtZLkxjCziEFGMmdk2RoYjfPS6S/DiC9frdrtl68aZOGiaKezYeRjduQ7qAzWUpUm9SGoJ6rXEPIsxgAlIxaFkjvNPW4KXXbJJ51kGEUVuovh4dDgvCGRY/miDjEIkGsqV5681TLZBg359zS3jQjoSu8d640EcpOfB8cm4lsxVctBOBkg/MYfi/RM0xeV6VI7TpIaBPEgONfEWDVcihwZIv0PbrGIvaKEQhRaQfFp7sSewVV4uj5ZQYUAUABCCIxHCfVbaxsAYc/zRGmDCBO77B5p41cvPw1DURZ6mBt1BQ5Y5tC4hhEFFWmloJdGoJzhweBIPbT+CPIVZ6eEaabeDJQMCf/mBV1x3/tWnobNvL1jRhmYanYUWZqfnMTMxhdb8Ahhj6OuroV6LAKWgSgUtS2hVIIkFDh5bwJe+9TDuf3qcNfoaLhbpCaHdpLWDrCgm75Yz6EDAQo4yut4WtKNJS4F8khK/IumpTG32unMhMmTBe8Mu7oynUj7RlzN6vvmR0LMLMhuxCjpetf7kZpJiCz2DXiVKE9J91oHicwgs7HeY8BmMz0AGQAN5UWCgv4HdR2a/+IG/+z527Z1Bc9kylEoDWoKbNRcoqZDEQKPOIaXC/HwXrXZqClQKjjhJMDE9jxNWNnH9m87ByesGvzK30DX7YzUDILBr/2i6+8AEan11QJamC4yj1myAxzEUubpCIM9LLOrTeNVVJ2HxQA0U0OfcrDQ6byWUCwYIYVZRacO5SefwVxl6cbcHOQQpwbS2tCRDC8dbx5dAjqgjFHMLFaYzhhbAkFwbmfB7Wg2PaBXSdafnxWjAzDUc+qBenv3n4GeE8s7AKkSsGHD6jt675wDQrDJxKAYDAFHEkWc52p2ug2CMNLSHGgCAmHMUWYoXXn6m3rB+Kco8t5tuGaQ01QS4iCBEZOGXEchYcDz4+EHs2D2xmEXC7I4oS3S6Gf7gzZfrV7/pYmSjo5CdDiTjmJudw8T4FGamZlFmJZrNOgYGGogEgyoL6FJBlRKlKlBLBA6NzuHz33gQv773EKs3m2DgbrJX6G0VSjjBvCRY2hAh6QLtV+aqqZtVvOqViDpOSXn2+tXLUKF56+5jo15pMMd3HTYVyELwZWCxmQ1SB6uBgfz59uGRXtAg014edTCRAJsXZa8P+xvGv0LUR0bQGGFDpyIvMTIyhDsfOcDe/7ffwf69s1g0sgh5WaAoTIoMlIaWCpEA+poxIiHQauWYnumg283BudnCNjW7gAvPWo0/ePlZ1zVjIMulKSEoOPYcnGk8tv2IiWkFfRZJDXFSB5iwRl5AgaGQCqdsWozLz16ru90MEbeFBjVDmBkeRJSQFwWM4vI8I0NXoakTqyCdgWgELzcGkQW/Eb17BMooVbOi6vUB88TWFqOx53DpKa/UhgU4oRQPlciKGyjuUEzF7QirA5A2pPIloYBVJZUCyc7Ck9V3z3dXVikHGDfVEoRzDiklGglwyokrvsIgHVr008Raa86glIRSCq97yXlY1CeQprlbzSryHOACca1hu6GgdAnBGeZbKe589ABGpxamkwSIOTDfTnH1Zafr9//xy9FgKbKZCUhoTE/MYmJsCu1WByKK0D84gL7+BoQAZFlCFRJFkUOpFI06w67D0/jMTQ/j5rsPMZ7UEUdhpQ3/qqAEOx5tt3K4eGc4AW2KAQmbW8YG/L7SAJEYEaT9poHy9+Jm79cBrzx/nQV1cuDlIkxRIGTIedCWfSYpIWfktEcNLmAcypBTZMfnkFXf023eXfGxNV55nncnifCovrQvMVVKhZGRIfz6zmfZ+/7qf/HwY4cxMjIMBoU864JZNKKlhmBAsx6h2UygpcbcXAtz8y2AMUipkRU5XvmCM3DV+SfpVqsFzjTqNY6Z+Q4efHwfilYKEdegZGl5x5DUG+BCQFFdL8aRlRIDfTGuPH8dIi7tfkju6nCZdDPzmVtElXCJvNsJ5ptXIBy+SjCsXFVlQ9scTPOeat7R+nFvOJXSdchgOqGsoGMjWOROhgtP0NzygNCcaYGTcHKY7Q3OoDnZI0UDB/nMmHomWmCd7Zid0IWW2qq3ivbtdRXo2QomGM85t9qXJg2QpTk+93dv03/5npdexwVtb6HHeNQouEA37WDDuuUnnHXmOgiZIc8lGI+gpVFsSdIEj0zg3Ty3RL0msOfQJB5+ZiwtSoV6zJB2u1i+ZIi/990vw+oNi9A6eBR5JjExOoWJ8WnIEujrH8TwoiE0+hOAaVOVoCyR5jkUKyBi4J4nj+GT//UgfnnvIRbFDURxbFa0emmmQ7ro6m8gWnDjIj4XegocISsrCHY4e+FyTGDPGU+kbHimw5Usn5LgYnIIhVT7/lWdDa/8nGD19DoQaGvyTAki9v++jtCYsdg+DseckjtedsOFAnJZlDYJow6oMKrgEMTHtEkXGBkexG/v28v++GPf2/mjX21HszmARi1CmrWhysIjaaXRSCIMDjQQJzW0uzmmZ+dRSoWJ6QWsXNLEG176PKxaMtBsdzpoJGZr32NPHcC+A5Oo99XMhnCreEQcIU5qZpIzgDEBqRgY19i2eSm2nDD43awoAC7M/OKwia6m/6VUqNcEPn3Dm/Vbrj1PtztdRCIC3Oykt6FB9UFz7UCN03eergy2Fr1f4Q2l115oSOtyCUmFVt1+ap9imr0xUROBs1qE4gCoMMo0YGAa5UaFwkNCwJx1w3P8JcH1h2fYEVmr7K4LLHX1Tm91GeNotbr4wNsv0u98z6txyqZBs4KD3kH6e8qiwIsu3npw+ZI+ZGnbKleGoiwhkjqiWsMoL5vCUUqFOI7w4BOH8ez+yQYXAhxAmhV4w8vOlVddcTI6xw5jenIGY6NTmJmeh4gSDA4No39wACKKoAqD7rK0i6LMkNSAha7Ed36zF/9444O33PHoKEuSGqKYm4qcrMoeF1x2BoE5PjFGB1vAWUVH/wBN+FUk85nz0AgcH6ylRW4dKMRQLuAfV+VQJYZhv2OOc4H7qfy1Ng7m3EN3P3GfjJ6fGAbB9dT9D8ZBaCzsS9BSxSvoXYEE85OHvnPkdUYWjl5SKigFjAwP4pGdY1s/+E8/H/zkjfdhbB4YHhkEmEaWpZClhGbMle/pa8RoNusocomF+Q66nQITUzO44PQVuPLCE9uZzUNknOGpZ0fZ7fftQSMS0BbxMM5NblijAc4FABOjUpqhLCRWLmrgglOXvy7PC3BmfqcKrEYBMZSlRl+zNvyuN1+Mv/7Ia3DSmoEPplluSvpYhacDyrn4lyOvrtAo5KEDGvTeU7SCsrzHBDcfe9168x3zPAj6QiXgHY72Fj94ICi4SrEIJyUwqwEm1YwsDXUkFJYKsiKBRrDKpP3zg9pvgSD5SSGEQJ4VeP55m/Rf/eU7kS1MQagO+mtxHbAw16Fekx8klVGwF513IvoThSzLDcOVBliEWmMAjEcoi9JeXyBJYoxPtfD7+3ZjZj5DvRaj08mwYvFA/PIXn4kB0cahZ/ZgcnoWaaeDgf5+jIwMol6LASmRpxnSNIUsS0QJg2QMj+yYxuduehL/+o3H2dP75l/YaNTM/jKl/GIy4xaKB4Fxx2D7YqT7taOoCoQjAHH25Q8L8RY1VF7+cBJSkFR9ohoPolQEXRHoysqn6zF1gJRUFcGTEiKh8ujNI2yfIU7y5BFp+KJmzF+bOhIoetMN5gwnLUT5vnvkFk4e744aS+8nm4ccSprcspGhARyZTBf++b/uZn/2qd/jZ3cchUQdzb4+aAYURWGQuFIAJGoJR19fA1prpGmO8clp9NcLnHfGavQ1YrTTDPUkwsxChp/95gkcOTaLen8/ZFkCgoMxjqhWh0jqhmfGfUKhNJJE4/QTR9BIAK2Vy8mDJwMAjUXDfWfKsoO1KwX+7v0v+nR/VAK6hCC30U5EZXMySQEpW0bKZeX3KBe61lpCx/8e8GwNnOcnZ7CLTV45KuduEpKqImggqImPYCIopW1elW3MQXPql/IC4jphtGUodP7l0yfcJ2sVqOQyCbSrcKCIADDoinFIWaJZF/jnv3kH+ocGkE+NYvnIABYN1L6i7XWGGmZic2HSIEYW9ePkzasgVAolFRg4SqUQ1foQJX3GsmkJrRSKQqJZr+G3d+/BnQ8fYmAMccSRFSWuuGhrfsr6IRzZsROz07OIhMDQ4DCajQYgFbJuF2k3BWSJOALSTOGxHXO48fvP4u+/+vCnv/3b3Wx6oQTtcZRKOffMEbhH8VP6g1M4mtmdzjRBmacpWTDNnIBpTUfj0RI34SKajJTZHD4DttKHYRntegCqKMQbLu0mtuuT1lQ9BRT3YOAuyG5CKiRfAdoh+dH+eccj+wBtQsPXqyM5DIwqWfaQhj0ozLdVVWq91pRxfy2zhFJaoShKDPQn0Jzhlrv2sY/+6x19H7/xIdz72AyUrKG/v4m4JqChkBcSeVpCa42kHkNwhk47xfz8AtYuamDlov73laVCEkfgjOH2h/exn9z6DJqNup0SDIxH4CxB0uwHWAxoDsYFpK0Os3HlIJb3R2+VReEy3okOhq0Ky5YM/T6u9aE1NY2XveAMXP/GS3SZpYDzZQBFBQR76Ec0cwYzQFOEljwi8zx1NGUWuCjlnEdC7ND+kBzQd/RMwMR4CYE7OWc+QzZcXXLWEH5iVeMIwaoN8508Pn8E7lraUGo65JyMwArCE88KCZjRZ2m3gz958/P1eZeegWJ2Almh0NesYcXixtuYlTBufX3AuBtFXuC0zav1qpUjKLLU0E4pQHPUGgMAF5ClCdrLskQ9iTEx0cYPfvU0xmdT9DVrSLMCtSTCZeetxQBbwPTkFPoGmmjWazZIn0IWXTCdQ5cZxsbmces9h/GFbz2NT3z1sU9/9cc72DMH5z4s4hi1WoxSSlugMJgczJHwOV4VrF2hsaE5d8wmxgelCABwX0LdSiMP8m0okOHdTvrNC6GLbwSvKhay/SJ0zfwVLt5VEciwsarM+HtsL7Q3cGSR6fcQ9Vs15r6jhQx3PSNTWnUXPU11z/OZOy4uHLRxr+1GF20WrcvSrFrXajGOTnY7/3XzDvZXX7z7hk9+7VH84s6jODaZg7MIjTiB4BxlXkDJApEw2edT0/NYu6KBU05a9gUpNaTWqDdizLVz/PjXj+PI6CwaAwMo8xKcR2CMo1ZvIKo1wHgMziKjyDnDkpE6Vi+u3SSldHON4v0AIBiwetkQ0NcPWQp022388dsuwzXnbtJFlgdH/JFxVaDFljDZ2dPUBtOPwy2MLFqwuwdO4Tkd4oxfoO6YWUUlY06VZAFLf/vgyKEj+lETfCfLFoqZFwYnGIGgOGKBFC1z7bgKHtDOElh5cGOF0lZgSFA8hC/yDCeuXfL3H3jva1G2F6AVkGUZGkmEFUuHINiETcDkUEoaYnEGrRVO2bgcfX0CMi8ArSFLCR43IZIGyqxrNLrSKMsSi4cG8L83P4y7Hj/EojhGITXyrMCbXrpNv/yyTWBlGwMNU01AlimKdgfdtMDMQo7DYx08s38aj+yYxPa9M5cdnOzcCQBMCMRcAMwc2mG25RCdYSvcMmtIlNuaRRDbnFHBgHASW0vHAhoSlHO0D5C8Q7ZGZCrGxc1PZ1hcU05QQ6Gtyqg3vYS26PleWMMUkGrsjdCB9zhJZgIlQveGltn1n5Ag84OtHMQa5qmFqNG7ih4Z0HVVhFr5DtWwiFIGhWlrkDRjSOo1aKmx6/DCJ549uusTtz50ZOnJ64fGzzhpCU5evwgrl/ajv8aRJBpxwjE8GGNhPsXSJXW8+3XbcGh05rFHnxk/s9aoQcQR7n/yEPvZb7br97zjUnRaXcNXLsCZQKOvDwstDSYVGDcBhf7+GtYsH8QD+8aNrNn+GuUjEQmGtSsXA3EMsAhp1sVADPzFH12NJ/d/461jc+U3XEY3qujb6A4Ony/GHd84s2jan5fjEBnJhl8Eqa64k73zOqNq0Ol+BHwDFCK32uP9QzdpQkECtN0bR5rIb9nwD1aOieEAWEUwvNDooJdUUpj+skAYpVTQWuKv3v+aG5atWYZ07KixenkXqDWxcsUwhGB2qdicv8e5PwR15dIBRCihlFkCl4wjbgxAwVhCAOh2Mww0+/DUs+P41s+fmF3oSCOuRYE/euWZ+iPXXYoD+w/hd3fvwkKq7ZYiiSzPMT2XY3w6w+Gxzk1Hp9O3z7QlwEyVCs4ZlJSgfV4+mVQBEI6GBhkGkxyegWG8iiA2QFYvQMeWnl5o6IP25xC4ILjhqdUBgDaFLcGsQvVGzt3LK6fdePRtYiOw7nCPgDI6WIO5E7UDubTtaIcefKE/Wp1Sjg5UhddKmr3fzQFLRzpopfocv6rpJw6tptKYKM5G/fLtBwsFdpwAbPmh4Ckk00pCCIFarQEAGJ0rJg4/PMoeeHoKKxY1Pr9qaf/1yxfXMTQQoa8ZoR5HGB1rQ2uGV7/4VHzqz6/a9tn/vEf//P4DDBCYL0p87+dP4Jrnn4yVK0fQmU+R1OsAA2oNIMtLFHkBDgmpJOqNGlYtGwTDGFEZoUAJwbF61VJAG2QexTXMzc3itJNX4N2vPu+m/+9rd32DjhnUwQQ2qTsGqTohgzHEYWwwXHAKX2GoyLmBjIFTKIC4qwFm+e5r0VURP7fGLAqtkA46pUlYqDCeZWZovczKCv0Qoi6vrMJ26R5Qd53l0/6ZIcQEIMFRZB1ce/Xp+g2vfz7ymQkoVUJnC9CqC40EK5cNQgjuSnRxzt0eNgAY6EvAyhJSK8hCgiV9SGo1U4urKCDLDEkkkHZL/PePH8NTe6ZGAIUlQ3W8982X6D945Rm4/YFd+Ox/33vHzgMLz1ciBgMQC3M4aSmVm3RRHGGgPwYYQ1maooWkmbjjgoLWZqmcknUNcjGJgLLCKprQqAoEGRv0IInwHlRfmohs73ViEfCfwW8l0qFQ2WdWVw0R8Nq/9zE8jzKdcJOEMetWuIPXqN+BgrGanXKLwLy34BAUtOuf6xvz17hjzFiohILVMGqQ6qwR6tPkZtsJxfy+PUNH5ehpXBxrEOAP8ZDSLDz11RNwnkApjYMTnfcfGGu9X3CGKKbdJgxpYYzoA7smfvKBN5197d+/91KcuHZEf+1nT7L5LvDwM2Ps2z95VH/k+heDRYXpn4jBOUejWULKljlAQxl0v2gwQVRBu76vseBYv3oJUEoIxiB4BI0I8wszeMu1z8PvH9mjf/vgEZbYE8GVRSnk0XjFZeex5XMlXmVliU5l0o6hllPMyyMZ8KocB3Lv5Nl+H8iQd+xsK4z5Wvju/ww2kO/RVyjCDEY7V+A1I8Xt1DLcgZ/caH4OQhWoTCDqj9JAWeQYGUpww/XXImYZZHcBSuXI0gWzxUKWWDRQRyQogE+4S7tH12sCkBJaSZRSIopjCKEAmULrArIs0IgEbv7ddvz0tmcHu7nESesWffCTf/Z8/fprNuG/vncv/vyfb2WP75l/fgazz4xxAcUERCTQ10wwNFDD0GAd9VpklY2EthTjnFd2yDiLJv2UcC61NRa+JHMVBYToQQdt9cYQnfoJDE7wE3xMy6kE9/zKdUFVD7ewEAiYDiY99YOQnffAqgqRXEqjM+w4A+Tl++FOlax0tSJ7lUGHiwleht3IA8VWoY97gp8gdIPWNh/R8YLQhe9LiFIImZrFKbMAU0oFqRQ4A/oaMQb6arxeiwBwFCVDNzeNxXGMJ5+dfMVffv429pO7duO61z0Pf3PdpXrFSCOe7xT44a+f2vnwY3sxPDyEPMts6k2CuNaHJKmDMQEuGJiWSASVDfd8YACUkqjV4vr6NUuhsy44N+eSchEjzXI0mwp/+oZzsKjJzQo+YPjAPK0ZvDyE/CJaeLTrmcUY3OJSANYcMEIoP0YgEMbZdcA/Z2g0EJE1clotsOqw0J4sHaEoK7lOQTmGO8XlkVUolBUB404FW0GxdbuVdgPUymzBef1LztdnnbUB6eQYmIiRddsocrOLvywUBvpNPlVZMJeKEU5owc2maFkUUFDgApB5AZWnyPMWGhFw75MHcOMPHxs9MtFauOisNfqjbz0bK5c38Mkbb8e3frmHlVqg0azZVUwNDmWtl3XrJKBLbfesmfFSSoRWyoQU3MquEWzOOJ2/ai1kcC4BaCWNFLunY5iGwOBRD80qxzvlrRX9rcR1lAIqy+xV9EwBW6Wp3xX5gT2AzU1kMmR0qXbYyaMAQpq+bj0lQMO5D2R8qLQO9a2iWwMXsTJpdLWf6B2bVVr0bOMea7s6qp0X4OeEn5ihEWGM2RQd24+KUQBoUw0tNhgUo6AVA7d5HNzWo+fcHMMmuEZfs4bx2Rz/+LX72bGJjn7Xq5+HJcO1/FP/c9+Nj+wa3/qf/3uvPnXLKjQHYmRZilqtH+A1xM1+ZHnuFIKpQ2fe+0ItDEoqDA30bV2+fAmKThdMRCZJWHBoFWNhoYVzt63GKy/dpL/6i50simO4JT6at4HMke4hNEXPIYUWCIMDOKSYqFyThy1eETIwe7CMuZ9iuJoxgHtZ4B5+W70UWFodKiFt4L5JoQhWIy2TeKA4XGwhtI6ha2GXzSs5Zoy5uCENXaoSS0b68N63X42sM4eyyKBUhjxtoSxSKC0hZYm+RoI4EnUjInAWPkzGZFyjyDIIrhFxhbzbRaezAMEkntozhs/edD/2H51f+eYXbtaffO/5GGoI/N2X7sJNv9jDFI8w2BdDeAwBLgQYj8C4gIhiiDhBnCRI7BH0wqEub25o7zRtfKUV2NDKh+6XmdjawYgweOxQlf3dTVw3ie2qT5hzFbz3E7GK/gJ22Ux7qs2GYELqyrWwCs4fyE7xExvLDGTBxcicYlBWtgIHITCCJGeuvj0ZU+Zl1o+bQCU7nk4kB/SXFKJDBF4hkiGn6piulpZ9oI99aZiTsE0qibuZxhzQiTOGiAvEQvAojuM4jutRFPEoMgtCPv9PY6AvRlECX/nRE+z//vttWLdmBJ/+yNXXXXDyEv2dXz7G/uPrv0ccaTTqAnmRA4xD1OpgUWINEkdaSpseBGddlDaLDkuXL3p0cNEgym5qxs+5QW4MkKVClnfx9mvPxAnLGpfK0hhccvV8VdaqsXMItofWLKCdtoBIWb1iruVOZoDgLV3vuOLljZQd4wwRaTUHxaldew8LJMWjA4LNVgCCI7hCBEcW18s5Ne4RnAVzoPgYxQSkNpnHr3nhWXrL5hXoTBwGj2KUeRdlnrpjxrQs0VeLkcRiWLXLUSroFvpsC50MRVFCSwnGOMqsi067C61K7Ng3jS9+/T7s3Tt5/XWvOl2/9oUn4dCRKXzum4/jjscnWBTXUK8JMK5R5hp5LgFdAshRfZmqsSLiqNUixHGMOI6htYKSHEqWKErpGMHg4b0/ezOgK4Ag/SrAuQFKIIEJjYP9reJuhsmJgfLqjWXR80OU5q6nZE6LjKj/PijrLjex0ePkBK5vTrZsW8fJVw/ic3219NK9fXXegu0LdYSuodYYHMJ3bQOgBQ1avax0kz7Y95QkGx5e44Eeuf/cVIMQZqWQcQatJPJCopRSmZcupFIGsSvjITDOUIsF4kig2UyQlRo/v2c/G5/uzHz03RcPf/LDV+GfvnKX/uxXblsXgR946xsuQXNoAJ1WhigWiOIaoCNIxbDQKd1Bt3ScGyHbxSND4PUESpbQWtkN5MIaCYFOu40T1w3itVduueNfvv040yoCdydIVXWA51eo0AKewS/oBa5axWjygL7+Pou2tJ0fth1DZq8QI+IdGLNrTOQ2mhstNnRCGzzJdUxT2gV8vg3F+np9ZaqaQGfhBeIYuH0m1WHRUBPvfsuVKLNZaFlAgaEsc8gicxuTpVRIEoZawv8IDJ8g5OGtN8feg1NIswxRDORpjnRuFhHneGTXGD7/jXtw5PDMT9//pnO+cPWl63HvI/vx1R9ux9P726zRrKOb52i1MifsI30cw4PN1/X3N986MNC4ttmsoZ7EYIwjyyQmJuceP3Rs+syZ+Xm3t5ILgVocIY5NtQta1SNorzQC9OIZS4JAbhXRkorP9S5Fmxt88DR0d3qD28RHii+QC+9cLufiezeVPpFRq+zBZGFRyR5hRhDHoFCBs69GDhghUkJZdjOyWREluTSCzzkVlgyRk7Y7LHx1hNBFDQPAVCSTO1cknGHMybf7zomogk/K8GkugHEYRWSQjAaDLEq0OymUlI4G/X0NLB5qLhrqq325Xk8u5RzDRSl3drvZb9qt9B/nWt3p+W6BNCvtMzjiuIYHn5kY+ei/3PrBP3vbuZ/+y+suw79/68ED//Cl37FD4239/usux/Llw5ifbZu4V5KgowXG5woTnoBdIaYhMKBRiwFb5MDIRbDyD5NcnZcdvOLyzfjB7/esODTRHRUwqROOloHxMIpPH2/0rFLX3kqZ63osNHHHGQyQ2tFBkN4bCk38BkNkhJ0sFbOlNPzV3vIHWpcHsRfQSgM16+UAQYecUATCEa6QhD+TeJx3xgn6lJNXI5veY017ibybmVODlKlyKbVCLDgSwbYpa9XBmDlnkZsYz6M7xtDupBhpKKhsAYNDI3j02Wl89mt34tCR2U9/5I8u/tClz1uJn966A9/+5c7ZPaPZSLeQyMsUNQGcftLq+047ee35p25eirUrmlg00sTAYBP9fU00azGSSEBwgayQmJhub9uzf1zv2jeO3QfGceDINPYdmuw7OtnuEC+YELYqazB4R/JwNVjZCcvAYCdnMIE8mmcVZeHnoa7Qma71fPTVbgkYV/gDXT1GS0koxirPIGH2RQWP71dVZrxMMYu2HRKlvpISs/cROkPlGhIrXVGknHG3c8DrVo8ewH1MMaSHUuQCkwm1qtXRMqjkQcTUMEFwwVGWCq1O5iYl5xyrVyxatH7NkqlNG1Zj49oVWLNqBMuXDWJkuIF6nYMzhbLIt3Xb2bbWfPdD0zMtHDk2jV37JrBz7yie3TeWjE63CwB49vD8Zz7+H3d/712v2Xbgujedg5Hhhv7ad+5nM/Md/bd/fg2WLxvCzOQ8+usMmsWYXcis0lf2lCCrrLWC4BqAtMf5aeR5ASEAIRjKTIELjjTLsXblAK4+Z92xr/1iO1OaI6yy4w2ceVGiKat+7QhFydahknJfeOEMzlklo2avs38ULL+tGYzMXKHAeSCYFBuxQmpiVySUlnv0niw1C4XLoyu/wkjf6OMGye3+RMYAJYFIMLz0ijPAWIYizxFFMZRUKPIMZVHYktFmmVwIBi7YEAVBlDb9EEpDCIZDY62+djtrD4kCA/0J9o/N4xNfuQ17901d97E/vuzGK85fh2/+/HHc9JNnbjww3nq31BrrVw799QVnb/n4hedtwdnb1uHEdSMYrCmUWRtZkUEpsxdOlRpgEoxJ9CUMKxYP4qyTF0GWW9FJS4zPpthzaKb95I4jeOipA9i5e+zGfYem391Nu2AsRqMR+4nI/ETzAFV7voAmk2WwEw/tlEEAaCuuEgkIPcsZJOatn4VV1bNAwz2Iva4DoZWA3eTReWPcu3pplIHZaIxAIixGq7i1JDEG4bh4EuXSwSRn0ibxAAw6YxAeUMECuQxEuKL8Q6RL2eOmz0QvBErfTPRUGcS0eGQQp21eoU/fuhZbt56AEzevxsYTFmP1kmE06wnASwDSGN8yMydgyRq0bILJIUBqyHITFloFjk3OYtehqfzBJw/hnof3Ydf+cXZ0Oj34mf95kM3MdfQ7XrkNI4NN/bmvP8CU1vqTf/US9DVjZJ0FKA3kmbYoXwNQUJrZYp3GEEFLMFvxV5elq/bh8u4UoFHiivPW43u/34l2TiXHLdBhLDAUZtIRzenA6VDOKHPB/MSdIdIa1YWBwESTXASi6wy9sWsMEXHFoCjlOuDUjVNwYcxEgxwD57JYFOGW/5W36hr6OI3tBt77mTGUeY7VSweGr7zkVOTtOehSQ3OFIutClimUKm1ch0OpEhHjEAzLYd0M45OZtjgXkApFUaRo1DnGZjT+4ct34YmnRht/938u6b7g4g34+k+fwJd/sP2ascnsN1s2rrj9hZefftkLX3Amztm2AYMDCTrtObRnJnDw6DQ67Ta0kqbyprabr7k53l1rI5yARqNeQ1+zgeVDQ9iwYhWuOe8ETM6fjj0Hxq47cHTuukPH5nHzrU/joe2jrFaLXYnsUPH4+KNlpXONLReC2IZLMGawq4vhMrSH5E5dBG1VYxXMW1LLe6100FaAyS3aVfQ8VNuimIYHdxTUDk7e5jy4z+QweTHxsZLA+rmYlZM7RiEPVPoCbWJWvgy1g4Ze+Ye0stdQdRCENCMFDVL6HGVZYNFQA5dfsFmfvnUNtp6yFudsW49Nq0aAhgZkgaLVRjp/AONHO8iy0ixcSRtD0yYNSJYltCztoglDLY6wYqgPG1ctx5Vnr8TBF52Me584oH93z3488Oihy/7je0+yTifX73vbRdCM63/9n3tZX6OuP/aBK9A/UIeeaINxs0oKjSC2rCGVRFFIiugDTAK2nh7nRjFIaTaB53mKkzctwikbRvQDOyYZWOJkUpvJbuijvcA814p4uCjFKGjPAj4498tcQzF5WgwMy88jmBOMaUReszGLvGgWeERF7fOenC0TgPNLmuROBCoJ9OgQlFWEEo4OADMJqIJpXHneppkN65YgnT4IZuvWZ2kGKQtLeA4oBSlLxCyC4Gy5NjrYIQqC+wIyZjyHaCzFZz/3e/zuzv3iI390oXzpFSfhP3/8KL74rcdEszmw+v+84zL9yldfjEvP2QDECgtj49i/cx/yThtQOWSRGsulNYpc2hI8tpS1Nhn3xoVQ6LZaGLfbhgQXiJMEA4N1nLqhH2dtXoEHHmO4415hQSO395EVs/x0wYvqxKIgJ6Fj5x4ErpkOJr+Lc2rt+M+oICIJCg/QNPNcC1eTjHByB/MVaAUxRHXVVAO3yky20AqtsoMj8Qv0BXxis1ecvcHh0PaRoqyoPjKm5C6GnkPgLTjxD91sGoqbnH6SkcIUgqPbLbB8ZOQr733HVbji5WcBukQ2No7pY7uRLbSQpynKojAxqDhBHCUAE3bHgbAs14higCUCUMqEPmSJmclpTI4r1GoJ1i0awIkvPRVXnrcedz20744f/mYnfvS7vazdLvSfvev5KEut/+2b97GhwZr+2z+7FI3+BpoNcxiIKbNuDZ02sprmhcmLZNYdU6bmvgh8RMY5dFlg0WCEK89dg8d2TVTmqo/NkiH1dHTVTKwQ+4wFczyzciEHrxCcC0pxTyfHPhfQhRUCeYiIb9wGIcKtPKFg+BUfEjISRIMB7FOckDqhsBJCOsdrs/BFypNDlhJ9jQSvuOpMCG73LQqBrJuiLEuUpfJurDbTCEyBczaswCDAYOp8W9SoNPob+s+WrlmFX9+zHz/79Y7r3veOi+TLXrAVn//m/fjRb5790IVnnyr/4O1X4dorzgBLNGZHD2BuchJ5mkPJAloVyLM2srSLNE1RFtK4kDChRLO30eTYmBiigg2/oVQShS4hZY75+Vnc+9AC7n7kGG5/5Nj1R6flF2s1U2XApxd4g0R0cjwCq0y0kJCMeWRC8QPilffqrWWjZZ9wG1JgWb1L5VFgBX1ToEP7h5MSczk+yihJUsBGLuw2HxVsSdOBsDqNa95zXpUjElzGQuQVrL4iqBdGNpuUTwUVPrfycoddUOoQybTtoFuksmOo1RKMTS68++8/++Pr7rv/Kbzkyk3YsLKJoj2P7kLLZmEwMC6gS4lS5QDn7vQlKUsoWUCVhZUz2HI22gIIjm5W4tDRSUQixvBIH155xQacffIS/OL2g/rbP33yp/964++vfffbLkWrW+ivf/fuLVvWNne+5MpTMdBfd3TXdvGBNiW0uxlQSnDOzM4UbWJlzmOxW75MCfcS5562EkMD2/lsWytTJDHggWOZhtt/pmDLgnvDRKZWWfoSjz2shS+FFcgmcckF+i3vDJU4ItdAKJvO6nqGOzQWTBzXdBgb6Smb6WMnpgKE0gE8h7WoboAm92vF8kWnn3POFkiZodQcNcFQFKXZEykVWCwgpTmKChooSgUp1RhtGyHbTlsf4iTeMj3VwaMPb8efvOXcG59/2Sb8+3fvwcPbJ/Ced7zg029+1UVYsriOY/ufxvTRY9AooTkzqQ95hqzbRZ5nKKwCpX4zJsCjGBqwCbJm8svS1tJQCpwxxHGCqdkc9z85jt89dDh9cs9cIyu5PTreK6VwInu6cyhJ22ECzGKtW2DHPFoJeMLCe7S2oQLin1dOoeEBqGAiISHqi0c/OuAaJbo62QnQkFE6QVyDnkUyGyjp45bnSX6opeO+89eSC+q/878Req2iQhfad0jCyb/Z2AlfOt3BUmeElVYQUYS5VOL39+9it92/C7c9sF6/+WWn45JtqzAy3I9Wy2z0F3YRRioJIYwhkkqBMYPWiyJHt9NFnpktQiZuxwFmUjFEFIGjxPR0C406w/CiGt7+8o04eePia7/3yyfwq1sewBtffAGGk3Ln00/ux4VnrsVAf9NSiFb6fMXi+Vbntboov88jgTyVdsyGCFEcoSgMfzjnKEqJtatGsHb5wNTM7tkRMFPmh7IAwj05oeELBZpQU6hn6EIeHNZLgIgMMBk9d5MGAA5a8WQAIs6DB4VMJKkCg9b2JnrZHeew9QNJIENYiVCwbL1k0vLKiVrQpA1+cGhs2bT6iRWrlqK7cBQ8qqEoM0hXowx2f5u1tIojLxXSXN4BmOPZmDIaW2sgSSLMz+UfeOyeJ9/2ostOAeIYP/rZQ1joMNzwgVfggjPXImuN44l79iPPc9TqCRgHim4JKUuUZWGVpxkl59bt47C5PmYqOh2tDG00U0hijqwAHn5qEr9/4Bge2D7OZtoSzb46hpsChVSVWlvHu0cE5/0sN9U2goC1Qwt25gXxHGc7KvJ0PAw3LNUuWZQQrgmQk3IihdizIMN8QNX8HggyY94N7jValc55lB/+TuMkuaJlfLqGAS7xmtNG2FCmnOKy+VvkPhLIgTV0zPNQK+ZQWwAw/SR0QNQg7loi0N8cQlEUuOXuA+yx7cdw1QUb9CuvOBHnnbES/SN1cz6kVBAihgaHD89IcGYOXFa1xKIyi+61QfhSa5S5iZ0xDXTnJcYm59DXZDh142Ks/aPzcf/DezBz7BDe9fpzMTU7g7nJeUxNt72sQiGs0DEz13qi2+2CixhgsGDAbHky3oSwNfiNmzsyUMemFf3DT+yZMSuRRILAEoXRUb/Q5+NvlArjYqkOHrvdfx5LBbIRGiGSEW8etSmnE1phBEJtGrdKSXuhMT61BtMcPV2319igXWA9tZ31bic/uakwwsVhtHkScZx92kbEA4OYndgPLiIUaRr2yDhuWhs0xoCsYEjz8g4PNw0C5ZwjL0qsXbJoauOm1Vi0tA8//8VDWLVqBd72xudhxSKGI3t2YWGhhXpToN7oQ5EbpAfOwLQ5x89kC+fQpsiEqZjAAMqwEcLueSukscyxUcZ7DrZw2yPHcNvDY1uOTKW7kloNA4N9YAAKSeWVGXyxLi8Y7oBdYpXNVrdGyCsAgvEBLUMW0mJKeKRab7yo+rKTGcejst50jHBic0YrXv53ZX0lUoSUkmHSQQJFFrRNtahC9Gfag3NZvJsYjBPBqpuzwJ6ejPQSdEVitYv9enhQDfiHfdCVeWASVBWy3JRjHhwcxGwnw7d+9Qy7+9GDl77mqi13XHvFidi6aQm01mh1C6gCECICCw51jTgDkghxLEwgXwHaZtRrxo0y0xpFoSBzCc0EWu0Odu08imUrhnDZhRsxfmQa48eOYe2GJZgaz6DyAkpJCM5hz5qHsrBhbrb17MxMG0sXJ4G8kPLhECKGLE3St4JEI2JYs7wPsY2R0aKcKhW4qYHR4/6H++OIiP4ZFi/ZnFAfNvG89P/z3p95w2xqEb2iUMkYXeUHFCZAkvXRwd4kBwtDK28ZDKvIwExNeiklRCTARWSRhEdurgGtEccRTt+6FiwSBv0Ks1dP2WQ4Zq25yc5V4CxCq1siTcvvGGhvWhORQJGXWNTH8b53XojNJ63A73/3ELadfQpO27oJ2dw8Du+dhoiBkUUDKLLcFRpUZB1o2ZhQCRjMnilSHBpaS5SlBAOQxEZQRqdTPPT0DH5z39GfPrl/7hWAQF9f3Vg2pRwDfXTdm4FwBScEKW4Cam9MGf1Aiq6il4IPxqy5FTmltK044XOwnGiRMjSWyqUShOgoVJogpQpvGUNl4PrsFCOhHvj2SCh7nxMI9nEKG7AungrktCJN3qIzFoQuCFGGtPSSSLKutaZSV3BGJjAUIbJlYO6Ak0Y9RqMe4eB4eucXvvMYu/+Jw/o1V5+Gqy5ah1Wr+lGUCt1uYSc/nflJ/bXImtncPyv7oLMZ6wyyUGg0EuR5DVk3xexMhlZrAoODTZRpiYnxBfT3DeD1LzsLjxyYf9/uw3NfHOxLkBfaoZ5uWmB0dBbLVq8xioRzaC0dTbnggFWc5kuN9WsWI4k5Cq0sspNBQJ+DtpwpVaIsJOKIg4vYGznOAhSoAz1B46+CIN2zyHOc+2m/oiOMHbQD7HJq7xEwgVBwzmDOpTOPpewNDgbKtDU6zKQXLF3cH191wSlaQBrNDtvBHiurtEaSRFi9cjFUkUFD2NwTQ1BiJNX7ggYYjzA5l6KTyQUN661yDq1KKJnjz95+vn7JZRux59lx3P7IDAZHlmFgIEZWdMBjs30iz7oobd1yxmw5GdIHGm61UQiDOGWpoaQRaKYVakIjEQqzc13c9eg4vvrjZ/HlH+1mT+6fe0WSJGg0E5i+mZgHM4M1E8nOCLc1DNq426BZ4pGTY0BYgicwMDTxQmziEHTAP5qUBmkYRcwcFy1PlLvQI8WAWWQ1OYdD3CGSqa7++bihUQw21cbx34zHlxsCqnFAWIMYoKgARfrYi1nlMihfBzT0ffZDMLx0xpRoaV8uHKL9pmtNRtu2HqJDar+UpuLJQH8Nca2Be56aYf/fV+5lf/vFu3DzrXuw0M4wMlRDX5ND69wcqgzpaa4pcZkZd9bKPh2Yy5hCHGvUE45ms456sw+CxygK4MiUwt2PjmN6posrL1iP/++9z//CxpWDb51vZ+BRZE+oN67vgSPj4PV+AAxCBErYzm2X1gOjyNauXIK+enQefIn8Cg+4MKvwiwZqeM3V5+pFg328LEunpMCYLXboY3Fa6yB+auXQffZypWl+aFcH17XBw7Kt3ohVGeksEiNuGatpr/AbRul6q7zAOGRZ4IKzNuWf+8d3Y9vmVTNKluCRhc9KwwcZjWTV6vGiocEGyiwzh3qCWTjtlazzsZUC5xEOjs4hy0v7m0lJyLpd/PEbztZ//LpzMX1sCj+8dRd+cMeh5G8/9Uvc+/gxLF61AkuWDaHRjMBZAaW6UGWGoswhy8JknSuTxay1MsislMZyciCOGOLIiPOxyS5ufWgMX/nJHnzpB3vF7x6ZYmmh0deoQQgrGL4kAPwWCji3L6wL42MJqEwqBVJWXqkwC+l1eG/AC8dHmwFPG5PD2IKnbTAbYdVrgGrCOvtOKDUpBK9eAuFxnxm5fyEKsoq50k8bzOWk0EjGnGcAx3/lzmbwcT/SeG7iwMpiQDNU2qr+NatvqNCEFCwtOPl7qnExNzINlKUpnzPYX0cOjp/ccYD9zefv7PvEl+7Er2/bg9mFDAP9NfT3JxDCpjLArAbSMW6CGzfSzC8DEVSpUKQFyjwFZyWa9QSdlOPWB47hKz96Cl/89uM3fv3mpzExNYeXPP9EfOL6K2/auGLorZ1OBhGZfZZFqbBr/xh4lIAxOtnIjk/ZAVp3USlASqC/r4a+mnhduNPAudMMEFGMsizxwos268987K0446SVUkpbFNQxkpEgezXi6MnIpIBMlcf0gQEKcJUGTCKrnwweEYUxDi803qoy5t01WnYmUQM0GBfIcon+RoLLLjwJp567Fi+97OThB58+amRM04qYAGO2kqtSSJJopFGLbHawiZ0Iwa2p59Bg4MLkhRlYKvDM/knkhQSLTQWIbqeLd127Td/wRxeh7LTxrV8+he/csv2a+a4qfnHvHnZkcvaZl1156pbTtyzHikURVi3uw+BAHWk3Q6dboJRG1TOpwSNztmTJNSQDuNDIC43p+RzHpjvYe2QBT+2exo4DLTY5V4ILjkajDgYFqUzQjAeVV/3c1768jvPhgrhS4E55t4YY6HlCblmVBwGTe8ooA4Tk/aINJSOHqI6UhCZ3y0MjOIVSkR3YCcgCodTOUgdqzW/3CpAdbWgnYfauHnM0835f2JoXZzsUZ6HDBN8qYqV9vzhOkXkKBgbFEsq5PCGfiKc0+5S/X2tAaoUoEhgajjDbKTr/+6vd7M6HD7/8wm0rfnrx2Wtw+omLsWy4gb6+CFoppLlZ6aYtQNDKpT8Y70AjSUzpm/HpFE/unsTdDx/BQ8+Mnz/TlQ9IBXzjN7vezeNYX//Gc/CiSzaCa9z011/6/fDuo7NfbPY1kHZTPPn0QTDFIOo1qLKELEqzlUiawTAIKFUATNvzKUqQuOgqecAFRyklmvUYr3/JmVi3LsG5Wxbj9ofNFqsk4Tap1ss1GVS/8KcDA+FlLUS3xgBytyAABDEw2rjtmeOJBhJUFk4O/2BnfGHcQKroKfMC609advE1F2yBnD6Gi89YhXoiUOQKEWcOhpPhVFohicRwUovcoRecmxNXGBNOiZnsYY0oijDdzvH4zvGdUnMkgiFrLeC1LzpD/9OfXo0YGb5569P42s+e+dDkvPxNkiSIowiPPDO29ZEdo1i1bKB50tqR9lmnLMPpJy7ByqUNNBMj3KSIpTLbMuY7EpOzXRyd6ODwWBf7j85j79HW6tGp9GhWlqjHMQYGGlBKoSy9FaU4IeWkmZAGqwhAb9oADxBn6BKy4NrQ2tMkMtdUVxe5E4pqfIn6QzWZjk9/CSa1ZjZv2JeXQaDoPHrxCNADIBasbgaxDydb1NeqwUQgb+4+W3batGEWkfymdaJxgOiJpoHCJyWmrZtmLaeLe1YXLazDyEiJeMRrxshdJj891DoAAf+M6wfNkSQxavUYo/P5zd+6ZR/79X2HcMbGEb3tpKXYumkxTlg5iEXDdTTrkTmVSESIuEEwpVTIMo12WuLI6AJ27Z/B/Y+P44Gnx/pGp7udKElQb8SoRRydbon/+tkOlsSxvu61Z+KKC9fik+LKL3zkc7+d3Tva+kacRHh0+8EvtGZmr4+ag8g7XUBEkEUOLgRkaVYjlTSgAkra0lV6lDwlX8vLLEq0Wgt4xaWb9OlbliMdO4SLT12Jrw/Xzzg8lT2RJLWAz4avptQXc9YmNDwIFlZocQaa5qRtwxq7yPFZB3kX3jRXJg991gBcNh490F8EcGaC9kLh7G2b7jply0rkM4dx4qbFOOvEJfq+HROs1ohRltJvc1AmuBxHYkBEkS+2JziYiM1xSvaUZ4NiFWpJH+7bPo7dh2a3ijhG1m7jigu26E9/5EUY7lf4/i934j9++NT9h6fyz9RqNUiloKTEQH8TeSFxdLzdOTq+wG5/6CAWD9Wxbs3IM8uG61sG+mLUEoFEGAXWSSWm51KMTXW+Nzbdff1sq0RRmATbei3BYL3mJ4b14akcsbfShHLsxuEA8VS0Bph/C+3uM3PNmWJ7TYjUguCng+akAOFcH0Jy5E5KHUD2Cto2DDVnV2pTPZaxytFi4TOcFXMnpDOYPBsNKN8ejcOMyRrBSuyJRJQHCk17WjqkR3JLipAQKrMFJLnPsSMDS55FqHw58zsSevlhNbHTqXbicM6c91FdbNAuHKA14BWrWTUtpQZTDLWkhiSpoZVluO2xcXbbY+NYPpTwtasGp9avGRpetaSBRYNN9DUT1BIBwRnyQmNmNsOhsQU8s38azx6cYxNzqSkp3aiBRRxSKegSSGoxsqzAf/70cdbsi/UbXrAZl563Bp/4P5ff9MF/veWOo1P5wSMTc+9/7PFd11946fOgpibA4xiqa904xuxBMtrtm9RKQyo9ZtJblJv6ZMwE53jnq8/GcF1jauIYtm1dijM2Ln782PQRJoMjGp2GV9pvrNfaJhFXV7YdQmZVHQVGhoUjcvam16oGMLgKvQg9+JWcCr+5WRnoZhkWL+rDi6/YBh1ppO0FLFnUxEsu3ox7nx7zp+TYAokmHKbBACF4BCAHE8K4jFEMLoQTRkJnkiW49Z5n0UklSlng5BOXn/2Zj74C61b147e/eRif/84j2DPauaBWq1kLy8GYQilLcGg0mzHAOJQ0LuHU9mNbAZMNHUUMgjEoZU4yLu2qCGcccRxhoD8xVSw13J4zoyC4Xc31gW0Hl6x7FNaJd5PGzkhSduZNeIgK3W75FMRoDN09qgnjYCGTSCxYoFx92oJHRKQcvOtJPTBrPor2zCLkf6DQQKvUptec+4UeEkKyrL6bofLwSoGUlOkHd24IcDwapXtAaRsBoiJPwY0NVpEGSAnk0pDhCFahHRKABmxeZCUlJTA+XlsaFAdG+ZLM5jNKgGlT+LKvD7KUGJsv1Njc5MiDOyYRAWgkArWaQCx4XYPJUusizyW6uUShTO5Ys1kDYJGxVBV5bNQT5FmK//j+Y0k9jvNXv2Aznn/BevzddZce+Ojnf8fm0hy/vOVxXHLNFRBxP1Q+jyiOTAoRGR+tAG0SXbNcodTs10oZmwRLD8EFOp0M5562Vp9//lYwPYuFdgurFy/Gyy9chweeGcN0R6GecH9UIgEh7XUIrQSHCJ3CF9UJgApfeW8eTgVmu+BlaE28sNqm0NuGVhpSlti8cbW+8qJTkM7NQ0mBRqxx+QUbMdyXIM9pQ7YRJApeFqWcB6RZytUwFs+ubBrimkCniBIcPDqPux4bu66UEotGGvjkR17+0FmnLsUDDz6LT3/zITy+f4HxWh0m6dXBQyPgWqMozGkuSknU6wkG+psYGurH4FAfmn19qDWbqDdr6OuvY3CgiYGBOhrNBCJm1lWUDmGRsGqrTIhu3Cr8cKFEa28siGH+pGKaiT37yyo+HU1AQnxV5EC1x8P2KcitLU1x3L2ep6EbR8+go+DMhA75rbxc6F6h88+gnB8zKUKU52lj/vrUDuqTC2s4fyCQNR2U8iEZNqWr3JAo5sLcNZ6OhCYYKRu6nsHRz0qNe6bSymWih9c4xGiNFh0Q667RwakSCpDSHLMHALVajFq9gXqjAVGvQ4oIqeRYyEXaKkSRSgEW19E/0IehwSZqtQiEhvwqrDdopdKI6w3MpbL44g8eHfz5PYew0Crx4itPxZ+/9VzNpcLNv33istb0JJJFq6C0gIhjWxXGhm6sYtZSY2q2jW4uJ0ppVhKV1O5Qnywv8I5Xno3FI01kqTlXcrbTwiVnr8GJK/s1ZOH4FuYKUvTJ0MjHtnRAa1Jq2gEQOHuhtcXphLJYj7oLhSj8zeyRCq81gkC6uywLRILjnG2bsHTNIqSdFhDVUZTASZuW4qpz1+msKMG5MC6V1egawFwrfWZyagY8Mod4mZQGm7GuNHSpIFWJWlzDvY8cwJHp7lcjBvz1n7xAv/yqrXh2+x78y9fvwgPbJ5iI69Cag87OMDJt40vuAFyjEGVZoMhz5EWBopQoS4VSakgNSC3NPszCZOdrQkC+UQe0wHoOASU0W0E4dgOGc4e8IuldFQzdFD9Re5BvgJYo4S9EKjSJjKfF3PONUvN7X82qHmwM7nh0FAb4zT/uXT4NgNvf6EguVGWEeOw0fgVJhWgvNKbBIIN7GdXyt/qo4ir2IClPNKKnrtDYP8/1EF7+CUVxh1YrhH+uFwFobZQ9oVZatNGkxEH7W5VdqaYaXebEqygRiGoJoiRBFCfulHZZKshS2pQECyx0bxcYCg1EfX0Ymy8WPvvN+xbf8dAhZHmBN117Jt7+0lP0k7sP33nb7Q+hsXgleNwEYxF4FMHpAmWUopYSu/ZPop2V0NAmX9JuxTF1wwaXXnHlmRCsgCo1kriOhU6OJUv6cNlpy9FfAwopj0fOFn1RIjuFSlyqBPM8IIxGckOI2lWh98wKArPhe9CkqTLNM9xeoIE8l1g80uQXnbsJSmZQhQIXMbJcYrAvwjUXbzadt2VvGCEFzjE/v7Cw/ak9Fg6bk4SMgjFop5AmXWKhXeBn9xxAmhX4w9ecq9/z1oswfmQU//Gde3D7Q0cTcHN6ECkvCqg7N48LCCEQcW4KIkYccWQ+c0skmg+M0ZK2DyOSMnDHoNvxk7JypAqAk1cAlnKhexYIveMDehlenfSmm/TZP5DiXqyiGHw+WfX5BNerRsq7VL7vysbXHOIglmtKUA3SFQjVOeQXBtt5cI19utPN2imkcIwV18LRCAFPAmWlvVwyd7+uuJGern4Mx3shXsqpf9X0Ch38CyrS2nkQ4EX7fBUgPuqPqVknmNvJCViPBFpDKUBrATCzkMV5hCgy1X3jOEIkBISwylUzQHvDKjWDVAz1RgOjU53pf/3m3Tc98tQYGOd4/zsuwcVbR/RX//tWFJlEfWAEPKqBiwQi4rb/JrcrzQs8tXsS3dRs/FZSuqIPnW6Gl1yydXz1CUvQ7RQ24VxAS42iLHHRWSdg6XD9XWUuQS6GMzxOBliFL974Evon4oSxRSMTHI4hDFT61TGTe6seiIljpBd2LyzmoA6FdasXty84Yy3KuWmAmXwuE3vPce4pq7FhRf9b86KE4P4gUsEY0lzi3od3gakSgmsoWUIpU4FV6hKFzFFParj/qVHc/fhRduG2E/QNH3oxoFL84FcP4we/e/batEDBSUEaBwRRxBHHAklsjpHSmkFKICs1ummJVrfEQidHq5OhkxbIcomskEhziTSVaHUzFGWw4kTjZhpgyhzKYZWaQSH+d62V28FgbqxOyNBIeMH2mo0H15k35numfV+ojVDR6cAdZDCI0JREImXukzMZmDtCTdMxWkEbFcQdoCU3mRl1ywojAgXQg+xp7P6wDL9S6lZu7X2uDcr6DpQ6rAIIaRAiT20ViX1gUGPKFzoMDbKbWPB0JANGMZvwWg1UaEBjM6rKK1mfbuQVtGWt4w3xjDOOiEeIowiMcUipkeYl2p0MC50cc+0U8y3zb6FtvutkEoWNXUURN7G1yChF2FzGWqOGZ4/Mvf1fbroLu/fPYNFQgo/+4SXI5qZx8NndqA2NgMc1MB4hig0Ko7k+MdPFrqOtL+ggbxOAPWUeeOlVp6MvMnuGFcyKKWMCrU4XJ65fhC1rh27kUD2FHAI94nbZBKlCgf0jLpGeYoFMuiC+riAFyxinGW1INLBkxsIr/2C7f7CQpgLDGVtPqK9ZOYTZ0cMAF1YRCuR5iTXL+3Hl2Wtv+urPnv6G4AkK65ZxZrLc73viINpzLfA4RpF1wZWEUhJFnoNphm7K8d83b8fioQY++ZGXYflwhNtv34H/+v4jBybns5vjuAapFQTjiIRxU4uiRJbl5nAPJaE1EAkg4QxJPUESCwjBuFZKFRLICloh1SZhtSZQlBpKKgOzNSqltdH7N7DeLoBtGUMuJrmO3m3yiyZuLjkQU0UH4d/QFXKKkRAEWTIPcRAWoTQT6zmMEYmY9quoHLzSj+BsHmOZLUD0lR+qckW1nnzBLT/GXto41IWwP8F9WttkSi+Dhlb0HZwCZKRciS5hixq+nQpdPfF7aU8vKlnkJiI8OrCdd/3TgNNkdKqRU4yA9QpMH7tZiYV2jkgINBp1DDcT3qjXV0SC9wnB6lAKpVSdoijn86Kc7RZlkecSabeAzuxCUxKbf4Lb1XeFOEnw8I5R9uVv3a//6j2X4fRT1uCtL88xO3YA2LQc4HXwWINJqopRIhYM+w4t4MhE+n5mIbeG2XWTZTk2rBzZdNoZG4G87ep4SVtsIc1zDA/04bxTluHep8axUGhEsUApZVDOHFCMZEzZ2K03aEYoNHzZCMs6y2KbyBpKESrC1yPfRnADCO+Pu9JgnEMWJYb7arjgzI0AV8iyFEmtD0qVUBBQmiNOgPO3nYCv/fxpt4zvgr+c4dlDk8neAxP51i2roWbnoGSBPM9QlgUGm/341QOH8eiOY+yGP7lGn3fWWux8ag8+9/W7sWPf/PqkHlvFwlFIibTThZQSA40IG1cOfH7F0oHrVyztx6LBPgwP1DDY30T/QB19jQi1REBKjXaaYX6ui7wooWWBpCawdu0J+NEtT+H7v3iEJVxAxAJwUT+/Euao6HSKjYMR85kfL90bvtzyMb1jzNs8mohhHhmhC5sISsvfLuPddsagDhNdcAe+MW+UqCeGn9yVTnaKzD3fW2aQsiTdbCctZWkDcP1xo+RwypNygVwxReoy9RnB2l+AWENESIourKKq7XmCzCkb5l06D+4AMLfVyn2pKdBu2nDyravP1daFCnC1G79v3z29ojgrXoythkwpQqUsMTIQ47QTV+oztqzB2hNWYMmiAQwP1VFPYkTC9LEoS3S7Gbpphtn5LsamF3B0bBZHRmdxdHT+/mNTrYumFxaUhkC9FkEIDskYRBzjF/ftYyesHNLvft1ZOG3rCmTZLPJOC3GzH0VXQXfaLhWqXo/w9P4ZdLuFXcSxxypCQCmJK87dsHt4ySCy7pQDNGY/sZHHQiqcuXUZli9qfGruaPphJJGv8xbQnOYOApYFPjyYKwOlK3SOelfRgLAVK3E9QuME21l6bVZ+rP++ctnQ588+Yy3KtOPKqSitoRiDVgwRl9i6fglWjNQ3H5svd8Xc1ErSMFZ1br5d3Hn/HpxxxkYwmSNNC3TTDJEQWEg1vv3Lx/Di52/Rf/TmC3Ds4AS+9K178PuHDjMlYmgm0MkKpN0C9brApjUjnzp586oPXXD6Opx5yipsPGEIS4bqqEUCsdBQyqx+cKbBIwambI0qpqDKHKVSSIYHUaQx7rh/j9m1Zl0d5SgeujUhU0JoESoRknBvCLzAe3TkrtHe+hOLCKn457LKpAk5SNdwC8FDg+ZjbSbG5ZSPBUoh+gjlIPyegcrWhALn73H9DcdmrnIlyJ1gwhtUE08M6UjIy5fJQU8ftTY7N8yp0qqCkFlQTVQpT7PwVHnqfIi0QlaEfA4VESE5pfRxCNtdGRgLl5ALQ2eTBS/BUeIPXnme/tifvhj9gwmgYyCuAVoBpTRAQFIpagWtpTM8WS4xPdvBkWOz5+/YOyYf2H4AT+wYPbB7//T6uYUS9UYCqgH2zV8+xTasbOqrL9+CuclZHH52FzZuPRky64IxAcKG3SLCA89MoSglhLAo14MnXHXJFjR5gSwvXCqPgkapNcAFsrzE6hWDWLOs70O7j3Y/DBg6SalwPKKF1QFewZEb7wwe4BQZAERUTsO0Q3DcyZe3nMyyQcPDP01HU/lTtQFg9arF1687YRG67QWDIKQ0gy61ESwmsXpJE6dtWrbzyEOHGI8SSLNrwtTiKjV+eedO/MEbLwLnHGmnCy1L1PsGcfPtu8CkwAevuwaAwnd+/gB+fOuueskSUy53voOBZoyzz1yjL7/wJFx2wWacc9p6LBpqQMkc3W4bnU6KdiuFzAt7VqPPXeLMlPSRqkDENOrNJp54egL/+j9348e372K1JDGVLJV0KIdW74hQ3qAHsRMLjatZ+D1I107bcDL2Bq79BIevq+bsig9yUhuVdqwyqFYGsHldYIBFAa49O+lAfwNFSnpZ2eqqFJ8w/TA9Y86FCoQoGBvtEqg8K3TDmX8O61lm80Fej6bIZQ6/88Y5UFgBXakyh0+uDXmH4P6enDxHlyo69DY+nEt+XMyT0ru2AQoXkcD0fBe7j0xhEx+B6sxhfiGDFomJZ0FCKqvIygKwhj8SAkkcY7ivgZWnr8ZFZ67D6198Op7eM7Hud/fu1Tff+tToYztHV5aao1aPMN0u8eXvP/rp1asGPrR54xoc2LUDA0OLsGjpEPJWhKIoEYkEOw7OY9fBucTu2gdgDugtZImhvj6ccfoGMNUx8TAmzDqC8ichFaXCYH8Nm1YN4N6nJ6E0IMgjCRQ9C4hXqQMHBHJHcgIwGxQ1uMky1TDMKCayrGbJveoyOJviAJu5Vtos7A1rl2FwsI600wbsFhQNW5CQmUS7ZjPG6VtXODTnLTADWISHth9gjz+2F3HSRKvdQk1wzHYkHn7qAN7z5vNw6oZh/O62p/C/P9/+05kOy/KsQFkUOOvklY/91buu0P/xsVfib/7kMlx+zmqgmMeB/Qexb98RjI3Not3OkBdm+wiPOETMzUbXWoxaswllayKxqIbbHziIP/2Hm/HNX+9gnYIHcRdAam1XObVXVAH9Qg/GCT4Jsw4nFln06ov1vKlOEquQAuVlp4fJ2QrRMXMUds8JV49dEBleOYaxMPeZhd/7RQPznaKGbXBee7QZ9J3aqtb98i4sfceCcXG30dD30RTiZABjLjbnFfjxlU7CZ4Xj888LFq9CXjzX/aHr6N74fKweIA43VYiG9r3jIwyCEkJAaYH//MGD7A3v+Y8bvv3Dh5DxBpojQ2ZuxRHieg1REoELjiiOECcm6M44Q16WmJ1r4+iRaRw6NIHOfIozNq3CB9/5fHzxhleuuO7VZ+tlw4nJ1Ypi7B5NP/xf33sE7XaKgUYD2x98DFmeod6sQZUKQiS46+GDmJ/PCiEIdjEIISCVwsVnrNVLVo1AFpndwmV3YWiYnRsadkcOw8bVgxhoiCGptMuTDCeG54z51Ct/bueDnV+kybipnkvSwpyc9E6m3i9IwdF7zjmkMgl5G9Ytg4gFiiw1D2QKpZTu0IBCAyxmOO2kZYgEQ2lLL8PmTUWRQLvdxa/v2oE4jlEWOeJaE/c+uhsnrV+OF12xCXv2HMI3fvowdhxqvyLPS6xc2qi/6zXn6s//5bXb3v/WC7BiscDhQ0dwYO9hzMy1zGTiDIoBSpYosxxZmiLtdJGnGRgktCrRml9A2m2j1e7ie796En/6yV9fds9TY6xeq5ls4mAbRZUeFX44utipbv4yZnfiM8CWFvHXWTJXEAjZ53CCWT7RMzStHgbICAH87nX3QiSFKhohiaFTiBiYO2/RxXsqCtOiiB4U4sYKIKzkEPalV0BDonqFi4qMeTDo6Umrd46mQekev8LJ3P0OiXlN4hVNIPte5Xsj4MZJ/SKU5gahPbJiPSOj/sDTyEIJBwqUMjXCBgf68eyxzic+8umfsk9+6ec4OtFFXz1BqzWHhfkFZFmGokiRZR10u11zeEieGyTNmYnPCoE0zzE2No7Rw0dx4poBfOy9V+IT77tcn7V58WNlnqFUDPc8Pct+essTWLpoAHl3Drse2wHGgYF6DWmmcf/TY6kSzJZutuOwXsTlF5yI/r7IPFuVoFMilEX6SktomITdjWtHMDxYvyGsRccYvACF8hnIgCM4fBoMyFdhQATtV2LgUFgAeZkP2ofLl9yd4w2b3M6hpcLAYBNrVi4yia2lsqVCJLRmMOu6Jj4huMSm1cM4YVn/6/aPtr5XSzglaYMxDSmB3z+4F+99w/kYGR7GvtEFHDsyj1e/9ExkWY6f3LYDdzw6ypQscOl56/QfvmIbrrnwRCQocOTIAUilwCOzR6zIcyhp4nTSxhGgTBldrY3PLrslyrwEUwpZIfHLu/fi3777ROPYdJbWazWTJiF1ECPqnXAerVKsi9kN60xbt40o5pCZoQdtaTHyzBxCcUpMA37bC46r1VXZiB3w0NgjhVARkKI5fmWtqmBoFofQHk7ZkXK1Y7a3uGVyV1nCt2cEl5JPtXcb7Bi0UyaWTgF6pXVcrau/u0z30KKwnjHBr6L6PlfH6J5vh+YRsflecDost+qCEiILUZ5DfgGNKJ5EStMZO/ssV0UWBtUrWWKwv4FOVuIL37ybHTg8ra9/x5XYsLKJqekZZGWJei2G0CUYo3LaGrxUELGEENos9HIGHQvIvMTY6AQYA15y8UasXdm37cbvP6hvuecIm+sU+P6te68/f9uqL5y8aQ127j2IkcEE65Yvwj1PHcTeYwsNHpktRoTUi7JExDnOe95GJKrAQi6hpIYWpv/aljmiNKY8L7BiST8WD9U+tOdo+mHjJZiQSojSw9goyQehVYqLheXUlVaIgjMe3GShKwJeOisRWleAVRfEoNGoR0uXLmqaUhwwFSe5MgXPQoSglMTSRQ2ccuKy7+47tsAYM2V1wJj1Dzj2HJxMntw/mZ+6eS2evv1XOOf0tThpwxAeenocP/3dnsf7aiz+4zdekr/ztduwdnGCybExTC+0AB5BaQGdl1BKQypu27XJhjZRkGmFslCQUkGWGSLBUEiBW+49gK//fOe6ifkybTZqZoFBA6Y2E6N1DZhVP7+C0uuGwE4yHSZws4BBZIU0ldqm1Vgzyd0Ep7YdAqm299yBdj8BQ/ewNybmmulpk9p1irTiBvk0Bz/3THvm5GRmzgrQsImYfrU2VDcVIMtgPQHbPqh4uA7G2KPEAoXvx9FrwWFDu8ypktAVJ1Tpae0nCOuRdQT0N+dPAiZ8UkUGrmFNLXoES2ia4JwHB54QWpvy0c16glLH+OHvd7CDozPH/vydV6w446QRtCZnMDGWQTAOLgDOBGr1GpI4Qi3mqEUcSWz2EVOX4kQg7eQYG5/BxjUD+Nj/uQRb127X//ur3W/bPdb64rd+tfMLn/rQBixdOoT9+w6jr38Dbn/8MNLcVD1WoLgUkOclNqxYtH7jiSuh8g5kWZpKv1YgzF5l+w9AXkj0D9SwZKQOzmYsiYJ0F9Ixjuo9ghH85XQ9M3orqqzABIJZgduMuax5OmuvIjCBG5IkYnigGUGVJdwGP7JoyqxEaQ2UWqNRZzht01L8/M498LMG0MpsZ+l0suJbNz+Ba6+WWLVsABecewKkjPC7e/ag081v/uPXn5u/5RXPQ7s1g99uP4JOq4NGzJAkMaAFRGySAUUUO6FRUkNriaLIURa5OelIAzUB5Frg1oeP4oe/P7BiuqXHao0apDSF5hgTpm+c6GWQIkCxruNX5wgdheiBjj5zexXhZNldT4iA9opW6OzQASpap/fZbgoSwqAJGvCKrJsP8HvBouv8qilcTXuN/5fSJKXI7FZOp9rteH2lDOpQiDKrBygzEgfbR69vKzGrAAF5NzpQR66fPofNNgLQ9XRQrnM7q5beYTlHIx00Q8/TjpbHxdeo+J9tJ4CeFYTr3WrD97woEUUCw0MDeOSZ0ZUf/fRPL73+rRff8fyzVqDTSTE+Pot2Ciws5MhL8ngAzjXiSEBEJt0nYgy1GkejlqCvniCZXsCKxQ286zWn4qLTlt/02e9uv+nBp0Zf/9CTh7577jkn4eD+CfzoF4/iN/cd/TTnwlbrsJ4XE9C6xJmnrNnXt6gfeXfeyaumvco2H0xro9SoVthAn1kLIHPWu5p7PD0oIwABj2ERvOF3FFpkJzeBVXfsYwThbIyBVycPLdEnUTxci2No6eupkxlgoKqixh0TXGPz2iHUY2aT22yZasYgBINUArfetWPZqeuGxl/1os1oNGPcetez+O29ex5fvmz4htmuxF9+9hc4dHQCNc6wcfkgztg0iJXLBxAxCRaZZc04Kl1dMcBA9DLP7WqOQhwLzHaBWx86hF/ce1gsZEzVGglKKd34vER6GhnF7g8woO0V4UtruLMYvfIIUALR2mkyO1lsENy48OYAWV45xdozMXymV5zewXIxI5tzVJksHm44SfFKiUSNrgsWBSpy05NYC+2OJjPzlTtko3U4iUk1BM8nAkO7E5nNmJ9jjIyUmU9ydL/RxGBVm07jDo+zCxUd7LNCOpMydYtarvAiwEI07nvhJ5rtIwfFwGi3inYVO6oGgXpk55tUgGYYHBzA0an2nZ/4j9+zo9c+T7/syo1YvYZjejpDs1lHu1NgerqNdlqg1U7R7hZodXOkpUaWSZRKQcsScSzQ39/E2qV92LJ2AGefugzve83p+NL/PvTd7/zsSZx6ygk4cet6PPbMFMYn2x+OIlOUkAkGKG6rJANnnbwa9YQhny8t8mJu9GaO+aC+LEtwKPTXOSKbAiMCr8SFJUDGUTmRdGW8neKqwDV/sC1QtXKOkBWj5a0UnDX2zAEYRCTqSRy7Rijmw7UAi0ypXQOdFRgUVi3rx8rFjdftH+t+L67F7plaMTAlseXEFeMvuOJ0DDSAux/ej3/977vTw5P5mZicxh0PHwADcOqWFd89feuK1114xjKcsCQBZxK6LCE5BwM3yX+M2WoXZlMtEzDfI8b0gsKvHziC395/lKXSbKBVsrR04m6yGATKveukfZ5RNRheVVSVuFfAqJDAHlFUX8wqHlO3KlitI+VFbfRM4mrzQd5ewMdevtKE825ZqLht2+RSKtoXST2mjd0UFzUYn5FQ2tYYQ3DyMgvQjInj0HY2Qn9Uj/65znU0dOZh9xx9HPJRyi7tE+1NhMLtw6VRBsYkiAQ7o15V+JRHpnv6Y9MxQuWoLbetwZe0WkvPBACtbMIvAUPt4nsAXG5Zf7MPC+0OvvjtB9ix6Xn9phdtxshgjL5ajvWrhsH5EqRpgU4rRzeXWOgWmOtkmF9IsdAtMT2bYWq2i2f2zd70wNOTH4BWWLUknjptwxI0mnXc8+T4th/86qnH3/uuF+C1r7wQP75jh77v6VHGIwFIw3sKn2w+cQViVSCVZFyIUJZfUprN/dqcE6C1QiPi5rBqbT0a2JLTIX3JlrvT0KwR0gFNAwMWMW/+rBD4HI1QeYXCHgoOIS9CIZyzj9OWCG7/aZslzbmtsWU3tXKhMDzUwPLFA9/dN9plDMz62gKl1OhPBN720jOxdfNiPPPkAXz563dj99FuQ0cCnXYHJ64Zft9LLj3pC1dfsA6rRhpQsoMybaPMJXQMKAEUuUSWKVtFgplDZ7UEYwYhjk5m+Pm9R3DXExNMsghxLTZldXU4LqIboRFDLJqEXgnBCjHcP8AWbHRuOkk1TW3L9ECoK24o/LIzq7hHXoFpci2prwHfHLIGTHE6N4bnRoxhuMCp49DNc226DnvaaLKYpNAp41/bpFg4Q8Co/6S4ta64V+FexUAXeCUYKOGqMvbBZrP2zivXu7BIkIxZfQXoiwU890MFGXviqWk39Dg8nSr0CnjzXNdVGAcHOixtGQql0Gw00O108e1fPs1mZrv6D19zBhY1EszPttCs1dFsRuiLBLTkUDwGWB+kLCG1Qqej0elKjM2137Z9z/Tb7t8xecdje1vs/meexfKhGhdRXP+fnz1xw7nbNnz8BS85B3/+jovxzr/5IW+XWnGbB6Y1g4gEVq1eDCYzY8cYc4nDBrSYxSwtlS1WauZ7FHN7FF1IaYuyGYcOF5wIBcMvgDB3TqllhdJhTXxviarzxFtt/9dzwqMAwBYHvEFKeYdzMRVMTkgCs4XFWm9CG826wLJFfU4omHU4SiWxZcMy/ZIrNiNtpfjVbU/h8d0zSVKvxd0sKy48baV+/Qu24uytS8BZidnpcUArJJFBEVkqkZUSpdIAhLUIRjlzwdDNGHYdXMCv7zuKx/bMMR4liOPY1e52rlyPwIULEZVAOGN2pc3QjjK9uQtWElG1mzyhK0InZh+/OuiVTZg7Vf29qmScWDhE75EduVuh8vJuF/OHj9j2yNL5MuVVJBa6mxWFWjlIg3Qr9amqqCiWCCBI4QjGBVahv3c5nkMJkQVnwWqsUzja0cW7xDju5dFcgK4qRt2u2FfccavAQWkcPGivGndkPXOKOk7iZJqzMmiRCBUDVFKhXq8jzTL8+t59rNXu6Pe/5TysXjaM7nwbZcnBtVn5y4sSUsHV0QOAZgJsPqGJTauaOOPEkctue3xKP/T06LUz8+nNDaGL8cn2Jz7/P3d+/IxT1+HFL3ke3njn0/LGm7czIWKAMciixMhgE0tHmoCtSmGY3rOaqI0C08LwWJbKeSJaApo74bTTTTv97ehf2XYWxuo9X7knIjNZHH6eWTKHCXqBVSRxCAwxY0ApZaeb5+CRCHx7u1EW2mQOK0UpX6gnHMNDddcDAVMXqR5rvO6FZ2Lx4j7sevYobr5zFyTjhZaFvOrctfr6N56H008cwOz0FGZnF8CFyWJOS4a0UOhmpuyz0va0Y7vyWJQlxmdz3PHEBL71230ff2T3HGNRgigSpric9sx2SjUAKb3uYkgRqvTgrbeHw2HFVBZUg/C0Y/ZZYS5MVZF5QxMgQQbjIPagItJDrj03EPODOzbPukzu+QGi6o3ZhSt0dE1IJ2iSCreb0AkGKWyvjJjd1GzdxgCdhJU94P8EirsHGQXIhcZB1xh31/1aUbgh7T2DSdnacQHW4Pr+Ey7wiu14voUv10dNQWq463ou9cjUKvkKXrBMLaVEHMdIajXc/cQY+5f/vBsHDy+gf7APWV4gS82htHESI47NP4AjLxS6ucTMdAfthQ5OWFzDS89fhhdesOanW9YNdYs0KxqNWv13jxxi3/re3SgB/OkfXo6t60aeUbI09fmZxlB/bVNfs27jc7bPsKuQDECw6V8pCQWNTCp009Ju9CY58bGu0JIwBnfEXggYfIzVhmAYA2cuyzmcJNoSL1y9CnhMmc7aL5cS+fOimG0tdBGRa2TbkWUJqUp3TBnjDJpxiChCX6NmO26tsSyxYfWiS1/5gtOxMN3GT3/9CHYfaiWRYPWXXnKSfO8bzsJAkuHo0UmIOEYcReAMdoNriTQ1xQgLBSy0c7TSAt1MYWa+wK6DLfzqniO4+a4jg/sn8r8RSQ1CmLLSjkjOUj+nj+GrMpBicddaZGlp7mjjjItlKtH4OMPgSA93U4DC/LXeqBCT3UdietC2Pu7+gKmB4nANBteFf52Oou97nm0koLrySYqtstig/e9uA7bSFsVV++HGEKBOzv39FeEOh8GCA/uY54Onb7Uvlfc65GlgpMhNpr7YTep+vKRtQqIy3xbRgJ6hArTirjH0ou1pXoYkHJKHhlYSMQcazRoe3z/LbvrRkzgy2kUcx1BaIctLtFsZsqJAqYwB5xEDFwJcmBLt8/MpZJbj1HV9eOnF6+pnnrREF7JMk0Tg33/wyA17Ht+N9ZtX4T3XnrUltkmqHECzEf1LFEfQymTZ+TJccDwn5K5Ls0cwywrMzmfIc2V1sXZoU2uqXBzQvBcoBHON0jVg+2OFSwRG2iIEzp0bxXpWr46zHdq4ZnlRzMzNt+13RhUoJVHKHLLM4CslAZoBIuKo12Mn/FqZ8jUvf/7Jd2xYN4zHn96H396/H4xDvPiiTd13vPQ06HQBY+PTaDT6wThQKolumqMszKpZJ1WYWSgwt5CjnSlML5TYfXQBD+2cwG/vP4iHdkyev9DRC5GIADjD1qNQNHkFlYnUI/tWKGHbIcTmbzShGGKMnzpuPjnIy5zro+BrtR+/ykh6J+wLrXAxUD2x0D08/r0XDldqORifey4CFMP8xKSKpuFzeoXtud5T284fJZc3oCFRyZ1fCc8DBuYOS/F0pBhJwCdvOavjJkTbQxf00MjpIEbjDWFnFZ2GEy1Eg72xRU9kOB5QThgdaEGXhYiT0Kt3r/yzSqnMRvCohvu2j7Fvfu9BHDs2i0yVRg4FhywVut0caV4gzUtkaYFSlsiVKa4gFcP8dAdRkePq89Zi69ohzTjDgfHWJ77yzXuRZhKveuk2nL5hsdaKkF20hXMO0MG7GmDBsoNNojClt63iS7MS0/MZCmnGbbL1PWLVAdL3JLPyYf8zjVsqWxfbuZDMSY8XcEsxR73Q+mot3UQn6yEYR5qV09OzLbhtHUpB6xJlkaHMMi8QVmsLHqEWR7bLZjvSsiUD61//4tMwOdPBd375OA5PdBdfeNaa7ttfdip0dwFHj00jqTUQCyDPCnQ7BbJMI801Fto55ts5OpnCXFfj0HgHew/PYHKug5JpbNq4AidtXH5/FDEUhepBSHBWwLkeVvE4C9qTDmFoQC6TVSsBc0K3zyvGquBDV61NiFAq4MjxwOdikW5x2fxgx02eEC054aA+BGfw+QnjFUwoB0Y8zPkCVYQWpC2gB30GdAjlh7l7AiVHkxWwUQeb2U99Z75P3rXWoD2RHuX4+JyGRzphfpunXZgyESIej6N8Kkcv/QzG43SSV0VxO+rDnaZFY6D7md3l4pQaGbYg8YPkMeSlJTJjDGUpIcsSp560Qp9z5npMz8xhbmYBc/PzKLIUWhY2vUOjLEoU0hQwaLdSFLJEmktoFqG1kCFrt/DSC9Zh49Lm/loc4Ru/fpY98cAzWLp+Fd78srMQc0eXOtPMrCYKcwihppgn/PzRdvM5AMx3JKbm8lQqPy7SLd6QB2Nk1bYcemZW+rVRYpyEQyGwIgTFegSrEipwwuiFjjOOblriyOgsdCHBOIMsTTqCLEsUZQEpjRbXMKhPRJHNvPfC9KJLT9m37cwNuO2u7bjjwYO3nLBicOoNLzwNzbjAobFpSMVRjyNoJlEUEnmhkOYac60Ms+0MC5nEsZkM+0fbmGsX2LhuKa66cBNefc2peNvrLsC6E5Ygywu798y7bL0Kg6YfA+yxbt4SkLtzHLpxcR643ysxKwSBcboX/owBQgdeWKvoJUQSqPSFQWkZXGfHpCkFxD9ba59JTkhK2zG6yRUaMep8AJxCpOCUpg5sYHBbKFIeoYTX+SPmuaWXtv116NLKoHZFcVXQlpdV6jNtW6puGof1CKhtWOUYIrLq8+hzZSEgMAYBfoU/kjBU4Hb82qM/N8G1pwU0rcL6dJpKTI2UNQ9/N21neYEtGxbjrz7wAlxz6YlYu6wfCVNozc9jod1GN8tsXpYpGyVLE8pJ0wJpZpK5k3psKhF3U1x11qp1K0bqfz3bTfHlb9yDhU6JV738eTh5/YjWWkJLnSqbCuPKWIcAygNKQCkwwTE128XkXH6d+Tk4qZ6EKZSXwGC5E8MdYT1PmGYGgTk/PBRYwxLvrrAq0TWhBGvVpFYQgqObK2x/9iimJucRJzFkmZlVECXNCcBSWdTJwHkEgCPPCwBAKYHliweWvuctl2BsJsUPf/kQ0lLd8YKLN2LVogae2TOKrCzR30zAoNBtFVhoK8wslDgymWH/aIrdRzp45sAsxqfaWDzSxMuuOAWvesEp2HxCE4uGIkwcncZTTx+e7aZ0DJWGj11VfXBaNaP4ClnhCsR3f0kRULY5tWcZ6pAcTR5W+Z2IGrol5iu/OZn6QvR3THfoLkQ7fnL4+/T/cww0SXonZkWZhuNw7figOawBMq40rappghXBs8gt8m3TeYQWzx/nnqHSb0It3CMhFlSI7ZFlDXuqEhP+Gx2sfrHgHuZ/e66xU4zPjOO5V4W9og/4AU8Lp7gDREmYtHe8IZe129niSAohBMA4ntx5NH3ggV1YsqiG009ehnPPXIt1q4egVIljE7M4NNbCsckUU7MFWh2FrADyDGCRABfaHCHBBSYmF9DXF+OskxZ9fKAe4yd3HWAP3/sUlm9ag1dcvhWCa3Sy4mYtFSC4L/gIA2a8GTY0K+0eyoPHFjA9n3+DAvxKBqEkVdUpzhIGvPQGvsdQoceaekG3yIFbQQF3Qkkd9C4RoJWC4CbMt3Pf+E+f3jOKRqMOpXIAFICk0jrwUJ9FWOjk9tkKL7jstPEzztmCW3/7KJ58Zvx7G9cMf/zkDYuxe98o5hc6aNRrYIJhei7DwfEuntgzjYeemcBjOyex+/A8pmZTLF40gKsv24I3v+JMXHjGKjDZhSozRJrh13c8i+17pkYAWzO8F2kEAlkNPGsn7L3CSc4GCT1tcDb3U4zGXMNYlSnhRFVh26wnlcAakgqyo3/cnukS9hekhKqxNO3u761t5RVWpX8IEV3QH0JIpJCZX1ntRS9wR8GT4qZ76KsQZfo+BAyxaIpkz8M3T3NSatUxqPA0HKCHRtVVVc9PujqgT4CgQv6HPPQIuRpT45y+87R2ZsLxxj9Tq+Nlo+JeEZ9sTmwUR9h5aK7xk9v2A7wfWVZgeKSBs87aiPPO2oQN65ZAaonR8Tb2HZ7HnkPz2He4hcPjXUzOpJjvSnSyEopxxLUEC50ulozUsWio9sGFrMT//uAhdDoSL7lqG5YM9711aqb94VYnhYgTODvE7XGFboKY2DcA5KXCzgNzaKWl2RNtk4rpP09okgsOzXxhTUcZ1jP/GMxWIoawiJjNE9LaxHukQpYX4FwgtmWUfZIhoCXgD2pViAXH0dGFV9z76CF95tYVUFJBRGYPIm3W1jb5jcNsU5icM0H/4b4af+drL8LMTBu//t0jKCTfuWZpP/JuC/Nzcxjob2K+nWH6WBdTsykWujk0Exjoq2PV8iGsXjmMtSsGsWHdYgz2N6BlinbaBavVcOKpJ+Om7z+Gn9+9e7hTSCRxYojYU4XWW1MEU85bX5DFBwuEySsZisMEVK/Aa7/Hzis9T0zPTmYRHU1Kbfnh+xiimQDtEHOdNQsC5BWURsJCFtDHjMJ26X5LHbisa0JP0GDalpEGXGoEo01vdgDu6h50YhQzq/bd9SGwyscZDATjDs5msJOd3MrqfRVdGdDB52CxEKUFiNW1oVHZ0eDGFmSOV+gIwG+zYe55rpjjccaz903w/OA6wxNDz4gzzKUlvv3bnW+76Nx1N734ivWYnZgA5xxrN6zAijXLcNrEAvYdnMWRsXlMTHeQ5xJpVqKUJRZaGRSAsmRIGgkwrxBHGiPN+OOTjeQzv7j7wOD7ntg5f8a2Tbj47PU3feeXj3/j4JFxrF+3BYxraIlKuR2AwSQTaDAmMDGdYeeB+e+VEohj7Q9GDonkChWbo9qglTlgmnb1kBIn1GwpEjnSOhMLZ0lLKRFFHMv7B/hCK1O5UogEN+VoNIVhLaJgZs9eHDPMdwrc9fA+vO7Fp6Bej5F2U1MGWCqbH2YmDucMabvE1HQLjHFcfPaJ8uKLTsZddz2EZ/ZPpQON6F1LFzfQygq0S2BhqovWQgtxLLBm1TDWrB7GimUjWLp4AENDTdSS2PjXpUSeZlBCIumvodm3CPc8vA+fuenhD43OFnNxXAuUiBeS0DozI7kmUAmqfEqW2J/8bISfhDOchGaSe7p6VObat5bYuWuuRT9JiVHUH7I8/vkUt+y9x1upymevSqA1gm1gngZwfWQ997pPCCdjoCE9srBVO7RFjmCu3F21l4zG7A2Fe55zuZjbU0i0oy2ohOYrbluP8jq+/zhuzH4LUGgUmDNcTomy6u+eE8Rnq0Bd/XbLP7d3OCzyGCho1ydC+sxtq7FUdnPTSQjn7vpaPcLe0dlvfOzfb7thzQmv2nL6KSdgYXYCUmrwqIa1JzSxZu1KpHmJVsfkinU6KdoLbYxPzuPYRAs790zh2EwXMzM5li3rw+KRen2ilb/u6OjC9265/Umcev6peNNLn4cf/WY7djxzAM+/9GQIAUhpaM6ZR6RMm+RbEcV4at8kDk10Xk8S7lxmpcEiK5NMI+IC3SzDYF+CreuXd8en5jcdHp8/GidxoLzJmJjWgkRW+t2uKApTR2vN8kVbP/HX75Rvec1luixKmINhTdo/s6cykwRKy1SlNB7fcWTxQ48fRrOvD2VRWsirLXxk0MpsM0o7OSYn2zcO9zfwrjdejEymeOjhXZiZL29YvGRwhQTHo8/MYmxaodmo4fJLTsXbXncx3vKK5+HqS07ElnUjGOoTkHmG9vwC0laKMi8QRQIDzRqSpA/3P3AAH/yHX93y7KH5z3ARwaZKHmf9aOx23jhNbyZQdRWJhN8lNwaWn2IeoEl3nNUPkAgxVHtpDYWaPvdeGy4mkDIKkYIObq7E9+w/5/4D7n0lZkOTqvK51932E1PpoDSMNWaOdtobUId3e9qnF0OVht4Y+P6ZQ0KI7se3SYUiQ1r3PoO+IwRXUe6kzJRHYFWgrCt/HfrtMWT0f7/h2/Zb+9Qaj3KrMTRf0SFElMEze+SDKY04qeGRZ8a3vu///gSPb59Cc2gxkiQG4xppoZCmJbQEGkmCoaF+rFy+GJs3r8FF52/Giy4/Ba9/2TZcffFJ6GvW8Oze2Z3dAujvq7+VRRy/vGsvJg5N4bJLz8BJGxY/9vAT+9AtJOIoNgsLjIEJc3yiWZVkgGbopBoP75xGq1sCzJ+jSvMDyij7SEQopATXEte95TJ90+feU7/4zA1HSilhavR7OQxRLjfaUofkBuD2nmLt4saO17/2YvzFX74RF2xdprM0BZgJiIauERljU90hwrGJ1vRPf7cDaSkQxTWzlUdQ8BemcqQQaGcZZuay919w+lp99QtOxcLkOJ7ZO4p6X+OyqFnHU8+Og7MEL3/hmXjLa8/HeaevQT3WmJmdx+ixSUzPzKLd7iJLC0AbN4ZzjkYtxlyb4we/eAZ/+Dc/vuyJvTMvjG09ew34VKRwAgXoiNY9aFXMAzYTqPcxIgrE24BygKZC4aYCf+QyhcrAxzvsCeRu8pt/LtmTjBVZOTCEgWTuYilwDHYo3Slgj++4V4PQ2paADpCombgeVXl3liYjIR7zJMrdCp9XRXVeCRLCqgZoq7re30ffMviuhKgFlffM/W4reDgNF9COe6UQKg/Wg7BIibq2fVOVFyFqH+PSAa/9KmYQhw+e1yt/rLpzo+cfeQFOiTv+A/VaDXc9Psr+8KPfuf/Oew4BtX5EiQAEB+MRtE1VKvICaZqj0ynQWiigJLB08QAue94avOsNZ+HSc9ZtydoZlMLc4uH+gcd3jrGHHngKfcuW4A0vPHXbvgOT6HRSxLUYnMHqA7s/mjNoLRHHArsPzeOZfQvXSAXwyNnPYPCAEBylUsizDG942fP0n//xJVgxkkJn7Srbe4CACUMFkMzB/cACjww10R4/iE3r+vGZv307Tt+w9CdFnpuMXu5hI01uUyrDHBp7xwN7Ft/98GEMjwwjz3MrEKZMCpiARoxjUy1wzta+540XIxpo4IlH9uLR7UdTcIbRY+MHzjx5Nf7ifdfgvFMWoTW3gCNHxzE/v2AnowATsalcwTg0s6WpucDT+2fwzzfejj/71G/Zocnszlq9Dq3NViEWjNdbeVQmkwyUiwvDBy5FWM+rKtK6IuVaa2ctldJOCdFEdv8INQRuQxhrJDQXIhr09LuK2qj/VsHZlJEw3uXuDWmAquJxMUJCMgCobhcYt6haO2XniBv0g2yuR13M7sgIF4W80gWqPKG7CE2xQM3R42hih88J2wqVMhVdZAEvQpr5l0fk4YtZelR4Qfdrj5RJ0ZrvKQ2kd5WRubGFfKDVTj+uoC2H8ugH7wZxaDQbdTz27PQFf3TDD6797s+eQCuLwOMYUklIBSjNwLidOzB/GYtRZAqt+Q7WLK/hrdeegte+8FQ0I/nyiEd9aarws1sew8LcLF75wm3oZgrTY1NIeAzOhUt6N9Jm0iSKUuOuJycwOtP9DbmVrttaA7ZKr1QaeZrhTa84T3/8r16ORZjHkWd2oJSFJbiVAV3lo4Y9pS+YC1YYPFP7BvswPNCH1tHDOPesNfjCx95y7dYThj+VZRmEiFxNIwsNTPcVkCQRjo4vTH/rJ4+ik0eIG3Wz19DWhuI8glQcu/eM4aQTFu285iXbMDcxiZ/97lEcnkgXp93OHa+6+rR1H37PizAQ5zh4cAppOzVHqguBspCQhUSZ54ZxHADjmOkq/PKuffjwP/0KX/7ek0xpgb5GzZbvIWH2KMsJZYC0QtjuEYR3TcjKhpZZO0wMp4Tc1GUkph7xuUkXICZqhwcrhMQJrW3Zb/hnKh0iwd5++cnmUhTMRQF6o45Z1B2glXDsbpwMLnOfOb4/FxLyNPByRe6aaYdToUflkU+I1p7Lrew1NCx4Txf631iAfrWjVzg2QpKkFKuo0ff5eB7pyng9qgTCFVfmiGFQllNI8ArKoHn0tPdczwgQsxMmQpM+7kT6oa+vgUMT2c0f/Kdb2Jf/514cGk3BosiWEiqhS2nOcWT/P2H/Ha/JUZyL40/3zLzve9Kes3lXK+0qZyQkJCSSAAtEMAgEJhmDAxZOgCPXvgYc7sW+xgZzbTD2JdiAMRgwJggMiCAkoZx3V9LmvHtyfNOEDt8/uqu75j3r3+/VZ3XOmXemp7u6wlPV3VVU8tBCJgmaQ0PodSv02x38zHO34+2vfubESMP+r1argR8/cPIP9jy6BxdetANnbBnDoYMnIWWGNEmCV2VhYZRGM0vx1JElPLx3/oZCAVnmsVJYSbTB5Sx6PbzllufYj/7lW7CukWPq+DGMjGTBCyQrQaaMZE1YdpSIFFfQ655/Ws0msmYGVBUWpk/h+dftwN+9741/cPbmsVd3eznSNHVIiBHbWu1WpUSCux49Ir7zk32YWL8eZWVAIXEpJVZ6JfYcmsRLbrgcQ1s34PGH9uP79x76lIU2v/Dqqz/8rre9AO25WcxOzyNL4bZpKI28X6KqNKw0fh+LRK/Q2HN4EZ/40sP407+/442P75sXa9aMQiSJP3LhNhqGWAdZe/LJg8UM0DQW4KDvPdPxwh7cDSR0VltVC/S3NcEM7Ro+KX6MQE2IAMsytQ6iBIZSmLKgPwwo4SJALiAhQ7L6g23y/sPG1dfo2pAFNOF+3he6EuM0xFUiIHwI4U8BRJQjqEakMYyenrYe6QnB0O8g0mMKN6KV+H2N5mJg7sJYo5ERMXgVflpCr+HZ+hAtG3MtkTb1n7XjOiEYDeoxMR5TDLFOT8OA/sKcwQX1hXCnGAww1BpCr0jwkX99UPz1J36ER3dPo9RuoU1I4zaVk2tr/BYna9HIGpCJRHthAc9/1ll4y8svvXV0KN1yfKH/ke/+4BHY5hCuunQLdu46itzYkKpdCoGqKmC0Ri83+Mmj05hZKO7OstTPI2lYgyQRSBKJbreLV770Wfav/9dbsaFRYurIUaSpRKUswpYMC6a82FyQAiOhddd1pAqANEuQJAlEIgFrsDA/hZe+6Hx89H++9lubJ4Zlu1cgS9PAWKQEjNFoNlLMrxT44m2PYmauwtDIiMu8miRIRILjp5Ywv9DBq266ElVH4zs/3oXjU913vvFlV/R/7U3PRXt+Br32MhIhYSsNoxXKwhXQbLQyyLSBvBI4cKKL/7x9Dz74D3fgi996QrRz9dXm8BCUsTVXkMdIQnylxowi3uuVLBErVLrmLgLqVtXR0gl2iAfRd9IjGP5+sPgW4p6kILTxL4ApiYCYvEImxEUCz7ONCoG4bM2Lf/gmg7phGU/D8SJEq4pwH0kNpyu8cmTKwyvdSFMZFAQEKyzr6x8QaqJO1+KSTEqD6A/SN9AlokkgKjQZTlKsRpc1tBQnKI5ZxPaFoErrkVfAnuXvEKxPwj9ryRh4EtLrOIoTXrEHlBynPPAOfRf+E+xvT3etLdI0hZEpbvvJfvGX//BjfOMHezA5l8PKBhqt1ClGqyGl3wpjDISwSLMEWdpAZ3ERNz3vfLz2RedPNlKB2368f2rqxCReeP35OHZyAe12zy1SSAutDfJuDwIC9+6aw2P7F28wcPrDwh1BIz5MkxTdThfXXnne4l/82a9i65oEC0cPIUtSKGVd2cOAEow/7E2iah2Sk7QKGWIGzAIFZpbBKiaJQ0DLS0t49cuvwF/+7s/qsVaKvKyQpSmDb64FIYFGo4Fde6fEl779OEbH1kArA2kSQCXYf3AK69eP44pnnoPj+47jJ/c8NfW8q86y737r81G059Btt11VoapCWbjKJ62hJoaGUvQLhQPHOrjthwfxkc/cg0/8+2NDOw8uiSRrQiYptHKKWPKJDowsg8CRQoJHVs6+RZeDRNf4lCohCmvjCiRZLk8xOITC5YoEn1AYKRtCCsYrGgSrG+IppBRYjCzGX6IwWzaHMQBtV8VcgpCEvxH6QEIUaAOgjmo8qzAFHFbLEHVbCP4zRBF+Ar7oqdt+EpC/jX0dRLVBuXPIYfl768ipHsMbSAfFlSM16a+TUonIlCFM1kYdXROSsiEllg3BnkgL9yIHjfi8Od4QwTWvI0mO6CLUs0DYAW/pCo1LUDvubqUsABfAf3z/rPi7f7nvjX//L/fi7oeOY35FQyYZsszluTemcqnMK+V2ynse7XVWcPONF+OmZ2+3e48sbr33p0/gGZedg1QILMzMe/ky6HQ7MMriyPEuvn3P8Xy+re92e0ddv918CKRJhl6/wOb1a+Rf/ckvT1xxyQQWjx+Ay2bl3l9VLntNYPlgumh+Bcl39P1BArrKsImQqE+mKcpco9/r4c2vezZ+/xd/xqIqYIyGTBJ2r4A1QLOZoKcsvva9nR9++qlprF83gSyV6CvgyPE5XHv1RcDGDbjr3keR9/O7f/1N12M47WNhdhal0SjLHK0MGB1roDHcxEqusHPfLL75w3342Ofvw//7j0eG7n9yWvQU8qzRcGWprAuWa6VgjHYCK5kldIOKlpQhCFo9srWjUzayj/AMKhm4koQ8Y2xLsOdrMD+8WsCyPUGBQYUIzBncXTAhJyMTrG9UhrX7ASTBZSa0SHPNUTdppGh7AmrhTMB7GjInkADWFV6df2ghQJCcB6ak+YjXYjHcWvxHRMVeU57gwi4CbTnzxjHb2s8a2h4YZwypMPQZNmoizLVnpPh+Ujgs2MzHYFn7YrCPA8VeubEZ7Fvso/XGLNKTiEBzK4QzDBqASDPMdsqvfv2OveKv/ulH//pPn78HDz5xEkvLGiLJ0GhkyDIJmSUw8AtZaeLAgOrh5191Bc46Y80nf3TnU2iND2HH2eM4OTmDFAJWV1C9HL2Oxr//6BCePtEeko1G7XwtAGRZAmMtmmmCP/n9N+sX33gxulP7UeYdlEZAaQttBCqtA18I5kJyWgNAygXMoTOvsT0hy6rywXcBa1O3gTBN0FnpYd36DO/8xedi/9FJ+4XvPiEmxtfAGKpnGGMbrWaGk7Pd937mG4/8wV/9/svQaErMz/TQaffx/GsuQndyCff89FG88jnnvuHi7Wtw4tgJtFoZsgRIZAYLgem5PnYfm8f9T5zA409PHz081Tm7lxukqUtxa4U7dwULFFpBqwpZIpAJCY3EwVefNj4wRTD/AyjG/wzVrRGFggeQg1AFpSF8tlUTrtfaIoTDUFhEbNGSU9ei2xpgir/FhlLFAUHToMi6g70vMFB9JZDDxOAWDyCgiERIaXikHuo+GsY3tW4EV6hGCy/0sNann450EEwhWJYxllY5ha9daihvGNFIiICeiU7W8zH1mM/r6eKI4Tqh3aBYRW18NEZCriHzBbiQ+dtNVC42zJFg76O/TC1ehmBIufaK8ydovMJvWTAxNufYyI8TFkopaG1d5fk0QZqkkEmKo7O9tx//3u633/v40W9ec8nWm6+98iycf9Y6jI1IJEmKBgTKCtDGuZdl3seG8TG89sUX3Hrn/QcwPT2H87eN4+jBWTzrmedCWIXuSon//PFB3L1rWhjRQOLHJgWgrauvCSFRFjne8ZYb7Rvf+nKopTm059qobAqlelAGENZCaeOyI8Ozuo0hFSEQYsdpQAJ0EFMKTlmEoyNSAImr6gMByCzDwlIPmzeuwe/d+iI8/PTxvzl4vP3ekdEhFJUJChBwOb9Km+Injx5fc8e9h1Ze96prsLR/PzZt2YgLLzkfux57AqOpws0/cwl6HRewV9piYanEsakl7Dk0j4d2T+HJw3Mj04tFzwqBREikiVvRrCqDShtoC6TCYt1Yll167tbymivPxY/v3Te1+8D8VpmmhPkDaqhhbSag4XtGMGPrwezAUl5YQp6qYDYIEciIwoJVD2/yt7pngwtAigp05MQrWZZFFYT2gLCKHtCfb5+vutErCXPxsdpAiyheUaFHFBCC7USDCN5i/5mrw9GE0zN+kd0Y1k9SekxYSZGQKpYuTfLgvYRk6/0V4KgooDuad983Gkf8OyrvOEcM7YXn6V4/HkJA4Xs2fnbcC5Q4lBRQmCNbM5KSzdUqo8n/DgVZIxqJ7/LPW40sAZqJQFVVKJSCyjK0shRZI4OwFsfmuq858uOn8YMHD1xx/rZ1T1x6/iZcuH0CW9ePYmwkRaPhMlg0sxRl3sEN1+7Arn0ncfDAUZx11nocOLwX3d4yRpoNPLTrOL72k/239ksXO3dnIWPfkzRFt9vDtVeet/j7v/dmrBvKsXjwGKwqoSqnaI3WkAIotXW1KUAYgzwnzmNAClgIg5BOBzZCcwBIUxmQiEwSl6TMGrjdsRZLSyu44qIN+N23veAP3v0Xt73XGHeGSes4sdZYNLIES52q/e17DuFVN12NVEpc96zzkI4ZHD10CM9/1vnIUovjk4tY6lR4av8ydh5dwtNHF26emc9vKwoX/Hel0dxellJZaOUOgg+3MmzfNH7eVRdvPvDSZ+/AS154AdaOrcMjTxzdUmmDZkplUqMrwrRUtMpBeAgFMbnyZOQW3AMA/yg/kxd5MMTAau9iK2z8/b7RiBaYQPgGydoHIbRMKQU0wBia2g/ajtGB+mCjBeeLFBj4nVxjytEvMLhaZoPidcfNIuqJZIiCTv2yfne9K/oQDsatUjzGIGRkdUgkLqQIcFdTuPABV4w05UwRceQdqMYAbVDSIs5RTfG5QdTuXUV3V90PIe55GiTodB8pXLIkEUnyy9YzZ73v8SOsy4NvjMYN119mb37ps3Fw33489Phh7D06Lbp5Aa0kskaCNM1gkwxLebXz3ienxQN7pjExnG4+a9P4kXO2rWntOGMUmyeGsH5NC0NNi7XrGrjh6m2YOjaFM6+8EJlVyDsdNMQEfvzQEUwv9j8t0gZi9lhH6yzN0M9LrJsYwQf+6BcmLtqxBsvH9qAqeqiqClpXUFpDaYtUAqqyroKZZxd3xjbyPtE35S6F9ZVFEpmEiRdC+g1vEkJKJD6oDuFgaVloWKPxihddhJ+94yn79Z8eEOPjaxADoO5/UiaolMKufVMfO35q6d3nnH0WksxgZWYOi8sW/b7E/U/tx4Fji9h7bP5jh0/13pNroJlJjLRcoLFQBpWy0BaAVgAMNowP47KLttkbrzsHL7rmHFxx/jpkiUXWaODfvnU/dh2YEjLJPNRmKYutrQt5TVAYM7OldOG1VWzCqTTHmI7RBClGrkUCQw+srtFPY9nKIXuQ9TUoGSCUCyNrO7h6FxRnKGtma++OGA3hek2JwXpD59GniajLeBfFXXf7iCQX1gDd4ZWRe4sM20CIFl4hwrmhMtR7oWrg7lQA/e74SZ6msLIfN23Q9Repb9zlpzmP8UJaQIl0c52N/BCuWcQD2OCokjksRENfUo4UFuXwcveyfV80bTXUGj+RV2jBh3UP/F30bOQDAaCqNJrNFL/2q69DI+tg9wOP4Zu3P2p/dO9eHDg6t36pky90S+lS8kiJ5lADwlos9dX03MG5oUf2z6LVTLBuKH32ts1jD5y5eRQ7to1j0+Z1/nhghc0b3WHr/UcX8Mj+2U+VRqDpfLzIYYlDn9Yo/M6tt9gbnrcD+cxBVN0VKFVBVaVzdZWGMS4rS1W5PPqcPlw8A8DiK3BkZ0OMAUC/X0IpDUhXmTpNM1TKlUlKpIFIEiws5di6oYm3/9xV+NHjx1BWClma+tiZTyAngDRJsNLN33fvrhPvfuPLr0arYfD47hP44neexvHZ5T+Yb+cfWelUgHArFcMZIIQPyvtjLlppAAYbJobwvGedZ9/w0itx43MvwNo1KbrtDubnFlEYjawxii98dy8W2xWy5pBjXstWsxCtKtUcDK6NqAs1JxoXkBgjIuoyF2uA0KQYaEUtIKeaBa23EYL2AWm4Vl2mEF/zEPS+KLSuJZbITwwICCGtgfFxdEDfGeZqWWtDhCHUaeRK2fc3IFh2JtEppoh8JA+KG4/i/A5/ypdOJfkIbTrlhfB8DTWzPsPEY+McAWLADePzWpuGAYTkgKtYdS3yBAXUjZ8Xr0wH5pjQp/RME5M2AhjY0MqRZzBKCA6Cb98jV6ZICS1LKSBkgh/dtVP8yyf/zf7SO34WO85aj9/7tVfi9a+4Bg88vH/+Rw/sxYM7j3/w+MzKB/p95yU1MokkkUiTBMa4A/hTbfPgqfaieHj/Eoabp7B+3dBZN1+/9diVV27F2okmluZzfO17+3BscuWdViR12gLI0gzLK1285HmX2be84Xq0ygUsL85DqRKqKqC1QlW6WLtSCokUqJRCWVJtVjBjRJwqYAViWbVgkYxDEvSpygqVVi5zqt+vk6YpqkpDeYiulEU/7+PZV2zBa194gf38t58SzYlRGChEobRIE4mF5aL9te8+gZc8+xxs3rYOd92/Fw8+fUq4Ih8JWq0GrIGHk9qfs5JQxiIvKowOZXjuVefZt7/uOrz6RZei1QLmZxdx8HAHuqxgTYnhiXHcduc+PPzkKQGRuL3/NiqR+ImancNSHnOoBbRrDIdwffD3GpIhxvIcTIJFdHETEd0ZUoTxnf4J6ZCKYHMTkJQdDNYT89gwtnAWMwiB+G/uZ9e58hN85INxFz/GoNDjNgH+iXzNXEPGlGEsIqIk4wWbTglw5cX7WFMspEAHULVAfW79oEHL86GOpacFLJuDAcROqCuSh6G1MIWRDkGBAghpZb2y8TAy9M/Rl3auM/oSrU9DW5oHPqY0k6iUxl2PHsI732HQyyv0qi42rRvBW255Nl590xV4dOfh93/19p3vv/2e/duOnVo6VSmJNE0g4cJKUkgkKZBCurCNkTh8fPn4V7v9HS978UVHt2zehENHZ/Hjew/c3q8M0oYDLi4+DSQyQVkpTIw18RvveCnO2pBgeWoSVVmiqkooVaEqKqiqgtXGr0InyEuFslJHiQBBTiBCEkMBQHIL7mjpIDvFEoqiQlkqlwbHJxpL0hRWCneuymgICXQ6JdaNpnjtSy7F+HgLZVmBAtjGOEthYFEooFsYrF03gpWFDnY+dQraHwAXFtDGQvvSa4ArtNYtFPp5hUvOXfv3f/aem+y/fvjtuOWmZyDvLOD4kVNYWGpDaQWtS1gYLC3l+Nr3d2KlWyBNRDhyE7ZIeP6qxSJsXREEZMYY35gY/zndZxC9gNA9yHWICsH4vFnEcFwI+e9kUfnfJMhWILQRc4W5JowlF4rrIRoNavfSH9xyGspX499NW5tCF9mYDXjQfIAG/m6OEmgGiCbWN0w/pXXYiU48JCz4HwkWURWnDZ9byQKY3B3k8xzJsTqeRAgqbM2pEywgN0JWLgyz+pRGDaGaWJWH0ywqx0ifUE3pdP22iGmZUZ9L6peEgNYGj+4+8OHJk9MY3rAWaUOi2+1gcnIaea+N668+Cx9676vwsfe99uQtP3OpXTOUoSwqt5HUuOeNMjDKhYqE1RgbHcKpheLYPQ+dRGt0DOPrxlFo+6DWDjEba12hW29sut0+XnnjZfbaq7ahvzyHvNeDriq39aKoUBal2/Kk3RlKYS3K0qAszROk2A1lb7Tkx/j2hRB1QSBr4FdQykqhVBoi8bnrpYBIhN/8RscRAGWBXBk848KNeOk1O2yv13eTY4hRjc8vZnH5xVuw/sx1ODW7iBMLHWjrlk1ZXV7IxG04LYsSLSnwxpc9w37ub37x3e/5pRciTbqYPX4EK50e+kWJIi9Q5n2UZR+NZhP37zyBXftmBCBDHikacJhnxmRxzLJu2VYZOboP0Q0E6n8TjBdw+6UCrBervg8uJQlaQAURwcU+MEVlEZRYsNZkqbygciXK+0pzLITLFMoVTcKRiYhnB2mfW+QPBDRB6IRnsqDzsRHxuAYJ+QmIEJ8LdKF+0UZjiNq76G9+SQjU3P5BBVqbQvZs/MIroAEFHLmQkBjRkfd1AL0KFz8WAnH8A2daaRY5Ag7jBrnHRDjPbdKFYGoKt67tQhvR/kV6yiTBqZmV99774JNorh9BIxFotVouA0SlMDs9j4WFOVz/zC342z++Be//jZfayy/Y+BVrFFSlACGRStquoWGUq2ovhMD37z86tdwz2LF9K7afsfb9AtrXivQJUa2AqiqMjAzhtT97HdY2SnSWlmCVciBJW6iyglIKqnJFcq1WkEKgKDVype+CEL7ieYwvW2tD9XgZJojoETS8I0JRVOjnFaTf1eESWAikiV+B8kufsEC3U2DdmhZ+5rnnI0sFqlLBWgTkopXGUJbgqou3wRQCh48s4MCRxSEppDta4ifN5S+XKIoS2zatGXvfb73CfvpDv4xLz9+Ek8cnsTLfhoJEv5+j1+tDVSW0qgBroQ1w+7170emV7uSAYVaeEQCoW0hHHB+sC7xiw7NOhpwydveQcqb4iUdWbPd23SggvlOEroRrq/pELgz1N7h/XvkNWObIxHWUGUbCLD4XxBqqiBCp5mgH9MrZg9COjYahnh/d95kZR9ImpLg5jclNCEiY0a5+0iG+k7J1hD5YW1tQ4K5sLc5FiC9QJ94fQikYeJ6B7sGYGdGclFBEr0TJOh8J4qMAF6MhDUYOFPt1m1Hr8bDT8/DgXAEWWZqg0y3wlW/dD7WSIx0aQqvlF+mERJJmMEpjfnoWZXcBb3vV5fjY+29+wxtecrEdbrqcgJaN0cLls0+yFI/tm916+OgcJoaHcOV5W5Gl0sWojXEp5tME7W6O5z/7Anvl5dtR9Doo89yNVQJKaRTkPvrdDbRdqdNTyAtzd5LQgiKFgVgSKGMgaSBuuNGK07VOv0C7V0JmzjLy/OtpWkdhRVnB6j6uu3Qzrr5ok+3nhbPe1rmEVaUxNjY8cc2V29HO+9h54BTm2mUukxTaW0L4hIlFpXDFRVu//49/9baVP/ztG9HtzWNuegqAgrYW3U4P/X4OYyoYVcLqCkMjTezaP4sHd08lhGxiNWUAJlopsqjEwCQkVEk4uNXhDlE77e/Ixq26I3ItvhKuRoEXMrZbt+irA+qEDMk9CcqVQEEYQ9360n+yJkRg70FNKRDyiUIkA7oK6BQ01qhMAW9s5ADSGECSJKCUZYNifaS46HnjE00KYdmqpa3ROMa6RBh/RGX1BZjad6v6JwKNAx0FxS0J8clAw1pSQnqPp2Gks58jQWELg9rbB+YqZGYQsW1vwlFDoAwhcoRc06JxcH6KXMMOPSe465FDyX1378LQpnVIE6DZSuGODykIuASmquxj5tQJ7NiU4q9/7yX4vV+41m5e25RFoRwyThJXaUwbNNLEJy6dgrYSV11+NkaGGt5rcLyntYaUAre88tnYMJ6g22671XOfF1BVhT/8rWCtgvb7xqwxWGjn6OX6wTRJajQg+gYvwhpvjRgTWCt8nFFifql7xezcMiBlhL7WOhSWupVJVSoYrQBr0O/l2LSugRddew4ApxCstVBGAVZj/dqRb27fsgbTJxbw0M7jLqsEJIzxykYIFGWFqy49Y/KTH/nFm17xM+fg1KGjKHttQABaVcj7PRR5AaUdpIW1kEJDQuBbP9mL2aW+SZMkhLuJ6ePGzjrqAWgrgAjsE+G8CG6EUz4Iq2u018W1F3erG2P8zvDIt1Q7sIZkAvhlyGeAJ4nmXNkYY0J/KUbGx0SZK2pusm/M+Mro7t5YGs4aEw5u8/TKHHERnThaqSOXuJotQo78qBAiYorCLbywG2PiWUiQa+jf7f9v/W77sOoX6B37aGx9hdJahlBZa/B9A/uG9HOgOSLKRA3FM0WGGFujGB2hZ3glG/rqjZj0BiIiR4S5DCgN8bkwx+waMBAqYO05BUpPCGSNDIudwnz2a/fBqARJlqHZyiCEgTEK1riTK4BBmgLdhUX0V+bxnrdehT/79RfrszaNvDQvlJcFF6eG7/cT++extJLjsovOwBnrRz9PaDNJJPI8x8UXbLv2+mvORVJ2UOQ5EpkE97Xfz6GqEsa4+JfRLmddVSpMzq6gWzgUV48XRt6xsFTRO0JgbnWzrIHphc6uE6cWAK+Btdu077Za+H1hxroVQyEESlUhSwyuufRMrB/NUBTKJzh0An3xOZtv2LBpHIdPTOHpg9PXSV+ayc2hQFlWuODcLdf+04du3XLtFZswffAEhHAdVmWOIs9RFCUqo6GUe6eUBq1WiqcOzeOuR06OGO3zTdXMbuDTyLAs8C2E8HufZDyXxgynYKv+lOmArtS9MB6wZvEUMh7etaSzmbxzg2iC/6QPCWgtbsQRn4hbPBhWCQw+2DYJAJWY42OJQfCorIyNG3AJxUV3kBBgfQyeSsEt4ojCVW9220KkTOL9fPw0P7KuyHk8KsyT/4Nyp9GHK1oeH6QxD9LQMveUz2tw92LLdcNBFPd0iKu/cUHItUexPmqjngYbREfvbnlHlLnIq3mjzgs2/F9Ktxh2xwP7tz/92BFk69YhlUCr2QCMQ2HWaufNGOXrVyhMn5rGa190Lv7k12+8/cwNI+uqytV0BXvPgVPL755fauOsTeO48oKtbxPCHRsSQkBpg1e86BkPnrG+iV57BVDO8EoBVHkfZb+AUc5Ntn7jbZoC7V6BU3M9lArIEjp0LFbPH1hGVpqgYFlh0WikWFrp48ChU4DPM+/Ki/s9R74WpDXOLxYWMMpAqQLnnDmOay8/y7o9ZRJGu+MIl5+/BaWQeGLPSUzOdh9sNpJgWatKYfPGNWMf+YtfffDqZ+7A7KHjsImEqjTKvI+iyFEUFYqyCnn2HUTWSGQDX/3hPkwtdHou7z1TTDQuDKAHWmUUcVMm+dqO4cj9cX+RmFomhPWEfAbcQgLRknIkJSBqOamCZWdoIaCage8JXVA77t6BjAsgpBfdtMHJDwrEI514iJqEqI4Q+Jhr/QPrN0Nk1IhDrIFyQbgZEIIEuWoMkdToMICIB2jEaczfz2Njbmyyhsii4NcV1ep8YRhoB2xVkhlKS/zD27f0RfBy6m3xUEXkHKp1CeHjb2FeB9rk8z6AlvkcpEmC6bnO8a9890GItAkIg+Ghhss/Z3VAwaqqXIFk7zVMT83gJc/Zhj95x/Pmt4w3WlpF+W+kCU5MLn18amoJCQSuumgbRpoZjLGolNsQ/4LrL8RoWiDvdQMIUEWFfr+HsqzciqU3jEa5UzzzSzmmF0oYkXhFzpGyrc275IghaHDhBCDNUsAYHDw8hc5iG61W6l1FH5T3zJ8kriq0tgZWCJRVhYnxDM96xjYIuGM/1gKjIw1cfcU2dLoFdj59Egouc6sUFlWl0Gom+MPffcPKy296BuYO7YIWCapKoSgK5HmOSmuUVYWyUjBwJdyErTA0PITH9szhjodPCGsFEkI3AdFEwXMWQAR6EH4IyeACg4hg9ejmgKQir0bEYcmqini/lAwEMAGxEdHUPgFB0Ibb+kbVGP/gK8c2jJPHiyjwyeNTJBwU76E+1vshAr3IQHDe4LwSniC+YePiq4MQIuAPysQK3gfSUAiXgus2+K5AQ3Kp+GZehsi4ey/ISgkwOkYXjI888gUbW0Cxns78fYLNO6MNodWQA4ve7RU9V8RxYqJqIqVco2/tGlPgZJiCcIfhQiBugs4rja9/98FvTR6aRLZmDYRQGBrOQAiQPCGlDTQstBVIGinmpmfxiheeg9958zX90abbaJxIgeFWhry0ODbdQWUsLj1vM0aGMmktUBQFzt2x7eLzz9sKVXShisLnr7Po9XvIezmMNlDGhEU+WINUAKfme5hZLt6YpmmQnWCowhRRDMwypIFYkp1gspAZDh2dweFjc8iyBEqVToFpV2lbwAVcjXHBfFiLslBIJHDpeZuwZkig8Dtqx8eHzrvo7I2YP7WMp/bNPiElHGozBkZXePVLr7HvfsdLsbBvJ8rKoCwVVFWi6BcoK4uiX6EoKlhjkSUphFUQCWBKgX/7/h4srJTIUgnhNz+GCT8NekBAMPFaRBUiCMAgc0c05C1+aI+u1RVK3RhGBrOsbe5Jhu4SMw4+F7J6suuMsSNiYX0PyAtxXoGQJZTucc8bhng43UgxrUY6UbCi5NfjY/WB0jGhVbEbT8eaIrHsKBPdO4A+6v2nWgJxzHyOqU0ScGovokmGHplipUHQajkQ94aFBRGGggLdYWN/rHXVrdg8xXmONBZh8L4/ot4mH/tqlFnnO87XaZrh4NH513zuK3chHVoDa4GskaGRSVijnSdl3Eq+y4jq3p8kCaZn5/Dzr34GXn/DBda5nQZJ6rY27HpqEv1eiQu2r8e6idb/hT/3efXl5zy9diRD3uvAaLfSWFUKea+Hoiyhvefm9o1pWBiUymL/8TZml4qvpokM+78CLLBMWcNnZCXLL4l0IroXzaEUh04sNHbvOwGkzj64HfgWRrukYzLxAuucX1TGQkDh7DNGsWPb+PfJPTnrjHUHzj17E6bmFnFqduXqVKbQRqMsK5xz1sazPvhHb0Bv+RDyzgrKSqMoc+T9HMpW0KpEUZYw1iCVAomwEEJhdGgIdz58Anc/MSOsSOPKoIhj4a5ajG2xsbIKMI4RojskgIBioivk2U1gQNgsY0DfnhCcp8O7BX8/U65CUBAeAFu1C0rJv5jHiILyGBh3YHYfdKV5prqW8e/V7QmPLEjAuLXngsQFi5hq8DvrkRAdoTHs3ZxmgpCljXThQmlYvwREzAVfQ4P0vzp6C0jM94iPQZBWo28tG0OgIas/IIBazc/QPlOCgn3hDSLVRgiY2CKMkVhjEHlZEbfrEN/U0bDHWYEORLeI7kiWpZQoNfDpL997/uGnTyJdtxGQQGNoCFmaQAgL2ipkjQ1IjOi8tLKE33zzdbh0x9o7japgrUCWSjx9dA4rvT62bl6Ds7eOvztL3Agvv2grxpoKqsiDoaiqEnleoqoslHE42hqX9ifLJGaXSzx9bAXdyuXRd7p/YH5tHKWM8Qgbko2SYBpj0Ww0MDvfqx574jBMt49GJqEqV0jDGAOlKghfMENbDaud9jeqwmgzwRkb19xErsz2M9ZDNIdx8NgiFpdyI2SCbq/CcCvD77/ztcfOvWgdlo6eQml8kC/P3WpjqZy/7OtKCiEgtEIjFViY7+EL39+71C80Ml+23CIKNbfAbiIDQPdERTjZwa9R9SIQfaxHTYy5TBAqtmkUFB/0POTRBmdSvgK3yo2E8HmkBPF4eJ5cRh4DswERIPaTlDAYuuFuDSLyouZDrUUCk2GszJqTIuQCVkNBTCkFbot9CgrOj5M/G+pKWlJYUQ9E10jE8QX6MDRmCVn7Nk38PSIWE9/nDStfPSQFzFGhsYSqRUSODOUS0qP7wPvpRsr4ISpwC7CzplFJhXlznMwQGY8vhilmz7r23XMi0JMbiSRJcezU4sGPfuYHsKIFiARpkqA17Da3UmZYwGW0UJV2C0dCot/JsW5c4p23XHXDSCtFWWmkSYoj0+3G8ZlFDA8PY/vWta5aNoCzzlwPo1zM2lhH56osURQalXIKUhntTt9ot9i3/+QKDk22351ICs3ETMGCwIBwx5xcHn6y/l57x/iQ+5lICQOBx3afwKGjCxgZHYItC1itAatgtYb2gX3AZVS0HhIOD6XYvGENAGB0pIkrLz0LNgGOT82hNACEhDEaz73mEvtbv3YTlg/tg7EKVd5HURRQqoK1ClWpXGoNX27cFX3QABJ86fY92H14YW2aZXEcNrrCIfZFKItWHsFRhA2wXvpMAt50IcS9AnAjwsaAtCUrhWj5ra9OI4Ws5a6PPGrrAh/QBcJchPaZsHDBD27oadBQFFYbxkzf1eJTodWoGKgWJi0EcDqF9kWwgDWlIYSnNbkxDA1RG7y7AV2S+yQIh8SOCT9vgtEEGEBKsUGmWPhKJF+8ILDqeYPmEKK+py2wgaj9i2SvI9LTodJg+GiuCXNZNnYb6RwcZOIVzy92oM2oKDkfmWBEo7dB/XObxYUEFAQ++41HxF0/3InG+Hq3+pc10BjKINP66q02Bkort8sgSzGzMI+XPf8cPP/KM6zSJWSaYKVfVCenF4FMYMcZa5FIoJE1sGXDGhhdoipLxyfGuPTwpYYygLUCxsDLtttHuuvQAiYXi483Mioi6YcrBZszx50QiJW5hZA+FbQXTLLmxmBoqIHdB6cb9zxyGFmawFoNrd2+EasVjFIhb5b2+77KSqHRkDhryzgAYGKstfHKC7ags9LFkaMzEEKiqhTWjY/gfb/zepR6Bd2FGWhdocj7KPMCZV6gKt1OXbcNQwJGw0Kh0Ujx08dP4ut3HR0xIkMS+I4mzVtz1JECt+YhFuaZghSMm3OPWDwSoSyd8MjLeikI8YYBa2yZ9adfQtzDxr+5sFgb7wnuoruxppSI0YPghLbriMf9HoUdgm19CIikjgBPF1tx5KnfLwi9RhgQXLGQqUKsbo82aVJaGQTSESqprzJRzv2AXH2btNt91VjYPMaq5TbSjeaLjzFISQCd7v0DbdcRl13VFr+P8xwpXjcHNvzkyKkW4ogswjwAW1POAXEOzPfg+zkyg6dDI03R7Rb4q0/+AEvzOdLWKIx1lb3TLHPnnk1su6oUKlXBaANdWfR7i3jn66/CponWC6yxKCqLU5OLKIsezj1zLdJEYNO6sYkN4y2osg+tSwgBaKVRFq6imPFAxxq370smKQ5P5nh83+LRbuESP/DxES2iuy8grICkfR3RCriVM1rlMtqg1WpiaiGvvnvnk5iZWsTQSBOV6sPVtNMwfhmWQ3drNRqZwOYNYwCALRvGjj3jos1oLyxianYeUiaQMPjZFz/Tvuhlz0Dn8D5YCBS9HGVRQOkKunIHPa01kHB+srEKWUPg4PFlfOobe29f6JpekmRhroWIFWioIKa1bLe0jQzIYxZCEKOh1hbgXGuqoBnQwIAltqi3RRXAOVPJqNKCJYnC6pEKxb+40JAVJfTB0B/dF3aMi/jegB5RRyoRDbL8aGHMJAx82wUiZegBghHBBfLKh+ANQ2URxQ32wXq5FJEGbH7InROk2OVqo4PanPn5Yqgk5CyTcUf36nierM1nIFsNfUba8gSOHJWGMAL73aEvhtII1nmUzxEczSXNMa+5Wq8otZqPavEvP5G04h4UejQFEDLFXY8cFh/9zB1Ih9dCZhmsTZBmTaRZCpklwaDSP60UkjTD4mIHl2wfxsuv3XZXCg2tLWaWuugVOc47cz1ajSzbuG7s+uHhBFqVIb2QqiqUReU3elto7SoZGWhoCzzy9BwOHF8+O8vSILdCAPz0CpGPfpecEI4n/SCFhITwp8sF0mYL9zxyZO0P7tuH0aEGdFFCVyVgDbRSIW8+nWDXGlC+wK0AsGXdWGvteAvTJ2dxYnrpX4212LF1/Xl//LuvR7kwhX57AZXfZa/KEkZX0NqfUNfWH/ZUSKTB7EIX//ifT+Lgqe7L0rTJuE7UmMpzRN0acUEfsGaUwYGukWWmbKGBqN4KcPQRn6HfRe0dwT2wTmAItUW0YN11E1enDOtDQJakNN1bIjLyfE1503h/rcVAT2vkCc+TcJPy4gw8KDgghE70Q0RgJEQuPhj3cdXfSZxYRzaUptn9qyOdgEoZsuON0jYA6Q+8r85ZJuLYKM8+61yI+wl2rpMDHU4LNu460mFKiN8XlB8jHurtDrqkMcbqARsiCqsbwDiDtapWdLVGe0fLLBVIkgz/79/vE1/9+kNoDo9CetokMnWutBAxjkhKzGhAJFhYWcYtLz4fa8dbrwYsjk2voNPOsXXLONZNNP9h07rR7zaawsXIYQCrURYFysLtvCc9U2mXO/DoqR5+umv29uWedmEr48MfACiLMACvDAMTuHQ6EF7DCwFXnNwrM3+fURrDrQwnZjpL//6tR3HoyBxarRbKft9X/jGwRgPSAD4BoUtn7eI/DQDbNo0jGx7C4VOzmF8q39HKUrz2ldceuPiaM9E5vhc2ESj63aC8jDbQzlGGUhraKCSJxVJH4V++th+PPj0v0qzhrY37IQWtzLC9T3LAQrMJJqUdmE1E2YnWkggR5df4jY6UzYEEiLcVCloIciBYH4i1agqXMa6fJFnrA07TBkcvUcAZkFglSDUhGVAgVsT4VERGcVsNvY9WCsHa4t9HFOQVUs1skvHg72CKkVSyn0s+RkIa/13cidMC/H42/tAPzyexlmlEtQKihmgjTdwYKU4W3jfQnxieGPjbd6tmUDiCZfMj4hCiIQOnk3s4tr2aDsHNFAAlixRsLrJGglIBf/LxHyV3P3AUQ2PDQYallEgSt8czvM3Ltkwa6HZznLulhasu3PitJBE4Mtm+faXTx7rxYZy5Zc2t42NDkNbEY3fKIM8LlJWCDosnGkJYVNrgzsensffoysuSNAt9D28WgHeBXEacSDhnrKQlDQ+nwKwE3wVFB1MbzQw/ffiQ+PK3dwI2gVLKnVb3O3jhoaKDiACshDFAkgJbN48DSYajJ+awtFJUZ29f/6zf+tUbkc9MorPSQVVUyLuFzxOkURWVz+vt8jHJBFhqa3z66/vwg4enhBGZnxBDR1/jaP2E1nZeB6EdsJyBueERhScGs4oAIYCoyKyl/UaxHfonAnJFMASG9YFiNbCW5X/37XiLF/rN+hwsuY1vCmAFq9FBRHYinAPFQNs1oQj8Xlf0JBThbxPhV8ASIq7EURsCHP3ZgE6isq+jF2ttQBDUTwEKZnO6RCVS64NvQwcUGekQelFDO2D0W80X4VpoTwT0VqMHQ2t0zXtxbo59a9bSyicZHJYTjtm1+GO1wqrFtwb6HBSaYbwg3Hv4x/XdyUaWZVjpFuZP//aOb+3at4SsOQQNA60dmHGNC1gtAON43hgLDYl+keMVzzkba8daOHxi8WWTU/NoDbWwdeMaqLwPVRWQkpCWRpErFJWFNS6bsFYaqUjx2L5l3PXEXKM0bluG9eeIOYe67RYynH8PYRkhBJAIyMRVSLaQIX1umAXraiw2sgTLPY1/ve3xd9/5wGEMDQ2jLApo7QL3Wju4KOiQsJQoS4VmlmL7mRuBNMHUzDIsJF764qsePufireiePAwjgG63j6Ks3CKAqnxWCA0Ng0QCK22DT359L/7r3klhsxaQpgAsEuF2BUuPIslq0dy71LoxvbJFFEbBxhmybPhjLcKPnVuCQbdlFRIgpvZUJ6VKsZzBZ/kztW/j5frfETzUEArNNp2vi20D0ZpxC+3+GXAlTTrL9ycgcjZWEVFeRC2+PXh30aMYh05jhlMyBIG2TO1Qf4TwJyV8sZA45vhOoK48tDW1McDPYth84PvNKUzZXYUIeC/0ywwIO28zzHfYf+Y6T5loiT5cfCAEpJWQInEAglADIroFUFNchEzr76Vn+OJAfCbGwGz84jRMJUhWhITb+WnQyBo4MLn0mj/9yI9w4lSO4aFhCGFC6T7hjbpbRHFx70QmWOjkuOy8tdi+eXhPu1fi5OwSRCvF5g1j0FbB2hJZ4uSpqirkZaz1qLVGkgqcmi/xnfumHphazKs0EYA17rRCMDoC1gpY65KpwvedkktIY9zKgAoHNSO/gLIEwEFBozWajQYOnFz6+Me//AgOHF5A1shQ5AWMr6obM04CRgO9vEKzkWU7zliHQkvMTK9g3cRo6+aXXguz0kZ7pY2yrJB3c2ilUZUKZaFglIbRGlYbTM/n+Lsv78TtD5wSaZY5i+lyATli+PNZgjOtjRM3GLsITD6AWIhpQlJNsm6oB365VT498iFIH7mSW0rOeKQQaHWwFhPzfQj7lCwpYT++gRVG+j0uWEQkubp/fp7JmttIt4BaAuqxATXWUJNg4wLFd+BpaEKSQ4566LtoTGJXSeJiHBC1vgbkw9sEH0NdC0S0Zz0qiQfxXTyH78cjceFxt9Xok7aNgNNo4H4+DsCnCbK8hgKhw9XKlxR7vGdgzuJEMteStYnTzBujczQw0dgBGo1GE48dmhV//NHbcfhUH62hBoT0MujpZwx81lS3glwUFZqJxvWXnXGREMDRk23AJti6YRT9Th95XyPLMsACZVnCGJc30LjcWchLi28/MImdh5eup1BDPAETZYiMBaWXN9a41UxVQa5bu2b4grO3PKuRWvSLEokQSBPGQEQcYjxoJEmGe544Jj7+749jblFDJqkrjeQy6jgBEwKVAXr9CmPDzfecuW09cqWwtNLDjjM39a971gVoz0xCVQpFv4A2CgYWZVFBaQWjKlRK4+kjK/jQ5x/96k93zYnWUOaQg4lL4mWZI5EWsNozsyOEFHVrRYzI411BIdU5o4Z+eAyk9uFaKPBUneEj0nAPRHchSi3ZTQIKPI5C767vZ4ovHVSe9E4KZofsCByd1NAWuybq/a/F9lh/OBKIyiOW5ROAs6D/DblC+z5pJf+Qi2XhD/cytw00Hhsb40aL95voXBu3pHOYvE9sHL4lMZDpg1Ao0TGg6YF7+PsdOf2EevoZREMjBduuI6JiXBULtLQIEnk5uobEGzFe5u4f6D8G+ckjTeN2DyR0BlgYtJpNPLJnRrz3Qz94YPeBFWRZAggNq91+TGu128ZkKhfzFkCR93D1xZvQbGQ4NdtGkUjsOHMdhNBQViDJMhirUVWVU3xaA1bDQOC/7p/CnY9NCmvjfsI4evJkHFpOEtfvvCihdImrLj/r8ec/6zwrr7hoR/dr//KBh//sD95gN44h01UOa1wxDaqEDONSXRhtoZVBkgAyTfDtew6KT3xlF1b6CWQiobUrTmnhrJKuNKpSY2ykdevWrWux0imx3CnxnCvOxuiaFqYnp1AVCmVRQVcKRV5CGQ1lNRZ6Gt9/cBIf+vwTye4j3TcOtRpIhICEK8GltUFZFnjBdRfZ33vnLXaklbWMNkExgSmvVdaLKETf+e8NuUcMMdiB3zlqcQrIR3t4bq3ae6PLFPJdDVj3EBMT8eCtELSiJAJzhvvBUVBEB7W2bcxYWhv2AC1WxdkwkP+dtRlRIqOfj5b6DFcDyCoiCRJUC+6u+RiZiXMggvCagCRt6Ad9FzoPWjmk/oOUAUPYlrl/htGHZMbR2dZ4Rng+CP9CvwLjhB8cPYb+ifpcBUVsKS9dbIfHs2pxOP47aDrqKtiyfoS/GXp1t5PC9MpWCLQaAg2pQSlyhO/X0HAT+04tXf8//u+P33jHoy5ZoRDGL6xV0IaqB1UAgE6/izM2DWNirJGdOD6PbrvA1k3jsLpCnmsImbn9X6UL3rsTEMDtj8zgtvtOirzyfOurk1tWgdta5+QmQkDpClWVY3w0wS/93HPtN//lt698x5ueD9lbnoUdbeJ3/vQd+I9/+LXypueebxuJy/pgqDgt+89RxiATAlZI/Mcd+8TffeFxLKxIyCT1xyQIBrs0sRPjrYtG1q1Br1NBQeK6q7fDlEvI+z1UVBdOlzC6hILEgRmDT3/7CD7xtYNiZrk0jaY7MS+k2wtUVgaJtHjdy6+y3/3PP8XrfuYKVErnbqvroAUaQBR0PSiFuGdIegbjFd25+xDRWkRVRJ86Kokgi38Gd8TXWqqhDKYoBsYQXEu6PsjYto4QTve+QVRK4+N5xmB9OCAkGeQKF5F+Pgml8G4tR3huczRL/+NjRwYICR9F6EMdHYXzp3xsA/2NY6yvBqJO2ajcwJBKyBfGVruIdr7/geP9vNL3mmXACIi9hqDh6EJ5/0VUzOQS1ftNY4v9q80poxNXhuF+kGGN9zj0GpG7FMKhLQACBre+9Ub7p79zix1quvzztIVHa41mI8PsUvHVP//kg+Lfbz+ElS4pWLddqlIK2ue+L4oco02N888YLmeXeksrnQJbNq9Dq5lA6wpSSlRaQ1UKSimUCvjhY3P4jzuPi25f+dkxoBocFnFhSsLlCiyrAs3E4OU3XGS/+Zl3209/5K1oT+3Ht7/5I8iT8+1bl08dh16cwXUvuAzf+Ny78Lfvf509/6zxbxZ5jkq5ssLGr6q5BSg3EVK6SkXfvGuf+MvPPITDkwXSLA0wWykHOdeNt4CRYXSXulDa4LytY1ienkGv00VVlTA6h9EVVkqB7z08j498btfNP374pIAQkGkKo7Xzv41Ev6wwMdbA+971Gvv5z7wbpqXxpW/8F3o95fszsPEy8GbdojmeI38kxp0iy5OARkaLa1P/vVA58ggM5mvn8SX+bIx12BpqiG2aGgiI6NL/XhM664t+rEaQcWx1VLoKYbJ+AWCbR1f3l4QO1lUTiAgmKlCGHeC1HijOwZEFucPkFrp+kbvD853V0SYJMlfMEQVyQxXHWs+pxvkj9iPMEz3v6e4ORZ8e9ZIiAeC3HNSP9hiv7zlaqveN2uTtijDP8X00pjBwEPKj9qRYzUvBOzEal50/gd/937+Bv/nj19kNE611eVGEOTLaIE0ltAH+5VtPiw//2048emAZvdJAW5fFVRnt93paWK1wwZZhLK3kH1xe6GLdxDharQxlrwB8yvmqUOh0ge8+NIN/v/O46PQp5m5q24W4zOVVhaIocNHZGx//xF/+kv3mF38XV18+iqNPPIhj+w5jdilHOjXX+fTM3MKnkkRgaXIZSVLgF3/1Rtz0kitv/tP/8w37xdseFd28RJq4ZIYOCVF2BgUhEsgsxU8eOyYWlrrf/91fuOqmKy/dgCQBIA1GG8CW9cNAo4Fuu49ms4mN4xlWFqahyj4sLLo5sPtgD9+48yTu3zUltLBoNTNYIWC0hoZEpYGy7OPKy899+Uc/8PbvvvDGS9GbOoyhVgv79s9A2wQpErg67kEqovVknyCsxPkkiKdVIAx5MYRhrEVC0hvy7kdxhGDxkqgX6siLLKYxkJQhwnMaPSckuZUx0B5QoI0KJrwn9JFbe44+qH8yoANqPyKBelwwxr6Y8ouvQIz1IAi8gDgt7WPQGQGxOjcUnmaENmKwnfrNaUJxI2tt2OcYBB11xMrRKFW3Ybra9Umg9h4m80ExC1FPNwUhagsOYTTG/R7mxlJ7HjULcoNXI0YqRRiVDjEonw+ifUSIpMwCu1mEPW7uDxnGpTSw88kT0DOn8Na3vQznnLV1/n1/+e94fN+UkKmre2G0OxfcaGS4a/es2H1kOXvOZRvK5z1jHbZvGcZQKnxRxgQwGtvPGIN97FTRL3Ks2TCBc86YQCZySFQwSmN2XuHbD8zge4+cEt3culTR2tWVpX4qF1bz5yNLjIw18CtveL79n+/+OWza0sTCwacwOzkNY3qYmu9gerH3QdntVzi0/wRQANnEOFSlMf/YHowNtfDJj78Ln/s/P2/P3zbxLpepERBJ3OgqAQirIWEx1Myw6/D8yz74yQduve/xWTRbwzBWY/14Ezu2jANlgV57ETs2DWO4KbA0O4ciN9i1fwWf+tZh/J/PPSXu3jkjRJah0WhCwCLzsTatNCQ0XvOyZ9vbv/Qn333+8y/G9NN7YUpg8dQcnjo8+ymLBDbs2OWIg1vKuiiF3xjCCN9xBvffx0CjY9qYfSCIQWRk/wwFigeRl2sXtbgY76BTKnFnfi3WMYAchBckcnm4koioiuWtCqJGcTQeL2NxK/D3mtrftPDgKueA/e6+5xlLqR8RZUQla3wtgRptAloNFwJNgkDyOWZIKSAv8LHX6RfGypEWGBqlV9TmKvbdZUEQfrGCVG68h5JABr4KxtHU7o80Zu9BNA5ikA6WVj7j3NXjbKERR2Om9SJ5BbS1ODzZRiIketPzeN4NV+Frn/kdvP7GS20C6zK/QPrcYBZJmmGhU1W33TMp/vbfD4z8+/dPYM+xHsoKsFaiUgqb1jTRFHh23s2BQuHsMyYw2pIo8xLHjq3gy3ccwfcfmRR5JZFl0mew8eEb2jYjpatzYUo86xln9v/z/73LfvRDv4ymXMT0k4+ju9JBXpVYXuhj/5EFTC/0PiABYO++k1jslGiOjkCkTVStIXQmT2Dp6D68/s3Pw3f+9Xc+dsvPXGKz1G1ZcPPi978IOAEAMDw0hEOz3U//7b8+eOsjO2cwPDyMbZtHccHZ62GXF7C2VeDlz92BQhU4cmwe37rzCD70xd1v+9Y9J0W3AoaGWjDwFV2k28tT5CVGhhv4o/e8zn71C3+EoWaJucN7UUJDoYGnj8xiYaX3W0LW3YUwk2CIa5Ar45yG6th0geZbcAUVUAOZuRhYrjEbs7bUZN3tqjNWdFciB7o+m3Avj3nwNoLbGdof2BNFLgejxaAi5cooti3Y83UXkwuea4+9l1BUeE/8ruaaDdB3MLcXodc4frcJ27A2amPh9w70vf5ORqtVtIjxMiFiZgpyO/kOfJ7TTAjU+kPrmnQyJM5L3QAEGvOx1nVinVZwtLYeQnCUOGigqSkyoNSmkICGwMmZRZiihGwMo33yJNa0DD770V/FH7/jhXZ8uCHzPA/JDbVyZxWRCMyslL1v3HNKfPTLe0e+fddJtDsSVWWw/Yw1uOTc8bcJVCiKDs7fPo71Ey08vWcWn/2vI7jrySVR2gSNLIni4fnMQgAygVEaQ60Mv/OOl9gffP2PWje+eDvm9j2C3twpFLCYb/fQ7XQxt9zD3pNtrBT+LOQju45OHT0+jbSVQcgEQkgYKWFKhfl9B7Bj2zC+8Knfwp/85k12ZKiBqlJQimIGAKyEtW5VaXSoieMz3U9/9F8fmnpy3zy2nrkB27ZOIF9ZxplbxnHFJefgjjv34B++9Dg++4OjYmqx+kKz2XCw1WtlN4munt2WjROtf/7Y/7B/9qe/iMXjx7AyfRIWgCoKQBd46qnj6JeqiqWESGZiTKBmrQaQAfE0Z5rglpCQIgbrg4pjzDnIOPTTR3PYO2P7g7/b2t9krRFyOtFNhBAsE8Q6sqTD9NSeCc/yd9rBhxAMf03oeYyGxmUZ0iIkRJlKYwwJ/nrMjRZFtjYgd/DBIH7L3hnHQXPhFYgZoGEwFJF23GDU4k38WTC0whBc6DtDhzVaWN7fSMDwnACsjbFK+t1asKpWsY1Vk1jrP4+Vhf+FuWJPxJMMgV8ZDY2FgYQQGU5NLa2fnV1ClrhTN712HwvTM/j9d70SH/2fr9FnbBh+dr9foVQ0t26SEukSDc6sVL1//dEx8ZUfHsbRmQJZkuKGZ27BsNRoLy5g/UQD/eU+Pvefj+Pu3TNCJQ0ImYQEhfGImgREgqJQ2LR+RP7z373TfvhvfhGqPY3ju/dCKQMFiZXFNtrLKygLhZOzXRw61X7CWEAODbWw++D01oP7jgKpQJqlSATcAWqlgMRi+eRJlAun8P73vgqf+5u327M2j61zKWAFIFK4IwcSxroVpmariaeOLmz92BcfxPQKMLFhAqgqJEkDdz14EB/6zL3/+sC+BSFEiiRNXaUj0CqVBJCgn+c4c8v6if/4wgf7t/zcMzG3dxdUfx7WapT9LqBzGFXg6UMnobTb9kHxgpor4ZkzlNqKvheD1TTndcsN6/ODUTvEoKsYrL46RNeEgN9k4K29w60Mlvm3sr07LkBsSfWF+yIS5DxPKACrwCXFlwgFCcpLBgTEAPCffmMj+HVCLqL+/jC++E/6MmpCSCRJEpHJgAKoI7NYmSfirqgoOdqkKkOENEKcjo0FqI8JYPnKgsUfRDVeIfo5kSLu+wKhW7iFh9OFAQhNOPn2i0N+lzhHwz4i6oUXsKAtPwGI1BE6KZ2Io2jSfewmos2Axgb4Q/A/QDSTkGmKfr9cOH5iFunIsEsnDYlSW0wemcRrXnY5Pvvnb3rgvO0Tv1/5ZIQSlFHXbWxPpICUGX6wc0Z8885jOHxyBefuWIc1IwJWFRgbG8G/fuMhfPu+Q1eWogGRZMxjk7AigRCuxFpZ5Lhwx/rLvvzPv6Pf/PpnYHL3Q+jOTUIkEkVeYWlhEcsryyirHFqVOD69gsn57guTJIHMsgx5qbD3qYNAXiBpZD5hIFCVJaqiBKRA3mlj6sBe3PKSC/HPf/OL8xeeve59RmundGScBePzN6VphvsePyb++asPY3h4GEJqPPT4UfzfLz74wWOL5duTLAmn7S2bikRK5EWBs7ZuWPe1f/uzxauv3oSFp3cBNofRCmXehar6sEaj02ljz6EZKG0BEVe26DMYy4lungWfcf4MD3oT1gnrjxEm1YSxxtiEXGjPlLVBMdASsWMkixDnoD6IiDLc94PWP76vbnlj0J3a5217cxwFkz0ad/kzGqCOfrj3Fd1dhGywFIOjB9yzJrTNn4toWNZQbaisFBBLdNn5XA4iwhBbY0qmdj20F8cVhNnzwSAarb+jPte0iTq8g7uCpPxMfU9gMKjEOxDO1hrK1ktbU9jCA7/fxn4JbxVriIwUKKdXbeJoDhCMTKkUnjpwCkmzAWtcUlJjDKywmDkxiWueuRGf/MBrP3zOmWNvMD7TDKePsRpCAmmS4ae758V3HpzEiUWFoswx1Grg4JF53HbfiW8tdOzOJCWF7o0hnDJMkgRlVeKZF55x/xf+8Td2P+/KDTj6xONQZQ4hBMq8j+XFBawsLqHX7aIqCnS6OY6eWsFiWy9nWQpJeZKe2ncKC7MLyFquJpwQAtq6DIqqLP1EG5w4chjPuWILPv1Xb//glRdsurMq3Qpl4na+gvK4SynRVxYn57u+MxWe3DuFIzP5B9Is85lbY8oMWo2oSo1tm9eO/edn/3j+iis3Ynn/biRSQ5eF2zdWldBaAcJgenYJR0+tfCoqlng0hGbNMEESA5MwGJOqMQUIcbnJD4VvGcqiNvnf8Rwp3AF6Keo7070QRnRE7yJbGl2akHdsYEzxb/ePhLuWOULAnxMMt/n3ciTFEAIpB0YTAb5pdiANNgkLa5dW0Gg3PQb6HOAf2PUoeZFGQWHEeSJEyenFbg8oSwjUaleSeZRytaGhfX+8TV53U3h4xfkjxMGAkK8rzKX/R6v0sVRdbCPE1YTwC2IsZQ7rBw9XBN9+FcLkMbbVyLJGKz9v0rrzw6rS2LV/EsJXvnaFVrQvcCwxP7OAy85fg0/8j1d/5cyNIxOV0uAuMbnqVghUIsHD+5Yan/jq07c/eWAFjSzDXE+hU+ovQIqQCih4IHCKL8/7ePYVZ/U/8/Hfuu7Kc8dwat8uwChYbaGrEp2VNhYXl9HtdJH3e7C6wkK7wPGZPkqdIE0zSG0FkAzhiX0nv3rw8AkkidvX4UJ97ixUpTSqsvBLq8Ds5DFcccEY/u7P33TDVRdtfDwvciRp6rY9WOdKEsLIEoFUuNQ4ZVmi0gZKu9UNQijOVUugFTAx3sI//u17Vp557SXoHnoKSUO6RGh53214VQqVKgEAh4/NYnq5eidkCoQVnriiVlNExqw6qEtoK94nYnYIRDQEi8Bkgwgvrvi5ccQsngztof5cnStZrI6e9XIVA/QkQCbszh9Ej9xK08/gWgQEBEaDoPVhLduNDtaX4O56xUfKhCtBr8xseLffbuBRpzsS5JQrFV0Q1obzdMIbvlqMqkarSPfYR8voxe06R3oDvxu27YLeAwRECMQcYMaY2vtrSA4D/WQIP/AQU7qcNwCETAvOWwHIpRwcd6A/IS5iGTZz8MjO8mcY0qH+0Mchc4METgZ37z0OWxRIktShMKX8jnsFCGBhbh5XXDyOv3zXSxbHRpqolIahwhk0VgAQEnmFaufhxZcdOdWDRYJEZjAaS1YbAAbSakgf425kKbr9Pp51ydYj//jXv9q6YkcTM8f2uTnUBlZprCx3MTu7iE67i6IoocsKMBpTcz2cmOnd6oCXgNTaYqjVwJ5Dc2985OEDQKWQNhNYXXk6uISFSmkYq2Dh8rwvzkzjqosm8KE//LkrLzpz/O/7eYE0SZ12ph3nVkFp5etaGPSVDhtiCc5S7iGtDRoNiQ+89+ftq26+Hu2jDyLJMkBVqMo+KuWQl1a+Taux5+AU+qX2Fi8ydogBeAtKBJdsJ3z8cESCcBbOWfwQBuV3B6VSq5Ad+SsopIBimAtiLWo7/YOGAXMRyFWEreUzAyISDO8ceDGvsCTEakbmQIfHo1afxQOjQ3yW3L54j/R5/wnt+DhmoLlHI7Spk6AGWQbUV/HovavdZBpi/dogIuYD/O/aqaNdu+q9NSWEOnInxF0zOIy+p/ud2NBpb4BcRUJwNYXHjC7t5BdS+BoL5K+4Bql3RP/BOGW9z57ctH1BSuw/OnP+3OwyWiMjLtuxy8gAWA1jNJIkwfLiEl5w3Zl479ueY5tZAqXdxnZKeEjGLxh4AFZINBoZRCJbFs5gCbhMFlmWosgL7Ng6tuUjf/62HVefO4K54wcAq0NZxk6vh5mZRbRXuu5sdOUOWWttcWyyi9nF8tNZw2VtldYYZEkCpTXufegQ5ma7GBpqQpUFqKKOtRZKGVSlP51uARiBxbl5XHvZJrzvN1/57vGRBEoVcP6uH5gBykrvrbSB0QZVWQE+txgXcmsBoxVueeVz7Lt+47VYOfokIDJYA5R5H7pSUEWFKi+hKwWrDcpegSf3TaHSPncQ361tWPwlKDW+ImTr7hJjopqQiNPEJkioV6EUZvW58JC41+BgZK3BEvZ0L1lTyu0UhZBQI0NiloQmtkdtchRJsRgupKGqEvXDW30x0Kfa+wgZMmlblQmU0OogqiCUYCPCjLfYMHaCHNaTzpkTU7s/xDQ9WWroM6AfsN+ZIhNx20iYCz4HNIfs78G5qsXC/D/D4nDg9w3ykf8X9rY5mImQM5+5h46niJYcEUZ9TdMeeZnRnFA+GXnjQMPcXPvg3qePoTE2DKtyaF2F7MpGaxilIYXA8twc3nLz5fj5V1xiE0G8HvkgjhsQxsBUrviONTbnciilcLE2q/Gn73nt5POesQ3Tp06iqBQq5QbR7RWYmV7CykoPVaVdaTetIYVEu6twZKqLTmGRuvYhnUY2EEmKB3Yfff/jB9x2CgunjYWwkMLlxq8qpyWN1bBSQiuL9soyXnzddrz7zc+1tupBQCPsyQJQabtXKQNjATWQFkbALaGrssCF52698UN//ivoLR0HKg1hJZTqw2iFIs9RlQW0VrBWIU0sut0eDh1fmjKaAql1pMT4Z4DR4hk8uokjpMC4p2FSYu5o5GjVqc7oCHua3MpZkkRUKgbaFF671MBP7FzNLeC5vjgSCu0NIBlSdo7T60iDv4hKybsrcYc+vz/usyOaUryTBM/dR6u9QYkj9im6yIMojGJAdfTIAYUPfSOsWjL0SBPD0WIgJfVZ1MdkazQXvg/1OYr/+cdZHC1Wcuf0trW3C/9y6zviFLZ7g3OtfQzYlzIL/FtDvUS3+rxyfqkp5qC8bY2/+AIHhKsRUFQKD+w+DDSakEJD6xKlKmC0cnFwn+lUpkDen8Pv/dLzcN0VZ1hjtDPuQkD4PTCk3NOmBISGTAQg3KZ3kpkskei0e7j1DS+yr3r5leh1JtHvdKC1hYFGUZWYn1vC4mIPZaF9QlOXPz9rpjg1n+Pwyc4HhUzgQL6BBAy0URhuNrDvyMJfPPDwAehSI8lSGOOq6QIWSSKgtUZRamhDKW0kiqICTIHX33QRbn7hRbbX7UEmsVx9Veh9Re4SHiodeM1/JMrKYHSkhff//tt/uGHrMLqzC0Da9FleFXrdAmVZQfk8RLAWiQUmZ1ZwYrZ/sRHCIUWvMVfHEVDbMxTRSkQVgy4Bt+SrXARCLczNG7TsGHjOGKDO6BGpcWQVFSftGRqw+KxP1kMTa+rMC94f2ktmjBMtpmU5SojxIyKjUxexbwwZDQiOsQYGqzNxuBeZVc8G0fToMiBDW1cqhLys5fNQV8AhXmmDKg9CW5sSEat10/vq1bsNMDA3hE4J5tTAGp+TgPzqMa86ah7kK1q88gsf4G35efZbgqhYTj3dTOSLuIpsgnH479/rM6p6eqvS4N4H90L1e0izDNZolEWFqnI1WKvK5QJLhYDpVxhqlHj/rS/Alo3DE8pYp6AMoUM/F0o7AOIRFe0PTJMEvW6BKy7ccuc7f+llWCMN5qaXQ31HoywWF1cwv7CMoqhc1W7frBAuZrf3WAfHZvofyBqpc3dhIQWsqwuXOsv2wMMHcHK2i5GxYWilfGVp6/MpSSjt0kjDGhirAFi0u31sXNvA2295FrZvGX110cuR+tWNSpt/KkrtNsgywjpQYKFUhec950r7cz9/A1aOHkSjkUCaCsIq6KJCVRZQlQssuhiWgpDA/mPzaOd6OZHpAEPFuA1B91oWCLafiMcMThdLiWlZ6swb4j1M2RBErsWwmMXj7lRw4Qbea208aEwKoSYYtfHReDAQdGbozsfoXIZT33e2m7xGLzZ24ZUwdzMtRyQ1OtEAGWoI7oV/zyrkUN+Xhdo4624J72v4negZnmfjgQjvCWgJLP4p4hx6QgWkNEgX7pZSqCOMhGlaIQbpuXrcnNa1T+CFiLIsGRXB3xX7E8MZg0ZjoG+D7wqKzyk7IwQeefr41skjJzA0Mgq39UX76l+U+saZsyxroL20gqsvWou3veKyxVbqsnJQjJbsaJJICClQGQMDPOK2SwjAuFj67/7G62+47Nz1mJ+ddN6ctx3tdh/zcysoCuVjatH4NrMUs4slnjiwnPeVTzttnfcmCUEYr1Ef3HU8eXjncTTS1FsK4+MyQJI55i+KymlJHbOm9npdXHr+Orzp5c/8VlUWkNa4HGFK9/v90m/TipOeCCDPK2xct6b1h7/9ZujuAnTRhXOTXI79brcDpZxfDrg4jbAGSlk88vQMSmWQJDJMDLc43D2gmAqPS9UmmH0XBNoSYOGrj3XFZK31KMBdNxYwqDN+jOfU82zFGBJTOMKtggaFw4S0Ft+JnBqUxCq0dhrGjmg0KuWoNOrPxLiYjX3h7bOxkQCaWs1KJmhMCYccYGHkfrHExu0XhLq468nkLx6gJiTKaEjE4YLO43MmrAISQrcehUbkFONUEQlSBwbn0NiYLcRlJObKzBkYjh7pXVFnRrcyKF26Fuak3kbYi2bjfJDq5sgQ7LuICo1HRQaJEJiZWZp67IlDaAw3IIWGFQZKuQSE2hh/6sa5comUmF1YxJtefjEuO3dt36jKZ85y2ZoBuJ/GoNOvoJTpSSmQpQlW2j3cfOPV9qafuQz9zjS67TYo7VaeF1hcXEavX4WtccRPLvtHiqcPt7HnyOKQTBN3j3e6QtIlpTWGWk1ML/TMD+/Zi5V2idZwy+W5FxJWOOudZRmMdVV0ldY+97VFXii0hMFNzzkHV1+48Ug/z5GlKbS2eamcT5ylNLHWKT6j8LzrntG//oWXYunEUcjEEdEYjV63gzwvUFUu8O/wikaSSJya7eLRp+c/bCzlyBa1iSJBceiD0EsdodmBySbEQtcJIdLHteX6LoTwyNQJPyEvASrbOogaqHfEZq5HcQe+iGlrvBKzgIulkSAMKCmOnGooDmDvrbtFg/G8Wv8YWAhKR7pYSdhfFmJV7hNWvhgYCsbBRjo4QXcrTGHllhmIEICmmJrwlhyyNtY6AiEaxkHX5jXQnLmJjDrBEAzQpI7kEOhPNBmMtPL4FwKS4jFV9j29jwGk6PwKrm8Q9t0RamVGkVcPr78/0gCIMViuhEkxWuvSAhWlwo8fPAghgDR1O+MtLIym4jxu+5E2GoCEqhTWjgBvePF5rbFW4sspRoqUWsNIi3auUGmbp6nbBtXMBH75rTdi64jE0twcrE+zbYzB0nIb7U4/hlocDIDRLmvFSkfh8X3zWOm7VUzaTmOtdZW5DdwqIZHi7gcPvv+JfbMYGWpBlX47BYRrMEnQbGbQxqDIK3fQU1fQyqLT6+OMTQ287AXn76hK7VSOMXnRLyCMQZbGw7H9QmH92jH81tteCbU0A9XvQAqnwYteF71+B6os/OFxZzGsrpDKBA8/NY2T8/33JlkGgTjrNeuJaFFpYINVqTkzAwh7dBya4pbb30cJnYJ14/EzYqaoQFf1A3VFyi0+CXzNlQlWs97XyKT1/jslevo4XkSY/Jl6bImjO+PHasP5VC5oMTAdlB2JvKVRxhVPwO8LE3EOav0O//doSPgTHUHp8pXJOnolax2uMXoOvicg5fqS3UA/bERmQGgnzDFEKLQLEd9tbf09joZ1OlMYIfa/rjQ5X3C+Wu3K8jnlSjrOoWX9prkjmhIShTceP7r/wIenplfQGh5GIp3xMMYpMQtA+cU7rRVggKWVDp531ZnYsXXkm1r5XH3+HVWpYEqLufku8lIhSSSW23285meutM++ajtW2nPo9bqwMBDQ6HQ6aC93XV0LwCkv4UGOqdBsJNh/so0njyxtIZTKQyYyMobbwNdsNrDv2OJf3HbnfvQriebQEIzRbP+RyxGUZRkqrVFWbk+WhUFeFpC2wHOu2IyLzhn/SlmUAAQ6pUKWSgw1XbxKeyY//7wz7YtuuATtqaNIswRCKBiVo9Npo9/ruWpHvnacsK6obbtb4O4Hj6JUFjJJCZ5ElOIFi6OSRCagWBAGmAXMvam5UPC5nySH+86hDuiOoZFQBxIk/AOMSQoWCJWGxeA7hfCCHpEl3Xc6Bq6PI7oZ8W++KbcuxPxZOjAu2BzLhILLNuzoj+7hIA0HXBf2oTEQDVxshz3vszxIUlRERRFdKlLultxZMGMgGJ0t7xkCahMitgfAr5ANCP9pOh+MX7gsaj/Anh/8OAVDBoMhYdAcCoTlExvU5Wk+pMQiL9T27NX6RyiWcBddi//CuOD4I0kSHDw5/977HzuM0bUTyFKJRjN1tCeDLBDjUsIiz3OsWyNxw1Xbbm6k0h3lozmWEiKRWO7m7iC2cqN80+uej41jwMLcDLRyqK0qS3SWl1GUOQQivRIJCGuRpRJFJfD4vmVMLpbTqS+5FvnfUrVI4f1NjTRxRPrJvfs/tWvfPNaMr4GickhCwCFGgVaWIRECVVmhUgrGuA1neb+PrWuHcN0VZ74BcAhsabkPAYvUu5BKucDcy198DeyQQLmyCGENTFWg7HfR66ygykt/pky6IrfaVR7avX8Gjx9YGALSeOQDEfJzJqY89fz8GlnoaK2YD8KYD56pBaXQtDEW6IhhgrBxxgjuJxM+WF/CjL4gizWgjIwxER7H0khBUDnzUfv8H1eaXOmGfsVGQmEJBlDDvRT/Cu4tCTnFMQfGS0IJIDw3iEytjTUHiCxCoM6QVkR5rCEWsN8pRmRX9Tm4pYwOAWFGIAJSh4KNgfgl0Dz01YaVXsZCnGDh10Flbi0Qyn5y5ERuIa1+ChZYYKhRCOqL/44PwtODj0EQcQkB836wMVIQ3xqLLBFQlcG379gLiwxZ6sBJ2nLVv7QrJASjBbSyUNrAKINet4trLtuK0eE08jmAlhCQRmClk0NboNfP8bLnXGSvfdY5WF6cQW+l491DjU63g36/50CKdxud/hXQ2mCo2cDhUx08emDhBsApNuNTWRuf7lwSDCZmNVqjkaV46vD8O7/904PQSiJrpi6G4bWksQZCWjQbKYR0mlT7EuJVVaHZNLj0/A0QAIpSmeVOjiwVaPhFAKsM1owN4cbnXwjTnoeEgYCC1hW63S7KPPc+t1OqzohZdAvgv+45hsWuymWjGRhDCBHODfJq2Txoz/NI1ZjRxy547IOEwUFsv+QtSJSjQLrrsXguoUDG0SCEJxF3XgvYOkOz+4QgHBIcjPD/GsoMaluE5/gufD5+otHgql5UBFEIJXuGx2folf89UqD7KAAd42V1JY9VdKrFn2roEDXkFOOXg/m5pEcxNswV/5BCo/YDv0ebx2hrI13DuAcQT2wZ5OoPolpOFT6ewDukZFcZAR5W8HPstJTPuBLnB4PvFICFi1lRe6QESdGtmjHf5nfu2S/27JvH6JoJJFKg2WxAJBaQCMkyjU8PbYVAr+hjxxnDOOuMsfuBuAq5fsMImkMJjFEgbnn9zddhfUtjYXbWuY7SoswLdNpdVJVCAhuOUbsarxaNRoLSAA88NY9jM727kyRm+AjevQVk2IvjB6i0gUgcY9x+154PPvzkJNZPjKIqVThuaIyF8iln08RlTC2KEtpoVEUJXeY4e9MoLjhrzfs6/Qrziz0IC6RZFiZ+fO3aCy6/cDvypVmnBIxGVeTIez2oqgSMgdJOeTliJNj59Bx+unOmYZAy1y0qnLg0Hn8PbpnnpUHLTSgkookBVBOYUAQt4i6Tta2fneSoh6SVuyekLla5hGABaIvAtFzpkmKg9vmY6Fke8xCo50YH+50QhgMChADjHjfrzLZHSx5JWYByU9XcXlApN1qxNf64WAwg0/Owg/S1IWtypGFUQnV0iCCY9DcF6CONYzC8XmMwNlJDXgIMjUa0Rpp3lQuPGGcE0WnAGAVFFGact80MXWCvAbTI5oe3a2zsRw2RCk7ketiBx3Hr/O5erbVBI8uwvFzgc197EK3RUSRJhkSkaDYaji/gEJzWbm+YMRZ5v8JwKnHxjvXXpWmMK46vGYVSQN5XqJTBhdvWv+/ZV56F7sos2isdQEgYpdDtdtDv5WGcgIVMXJp2a1yG550Hl3D/U3MC8PUg/fnZMJvCr0JGYXNMZ5RBq5lh75GFD3z5e3uw0rEYHmpAKwMLWqkzsAJIpHSbXI1CWVbQ2kCpChsmGrjkvI0fVEphqdOHEBajw83w5ovOP3Pf+LpRlO1lQLqjRFVRuCK5Ptjo6lNoaGOw3KnwtTsOYm65qmTY4uE+zhq7w52ExuKu9Lh7/bRHIQNfc7xDPBUVlxPiuGGTxhGEMFyrC/fp3jEoncENZkqXLHSohRjxQPhprAl9Cgo7vCsY8JhJAwzB1ZR57LsfQb2fRANByoU0bHTAKbZFCibuu2Jn/oicjCwBCdGzAZ3GfkWEFJ8huvOstXQzR7HU/fqcxN8DevXjofHT2U0+R+wVsQ8DY3FKw9RQVug7M55BaQdUXutuDblKn9FB0JyEf9QuG0v0E0JnI9sxugrpY1z+vkTii997Qjz82AmMjq/1Ow6aSJIUpI6dEtNQyh3xUVWBC3dMoJmlsFZjpCmxfu0ItC7RL1zChRtfcOkH169JsbK8BG3cjoV+v4dOu+3yDSIaLKe8NJpNiZnFCj9+aAYziwXSJPEGUvjx2EClWmVRZ3TdkrdLtC/x7Tv2iO/dcxTja8ag6aS6v1dXGtZqSClgNNDvFyhKhbxfoZUCl523CQCwtNKDMQajY8OAAJoNiQvO3QIkBrrqQlgDXZUo8hxaVd5tdHEgpSpom+AnDx/DvbtnBUTq94FYb82kq5CiClLkkcu8gjF+P5Nh+eXryKa+Z4hbXE5gLjhg91g7uL+K7x1D7R28Pc5ctXvCJBHnDVjeOMBwjepJ1sZG7TDhryFLZsE5Dfi7Vilj4QLQHuvEfrI2OJ0CSvTvcwqUFDWC8BGCJJEiJBcRV1Tuxufb4kYs0IZp8BDr5Ak4GMoJtLOWPcZcX0KK/HdGJz/Tq65x/R/pR8o6ruI6hcNcyLDlB9QBRJRXpxPoa8aLZGQDLVfNudPuypcytGSHrEEzy9Dplvjwv9wDZVNkjSaEFciyhisso2NNhapUUJVBr9PFWZvXYHjYlT0cbiYYGW5ipdPDwkoOALjumWchMX102m6XQVUVWFleQb+f+3O+8TiV0RZWANoAP3pkCo/sWxRSSEhpEVNyoEbremnkwFUS2mgMDTUwv9LH57/xGJ46MI+JiREoXbGJtb5YpbNWShv08gq9QgFW4ZLtE9g0MYQln7x63ZoRDLcSNLMU5521HtCFK6ILC1VWyPtFWE51QqlhhMT+I4v4t+8ffGO/0JAJIEDxOAFlDCbWDLeuvOQcK0XUzHUrz61mJAL95HGx+JyzZHHFR4Dwa4wtRLQRlABiLvUQTwvtcrQW+xkZLNpeOl9JHF0TGmtD24PIr36NjZkp0PB+P2ByG+PIB9hBRIEYRAu1B0TsM7nugM9EMaA4woOCNSEQTn4MoptACqaYQudYX4MLzpRkRFjxGA2np4AIh7Ap9sSz5CIYsPoQAjLibdVozBSN38QtQIrIb2cgfgJqFY6sjcVBAjIkBV9Df5GAvA+ni9lZAFZrXHHxjhfd8sIrrVVuj6cULu6UNlv40cNHxee/9hBGx0YgUzeHiUxD/4w1LiMFBHp5H+tHJdaPD/0NAAw10heMjg+hnxeYXex9avP4sLzk/I0oi7bbjmUMOu0u2m23bSLEWC38Yo5GIxW4Z9c8fvjwtFBaIsvSeOTM84tgvCxpwNwqkKwaAzSHhnHPzknxiS8/ipVOgVZToioqHwfTKHOFqqjCjvS81FjplsjzElvXNnD2GWv6s0s9aGsxvqaFsZGmTFOJMzcNQ5c9T1YNVZYoiwqAgNUIK59LKwqf/c5eHJvqfTVNEwirIfzhY2UshCnxD3/xa/3f+KVXO2FkO6FrR2wGUc0A+iFGdl/Z4IbQdkKnZPz3Hm2FVDE+VhSKOLB9RvG8Hykq/4bgAjELTRbUa1wuGHzv0iBK4qiHjTB8TwiJn5sL6Ci04ywcxYNIaIlWpPQGMzIQuhpEkvG/eEaP0yYqBxJwNjWkZCBPP67w6rpg01gpiB0qm0OEFV6PYeLZSLDFCkJ1TBnUxuQVY5yTOo05KuR1CYDT7Av0L3SKgUIBZNT8oouJdA3POEYaQPDkYooazwCor6BaQAiL19541R2f/7c/w7UXrrdlWSFJ3TG/NJEwSYr/+++PDN332DG0hpuANZA2FsXVysIYAWMF8lJhqCGwYaL5BwAw2szeNjTcwEonx+xC/53PuGCr3jjRQt7rAFahzEusLLeRFwrGCLcarwBlgEprpKnAg3tW8PW7J9+42DVoNlM/l8Kv4Fu/oEA8Z2MMzAVj/UcKwJ/JkzJBa6iFb/xkn/jUV5+AsBJCWJ+nR7vd+ModKZJCIElSFKU7StBIgXPOWNvqFdVdlTEYmxjBxGjrz2UisGldE7rMIWUCpRV6eQ6tFQQsDBSsMOj0DL78vYO4f/e8EEkahFx4BaurAh9672vtza+5DrOnDkAb7TJMknaWHHExoXFzPoB+EJ4jqM5XiRxzMIVDjFePtjCOjz/IdXWMuVr5xEfiqhZ3yQaaZLCirtz4CmwYB+tcLXYHsHTeETEQouTXQ4uEfhgNASCExLyCCHrPugB9QkhCCOYmRcVGSpBqQbr7mHMQwEQ0MQSHCA3zWSAhpm0F3NUczPvP3VOsaiPSLPADa996w0BzS8qEpohoYOtMGF4XlJgQQTHydwYER++vzSGbN8HaJtTPlTLiLVIAQw2L0VaBP333qzDSTKAN3L4/AaSNBhbb/fwvPnkPjk/1kDQyZ8aFO4kSecMp2DQx2DjuYtvrJoZvHVo/jFxXKIsKV1+xHWuGLXRZwlQa3U4PvW4BrWIac2vcymaSSDy2v42v/eTkp07Nl19tNtMwai99jmtprqMLGVR8GKgjmmcXo5FlCYAUX/j2k+JTX9kFaxJoo5zLVylUSrtDmNoiEQkEBPJ+AasVtqwdQa9X/FqnU2BkeBjjw40/SGQqN4w1YErnh5dFibzvNr0qyveVA9/56XF8574TwkD6YLZLQGIgURVd/P6vPM/+yq/dBDu1B+2FBdDmQGLDOtoBG+rqlTTLrBm3evSh+oeBoYJFjBsLa/GnYAltQB4RgTHmtFGRcreHxzmsjaOKDG5JqkL/OFM75qjveavToo6EwpqZF0xCNOSq1GJw1tZoRvQI/SUI71uKFXnYuy3104S+gejDIF0NTSDGiwKipg6Q8kdUPIMoSta2vPDvqV8Mwfh5obhPRHgxq22gEaMLp9Eql84ioHc2ubwHQeHU3skMx+B8BLqB08uGcfK5hnULXmtGRoAqx3XX7sAf/9LP2LIs4XUDrDVI0wZ2H5wTf/2Z+7DQ1hCpdEcGWV1O4zeYJwDGR9zugi1rhzHcamF+oYfUAldefBaE1igLhaLUWOkUKCu3EKgUUFWAyxUo8PDeNr70o1MfPjRVvDPLUm5L2BgEiIdJlmScQG89aT+ViPEfow3SLENPp/jkt3aJv//SQ+j2nItXFIXL22Pd6XQIiyxL3EFQW2HtRAPCqNdPL+UYWzeGMzePtrIsXTMynLl8+8YgzwtYrQGrAShUGvjJIyfxH3ccTfLKunTV1npBSFDmOd508zX2Tz7wVmDmOFR7BZmMFodcuWiFqNhIVCjBJDHG4VaL3IsaAwq4rBxi1VpPzcUhBRBiYIHbCUXwdqNSIrkl0afnaIWPnolWVgRFIOkcIT0rAAgfkxOxHzF+V78WR4Ja/0go6JbBGNvpP+TWyiCEhB4sda32Pvc/Z54IkURixHtpDiNNI62i6yXppIOIe76C0mfzHvmCIRnL3xSfde2R8hKMjoFLCIYGAxYAF91HBXAswr5Ay8YU5iMgjzricnQS4S8eywzrwWQ7whOc45ybuO3MjdDQqLrL+NVfeC5ueeEFtqxcPExYt20CWRM/fOiE+Mhn78fCkvOutNE+GaL7l6QCEBZrhlzmmXPPGsfY+mHMrPRx/pY19qJLtkLZCnmeo9cvUZTKs6WFNQrauK0W9+6ew5d+fOKNh2aq9yZZI6DUGv38P6eXAJp5J/YDlopgtpsIp+aMtcjSFMpk+OLt+8WHPvcojk8XEDJFPy9RVQpaAbp0bqC1FrrSGG1KpBA7jp7KMTExhovOOQNpIobTNEVVFMj7OcqiAISFURW0An76+CS++MODN6/0lEmzzOfNFxAiQVWVeNaV50x+7K/eCbu4hOXFFSgYNBt0TMnG2Aehk1p1a898p7Hy0XKSEHohMXXLDwBGDCA5a0N+f1jBDEb9EPHqjw19pL9jnAnB6tXRxEAfTzOGIPLcfWLPrlJC4XlalImoiZQED6wTWo0WMbbjnuMIzbpzCzY8EREiUcA6hERZgAPCEjx2x8cfoJoTT8vOOFrWX/Y+jlKtjecBBaFupzFq9CRaMqDH0CkG6M/m0BvciPRozCY+EwwdEEML9LO+PcSyl50eYUY+pH5Ej4CQnUWaJli/bhxWWeSlhrU5/vfvvQbnbBn5G1UVfuuSgLYCMk1x+33HxEf+7VGcnHcVuo2xgDZIBC1iaKTe3T9z6xoIMYSTJ9q47JwN2DA+gvbSCrorPRSF9iELA12585Mr3RLfvncKX75zcmJyUX01STJQ2oZAF4sY3+O52P3QJUgw4RiS0FewZiKB8MyojIVMXJzrhw8eFf/rk/e9+86HZ1CpFKpSKHK3igjr93BBYc2wxYbR7NbJ2TaSkWFsP3MzksQMCbitE2WZw+oKiTCoSosfP3QCn/vuwVvn2/q21G+kk1IiTVJorbF5w5j87N+/e8tIE1iZO4VKu3JQWTODiDlwolVEhOWD8aE6AglfoPax0XIKjxK0NbWVkNBGMBdR0LkJjkqFLDvvI1/JAiRi3i4WqWL9JGQSERmfx/AtV34MScY+rxquV14MuTCXL2JDT+jYdFB2HLlZWG81JSioz9EX6YxoNP1zIgoshAhbHWpzxXKQEfLhShYD93M3P15bfV8IA1iGWP1cnQ59xrgofxdCKh2OxC37P58/ugJEvuD6ic8jj2XGG9j1QeTn0bC1Alkjw9r1a3zG1QTdbh/bNg/jb//wdX8w1Ep96ipWAT1Ncedjp8T//ueH79p1pI8ka8Ef4EGWuGzDWSIxkkqcuWMzIAQWltq47vqLMdrQWF5YQlmUPlauYLWCNhp7ji3hX753LL/tgVmx3LfLiUwQTD2JMZcpNge0omutR2AW/igAu89tBnWrDdq6k0rWwh/EBFqtJg5Otj/+9195Qnzutv04PqOhjIOZSmt3tlIrTIxIbF6bYXZuBUgSjI6PAdaiKvqoqhxlUUJCoNNWuO2eY/j0fx24bnpJf1okjWBMaGUsTQQ+/n9+XZ9/6ZlYOnUQpapQln13Sh7CGW84lW0RmYfxTA1VcEtFzMotKVkv61EVFWIld62OSOrBfGqTXiq8pEbDHhFP/W83EcZS2S8uuMyigqEMy607t/o+pM7QIgkOjwuSdXe5skRACWTQo0IiFETjdu/g7yPBd6tHlgnj6nfX43MmrDhFxBnHJ62tv4dIS2iUGQAeiyT0fDoFUI99+n4allTSX62VPWNtA5YhZ6zajhJQ7QDtLJyCpkUUCkq7hABuE6xk880ajDwFRp+AWfzYbOSzYNiE44UsTYdHh5owhcu9pQ2wOD+P667ZgV+/5Vpr/UKatLTlxEAkCfYeXXjhX372kZGfPLaItDEMSJddJEsEYBTWjsgrtm7ZiGphGa3U4tqrz0VnYR6L80soS4N+L0dZljgx28V/3nUS//jt4+Kh/Z0hZZ0saeuQn2Mt6/ubALSdxfOjy7kX05mnZB1E4iCaILMdLIOIp9IpuaFPiJZlKXpa478ePC4efHoWz3nGJnvNJeuwfesQhhsSShtMjDVxzWWbUKIAKo2R4SE0U/GHRhUQtkRZWRw+1cbn/2sPfvLElCgqC5FmbjCg5H4CUDl+81deYV/z+uehd3QXrFYoi9IVIagUksQSF9H5gsDgoCFFhyVMfIwlceYT7LsBdFSzsnULSEwUlBJi7CRYFVhHe+/y8LOHbTskRwAA4yFJREFU8D/JhTNemGjyYl8iqoSt95MEJwghQRwwhDQ4JtYHa20oiUYKyLJ3wF8nxUrKJvzOxi/9wdwggwJxWZ/VVwSim8/RI/8M9nuw/5S+ehUtRIynEe1c38gAEXH9eCXRQIT+xtMQsf06io7fBVc5alhPl7ryDAaG9QfsHndQGdHoBSRHBod1nfsbQfGF4YduWAAjo0PbR0aGYVTbnawwFpUy6K4s4Vdefz3ufeyQfWDvjEiSDNZaaKKdTDC3XPQ++uVHxczSRfbVz9mKRtOg0UhgLbBtY+uJjZvXYmZmERds34gNayQWF6bR61Xo9yvMLHfwyL5l3PH44pUn5/KdQgqkaeIwOYEKr8CJaI4CFkJqCCN8fjwJY1yVNCkkUuvPHDoiSjSbLSSphIT0gXk/fGtDeAJhB61bItc2xWy7xG33HRd3Pz6Fqy9ea2+4egsuOXsEmTHYccYIOqaJ9uwi1q7JcM7Gxq0CFYp+jkd3T+NTX9+VP3V0ZUgkKYRMvKZ1widFAlWVeNblZ9s//aO3QM2dgir7qIoCqixc3UqtQIfMXRaH08FvzjR1wY33RIauM1poKTIy8ad/hkSOFzMlRhJCsGM4tJeqLoRcKCmRX83YMgQwuFJ2uvFYj6bA3ktt1VesCKUzVOPviS4X7wgTCkKHniLCspgW4OYBEbEIUqADSjtS+DTzARl+N8YpfwkBbcgQILRRa5f1D7xPtaGIGj1XKUczyCOyVjeU0/O0vIT4jsgTpOBjzwaNxKCCdtPI3N/QvljNZ+G675t1Ofws3L618bGRi4dbGape7uRMayQC6HU6GB4F3vsrL8Cv/q+vZ8tdVQnpD1B7nk8SiUpbfPa2p8RSu7RvfflmDI0OoSg1No4NYWi4ifbMLLZtGkWZtzE7uYjJ2QKP7Z/DT3bNffjAZPe9SlPKqOgxWO8HiqC8LAQSn87KQNgE1roszdZajDRTrF8/tnFhpZhNh5op3vUrr7CjssDXvvPQ3r2nehf3Oi5Vc5KmSNMMQgi/495huLBo6898JYnL5GiswHKucefjM2L3oSX5vMs36JuuOxPbNo9hfHgIK4tz2L6libfdfDkMBHbvn8c/ffmxozuPd85uNRvBegC0Fc2l0pkYawx/6M9+CaOjEu3jC9DGou/3jRljoLXxWIcgOLUjeJMMvdTNY4jzBJBBKCNaOxmUQY33mKmNzzomdAjEencwIdfOc2RgWv+M8IzrLL8AlzgewCVrTgIb0ccgZvGCNYgYmcKgd7v3xqcgiFaGvYMWJuqu6GpEWKevIBRvbYgjUgcsHJEEZaD1fXRbVmw8T8kEGRYhow8paADwW9przmV9WgdoisH7GY0Q31db9SQlwV05plwEJ0JoLw4hTCOb34g6mTF0zMD4JbRGVqyG/h0darMaPrEWqlu927Bh7OutoQT9pdxVF7MKyhoYIdBenscVF6zBr7z6GeXffvFRYZF56+aUijVeGYoWvnX3ETHeVPadb9qITRMNbHvWWRhuSeTSYO34MA4dWcAPfnoUP37sxNGnTnbP7isLCAmZSEiwxSdC88YCcMcSKW+fqhSKqoRVFaSU2LF1/Iybnn/2yV943bWYnsnx/o9894Npu1fg/LPX45d/9WW49VduvOjIgRP2vsdP4O4HD+Lh3ce3Tc51ThkLd6gzSQEhoXVcQXIvdBMqhWdIkWCpZ80PHp0RB4+v3HnTc7ffcNMLL0VV9DGUNnDxBTtw+Egbn/36E3j88PLZWasBZSwSGSdSkhCZCr/4xpd2n/vCK9A+tg8QQLfTQ1mUMD4wqP35TB8Eg/VHQRAYzUYUI0hITIT37EAwt6KRPUR01yCYgqQPCXVEGcSkHMKHbjAlQFqR/oquihuO9ql/KQk4VxJkkYM75Nvj6IbXffS4Kxz8NjQmwZVdpEOI43mh8nI1gBaI9E4JSRn3WkWl67QOjc2RJyJWQn8BqUWyQgjuVCDGBvknoFh6HTNGTAEFJO5ndRUsC0iu3jT97Whp2XfUtmV/hz8HUBnNF9/egdpzAe0EJepkzFA/GK+IQSIx9Op+1JU5zf34yBBkaqGqAkb5s82+gIdVFu2VJfzcSy7CTx48Zh/aNy+SrMEQpGvcnX1O8MMHp974gmcuf+WF15+Hic2bIVWFXq/Crj0z+Oadh/HT3ZNioacASGRpAmtdiiyHrASsjtl5BVziUViDsiyhtMHGiZHW86+5tP+8a8/DFedtwnk71mBsBMgXZvHt/3wY+47NfyAFgNu+fR9ufM652L55DMPnb8Hlz7gIv/H2F2Nxvn3y0SeP4/t378Z379zzwUPHFz6gjIUQEjJJIJA4T9VbFdprJSCRpAmsBA7OVS/8l+/ux8n5wn7gPZswtmEExyaX8OkvP4gfPzYpRJoE5UDMKYQ7ASB0ifO2r7/zd3/zdVArM1BlCVXlKHo5jDF+BVL7U+5Us81AInEuhiDUUWf4ENwXkQFq0JucIhFsdxRIgaikaoJhVwlgEB1mbTgKpDbrMSaySqgxZs09CveKqHwEU24Iu4Jiu8Kuek8QKtRjcbXxDSh27jKHQLsfaczVzoPeXp6ZIo9U5QhlsG+e7h6JaXbPad3E4DMhVGr3R8GdamYCz7khxrLo+cgHtfCBjXMXeWNg7iygrUu8SSm0w4zWjA4YnwhYYZhRQjBKob+eFyJ/xS0cvE/x/5F+7g0C8OXPsiwBrPLei5Mf+E2p1hiUpkJrWOCXXn0p9vzDPehWJoAJop6xbjvGTLv/1Z/snMK5516OscxC9fo4eGgB//ydp/DI/kVRWYEkS/2KfUTzjH1hpQSE2zda9jsYbjXwnGfusG96zTW46QWX4IxNo7AqR2dxAXPTJ1DO5Xjq6Wncfv/RB6y1SJMkwXfu3i9uvvtJ+8uvuw7dbhei00EqJdY0MrzsRRfgpS9/Jv7nTP/9d9+z5/1fvu0B/PD+fWJxpQ9AIEtSJIkIsQFyGYy1SJAgbTTQyUvc8ejJoZsePdh/yxuej8WVEnc+clz0dYKUnhU+7mMAkQiP6IB3vPnGGzaeOYb5g/sgYNHvdGB0BaN0SE1rtJ8QT2JX3Saeo6tBdCAEuMPqFJv0aHH5ClXAR1EZ+mcRGIhBf99YWCEDPWZr/YnCWBdOAC4DgM9IGwUNAwLkmdYHmmHrghIEIigUrnhISbvYiBFghVsRdowP0sy9VgSbHkSE9Z0UCXfTYj9EoAOp2bqesOF+0p/GT0Q9dkao0RsPT8/g4gbynE7x+PGJOBeDysoyJBSRlQ00qymNwAuWvC1A8IWJeG897hn7ZGp8xvoz8HydH0Wt33wIANv/6LdzuDJpGlYrV3lba1itfdzY1cWwBui0u3j2lVvw3Cu32B88cFIgyWr9cDTXyGSKr//0sJhoCfuuX3gOTFnhgZ2nsOd4WyibIkkQ4+t+nh1bWUiRwIoMRlfQusC2zRNjP/fKq1fe9JrrccUlm9EwOVaW5nDqyCSKXoFet4Oi6CKzFnc9MYWdx3rXSymRNhoJ+n2Nr9/2IF74rPOwZcs4FufmYaRFWSrIvICU82hlTbz6pRfjFS+9BEePTNtv/2gXPv/1R766+8DUG41IkMoUgljK53U3ENBGQCYZVnr9fOfBRbwNFtu2rcXYmuYVKwvVzixJUCodXAnrmbaqFC44f8viL7zlxejPTcMaf+C7X7oCA5Tx0Zd0UuRGCgErbFA+wZJ7AaaPgIj1Ij3DB4FifEOC7xE9jCCBJgtM99GzpLhMLf4Q2mVK1dq4GuYUlQk7tekauZJxdc111/DyawxSBCUq62N1feaMHjQ1AqjzgyG3k7XqFbMIihk1WjILHVZgI0blAefgqtb9uSCTAQ2FY1ukNKLCjYsdDN0F3el4KIJYhmQC+mXPUJkEQop+/gJA979wg8A/RH+O4GtZbYOLNLAAREqWzZuteQrsOY4ag/Ks9cBPJZsXzwOkuKwXCG1M2KuJkF5aOyYjomsDKQq86aUX4oEnZ9Duu1xd1HvKUiwTgXY7x+RCH82RYXS7XRw6tYRcG8g0Y+hYB7oaA8jUFQVSqsB52zee9xtveeGBN772WdiyoYnu0gLmju5D3nPZWpW2gDaoygKNTGDvgRXc8ejMXgOgkUpIGKDZTHH7/UfFf935NFKZuE2jxqLSQFFo5IVCp9vG/OQRLJ86iE2jBd755mfi25+99Q0f/5PX2XM2j7+rKAsvkO4sJJUd00bACol+aXDg6Cz63R42rV+Ds7dNPGG1du6nt3i0p8b4gN7rf/bqibVbhtBZmIWuNPJeF8Y466G1I6L1FqUsVVAyAEKudUc4YhJmbWvM4zia8tRHoYusZMklsTZAeHKhULvfACaeu4sWHuE+jrzCO6hwRvib/eRWG155EQqhMVIOe+9KcpeWCwR3mbg7E9EmEDyp2JsgfKd7PoyflFxAT9FNDgqSFIWNyCYoRstoKYCwgsk1lEV9XNaCb2zkK6zUl0FFRoMV3BVmCJm7hPU54miZuW80Dm/szMCchSA/wOgWXW9SXFEJrUaGHFlHxBv7FzNjsArdfg8cr0bUzwsYr8CsD+Ibj8K03xQOCPQ6XVx54RhecMUmK6xC7JnbKy+88quUwvatE8iEwKmZHo5MtVFWgFsi9sVpYrFBiCRFVRYYGWnhfe95g/3hf7z/wG/84nPRKOdwbM+TOHnkMOZn59Hp5MgLF6OrygJlmaPTLnDPE9PYeaR9sSvEbSGNtciyFIW2+Nbtj2LvoWmMrBl1K3tCuHTReYGyLFCWFYqiwMryMuZPTQHdBbzl5mfgts/c+rHffP2zLYxCpRSSLI1ZOGEhpdt8dniy/a2ZhQ4m1o7gorM3eqJQ7MZXq7QWWmmsXzuy8TUveyaKuSmovISuSpf1gq06Wmvd+SwA/VyFyY0fYgw+4aLORFyQ2PWASrz4DMaOgoUU9H3EbnxPj9vnYmr9gLVsMyzq3wVBEQPtx+9idSUbBKXuGg2Mn8ZGKAR8zPX3U1tS0NGcGLcgneYsqQnjBuufsQZW2Ci0wtteJnhcgYSeknKArc1B1CCiRhNyGyFE6LsQdbRUi2GCtekvcoRE6YprsUgR0csgfQKEG0BEhN6IFwTjQYARMXDWaiMY84Ah8kMgVICGrB+E4IiZUP9JyArAcqcPpbTLQQ8T8nBRdhBrTSzQazReev0ODDeTVUkhrbWotAGyBJdeuBnNzOLY9Apmlortxm99gUCo3JVmGaSQUFWJl7/4avv9f/sf9n/+1gvRyidxcu8uzEydwuLCItrLHZT9wp8IsNCqQq/bhtEKTx5YwE8envyUsgJZkrj4qLWA1hZDrSZ+8shx8Z07dsNoF/PQqoIrQlsh77oziw79OMVRlh0snDqCNVkHf/Hem/Dlv32rveTsiW/2um1k0vrySBrCGkghMTPbuWXnU5MYHclwyQVOgRWlDrnYifmqssTl558xc+6ODViemYJSJYwuobXbwEYcY10RYGgNLHXK4F/DRObgcZlotL01ZEyzWpGxGIZnXHcAlwSEVUQiQbDeAhsurJ6NReyPO+Hg2d1XHyK3oobQwFwAOFRJ7glZ2Sg41N+6kMTVRyYwNU8jjj/E3Kxf7ZO8/bgqGSsWIc7FAOLjgm5jB2J71E0LHwOlP7gSETWaROTB87zVzzjS89aysRGNhQiCKAhxA7X5iqhShHmpG7aBGBYbc8gxZhEFXvBooV/k8hvJo3KkGWRxS9+H8DPwBMWgVs+fe19E5sQ7nKaLi50X9/PSnzt1HTXGQPvq20ppL2MCnW4fF52zFts2DX1fG+fhGGOgjTsx0S9KnLVubN2528ZRVQX2HpnBckcdd5uODCTcHrNms4GyKLBmrIW//ZNftp//2Dtw/kaFyT2PY2byOJbabbRX2sh7XWhVQVt3mqfICywvLCLvtrGyVOC+nbPYd6r3zjTLwnlnSQKXZQkqA3znxzvx9KEprJkYdWXCQ2FTjbIoUZQFjFGwcIUutQW6nQ4WZydxw7O34Ct//9ab33nL1bYse4BVyFLnxaeJxHKnMg/sOoGWtLjsnI04Y6KxvVLKM4+z1BQLu+6qcyEzi7zbdcu9xgXqrT+iEnJgCYmiMphZ6MV00IiMF2MndQtOnxrSCQJn/fYQKjfnmVTCW/xYIYUEPwiIP/zOXhARAoTjXEsWs94XsPe7wG5EbtbasLoW0SHIeA+4SfQdFw7ep/iDW25SyPydADzDsmukuAmdkUvtEYeolV6jDAL1vtHBXKpdYLnSp7FwoQSiQDLkQV/XMqoGUlI8i90byBbdRiHqfBDI5wldQ8B8PgiVDVyP70dtTPX31/Q54xFvuMAWSgZQ4+D8xFsEM5bxurWUwUFgabnz5FK7hzRNgnEA3Bxr46qAGb+tolQKE6MSl5wzfhOsgWaG1MIBhysv2jK/fv0QFjo59hyeR69vIfx2CAlXW6Pb6eDqK86zX//n37e/+dZnon9yD6aOHcRyexntTgfdXhdlWUBbC+Xd0l6ng5W5efQ7y2hkwIETbTzw1OIfKKRIkhTGB8slEUdri7GRIdy385T4xvd3oigN0mYCVZZ+kC5YnncLn/pZwWgDVSloA5TGYm5mFhNpH//7t1+Iv/ztm2wmNFRVhsKlealx/86T6K4sY9vGMZy3ff3RwAieqbQySNIEV156Fvorbbf71hiosoL1KyfGGBh3eAoSAkWhnAKjTbY2xkIiQkDNWobJZ5NIMa2AwIL1ImPFXU4SWhuEmbKvhtEQsICD5ggMioBm6L2DlvR0yNASk7IxDAbLQ/zIRstf+w4xRsbfw+OAYT78M3S0KCAVeo4pKVKqIUmircdo3H11JcP7ICQh1Hg21LAGeCZOl52AjcejVY6UQCPl4Ixow3gjIh2O1hFQOucPUqqD6Id5gQPX2dyxvjn2EeFBft0tggG0p1EI4ZMpsPgiU27WWh82GFwJRuR9/x4pBTor/dmF+TayLPF8HRGf0T6brLYuRZZ2xXYuOXsdEp8XP8TVXHVqXHrOOrQgceLEIg4cWViqtIH0c9FqZFhaaeN1L7vWfvFT78Izz2/h6J6dWFqeR7ffQ6/XQZH3oMoKWluoyqLfV1hZ6qCz3Ebe60HAotvVeODpRRyeyT/SaqWwcYUnOqvWWshEwiQNfPMHuz/2+OOHsW6sCWVKt0/EardR1Vfm7Xb7fjXDbfE3RsNAYrnTQ7ezhDe94hJ8+H/8rF0zLFtVmaPZdFWD9h9ZXLvv6AI2bBzDFRdvBuBrwUknGMporB0fbm3fvg7dlUUXrLd+6dc4BQZjIYSH40Kg21NYXO4/QYetKRYSfACE8UZmlGy1aXDi4dEJuyQE2MoeuZbuC0EFdgnFCY9G4rao4A76F/r72O+8b3WAAQAhphhVor8uKXd7lKKAjBg6oFGR3qFYWBhb+BljZNQ2pxkppJqy8LTmNCQES++subzWujhZbCwKtpCsDVl/d+h3pAkZHGo7zkPsJ/8Qz4gBIoc4nx1c/KAHmRLjNPCtnh7V06M2xPhoHgid8X9uGAPakPU5xNf8LWHYrKt1RI/QFiHhotI4ObWIzJ98kYkgnUjqNDwjhAvnnLV1BMNN6YtLW6QJ3P4xABefvxGtTGDfkTmcnO9caYXLFTbUSLGw0sUv3vIC+4mP/go2JLM4tnc3enmOfj9H3u8jLypUyqDSBkWl0ekVWFlpo9PpoigraKPRaqV48tgK7n968SYjUySJ9HLpERj3wavKYHRoCHuOLr7nS7c9jPnZZbRaGaoqBy23Cu/Dl0WJbqePoqhgLKAKhaqsYCDR61dYWVjATc/Zgb/+vVf1x1qQVVEiazSx3MmXHnt6BmPDLVx7+ZkYSt1ekTSRoTjmpg0Tz9uwZgT9bgfW+DQcsKjKKgTyvZmHlAkWVkrMt6t3hwR6fvaiZaP4zWmsJ/vUkU3kwCh8MdGjY0rHI8YYt0IZBIAEvI6gBAYQguCoICJAy3iYhK1eWZlW5sj14t7W6tVBjjL4vbEPPKNrtOghrheEIvbdePTJxxz665EclX0LhsK/PKDPVSgwJkB074ixrnDGNMzjwPyxdh2Aqa++nR7h1hHXKhpGrFYzfvDzStlaAxE9Qet09osTHu3EOYzt+gY9GqovFMS4G6tgzryE0/Ez8TrRhPoupEClNPYcPOWOCMKFJWgqrHVuIeAqY2ttkPf72LhmBOMj2bvcKqVD5EprnLFxzfD2zRPodAo8uX8WK73qWCKBRiPBwnIbb//Z59sPf+Q30ciXcGzfEeSFQt7P0e/3UVYKlbaoFFBVFp1uieWVmHK6qiqkmcBCx+KunYs4Olf9oNFs+Q3qNqRPlyF7qbcmxgJpq4Vv3rFX/Nfd+zHSymCUL9phLQCDJHEnyauyQreboyyUr9prUFQKRkvkhcbi/BxecPUm/NlvvVwbmwNWo1dqPLpvBlkKXHLuZlxy9vo9Wrs9TfCTtf2sDT8cagmoqgAo5qWV27BqXJAxKIokwfRiD92+ulsmkqBSGBMxUlRI9VUlXjeyFtdgFlf62BO5NWQRSVs6mI+wAhiD96uAlGfywGqrrD5fGBgMiAdjI4LTCghgsOI2DfV0SjoKKN1PKIYp7tA3AYjolgc3jX/P3hfVHP2PX4mWnocMYjt+qZ0JJHcL+YsiXQbHHM0X68mqe2rIaNV37G8INn/1hYT/7p00PXWXlFpyY3JoOq72EppAjR5RqZNcgM0bGYr/f4iTkCuEQ2BlpfH4U8chBZAkmfceaFUbXgeQMRBQSmO0lWDLuqGP0YxRdo5rLt/WXb+mgdnlDvYfmUNVupjX8soKbnnxs+xff/zdGC4mcergHhTaIi808qKANi7wohWQ5xorK310PBjS2kAbDW0NkqyBB/a0cf9TyyJNU58Vh3sMAtKC0lk4jlBKo9XIMN9T+MK3nsCT+2axZnwEeb+PEBfQBkJYZI0M1hr0uj23Z8MYmEojL0pobVGWFZYX5vDiqzbjt9/0fFtVJYyxeOTJybump5ewaf0orrls20VEbG1codztZ6xDmmjovPRnLq1LiqaUQ2PGbYgz2gA2wdHJZfRL7Sqn0EQLEaq9ELcHhhJ1NqfvSbDjJYrnOA1IlozHwuJ/vugtIR2BUCJslWsSkBmxbHRHrEX0PUAsQ1/EzlNMreZ2goSSoxpRux5//2+UAL3XMwWNvyaUDGFwtBkJG+NH1AeO5ohudWGjOGHsh3tf/ZzqoJKt6WiOOr3SpL/jTxGrSEmeI5+/k9GHPcfbonG5tkRAYQFdhjGgthLo5I1MALVLMS73VEg5FGjiFRqbK2MirU7XP6dofCoqMqjeYO/ac/JTK8s9DI2MwRoXAnFi4t6ttRuT0UClXCKCLetH/N5D4VEa8NxnbEIrtTg+2cah4533i7SBbr+Hay86e/HDn/gDrBdzOPLUE+gVJcqiQFUW7piadrUlizx3uiMvUCntcn1Zp2SbjRT7Jgvc/vDMVxc6Bo1G5kJZXHKtZS6klx4p3Ia20eFh3PvUjPjcN3ejkwOykUFVFchaU+6wNE0BIdDvl8h7lV+hUFCmgoErdtvvLuJVzz8br3n++dZaYGq6/eKHd57A+JpRXHP5NiRwNSUtXNzkrM3jkMKtOAo419UY7Sp/++NDNGllpbH/2KLf8U8xMLfS18gkEmH8aurpLSu5AmTZuSUjS0hKRgoBKRN3DjQIH7OgTB55LGEQh/H3RMaKlpIrx5DPnjXBrXwYD7NO3BWia8TUtQwTIeWxb4UsPKKiIawH5roMjgU+fmPpvGUQYHoP63Mo8yXDO+vowRBRAFCML5LXIfXw8qAEhHArwNEgyFq7tfikrfebxhoWMJiSDciYEZ8rOF4TNBhPILTL0SZVl44K3XrX0Pi5F6G/TufxVWRR60ctBjnAX+RJlVUJbYxTZJ5vs1YDUwuddz59YBbDY2v8O2XtaWsBpS0MBfihsX5iOGRXKSqF8bEmLjlnAjI12H98Bku5/YtKK6wfbuLT//xHE+eMdLH/sQfR7eeu9oWqAGgY6xb2+r0c/V4OrSs3h9aCtnQkiUSvlLjj4Rk8dXjlja1mBmsUBNEJXpxdfYp6XMYa46tvCyDJ8KXvPy2+/uODWDO+BqrSsMpE5OAHKFMJKYGirNDNS79KWKHMc1hj0On0kKCLt/7spTh/25p3LawU5u7Hp9BAhcvO3YTzto6+rygVvE+LtaNNWGVh2GZapWLKauuPQwghMTnXxf6Tyx9DkvqJcmmAqrLC+3715fbNr7jWSgmouFU5TFK0vmQZBzOaBrsWkBc1Yb1F5EiHt8cRSJ2+JH0MITEkwxmUEEH8MHRno4KsuytR0dTjOgD8+EhYYzsI7bjuiFrbbCg1xFNHRvCLK7EtasZ6heRiQKKmyKIxivMS3WWn5PgWiVrMMNCdlYsCF26uLNx3xFN1pBVR7CACY+An8IM4Ld2iUpLChxQik0W+EB5VBeTlW2UGozaYwbm3tsYXfA7oPVobZClwxflb7twy0RzT2iBJEkgINKREL9e4++HDaDSbAERIFaW1k23a1Kt8sR5jgOFWw7u/EsYYXLJjnd0w2kSn3cG+gwvoVBpaa3z2//2+veKcUTz9yP1or3RglIKuCsC474tejn5eoCpK3984VgtXqLrZzPDg3iXc+cSsAFUkMw7MkDInZnTrRBYBk5DCL7VCM0vRrww+8x+PvO2BJ6awfuM4yqoKikL4VSZYH1STBqoskfdyGKVgrcvnU1YW3V4PW9YDt77+io9VRuCux0/tnVlcwbata3H9FWd+ELChOEDWyBwaE3EVrPIrneHsFpxl2bV/GtML+XscKgKSNIHWFmvXNPBzr78Or3zB+WhlEpoEZsC9CowKKt7JEUJ9/xhZZLKYVMFp0NKH+JyIWI8EhfKkW49gRXgO7N0MLQZlWkcLJAABnFlCPDHdNbUblVi9EDt3K8PcB4HmK5k2uCP8fmN8AkmCSNRu8OX82FiK5hB3C/2i5yIi4/Qi5ST4rb6fJMikUGrzSTQNrpu7R7I5JhoMUKDGEwIR/XJXNCJoHp/kSI0mN/4LeDkonQH+QeyagGArzPF7GxAeJwZDhMKlfV8/1pz4y9948Q0///IrVoyqkHkDn/jFsu/fcwCdXu6UmCSjYAPvhs3T1sIKIMsEUgEknoWuungLxoYamJxaxIETHfQKhT9+95vsS150IfY9dieWF+fg3M0K1mgUeY5up+uUV1mF9wm4vKsSgFIVRkczHDhV4Hv3Td3U6Sk0GimM9q5jKMGHwNSSOmpEFE4qBa+1RquZ4dBk5wv/9OXHcGquxMjEGpS5AqwEbVy01mfIBCCEhSpL9Lp9FHmJqqygtEJZavRWOrj6/HG86cYL7Z7D0xc/secUJsaH8OLrz0Mq3YASr21pSwSdaaS6k4CFrhRgDDp9hQd3z6Ko/OFq4Vy8qqzwyuddYNeuyXD52eNYM9JaR0uc1B63qCRHFDgmOCtQX+khupEQ1mlJ1ywgLNcDYcuGjXQPQkeZFuzA5BBqqMeucNr+xN8tqDw9R0J1tOB/oRU0G++DEMGdJleIt03jq7UpfKzRRGQDuDEHd5jOuNoYk6T+GROID0qQaUx9zLTplfYp1WgUxjQAk4JV5zHKgZjhKtrUkVTQUYwOhqNw9iwPN/CCwYG5QkcDJ4ByiwUEK1zSdjpLaQzvx+mULl/xdAjF+HeMT4xd/JwrzsALrzoT460UpVKwcHKaJBmeOjwrHt99HGvWjIa4Mjx6s9btBaNVUUC6YrRCQFuLoWaCZ11+JiQs9h1awO7jy+KKczd//9d/81WY3vc4lmam3b4x1YeqcnR7PfS6OUp/tlG4FwQ+FVZAaY3hoQZmVyy++dMTDxyd6f0gy1K3ed24fWcUq+fGgh0WIVjOrlgNazSyLMXdT0yKj33pMWiTIhkaRqU1BCQgaSIo4GogpIuB9fMCeV6iVBW0NegrA2NK3PTcM7Fjy8jf/+iBY2gkJa55xpl47mWbrVIKSSKgVYEkja4CIS+SPivcWa79x5ex+8jSWitdNW7aIW8bCd5887PRquawdW0T1160Zd4diaK9TTIyrxBsj1UsRkHU5egqQgBCP/WVQvpOWLZCBL7fKq4w/v/+kCvHBQSn/53as37bAhCEoZ5RdeATgAVDWgzFEHNFlHD64HtEkFGYqI6B9YJYR1VRGYIY2I+ZFFmMTwlwY0HZFTgNam0HI8Q8CkdIf/Z0oHq5iA3VaVQn9mnnGLFvgTMs6sbL/yDDGFFb/T2uGZptG15PzQSHU4hVPBHH75ASuchXXbz1von1w9i6LsPVF2y0pVKQfgd7miXo9it8+Xu7IBqpz+3n+2BNkAG3gOCyTnT7FZLEAYorz9loLzx7A3pFF48/NYV2X+G9v/u6m9brKcxPHfU7BRR6eYF2u4t+v4eqKkMGZWM1XHzXoS9jFbKmRKElvnn3STxxcPl6lwzBu41+JTxab08FIagqEVl7BpNh498CMCLF1358SHziy7uQNIaQNBowSnvg7w5i01EEayyENTDKIC8qtLu5Q1BGYKWdY+N4ilc8/4J379w7iSPH57H1/+PrvwMlu6o7Ufi39wlVdfO9nXOrW1K3UreEUEBCElECG4lgggNpPCYYg589Fm88z/CNZ8Ce+QaYhGfmG8ObZwPjscEe2wIMiCQkIRRRt7pbnbtv6JtT5Tpp7/X9seOpbr+Sbt9bVefss8Paa/1W2GttGsaDr7sJRISQcbRaHVChpZmAjgpWxntRFBAFoZABnjwyi7VmWjeMKwgDZGmC+27eTa+4eZ+K5hUZ3nz31RgeCJFrKaI8m2WiNGMtoSDpbEgOCZmjQ1S63zEAaHlviICcGqPnsowA+7xe3jX9/XPPcX/79/ib0ETN++2Q3w/DPYzaAMeciMh66owKap8BZmOyTDycDwMZPGRpdzDsXJgrjcQHUPLK2e9L6MiMxf+ub849yWzHQ1T6DFdqm5w91Kmi3txrdOfWyDBmj/FaYQjAGr6dbc9X4wmOwVrkpRk36WShZg4t8/PW0Kdbd79BqkBRSIwNVXD/bXvRbieIeYr7btsFUUgbtwgCGA/wvZ9drB19eRaDo0OQModJryOFdGtCBBIS9VYPICAE4Y137UeN5Virp/jZieWH7731KnrtfddjfuYc2s0uslSg1eqi2Wqj101QZIUFIepMpYpiUGMWCDkgwPHIU3N46viqSgUQACZTrCEiIjKlW+ycczWVzjZipS8YwJWaSEIiDhmIhfi/v/ky+69/+SIiHiGqcIgiQ0AA10cfpD4Uaioeg6kjCK1ugm43U+l1igx3HdqCw9dM4KkXzoNx4J7b9uGG3SNfyQuB5ZU2wFVBD5WL33hqdGAkC3B6ah3Pnlh6t2QMZE7HEiAZw4fe/SoMxYReKrGy3sSdt+zG1bvGThGpoFsVL4bLXmrN+iL5PUnuq01uYwHlxjRDMwRqvidc9jKy26E7H+G59XBYCR5C8Z5lkYBDC1xvhBKy4szbiO4pZqMalMLs2C9HZOYzc7axpCoCmmbKiEFtWtUG1+dJDcO1I2VlG5bVBSyK8+fN+9cikDIDN/zEzaj6yy+DVp5j/yot1JljqgZNq+eQZdLMTUzpfvveoklYoQDGHeUwwGSLMFlMLNO1DN1VXUffuHwaJGIgSGzbNnbba+4+gJW1NRCTuOPGbTiwvfYZIVOEoZr7MI6w1sySP//7Ywh5pFAzEVQBRQVICCqnnRAC6w2VLmvv1uHPvfKW7QjDDGcnV9DqZl/+p+99M3iyirXlBSRphlari0ajhV4nRZ4LdZZW5+1jWpNSzgYBHhAQcvzDzxbxw+eWmCSm8u6bvQjfq2uo3PEpbqSOL4EsV9cBZyZbahwHYCzA1759gn3hKy8gSSUGBgIUeQ+QyjsoiVQusdykfCZ9OoQhSVL0uina7Q4qPMdtN+7G5GwDS0sN7No4gLe9/ob3JWmO2bk1FFkBBIqBFoXQaEgFy7YSwjefnML8Su8bjIW67wHSNMOha7b94r2v2o9et46sEGh3exioSbzxtj0HapUAolCbyXrBtORzjMGTikx7uDxJ7tQ1H3g4taY0dw5OWOlpkhM6LcM8px/JOQ+VjxiMpDWE7uhaI1bpe+RMVlfdlqEE+xw/At+9TH1IkNcevKwN8NQpQy/MVNZ2j7fZFogsg7GHKMxcWuZk8YyHfPQnmjkaBm6GcTkKMfPkIVOCDu0p27v6UZlDyM4baG1hXh57swYG+UlyDM5sIr9tv2/qTLDJbGuuM1H5zEO9pkanRrkGxgLoz8Sh1lxpJ1khEQUcr7v92me3bhnB+uo6kkJiw3iM19+251NZlqoEmlB1GIMwxA9+Nskee+YCBkYGIUSm7c8EmKSFDOh0UzS6OUgS7rt198PbxmOkRYGfHp3Bq2/dU3/dvQexemkazfUGut0MjWaCXpIjz1XJNiEIRaFsrlIoGsjzAlEE5Izjb55YwqPPLrOCOKJIO8/g6ETtN8O23XpLg8A8ii+9StJXpyyOoxDgMf7mJ+fZZ778LM5f6mBgIEaeq0BTKfXRGiKQPhQKAqKQIwxDFIVEmhZIux1sHg0xPlLB2QvL4JzwwH0HsXE82nJ2eg2tbgoWVlWKj0wzR6mK5z59fBnPnlhi0nZfEZoQAu9586FvjQ1wJL0eRCHBeYB6q4V7b9mFTSO1e0wUf8kO0o+0vM1g5sAUmTXqoI9+rNpir4dFGP41Zj1Ks23Vln7U5SED7xkeICs1pJiBH2pgsUNpgzqU5r7vHwPn3G5Wxlhf2hf3PIdOYOsoWtRCfp1GZoN/zZlXFfOj4vvc8+EJEuYPrjw/cNcZyUyl++xtVi327WpGKNhzs/AYskcDdq371ogxczrD2Dm9zea1ZdfaX19Caa79sRpGrkCa6afL/gv9uY2UN1Ou75NSYNPEyMB7fuFWNNZWkOU58gIQIsVrbt+NHROVdwkpdDyXKpPWTgr8128cPbqw3ENUiZXpQxpmLxGGHGmao9HOvzgxGB16w6v2YyASWJhrYWa2jl97532o5KtYWbyEZjNBs5Wil+bIMn0gXBLMESQiFc6U5gUqlRDzTYk/+/YcfvjsCpMUKN5iECbzhAZzkWpmzYnUkSbuLPoOlRjdXdMJPOAGIkIUhgjCATx+dI394X8/8tVvPrUIGcYIA4ksV/auQnszRKH0cin0EaRIIaZOJ0WSdjAxOojTFxbQ6nWxf+cQ3nLn/oWLs2vBwuI6qrUB5IUAmDovmUuG6dUUf//4xYdbXWdU5ABkkWFibIi//q6DEFkXeSZU+loE6LTa2LF1ADdfPf44RwGho5it9LbISzMoow4xL2bKMImSPcST0oA3d26uHFKxoAg2DMPnCPb+yz6CgU9mVUoow/ZBP6OE3jxvnjSfy74xOUTh3uv2PQRqdotBKfbhesMZAnU2P2fI1/W2wSzKcP03gakWETM3Ce4y8h5XnjPXd4N6+hmDZqgmP3zf9eWxl9fMF2bwfrvFdH/611imKh2DcZlS++daN2IYLDT9SbLr55siDDoEU2heITUO0ijs0HU7Oq84tBPz83MoJCHPVZLR7Rtj3HNo+9fTNFMl/kjZOYMwxMnJ+s3/7a+OQwY1BEEIoVNoSZKIONDqFlhuZr990zVbjl6zdwwgiedemsQ1+7fiVfdci0tTZ7G63EC3m6Pby5BnKmNyIYAsFwqJCUI3USmieRTi2TMdfOnvZz7/3KkmoyBGGIVKEPKysFL8i1kEbWIC9aQrCKOmStpI5rIXyHA9rqWsqv8YcI4gquHCYvL+//bXJ4P//JencGamizAIAUAdFchUtSBDkyQkAkYqmyIRkk4PY8MR8iLD7ILK+3P/a65DN83lCy9No1apqK4b1bEb4JHHLuL8pdYXEEYW7jIGFFmCOw/vFnv3TCBLEuTC2c6EFCDKcPfNOzAyGCEvNDw3aEATh8luAOYObTtJ4AjPpAdym8jblMR0BZg+KcId8nFb0uAgp8L7qlF5r/r2GYv/+mwuDnUY9FNGfmaDS8tgfCZXRljmIR5BkbE59F3kodLyMx392Pglk6ITismZtmzhX804LXoz31tBC3j/2Of0//YPkVuoogfho2TnNijPteFV/YLGtEteQRDT5uUo1e87SmvhMy93jwrVlPYzXnoGzGfePCg0COSFxMhQDQ++4WYw6qJVX4cEQYAhl0AYStx183YMxABgItq1CsoC/PDZGfb//O8z4OEgwoAj4MpLGMcRFlYzJFmO19xxFcYHA6zXuzh7cRlveuBesLSD+elpdFopkkyo+E9RgKRAXhQoComsKFAUGThnWG9L/P1ji/jL713aMzmff5KFFQTGbsrdfrM/OgTJag5WSOu9aL0BZKC9Z7vxFk8xPWdMFTpcKAxjtBPIHz6/wD73tRPv/tp3pzC3UiCMKwgiDiGl4siFUBkKhFIjAh6iyAVElmAg5jhxYgaFKHDLDdtwYMfQ/Pd+egEBUzawPCuQixg//vkcnjq6xIgpJmFiqJS3QuD+u65GHKrcYSZrhTovydButXHT1Ruxc2P16ySVMb+UdQHOS1aSpmBu07G+EAxzLWO2HaNWOTuOd52eZ4NoiQjaU60Z9RXQQN/f3hZzn5U2or/pzRhgF95eY1NP+5se9nnSS03tkIr+3jzbIlivY0SuMo9pF26+fKRoDGKk7ykhILsufr99xl2ejfJ1/hxaQOe1BwNqVX89xFxmVmXmZtcGZiPZtKsl1KeBlhNEBiTYWD99DXOo0IZZkDUSAnBxc3Yt9fWadC2aJiJs3zJ682vvuAZLs/PIMgFRSF0zQkKIDPt2DOCabUO9NM3Adf+kFrap5PjrH11gX/n2OQTRoAp6BSFkMY6cXcfmsep7bzu0FYwIR16ew5YtG/GaN9yGi2fOo7nahhBAmkukmUBeENJUIE8V8JAENLuEnx5r4svfvPTFH/x8lbUSTIdxpDIcm+3lpcOyP2auvfVWZg0YBGY+hJ14bw8AcLCOMbP1mOKAOmaEBwxgAS6tZt/4myem2ef+4vj9//PRSZybSwEWI45UiXBVhDaDJJVXCJyhKHJsnKhicXUFFy+tYcumMbz19TdsPTm5/HCj1UKtWgFjIU6dX8e3n5qJOwJgQeCYFwCRF9gwOog7bt0PZInyfAgV1lHowp29NMWGsRA37Bt7VxR66ZfdTlOSzaAmTwS7RIVqzGrh3fEWo6z0Sw/TgNXbvbl2zy1vkrIdh8FnBOVrSnfZ/8z3zHoUDcImuPOHsKpMP8IwjPVKdj1nO7O9c0TmtQDGtFPYbeDL29NMXyPeEjvyEEbZhgWPUNXvK9kZFZr2z1r2/5jekz/TDuv4zNcKDnOtD7G8MfatieVBFm65/hF5c66Zl+HsbhzG3mmSTLp7bEkEuAPpAHDLwV0vXrVjCCvLSwALYD33OsB1aDDCoWs2VYUQlnmDSDk5GCEhjr95fJL9w+NTqMYVbB4fQDcP8OzZ1Xvvv33vV6/aNYaVdg+zi2t4x9vuQXvlIqbOT6KX5MrelmUgWWh1VoJYjtVmiidfquP//oe5L37j8QV2cSn7bckjsDDUY1Q/SuOBHWc/klfz5o5pMSjGxx1NeJZ/8o53MiOV3YKqxSRAA16pc/SoRGchppbT73/7Z3PsP/yvl9l//7szeOZkHZ0uUIk5atUAAScwpu7tJRnCQGB0uILnXjiLTtrDA2+8GRM1/vnZ2TnU4hDzix383ZMXsFhP8oAzfajTeQvTLMNNB3bRrp0bkHTaquxaIZCmOQqhzmCJvICkAjddPYGhSog815WupYpJKUtbg1rKSEsS2TTDltnBIRTGypLXqI0WvZg57pP+BrGZe2HH5tbmcrsbSsiqzAbLKLIfybg1hH22+c55Mcluah9NGpQJ5pidP3XWUkdQqrQhtr4eqq8vRziWxqyK5dCReaf62T8mwF3dPyfl9VV9lqX3JiWRogf9DIsEywU/HNAzTAcOngIl9Gj3lmWajlkZJOajUkNeXvMwtkQfAZq154whzyWGByq44+a9oCJBt9MDUaDqPGp7a5apDC7XXb0JQQBrYCchbaoszghpDnzzZ5ceWlrvYePEMC7MLiMKxIF3/OIhiDzFqdPncd01W7F/Vw0vP/8c2ustiFxAyhwBKxAwlTJncr6D7z63ji99d+nA3/x0mZ2+1PvtpAgQhIEXzqNoTEXWGGHK0c/ofeEgPfoDAaEjJzvbetZstmkrQc0SWOamd6ZKg6EmIgCBBQyFBNbbGZ45tcaOXmhg21j03oN7hr+6f8cQdm8ZwMRwhMFqjCgEIi6wfVMF8wtNTF2cxtXX34jf/OXDaDfWEG4awdEzqzhyocGiONSLQnb7MSg4fdvN+zBQI7TWuiDKUeQpiqxQKXikBDEgSRJcvXMEWyaqn1vvJJ909Q89acgNxzaE6AhKTZEXV+U+9UCTY6xeRBQAlZaE7BxfqS3PAO99Zq51L9LfO2+ZeZSPHktM2d7vvjN2PDMPJRXT9EWvMwE2/7itOgTvPnLPcNNXmiHdP684pQ9L7XwYrxu8TW/Wwkdceo7s/eQ0CJTbNI/rf5kx+MzYjb4PJTHXnqU+s8HMrJYgnEbBZm4Vh7L0ppg0uTqgKAsoa/+zv83M6rV3eheIBLZu3nDwzpuvQmN9BQSmot2N/VkSJDjyosBV24exbaL2G5eW8y+bmg+q84pxx1GAuXr6zWNnW7j5wDg2TkT41x++60t7NseYmZ4ELxLccGA3Lp46juZqA4UkrLcS1LsFFtczzK7mmF5KPz+3ln+ymwsUAgA4wpDbSlcSym5nQgI9CrF0wxnTldW9F3kODD0PYb/Nxf/blYovE4PU/5CeHNIxKwTYVN8BA0jHcfUyiQtLydemVpKvVV9aw+hQPLBhJPpfe7cNPnTN1iHs3hRgx9YBbN0wgPlLS9i+YwW3H96Fpbk5SBbg0nqKXBIqAQcxHTejN4Ap5HHTwa1A3obMM4g8VwZEWSDPc0ASSKrjEBvHKti1aeDh0zOdT0rJEQYuD7wlHkODRDZ5m9v4sNdZumIOifjw39ynP7osXYvPHUub07bv3puH9SMHcz9jsHOhmDo5hgy9RpzbazhnOgdUH7Njjrn57MwiXqYW2RnI9f1ev22HzGf2GQrNmBQ5NqjUY0LMXuczVY+hlpDqlRmPmVfrTbbzBUvXBlFbMeHNfz9DZ3oxzaZRz5SWyfjMTkhzfEvtDW1sUs/x0RiDPuPpIVjm99Uzcdj9WO4rh5vDLRPDJ3dtH8Ta3KxGV6osmfL6cnUuJC8wNhDh4K7RL12YnftypVKx6JOIVLwmqTjOcwsddFPC5rEhjI1PoL6yiFa9hSis4NjLszg/WcfkpQ4urSWYXcseXusUX+gkErlQ9nEtrcADBs4IAVMONwkOTlzTkHu5OXEfMDiNoMTKLCMDQivx4eAaeReCcZumXG0pDtLYwkhmc4ZKC0VdwABaakNHZ6uFSgtgqZF3l5vFWy8sJXj6xCrGBsPf27u19vkt41VsHmlh155tGBysYGJiA5549iyOnFp+NI4iizBcX3Sqj1qMvbvGIXotgJGqYlTkELkK5+CkSqYXokBlIMaebcOohCvIpQAFgR6qb+dxU0ZGpfLRgH3rCEpJXHXfZfYQ8z03DgBX5cfQKDy0w+wm6WvLbmbTA9LQ30dyBhl5/dWMzNmj9HfMa8lnCCBlWPU2p4/OmMdMTC4/wNGRmRoqbW6jBnP4KrFpVwVYmnV162AYoGEiruuu/xYh9aMss/+9r/w8+yYLMPrm2KmxBD+PnI8CzakF440kPYdmjQGAlZr3VW2NHJn05sg83gMRcELoisifcajMLAw7t45gtAbMdro6vk6q4HLdbymlCigOQ1y9axT0s1kvMacGH+Tm/8xC8sz5ZX7HaEVgcDRDKnLMLaZ49IUFTK0kUytr2Yfqnfz7vQLIhRFgislGIbPB627EZiHMeV1lyCOmzjM6niPL68WUZ5Z5AdV2cgGEZuPZDI+mSrAmKONRYjZmlOxglZSX9niATzeWGRjOrlZbXRYEAFeMo5tLJA36wkK9+YWAtTA+wN51/YFLX3/VHfsxODqGtcYCJudbD0RhiEKoE/WGaYIBopAYHR8a2DRRQdpbBYPKIyaKAkUu1N9S5Q7LhUQmJSZGKohCjiQRiEIGwBB13y6wxKTeGmOqxUZ90tfflMp7qRCTrxY5Zlc2atu5KzELTxKbTce8QEbvveuDYbiGwfWtu8dMDIFdyWhv1SDAxlCB+ejErbWPUJlGGSZ3ujeNZVXKzkUf+veI3qDU/s1r7HAMLqrdpvXRneifQ/jI11tei3I8JAmvL5YxWaTrMzv3h2P0+os+pu8jdIMiNa711sFca5CiRm2mXqcn1AySk5JQjUJctXMDuBTo9VKVVTVXhZ5ZwKCChgGAIy9ybJqoIg6YPp+oPeekVDshFFI/M9u989tPztBH33kQkB0UaYEnjy3hJy+tsQwcIA6BEEFAAJNmpqwh3gl3N1WkM7wYm57iaQaK6J3NGZiERc9WqMMAI3JB5dAAyUgJo81bDEZ+Z5TUieIQcaiMcWEQINDHI2zmUN0Vt6xmCQ3Csb0C51BthAFYECGnAIvN4hvf/uk0sjxELgrcfusBbJuofsYciWGwzBecc0gqsHFi4G8HB0IUeQYidXBU6DgwKUnXm1OnBEQhMDQQwZQmNwRj+6Y6q1GI5w0poVNmbzBuXhj1xzThmXp8onTIQrVnzr8575j+1n+22bweKtG7qcRAXd/L7dh+eO07sirdWlLb7PppGvA3oFEhrUOAeZ5P07qlncuFm4FS5WpLztPtJhLlFxEMEveZEfNstq4/rITmoP/2UbYNjPQe5lC+u6ffKWIyNhjacO3jsjXzhZZt32NkjLm5V3RmBKVr02S56KefvJAYG61Fh6/bgTzvqcI3ZI70KQZXFAr1FIVEURAGahFqVQ5h7F8eSlT9DJAmOSZGBrB1Yw1FL8XFi+v4+bnGlxLi4EEExtXet8P3kSicEFNzBRUdQkwjdpWXLAg4wlBF4FeiEGFYzr5r50NPgqVPuO89L6QjRp9YNVkBTHn7Go02Wp0OOt0OOt0eur0MSVYgLQiCOBgPEYYRoriCKIoRxjECrpKp2U3P1HilZBCkDP4SDDzkAA/x1PGl4KWT88gziU1jHO9/8BWfSrIMQGCLFDiGCQwPVe8PuQR08Vt1mLxAXgidIUPl9pYSyFKJWiVEFGp0oHPuM494zagNl5eSvLOTeq3IeLIUSrCmKQ+hSJ31glmJC0u0lkmQ+9zsT7cP1XpYovA31eUXwxjTWakJD0VS+RaLuExbzDBTPVBDE+xyJGjmxW5MzcQ1O4PK5dZ3eNrMm/c45QDyLpGGBsn2we+v9P62M1K6Rpbn1Gfu3r1OWMPSO+wYzfx613sI1a6ARr9GBywxVM2ELdIlgxzN5pYg/3yfWTVyTiAYuiO/LW8JiAASGKjFO/ZsGkG32VTpm3Nhc2gVmu5FIXV0vEQIoBIF1jxix0qKyRRCYGg4xC+98SB6rSbW11P84IU5zKyJDxMLIYhDEocgZU5SXVGxWeooIUCkYro4D9VPEIDzAFJyZIVAr5eh00nQbHWx1mhhZb2FZqOFLOlA5pnXL8uu3GcApAYZYf/iOimqF5mr+IwkzXDVjtGDB68aP9lpd9HuiiRNsmc73ewb3TR/pJ3k071ehh71twhEYYg4ChHrYpoSqnyTSeIPbdwFA1gQot7uyq9/72Vcf3AHRNHEg2+4Bt/44UtPn5hs3Kmqk0gQ4+BaDa1UIjCm4bAge6hcmgIFIDvBWSExWA0wVOPvXarja5K0s4Ip+4wheEbQtgfS/SsbW00GD83iLPqymT2c3mS/s8zrMnWGWdXLV6FUO9bX6D6ya2XQlWM6JrrdsD5fHSxzN8esSoZsT9U16o2xN9lCs57qZ9GMRWMeSvhHEF/JfmUEpqE3cxOp68weVyqFQ5MG7as3TsA4JHsFQzxcHw0CLKNex3Ccqn05gvN/m7aYnQOTsFHTgQkIdkRghfhl95NDcKWUT2Zcdu6MYFXPGqyG/6lakWi3Wgp5CamCWDW9CT0OzjiKQoBzQhiy3URs2nTTsHPFhAQ++OYbae/OCKdO1PH8y8t46mTz/lQG4DyElMbOZzts0ZDqO5CLQp2D7nuFDBgfqWJitPaZ0eHw4Y3jteqWiSFs3TyIV91+Ay6cX8V//LOfPHRptfvNWjVWe9dm8Sg7bAAgtJIb/ZPq3MU8CFHkHbz6jqtP/sc/+lWs1BugVrfKCtybpvm9GfEvJr0c7W6G1UYXq/UOFpbbmJ6v4/zFJVycWx1fXG3XO70UAFCNQ1QrFYRhhEK40vX68CLAQjx5ZI49/sx5es0rdwLUxf/xq3ff8dF/8y0IqbxYftZOdXZM2rgXSQRRqHEVwoUDFJKQiwLVSohqHNwL4GtO/HhECkBnWusjbG8DwqxhX451rhmeackDCG7POuXaMJ/LUIOnXvjqp5WafRLf/9tnJv7o/E1piE71rw8laekGzcTLyEIROnnjdgjMIA/H+uDNnbquj5GY9YPDIVJ/b0r++YzdoSFHr2pOjIpP9nozrlI/zTAl2bH5qnGJ0dn5cu247B7k5rB/PLofFlqa+eifb41auc84SzThGe2JAM+m6D8vDII9JAW6Waq1D67DF3TCQCh7ofRsaSHYHoCmHWcFNNFj97bRTR951/VYuDSLuaUuvvf8EhbqxfcpqGh+bNYTCFkAHnAUUiBJUou4a1GIg1dvO3LN/k2Ht2wYxKaJAWwcH8aWDcPYPF7F6HCEaiwQBwxVTiggUI0rmDk7hTzPT9uKSsRssRin6rrxh2piOZiOX/LWzXlR1KU48tKFo6dOXjh826EdmFyZASMgogKcGKoVho01hr0bY/BgEIxtA2MhsozQSrL1xbUOpmYbePHEDJ4/OXf61PnFg720h0qlgkqtAiEUzJVCRfY3kwx/9u1jj9y4b+NDA1WBW2/chHfedy395Y9OM16pgmt3PABkeQESquPC5iFzAs9Cb6mMlMpTEtpybhaeMiAOA0gCcin68tWWGbyZF1MYlJFBEpYyLRKwG9BTtUrETs5Fru/QNzsJbASKFfWGs1n605u9JJBMm87Opz73NrZhVIYJO/jmNk9ftzkI0qjaJWbpIStPJtjnWiTnzaqHeI0wYUba6nm1tkcq30Ouo7a/UPKjRMdmhfsN4CVjOEl3vtV7ZonpwyC8K4RzXIE5+YwO3t4yHmaAvJg3Zvefq7xEVgNiZh29vhi7RRjyPQxSVSESEkJok7h06X44V2aOwEyJsSPr9SCNnIgIv/+B25cGgy4uLrfxzLFlHL/YYqYfRAKMc0Q8QBiEyNIemr0eAGDn5vGx2w7tWb/j0G7cev02bN88hOFBDipSiDxFJ0mRphlE0UbSEOhSDiYJTBIE53jh6AL+7JGzC+ttcaYaxxAkAEZgmomZ5fbpKoQ0g2GlRYX9gpAXBYaGqjhyavnmP/jsN+iPf/9t2DYxhtnzZ0BUqBLhmSm5xsHDCIwFiMIAlShEpRJh73gFN+zcjLfctRP1XnHg9OQSPfnsRXz3qcnPn55Z+2QcRYjjispiISTCIMTJs6tv/eZjZ+hX33QdOu01fODth/HE0el75tezJ8JIV1RhDO1O72iWisMAU5kmFA3CeF6lXUiFyEpoxf6piKPdbaMSVxAGkS715iEvs3FsaIULfUAf8Vu4y8qbwKo+cKir1ASDPgxuGJYhXX8Dljej2ui6P14aG3dom2x/+p/PmApxMR5WNV+Kyfub1qJG0s4NO3d9c2NQg8fY+r/z77GfMYe6wBwTdgLU9UVKCb+8mmWMGlUZpmvRE8F+bp1BBs2aeUK5vz4S1lNr57OM8PpUVfShPSNATVvke6Sh88OZBURp3gzCY0xlWxFCIoxivYelN35ZlUWOvNBngMkwIyPfVGxXoB0dUhKkRMN3SkniYJC4+eCWIw/cswvT0xcxM5fiRy+ufrGTEsIwQEECQRAhCgMUWYpWK8HmDaN46+sO0xtfex0OXbsVm0YDhKKLNO2g217AcqOHXjdFN0nR7iY2MoAxgOt1juIKZpZ6+F/fO4cT0+1tYaUKT4rCeC+tsPSEVajZquLSOjUzWHkhFCyUqFQr+OEzl9hn/uP36N/8s1/E+MZNWJy5CAYGUeR68wSQeQGSDOAhwoApjwMPUK1WUAk5BgZi3Lwnxq37bsB7Hjjw8PefnXn4q48cf/jspbUvhGGIWhyBcYleIfA3Pz5bu+fmnb1tGzi2bw7x3jdd//jn/uIIY1yVcuNBhHozebCbyOlBHji4DafWSVMsggicE/JcQBLVDWdgTJWQGqrFeN0r99P5meXPn59rfTKOInWui8Hwck9l8lmb2+RaxJpPcdkOvMJGYaxMuMYOVUIcfSpQWX0rP8NVHyp7Dn3vm8/I+jeOy3XV1y9NFyCC9MboI1Ofkdt+alTFGCunJtIohgHOOG8Qqzk0r6fBV9NNLJdvByOQq35kGbmh5X+cmcq+eTXMybc/WWTYP48+kvTvt0i7vFb9fxtV3dhNWWkN4QnCAnffeg1tGBvB33z3ORZU4hISEZIW87zYUwipPO6CQFrTAOBSKXGtopOEkLQYhkq4Eec6OwPh//r1Vx1G0sTaeo7vPzuHiwvd34auQBYiQJZn6HXa2LNj09b3/MI987/0xsPYs7kKsASt1goai220Wx10e6kqgygk0iRHlheqMhgDSKgIBGIKgdbXevj2k5dw9EKT8bgCcFYq4GJQYpm81LxxQ/yMmfNgZDeqsQ8QVFKygAFxHOLbj59ln/1vjyLJGeLBIXS7PRu4RqT07iBgCLnCxFIShJRot3uot7tYXlnH8uIyWvUVDEcJ3vX6q/Df/+CNn//td72CRmocrW4PoiDE1RrmV7vJtx4/gyiqobW2jrfeuw/X7Rr5nsgzgDjiKMR6ozez1kgQhLGqY0fG4EmlM3OkM1PoU/PPGioKwhBFIbBtNP7Pn/vjD+J97371w7xIQUQIAoYSp/JeROSqHHk/xmvkq5D+PSVC1puwbIthVpDYNj01xG0atVF9dcZXRUzHS2jNY+7w++y16Y+1PC5yiM8qNWaM5n7XXztGDWFMBgWbksdsUOO6Ql8UvEEgQMn2Z1CU3z+LdAA4Q7q7prxu7lnusz5GCc1MoTe97NsTfpu+duMxKBcD6wRMPwM0CNhMoGGYjCnBn/QybByN7/noO1+JN73qWhTGs+2ZHJIse7zTTUBChUqY6toKaRlORxbZpykhyWhRrZYTZA/dcw3ddXgzZufW8dLZJp45sXI4KQgsCCAKgU6ni00bhgb+xW++hf7ui++b/+fvvwV7RrtorU5h+sI5TE/NYH5uFaurTXTbCbJM1XLNdUFsAqmkp5AqsWmWo5cRfvjcPJ46tsQkBarsm2FehpD9YGJnMwHBZmQ16kJJbDjprlGCymEdgPEAf/39k+yLX3kSLBoAj2sqxxZz8J1zAmMCBJ0fiHIwJiCKHFmRIxGElVaKpdUmVheXMBT18Gu/eDX+y//1Bnrrq/dTlmfI0xQ8ruLbT0+zqfk6ZEGoVnN84MEb7o9ChQrjaox2L8f8YgthFMHmG/f2oUFfqnAt0E0Eklw8roeJgDOABHZtHfnE+ECG33jbnTh0/a71bq+NKNAVng0c0VLTzKlvEzHvja3KKRVeZ/QEGUbix8+Zf61dyPvb3MuY95ntg+uL+dBK8D7Oaz7z7TBmYxk0al4EA2aNgRxw9O4bvF1f7L0eenTz43l6NTJiXvuAOW/pVFCXDdZholJWUjMmZlCTudahKHOcyoyKc2fg9wbkwy0PCTL3DLse3rMd9rL3wcyVGRuYRqAotccDNVrOVJ1VNQFcRadzDlEQahXCe37h8ONvvns/kuYSBmuRdyRN3dJLikebnRQmdMWspcrIQo45c4WuWx2BJCcwrkw9JAQmxir4/3zkbrTXVzG/JvDY8zNYaucvRXGMXi8FAo7f+aevo0f+6wc7n3jXQUxUmpibuoDz07OYmV9DvdFFUQjkWQ5JEgVUPrCsEDofBqnjTZIgpUAmMoBHePLFZXz/uQXWLRiCKHJRA3CmCuVNhyfQ3ZrZnPjmFLhFAoao9UJJqQLSCiEQRQEKCXz1H06y//GNlxAPDINFkUJwgZGqiopV5ohCVxPKIIoceVogTXOkmUSSSTSTDMsrTdRXV7F9FPid996CP/6d19OmsQgyy7Dekfjqd04hrtTQbLTw+jt24I2v2EF5loLzCEIynJ1aAkMAAvSiOeRkThlIoQy19VaKJCmesFV/tcq1ZcMI0uU6Nk+E+IPfeO3Y/m0jv1FvdhBFIQB2eSUdMpv1coTlz51DLShtMj3J3jVM59ov21Xs924PWjRkOCV5fTHePoPo/A2n+Igz2DvGwoyQLvXfGqf9+/UG7GcDKLV3OfIx6Mn8bdR7229/fOU/bH/9vjkTgZlKZxciIucx9BBieQx+n8voy3mXy3Pb1y13rwFZ3rW2f3a+dPsm4aURID7/JCimQgxJ0sNbXn+IPvEr96K1sgASKWpx6MM0AEAvKf660eoBTJlCSO9VoWxdNr27abveypHmBPAQQhJ4APyLD76ato8FuDDXwvPH5/DyTHer5CHyLMHt1+/u/fV/+hX6vV8+hBGsYG76As5enMXcagfNToZuT9V+zdNM14DNVSYYnb69EIQsV3VdpSRkaYEoivHCyTV862dzbK0rEUahZXROsGpeREboOjutNSeYhVOzyHXuL3jE728kNQlCCIRhgDQn/Pk/vMz++gfnMDo8gjAOVYyJB28Dpox1gNBHFwQAgSxXqW4yIZAmOXJJ6CUFFlca6LTW8OobJ/DHv/t6unbP0B+QKPDES4vsZy9NY3CgCira+Mg7DmPHRPRxkSeIwwAnzsxDyAAcXMNm0lRFalpI5TwCB1aaKZJc2Qg4C6wM3b1jAhOjg1iYmcFr7tiFT33oDV/aPl4ba3USqCOTpDetmgeLwmCMre4HZkb7DRu+VAdcJlJ7L0ovf3PZDcYMWjJZZNllFYcMfV/eN787Hvpjl1/n0EIZ+dl9zJi1bRG8cVgU6IWXeGqhf615bxm67rtl+gxWXbKVkPz+arTmG+fd+I23sOyR9cfev2ZmgH4Vcx81WbWyb536Pyg90zJaz2GhkaRFxEytIeNAFHF0Oh3cecte+sNP/CJi3sXC8gpGhmsYqvIHSaNIzhgY58hzkTTaGThz4UUm1IF0jntAggeKmS6sda0aypnEvTfvol/7xatwbnoaF2ZW8cyxZTR6crHIM/z622+jL/+7h6r7NuaYuXgak9NzWFhtotfLkaQpsiyBkBnyIkMuMhRC1X8Uea5LqAmQLtnGGJCJHIMDMY6fa+Bvn5gdW2lJhGGo5kf4oAAuOJxZRfAyWuVOqhCMPYVMYltd0sy8SnYAKRFHAZJM4H9++2X2nSensWF0BFGoTp+HQQiwwN7DiaCKywoVLU+ELM1V5LCQSNMcvTRHLoBWJ8HS7Bz2b2D4w4+++rO3XDtxpN0p8OffuTi12lTVvndtr+Kj77zliwHliEOGk2cWFtabXQ2jBRiTViIyBp19FRCCsLiaIBNaddRZXwFg88YxRGGANC1waXYG73rz9fjEr9y5PhgS0lwgDLmHTFSbqnyc3qR6HqXJKcU00XLu7Dge6nLzfiWkdPnfdqm8OAR772XXemjF0+8UcNSMxBAFc6cGAC9Lgw8/7LMsH7ZqEYjAXPlV3baiJ5d11LO22A2tPaawYBnQKE1pAUzTHenPXTyYUxidzc2KWY2OraAxawNNEH67HqqzXkUdGmPGeyUkaT9iZj69C6hME4xcDQJ/HSU5RqeuDBCGIbqtDq7atmHX73/sl3DVVRtx5txFCMZQiQKMDEYfJ6k0CdJH+LJcYHmtAy1jbYYYM0blxGJgxNBNCZcWGggDDlbk2DQWD/yfH7wbayurWFhcx5FjSzgz14u7aY5//bsP0h/+7muQrszgwvkZrNQ76CU50l6KPEtQZBlIFJCFikLIM4EsLVBkOUgIyEIVuIVQabbSLMNoLcSZqRa+/tjcHQvreSMMdAiX1m78NfP/Y456vHUkcJ/4y0TgozDNhBhTDIKYLe0VxyEa7Rxf/vsT7LtPXcLGkUGrTnB9hIgz2B9D5FIScp10MM0LFAKQjKsKJgJIUomluWVsHyrwB//01sM3Xzt+6uR0c+/f/GASYWUIzWYLD9y9D790705iJDC72L5qYaUJrsMrjBrDGGxfQ87RTSUW11MUkoOHgU4xwwAWYHR0UB1xEhJpr8Dc3AI+8s478fbXXU95kugDylql0qloFKNy6IgxnVmBDGR3aMJUrLazYNFPeXOY+S7bX9TziKjkMCHNcMqFRzxU7aEgvW1KaMGoiLZIrd5Q1sDtbWBWug+2beh1NczM3qhRPRErPcva2wwb6kMvKt1OH0LyxwZYYetQmLObOWTnmJ1DTd4YXGI7u0kY+uZGj5U0SuIm5bFnCui3gfrjMXDAfGdmhRlHE9cIkzPwMEJRSAzEDB/54Jum3/LAbTj38mmkaQYpCYO1ABOjtfsFAZzrY3VRgFRILKx1AM4QBorgDQIzckiZHjnWGxlmF7uHwQCOAh95xys6N+2vYXJqHpMzLbx4vrGQ5Fn+5f/vr9NH330Yc2eOYX5+GXkGpKlEt5urBKGmSliuQUimfvJCF7GFBJEAIwIHQ5ZnGBuMcG42wdd+MPvumZXk2TAIbCiFrzKaNdPEooVu30tPsUNgMMhCMSnG1KS6jWhsCX62A0WwcRRhab3Af//bk3d892fzGB8dBOMEkkJ1kGmkIggB9/IPaeif9DK0ewl6SQYpGXKhvCiFZFicr2PLEOGfv/+mAwd2Dh/5ztOz9//0yAJ4UEWStPGBhw7hxr3D1GgnybkLK+BxRenRUhOTthlLqaoirTZTLNeT9wHMbhSShCAKUKtGIFkgzwqEQQXrq010kjp+53134fYbt/e63QSMB1AAXcIwFPLGA2j7HzxVCY7IlVDgJcYAuI3nq5O+zcW36aj30lO7pEWEph9lb5mHgryc/u4Z/rPKxmtLLbYtpq+HzpLgGK7PME2qYNLZc5m5hlmOYJotbX4fQbrP8Y98bnanN4fc2SoN+/JtZyVmTm6elH3KVavy1eXyezfH1qZl2vc2oEN2KK2/nT+Y+9W6cShnUdJp48E33kq/9cFfwMrcRawtzoEDyNIUcUiYGFE5vEjv0yAIkOWEyfkWklwijiKAhKJF6RiZShsdYnqxhdWefImTwL037aR/8vYbcWHyPOqtFM+cqGN+pX3ff/ncx+gt9+3CyZ8/g6WVdRCpo4RJkunjeRJFLpBlGXpJgiRJkecqeSh0UWuVvkcx+jzPMDwY4fxchq9+f+7hi0vpNxgPFH1YVVfPGPl7ylAf2bklQ/t6/rhdGCMaHJZ39o2SFNb5wSxwU5Ivrsa4tCae/c9/c3rkbx+bwlCtioDraryMay+Erg8ntQQ124NxCKEZWaeLXpoilwI5ETLJsDC3jj0bOH73164/PFhj7/qL753B4lqCtJdibDTCBx46BB5wPPPiDLheVFscwCAxKMk+Nd9Go519zUl5FUlSiQMMVULAVjFShsaZ6UXs3lLFR95+uLplrMKTVFVXcRYSArQ0NZLCVC2ydhD9fKZzjZBWO0uI2Ns4Rm337TnmvZXghlFAjcE8RGuiHnNzDajmyijRqK72ZmNbYL5dyKEss4kdabnnWbWJGSbnNqvb1+ShKaMg+NNgUKkXziDN+jFvLmzPPGTmIx+DEt31lyNa77l6vC5Ew3dIqL3gq8G25x6KZhruK6ZlzhT32dn0GljMobWZMODotdu45bpdR/7Zhx/EUDXFpfMvQxQZqChQ5BkCVmB8JNZnd9WeCgIGFnBcWu58fmEtw+BgDUT6c2ZoUq2fLAjnZ5pI8gI7Jmof/8NP3IOku4y19R6OnW3i6LnlT/3Rv3j/6Te8cguOPfMEGq02hAzQ7eYqtgyqSncvydDtJeglKbKssN5OaRJkktoTREBe5BgejHB6JsWfPTrz8Nn55AtBGHoJMxVKt9LsH3m5tTWCV9EbJ8Amr2OWw8FKIzsLFoI7O4T1munLojjG/Hre+tLfn4m/9p1z4CFHXONI0hRCSghSdeKEVKfk80xoGxEhDDkCrqv2ZgK9NEcnSZAWBdKcMD2zhqt3VPBb777pQ4168qW/+8EpMB5hbb2JV960FW+6bQv98JkL756cXcHg4AA4Ux5JrvscBkCaSZydaaOXEoIA2q2sJG8lDhHHyn6mqhmpYrpMAlPTl/CGO3fh9XfsEQY+Kxo3yMsnSKU02EIMetOq7zTxmkR5Hnowi2ftN1dAZ/Z7i5jKP85Q7gipfB+8944JGjqy9j1zfYkBOhXNNODbnwwB9qvAJVTlzRGgPZ5k2aD93ChdBm0a2jYVdIwN6vJU2HBuVLhMGOZ6M6aSfVAP0yAxzpg9W+kzbXmF/pv+WeFldR0qq+DezjToCUQOMfMARZFhKJZ47y/dc/jWV16Dcy8fR7vdABUZZJEhz3NwCAzGKhezMqcqNhmHAVbqySePXVjH8FCsaAEEFujtq22vrU6GU1Nrj8QB8IlfveOLm8eAc+dnsLRG+NGTU8mHf/3tn33HQ4dw5OnH0OslEAVDr5ujEEBeAGkm0E1y9JICSVogyySEAArhUvaYuDMiQiEL1AZjHLnYw9cenX34wnzyhSgKwRlB1cTwJIz3MtNIejltXCRM20bo6v1t1smQj294NTaXfqnl2yX8PPK1SgXrXZn/xfcvsv/xt6fRbOUYqKnaj7JQbm5T7kySYmRFof4GVyloLTSXEgUJ5IwhKYCZmWXccs0Qfv2XDn/o+ZOLjz51ZAYsiNDttfFP3n4LAIm//tYRVKqDiKqqZBPTUb1RGGF+NcWlleQTgilvqxGgRIRqNRqIYw4hcxW3JiSEyAEONFsd9NI23v2Gg7h258Qf5HlhvbVWypU2rNvsUqs1vjfSRz32P5/R9KGFku3JVKEx++Py9bdCiPU9s+yhg/e3QTCqwfJGN2jK77vH7AwS6mO4/YzZf75TZ5mtQG3btv1xpgzbVe7FoqE8R+a5jDuboptnOwswXst/3GbVj27LzzL9t0ixBAn9tjxsqZmYs9mZKwxICNDpdPHGV99IH3jnq9FansbK/KzyzheqGI3y3ktUQoYw4BBwaxSEHK2E8PPTyyAobQJQ5x65VuUDMCzWBU5NN976trv30Zvu24XjL53AeoPh0SfP4M1vvr36Gx98E448/SNkeQqiAElSIM0E0lyhLuV1LFAUQmeTUbn2hJSKR2ghUOio/tpAjOdfbuMbP154eHo5+0JcifT+9uiBMSvozZ43DMmEppglMnZOZgWL54Ukw7VNQz6lkJ1x26BZGIPKABh2iSiK0c05/v6JBfYnf3UOF2ZTDAwMQJBAVgjFtIQ6nyUE2YPcJgUIqVOoYDokIhNCobeMMDu7iNtvHMbbH7jh/kceu4Czk3VAEDZtDPHx97zy64/9dOqrL59dwNDwgDrGxJgOVOU4O93CejP7kxIxQh2tiMNgJOBMl34rIEmgEAXSPAcDw9zsEg7uGcBD9+z9bMgUmmMsMLDKIQGDssyfzMQ7uWscY/AXzNso5Oa0bKvymIO+Rxpbn0VlZvN5Asgsn0lLQv53ZSO//9swQr8vigg87unlry8Zsy1KL6PA8txbqemuJucNtTURzQ0+SvWQpLNLGUbrM4ny9eYec5X53m4ogk4TTX1zYICtnmN/LbxGS2jQojKCUVV8NMoICBhHknSwd9v49l//1ddhw8YQF0+eQJp2IfIURSFQ6OBPKgoEjMCs91TNURAEkGA4O9P80ORCBwO1CqgowEFgJBFHHGFcxTPHpnBwx+Dff+y9d2Dy7Fn0UoafPT+Nvfv34fc+/Vs49fMn0FhvgSNAmibI8hxZocKb8rxAngkUQuqcXxKFlMgFgUhpTkIoL38YBsiJ4dFnVvH1H8/fcWm1+EIUV5QDxFsL9y/zQDyz0Nww+37h6Nswed9+8WAz6+N8mk1ywzWZ1xGTuF/AGLd5ECFFjMeOr7P/8Jenv/TDZ1eAIEZcCZQHQ+gzW9oeJKREoW1kkgGSmcK1irNLADKI0EkIS/NLuO/WTXjdXVfj+0+cw+xiB71uB6++bSvuv2vX+5589iwAoBKqUIlqJUSa5bi40EIvIwR+sRJNXAyMqyNhOaROjFiIAqJIIUWBLMlRb63j/ju34RUHNpHQ6Xh9oWulhf7NmWKgav6otFGsDGDaeAynctqFtZu5tH/tQjk10Ekpn2Gwvv1VOpGBy1GeJ6fMPvWeqhmEURW588T5xOW3229w9w3Zvt3Kt9eVkD4zOa+YC20w95ixMa+vdhOYTWKliGXktnWffn01lDF9MLNPZTa3cWZRnvre84b6tNAv3PWCGOYFKPOFlCrU4B1vvm32jfdci0unT6BRryNPU5DMIaWyLxVCgCA87UgqBqW7G0QBVjvFl49ebGJ0MAZBgjGBAAIjlRgL9R6W1+v4l7/7uodksYa55TZevriETVs24mOf+BBOPvcTLM5PgwccSdJDLiRyISCkgCRVmtAo0YIKSCgPI5M6cLaQIE6IqxEW1zP8zQ8X8M2nlthSh55lUQxiusoQL6Mvv8alNRcwJ3gMCLAzaXiSnk+bYMiqAuYif9UMIVqJ4j4vEZ3+TgjFkXkQIAhDnJntfPjP/uEi++q3pzC/nCGqhuARKTXNLo4iAuGl+DUpac2PEATiEZodgbWlVbz+zh244xV78eyRS5id6yHNOnjbA9diIADOnlvAwHANkAUicKw2c8ytpg8V2uBniIs0ohAyT0SeQQoVgFcUBUQhdKhHCgKwvNzGxhGGN9y2HUNVdX4y8JCXlRbMbG7nbfJ2qEMKxErz6uxarp0SE7DTfjlisnvEIipNDB46KT9Hj9+bXwM3fAnnnmH66mwX1gb2j7wul5xXYG5eH8l/HqGvn/bP0n2Wdr3rHeNx5ggQ7PEjGwoDx7wcejMouO8cLflI0v2Un+feu/UwffOuIbImkzRLsXfbxPYH7rsO1FvD7NQMZF6gyFKIotDhRjqzqnCxmEy4ORMkwDhDJyUcObeOPJeIOUMYEKoxB6IBHH95Dr/6tldix+Yqzp2fx9R8A4OjG/HBj/wTLEydwvTpU2BgyHo9ZLlAmhY6uaHUAeg6115RKKomFW4khQCJAmEMFER4+sQa/vzRS1994kSDdQqOIAxVPi+zEy4jF08NNzSnJaj1Ufr06V1HpDOyGllIMATBzG50DM3wLTIQW39uEIBZSP3boCcOhigKsdaW+M5zi+zkTOMzr7ph/FOH9o9gbKgKxiWKVBXisMQMFTti8pGRnizSsSycBVhd7aIQ87jl0FZs3FDFmTMLEBjBtfs34DWvugbPH72IjZsGEFUCFKnE/EoXrYS+aeLSjPPB/Jtleb3byyAEhxTqGEQhFHMtCgFihCKXWFtv444bNuDGq8fp6ePLTJK3mWFyepOu26d+yCor7qW8MBbmuA3JVFI5yzCg2uo3Vvt2K4OYnPrpNtWVbJeO+fUTk73xsueZhp23zhdeGpVpTtKPxPw2yBCRnivvwWVGYAZmeL+BmT7zYuV59ZkRY1f+3ArdK8zJZXOl19VssPL3/rPcp6qQCdmkjGY/GI5JTCUUAGOaORBefcc1szdduwlTFy4i6SXI8wJCameXUKmgY86RCUI3VfUeWGDKCwKQAA+U7XV6oXP1fF2cG62EWGu1sHn7djx/agE7t27AXbdejSd+ehSLK23s3Lkdr33D6zE/dQbT508iDDjSXqIdBoUDDEKoRCyMbMk4KQGQBAdDXOMgyXBqpoPnTjZw4mKHNRIgDEOEnEOUJY9bLWN+gEFULo6yhNr1BWb5Td4S0veE/TYW47WTmtB8CWKgvyUe+zACWGA7KqXQi23KPhGiiKMoCKdnOp++tNT79FMn1v7gpqvGP3vT/hFsGa8CsUSemuh/QOiASyYZpK2Q5CSuZBwrax0UcgE7dm5CHG7H+YuLICFw3XU7cd21W3Hh3DJ2bBtBdaiCi4ttdFMJxkPtBZSKKQtCAKDVzmSj0UGRB6qikRDICyX9hGZkHBzrjS62bhnBvTdvwfHza+gkElEU6jkx86I8qgSVu9sulNk5kmz9TIOyFAPgOlMot1kufHTbjxZ002UEoRmJUaMuRxmanUq67DvLKKAEUGAyJcD0z3TFY2weoiq5umGYmR60ZToO4ZQEqkVoPnNwyMXRqGuTGUbsoVaLgu1vZumYwZtvg8BtH1xn7Bz1CR2bh0y96wtY9pxPRoWRKu4uYAwCppyYsluFPESWFhisBLj75t0Y4gnOz8+hyNWZQllIVdNBEARJZIyhKCQaHZXzK4o8xE6qZBoPAqy38vOn59p4/aERnJyqY7lXR1EQ3vymW3Dk6HnMzrexe882HDp0LS6dP4aFuWnEkToWKESuA8n1GUqhPPIqJlPamqIBZwgixVBPzSQ4cr6NM7OtYK1ZSEKg6k0w2Nx8ZnZL2psnHHzk67QNh5ItqHLkaekk5F6CNjAqne/z5LtZD68xrhfOqWO+VFLEITR0dwseRyE6mcSZmd4fTS0kf/T0idVrr989dPrA7iFs31DD4ABHpEEIkTJyi5wBTIIHABFX8k2q/s3ONtBqpdi7ZwK7d41jbr6OgdlV7NuzBa1GD4uLTQxMbMDUcv5MWjBUqwEAlePLHLngAUOvl2Gl3kMhhkBa5y+EOrxuDJSkS7K3Wl3ccvUortk5fOTFs/WbjawGYDMlcMZUEjjJUBDZkwhEWnp40shXqzjjl+WoUkgDfZ+TRcS+fcnZYMreUJWG2wWelsCfXi9jB2OG+ZHzpNnU0iV05TEvD31Z75929UsPDfWfDe1HlYaJle1l5nkmuNHZEX31GFot8z9XvMqhpJL6aSjdATOvb2YP+OjAMT8zj9wwK4uIFYOTUiAIAxABvSQB11V8zIOUFiBx0zU76NZrN2JtcQFptwshGIpcCVAVX6VS5AQcSApgtZloQaXCddS0SIBLBDxEKxE4PtXGg/dchWa6gG6jg7c9eBhzly5hcWkV1x3YhVrMMXnyBHq9JqIoRC+FrbKkkBesg82sAQ8AEEchGFYbOaZWejgz3T06tZjcvN7OQeAIowChzslmEzV6NGLm1chEX2Pwr+n3Ll/+vWvXITCNumz5eM2cDAHYW4xKRGRd4E4t8B+kBm7TnnjQPQo4BAFpLjG7mpxZWEvY82fq2DYW/+nWjdUP7dhSw7axCsaGQ1RjjihgqpQkV21JEDJRqIK1xLCw1EKa9bBl6xiiiOHSZB0ikdh71WZcutTA95+ZwkI9vSeOQ7XwDDCBcIIEAh6AiLC02kaej4NIohAESczmVSKmSlhxcLQ6OUaHarhu79jhF8/W1eH2QAUXEhhCBlCRo5fnqNQGwYmgSis4QveWxTEio4qaDJTwNqK7vKT/ONtN2RZkDiObRZeyzxvIVbyTQWEmSaCTgF4YAIyjwT4VRlj5a+7brCwCM8RWQpAoMa9+VZX6mDJsUChsf5U6ZmCoRr6lPnk026e6lPKFUX8/yp4vk4HVXwum58OMw6o4hlESIY4j5FmONE1x6Nod31tf7/7KpZX6WhCokBqTleNVt1yFvVsGcP78ORSCociFimrXKmSeSwghEEcc7V6OtUai+yKtoOQMWhCr+bk423pmZjG5Y/euMVQqNXQaLZx9eRbbN29CFBZorTVQpBmCGChYriQqt3wFEgwFAUku0cskWj2JeifDUj3H4lqB+eXevSvt7IluIqBMARxhxHWlcMW5uJkvOM5wxfVmrETr/ssIMzIagBOndq1CuxuotC8c9/N74H0ETwIzU2G4j5FdtlfhMm8COlkgAkhJWO8IrHe6Hz491/vwYK2J0Vp4+/hQ+JnhgfD+kVqEWpWhVgEirjxSaaoSo/VSplRDSRgbb0GkAjdfuwmj7Ryrq3XcdP1OnLnUQZbN5AGPwQAIYlBWNmWDCALV54WVNjKd10wICSKFhqTut9QphbM8B0nCvh3DmBiOsNbKEUUV8CBAr5fgqn2bb/3wO+58/qcvnMdf//AltmnDBLJc6viYQEt3oeeK24O3Vl2z817OlW8+J7uyHtrxhZkPxY066alsZQmnnmnQvZ9KWl1jGJuHhLwu+itu7EGuLZfbnXkpoAFfvStLWp/JGqRlkJ1lbCg1dTmS02NQctSLK7LPsazQkb8nqMl+UFZlodVsgwCY969BbIwT4ihGmqVI0xQff+/r6PaD2/Fvv/Tdf0tEHw64ikFMUoHx4SpecWgHGE/QajZQ6JJjhRAotPfR2GoJDM1egfV2/nk7P1KCgsDKtJATZADUm90/SrvJI7feuB3Tcys4c3oKAa/ixPl1NNIMXGZArvLyEeeQkkEydRxfSkKeSXRSgXonR7srH212ij9pJOKbvUwizSTIrpupBwtnFnGiy/4uEYulcU/A9CnrRmMwf1tBQe56s5S6KhGzRGfW1EkjcotaphkYtaNMmB59wPde6lYMUbhCigiDwKo8koB2Suik+bOLjeKBgCumFYRMITGGLQSsFYXMc2I2YZssJDhvg0jg/Fz36Y+886Y7sk6KtcUFvO8t1+PUxTX6u59OMV4dAGMBhCyUDUWSjd6eW2yi2c3BuFIVpVRBoyp+SuhalgpiJ1mBLeMD2Lph8E/XWvUPG4WCJEPMxL9//WsO4sEHX4mllTV6/OgltmliFIxx5IVjNqxvg5RVMS9PVt8GNRNdNj47uG/nHh5a8Rmaactc7qEWD1MBYDY9i9J+tIoIh0oMwjHwTzkpubfpZUkFK6M5z57FfCpzxG3tVZ5KqL7UdOXkOxwyLI/pSigAYLYyUWlPle71vjBVkPQzjSpsugeoBIWVOMRao4mJwQi//88eoo+89RY8+v1nUW92fsfspzAIQVRg387xyau2DKFRbyLLc+QyQpoJS2OFcMJFCEK9VaDeyT8LaERNpgOKkRRphuEqx2+87eZHDh3YjIX5OawvrSHLJE7O1vG9ny0eSImfCThxIVTovEqqyDjn2CQlLQNAXkiZCYmsIOQmQaKeW6UKG1ujQoJqDtxxNsNT7EXlFfDIRaF8U5TY4SsnRNTfzPubnENRwxDAujnt83VnzOo4Sem8LuQIQquVBB0m5vik6bIev2kH9mU8Rkznxw5DhkocolqJEFUi8DACBSEKGSARHJ2cL3YynrcLjm7O0M0ZegWQSKCTS/REgKPT7Tv/9JGTRxcbQLuTodet41/+5h14w63bKE8Txzyk6Z0ay9Ri6/H1Vo6AhyAJCDKuXINQSDMzhiQtMDYUY9umwQ9ZQmYM4AGKQk6tLK1h/1Xj+NzvvxUPvfpqWl1vgDGJKFJeqiuhUzsncHN4RZRi+l/aaP68O+/x/9tDrMTUKqQN/fCYk7GhldQ69AWuesiGvIPqZFLskGfe9zaD7WCpn76a2Y8W4T63zWjRocfgM2TfQ3i5RxSXXWvmzsxJyXBs2zFzrxpQebkIUaiK2KysruPQwW1P//fPf4A++Iv70Vx4GefOT6GXiq5tVz9+366JPVs3VNBstlAIUqqj9joKofplEvzlgrDaylHv5g2txIJIB0hzIM8LDFXA//k/uZ0++NYDWFqcxdz8OtqJxMmpFn7484X751v5mZVOhsVmLld7QD1laKYM7YzJVs4WOwWTnYLLRAYoWAgEIcIoRBTHiOIQcRwgDM05WYKxf3vKGHxGVRJsBkmSt5ZwdGzVc9OgVRecWCV4aEx/yUs369UifZPlsqZT/TDMUz8YyB4lYKSM1hrDX3GzOmaoloMx7pWiV2gMYFCQO0AQBggC9cNDjjBQtrE4IIScEIUMccgQhUBcjfDiufrNX3n0bH16Kcf8fAMh6+Ff/9bduO/QFkp7HQUGtWFa6gII56bX75tb6QEIFUogE//ipGCh56ebFohDhv3bh1CLgTyXqtAuAXEcHIoihtbSArZtCPHvHn4QH3vXrZQlbaRZimocamSkSseYM3Egd5bMzdOV5r3swi97dxxq8W1Cl21gck+x1zGUCMkYdf219+0YVngZSQpVcg19zzQM9R+zmTH7tx/uwOw9vqeqhKg0QOp3KHgPsRjKG4L9zmkI6sf2x9N2fSbo9gHZZ4MIURSBM4m19ToefNOr6L987mN33HPTFsydfxmrS4uodzKkuVDHaBhHngsAwJ5dGzBQDdBs9pBnAnmewxjRFXMiyELNa5ITFtYTpBkQhHqv6s2e5YRKQPiNd9wk3v/Qdbhw+ixm51bRaOd4eaqFn56sf3ahXny/EgWoRgxxCMQBEIZK7eRcBYRynVCR6xJqnKtAbAtKmPfjFSJhzKelEol5tGBoroReSnRYfjmzgW2MAHcuUr1sSDrTLZksm0oTcQyIGaRm1QizlmSZnbnHSA3FoZ3U8QfrJJz6ULmbAzCm0tWYc3DS0Is+rlD+UWEXjAQYJDiT4EwVHxmohnjp/Pr4V75zFmcvpbh4cR2DUYHP/tZdeO3hrVQkPSgJqk7GxlGATpLj9HQdiVTFOiWkqiKuJ1JaBmPSVgvs3TaErRsH3qUK7gaAypB5Js0zFIXAwvwyqmGOh3/9Nfjsbz9AW0bCB+utFqLAZRQwcXVGwijEykob063TFTmaQxNWGJWN0yUE5VGAdRCQYV5wZgFPWsIXiqzPIeBJTjMSxViNpCWrAlhq9BAW9Q3TCXNH3T4C8x0b5nOVQrkviwc8KY8rTVsZaZWEqofOTJ8NO1bLYrKYxChEjjTp4vc+/nb69//qfdg7lOHiiWPoNBtgYGj2chQgdaQNDEkuUKlE2LdzAxiT6HR7ir6kdKEH2oFEJMFCjnpPYHqxfZQICAONmhlTwa15jtfcupM+8ks34cyJs5ieWUO7TThxromfnmg8Mt8Unw7CEIxJmGhY0gkLCv1MU9FbCvNeWlWf2XniYGaPato0/5UWrjRvl6NtH0SVNT+D2tSPi3CA5i3+mhjkbTidWXjyfU+Gc5prlDmbWZZrNpzpjJNYJclnJTUsrFQC1xAPh0ncZQhODZQj4CGCMEQYBoiiEFEcqt9RiCjkCAIN440CRFAeGQYEYYgXJ+vsaz84h7OzCaZn6tg4KPCZ37wDd1+/kdJeT2UG0PcDwLGzK1jvEMIoQpEXeiA664Y0bmYVJ5NlOcZHYmwcG/hTxQGAMAqw2ui+/8y5BaTdHFkmML+0jG5rBe95w9X4T5980yN3HNxM642mPmbEQcKsHZV+3NmfssBw81ZGNGYTmvdl43h5jUq2NfKQiLeW7l4D86VlTJchO48BWugOZ+OCR1sERzSlcRK5xIoeI3UIsz+ezUdyLv/wFb1dPuICwdQWgQde3X394y4LAvW3RFyJ0U0zcJnjM596L/3+R9+AausCZs8eQ6/TQABCkhWod3MIUlWGjFNkx6aRvXu3DqPTaqOXJCAGrT7qfPb6uVJKSOKYXU0wNd++GRaNKmeWKHLs2zXy8X/2gTuxMreAc+fm0epIHLnQwFNnGo9Or6Rv1TWfYc00EUcUBYjCEFGoCtQGgcoGa/ZaGIQIg1DZyBgrVUHyKMOt7RUQvvrl0LcVCna5+9C8bpL0nlMk6fKCOSI2aynByfBQw3WYpUa7iI5IfelkGlTvfSe76SHrO3xXgvrmM84RaEYURRxxRdm/4ihEGKhAylyfhu90U7Q7CTq9VKX1yCRyAVWUkwcIgkipmDyAIO1VYQGOXlhnf/mjizg11cH0pXVsHef4zMfvxj03baU0ySDAITXTfPrEArs430UUqcRx+mgnJAkPYaqNnOc5qhFhw0g8ptCiyvra6BbJzGJD5XAKGcAIa+sNzM/N4+arR/Fvf+u1eNt911Kz3VHIJFBpfMySGzRsM6YxE/Tn8TR/Qb35LamAPmFYwnKQ/krqpWIK0ssHVqYFXwlwzNZtEKPygZW9lkTWIlZSXU3ogbnHV2UNlVhPqs9WmXmGhWi2v1bm/yNz4PqkEYAnFCwT9qbL8k/N7YQgVOII3W6Kakj4d//qffTrbz+E9vSLmJ88iSxpI0u7ICbQyQVaSQEiraIFqvF9O8cvbhmPsL62rg9JOxiQC3X+UOWxZ+jmEmemW1hvF2qvScW8kjTH5rEa/vVH7v3ixmqO46dmsN4Bnj61hp+cWPv89Fr2gESAIAhVZHwYQfIASSbR6eXo9DK0OimanR4arS4arS6arS5a7Z7eZzmkIARBgEoUoRqHqEQh4jDUDI4rpuwrhv4e9/Q/ZvgK84BWSTvzzUkeoreM0Fs7y3+AkGmY5exgDC4Jrk7d4qkEjlhRlqiW+MkSOREBHLbYgKEszjmikNtqyYyruJg8F8h1BWIAqMYBapUQg8PRxFA1/sNKHN7OORsrhJzq9opvdtPsf7S7abeTFEizwidRRKEyOpqSWi+eX2ckL9B7xB6EYYjt2yfwRx+/G//y//cU/fjFeRZGMaIoRr3Zw4sn57B/y1WIowp6aWqyU8EkYTSbQgqJkEkMV0MEOikjDzh6icDsShe9VBU/SZIcjAK0Wim63QVMjAzj937tdtQGQvpf//Ayq1QqYAGHFIWef46+ECczLBsMazennXnAVo627A5W4Sx5Ib0MGCVDvN7Q/Z5KCZNyWrWjirRozKqZRhnsmGdpV7jPiHxm2A+Q4ElpTVdlVVg9zg/o9ftpmbynYpo5kN5EOjtbmbG5edXjtp5gAIJ0cWOBKK6g3e5ibDTCv/uXH6F3vn4PFs79HKtLS6A8R9JLkGU9RLUY9XaBZjdLOANYwK0E2rF1DNUYmJtrQUgGSUJXEyK7wYUQiKsR5hYSnJys30GkjgyBM/SSDFs3D0X//nceyF65p4LnjryMxfUCPz+7jufO1D+x0pZ/wsIQDFxVCcoKkCBUKxzbxqvXjg9XPzs0EL5roBqiEqp6jGZ+0kyg2cmwsNq5f7WZfb/d6cIgrYCrUyYOkam/A66DvT19zMdEVxIizuZoaIFZorcU5hXnBQDj3FQ/XMeBUZmQnQBy0lS5jh2MdlLKyFFp+2AklZLI5onMElKaZKXBBAHH0ECI8bHqg5vGal/ZuWV4bMemIWyZqGFsuILRoRjDAxEGYpUMTUocSLLi/m6SfbHVzlHvZFisJ5hb6WJmvoHJucbhS8u9l/IiBwAMDtYQxjFevtRiX//RBcrkXhwqgK1bR/GZj9+HT3/xSfrxkUssqtbAOcNjz01vvuvG7UvbxiO0ul0EQQijfujtatm8srcp7wxJQhgppr+03kOrp9SMTrujz5OpAgyzCysYHRnAR99+EwLG6WvfPs4qlRg8MBWS/YU2jMlDG1cgAvPeciyDd/RGdfeSTahnKzd7z+pX0xw9KM8TiCDNJzbq3S68145pmEqo0ZopyNFr6dkoq77+e6fawTJvBpPVoRxWUpLYfu9MW/puHyXquAQtRPrnV9F0GIVI0hQToxE+/8e/QW+/by9mT7yA1ZVlVQex14EQuTpOxznW2l20usWXOFdhFiKXADi2bhoEJ4FWJwEYU8d3SJk+iBEKUYBxoJNKHDtfx9xy71nOlc02z3Ic2Dvxmf/wfz7wqYNbq3j6Z8dwbraL45N1PHe++dBqS3wzySXyIgfnwNaJwYH9OzZ1Duwexf6dQ9gyWsFILUAlJBWATSbOUTtuJCEjoNWTj67WEyyudLHS7GFxtYfl9XRhud57f7tXfL+TFuqkiQYcPFCeWLJz6DMzH9a6tXGOIke7DAZl9SM4BmImSFo1UzoLqS5y0dn+wgF+jJAvvMrSF+QIzNd1ObgKBCWBnZtqh67dO3J080QNOzeOYtP4AMaGQkwMVxWjqgWIAsUcQLAR1wETamIkIAcDEGrIsgoEAYWEzl0ksdrJj04ttnF2so6jZ5Y+e3Zm/dOdLsPYyABOL/WCv/rRRdFLJV6RF9i9YwM+89F78On/8hP68bE5FkQVzCy1lp8/OYe33L0LURShEEq940wb8Q381RI/DBhCro4MKR7CsbjUPjq70Dh89fYK8qJAwNSxpCJTB2UXl+oYHB7AB37xOlBB9D+/d4JV4whSR8S7vElXQA7e34zBxmr5kLsfeRkm5o6D8csElmvfEJZ5tPnbMD/zAMeIbFtGLTNEYs0PjnLVv+pQc59ctuMtGWu9Nv1snExntvURaak1pmPOFEHbjUOMdG0TsuTtq5U+NPSmD0EQIC8IMRf4N5/6AL3t7u24dPxnWFlaUzFTqTqIDZDOmMqxup6h3Su+FoSBqiBEhCgOMD4Yo8gypKmwNlDGVAB1UShDehhFmJ7t4aWz64eFZKhUIqRphoN7xz/35T9828P7NjL85KfHcGqqjhcv1HF0snXv7Fr2hJCEkRrHPYe20a0HN+KanaPYvrGKkYo60SKkUPn3pIQsVOr2Qp95NEtbjQMMjQfYs2EQbP8AGBMoJEOeya2dXvFoK8nQ7KRodQg5Rbgw18E/PDPD6h19KsXyArLrp1bOOUgYY2CaaULzHuhr+ggDhplwx1QAAKFvQ/AozS66JUbD+chwR3jX+5Lea85Td5jC5GAg3HFo29F/9sG7MBKkaDbaqMURGAmtRqpFbSQ5ckEopJPwNie6VGhGEplIBFWgkzOEQYAtwyG2jI3hlfvH8aZX7f7UhfnGp554fg7PvDzPZBTJyZU0+OvHLv5cQByWEti2eRx/8JG7MfS1n9E3n77EGGP45hPTwQ37N4g9mypYXmshDgJIpgxiAVNs3owx4EAYAAUp6RoGIZbXOq+5tLi+fsOerSCSKIhUskSp4nwkASsrdYyMFnjvm65GL83ofz92llXiqFySHtyJDh9NWAnlPIe+Kqj1nZI9x8yRasrJR8so/ZfHvFw4hCIcZomQacGpmQ4cobqOkh6BseE5ROi3p640VjKHyAzjK6EykxJJjxH+8zTdmqKxTEttnzEaCa/6Q5fPpVVbNeqEO9qVZRn+9e+/ld56307MvPwslpfqKCRH0u0hzxM3L8SRC4aVRo4klc8GAYPyOjNUqzEGKqFNl2OYBkgdWxNECMIAnRQ4enYdS+vFS9VqBUmS4NrdY3/wXz719of3beJ47MkjeHmyiaMXmnhxsnX40kr6UrXC8JY7dtPrXrkT+zZXMVQDQBKFTNDuFEhzqc85Gk86RyHVKRE11WrsQQCEmq6rIUO1osKUhisBxgcYOK9AUAxQgOGBYTz63DJ+9PzMbilp2uZ1MHPpRFYJcZv5dyJUrSuVyJ1pQeevk2s7LEm3Mv0CdlHLHNGX7P0uZx8BWPEMj5GxAM+dXLr3v/3VC4+/4+5d2L11ACsrq8iyDASOojCbXdeyYwxcSy8D6jhXKMxUIC4K0pWMVMZIxpSdbaASYWKggm3XjuKV+8bw1IkJ+ovvnjncyfHSbD2/+RuPzfx9IdlDt0qGjROD+L33vxJbxqr0/3z3HFtcb8nv/nQK7/+FfRgZitFtpwg0vFeI0kl44/VkUsHvgHOst5L69Nw6SGwGkXJZSyEhzFERISElw9pqCyNDOd73pn1odrv0g2dnWaUSW57ihzYQ+esCO//9nrLypvfimxTFWElo//XQnKMHKrXP/OfpLpjzbgDTWYB0H0qpdjRTs0jM2bmModZXKRz1uL73e03dXLj+u771xQ7Bp0sfWZHdBOYbYxaziECrpSpWPUAvzfCx976W3vPmm3DpzEtYX1lBITh63UTljCN1PE5KQhRwpDmwWE/RKwgs5Ip5g2mBp7xoRqhIQZamocv8nZmu4+RMt4YoQpIkOHTt1u994ZNvvn/nuMQPfvIizs40cOR8Gy9Ntu6dXc1e2jhWwUd/6QZ69XUbwZEhTTtYWs2QF2pFAy9LCplQJFJnLU0Fb5CpCwAUOjNqrwC6mdSx9spcxDkQxyGSBHj62Cy++8LK51eaYjqKzNGmMj9wjKfPRAHHf7RFHCYVkgEuVicgj6ZIhR+FEuqAsuNuJgxCQx0YH4On0RqVBSYcosz6+m01log5AxBgeqH7xNe+dZIdO7Xwk3e/4Zp7X3XTBhBrodNJ9USqvqjfElyomBCVkhbKGCoV+RZCovDCELheICEI7V6GdjdDJeIYHYrwi3dsBSCP/vl3LgRJxuTMWvbWr//44ucE2MOH9wtsHKvg199xA7ZtGaT//I3j7IcvzLDr943Ta28ZU3Y7obxzUhN/ECgCKHSuf1WgUyIIA3STDJNzTXQyiSjkaOeZNcwSlMtc6i24Vu9idLTA++6/Guv1dPKFMyt7BwZrkIW0zMuFTXjIxaApMOsIsWi8tAZKZbTCxKIcd78hCuZt5JJNjZXkpF57skwD5BiIf6URojA2K0/NtYRtQLwn7DT39pjcFTyqhma9sfrmkCup3JbZeW2Y+y4LTdEIMoxCtDsp3vDqG+kjv3YPmrNnsTi3DElAqsuNEUmVNkd7E8OIo9EtsLiWIC8kKlGoFRUvckrHWnGuqsMb2g/DALMrKZ4/0zq61MgTIQq87XUH6eF/chcG0cHjj5/C+dkGTk63cXyy/dBiI39ioBrgl994Nb3u5k2Yn1tEN80gSR0xCrgK4QAnfXJOzY/Qwl/qikLmWF7AlTDmduoNeiYwUuYSYhGOT7bxk5+v4pnTddZMpArB0GXtrKqol7If5DuhZiyOHsI30gQK/cJe5y29XtfQbAhDuCXC0xDdSToXKGjtblpSWfXGEgmVCNfrOapxBAmGYxcb9y1//aXdZ2d2Tb3lVdsxVI3RaHegy8uBNIOUQhUNCALdTymtmiUlqZQjuYSEkn4SsFWjOWNIBcPSWoJ6vYNDu6q47eC4+OnxdSZ4hMnl9JP/83tnH89eu++RVx4cx/hwhre+5ipsHB+gz3/lxTv+/JGX2f6dr6R9m2tYWGyC64IgpoKULCQyU5SEVJBFwNQiXpyt49JiG2O1CGv1NjhTCd6ENtTLQgCkmPF6o4uRoQo+8MD+PQurnWsX6vmZSqWi1CrdtoHjhkE5gePKgfl04ja8Yl4lD+AVNji8dn1Go/42Tze2C1iV0VGVohzj8TNR0tbgbtCi4YuaeZk+lw3m5Xivy1AYtLXWMGw7bodEnWbAUJL4nqmj5DU3Y4PzWgY8QJrl2LVldOKff+x+oH0Js5dmIIREXhRIegWENP2RiGKVMj0IAiyuJVheT79kmJYq8ALkUiITAiAJlVDAIEqBICTU2wLPneng2MXGzUwK/M6v3Uq//s6b0V6ax1NHJnF+vovj0x2cmmndu96RT+RCYv/O0T+986bNmJyaw+p6C5U4BhhHwDlCziBDE/vmCswocwazsWdSqLURkhAygAUMeU4IQIBQ91fCGOttgefPreDxoysPTy4mXxCMo1KNFf17VaHscjJmGZqFuvZ7I1yh5sMCIx/Fe/GEBq1pz2Wofkto841+gFlUt/DSQ2clTuptAsesnBNfEQUskZiNzjlHHMdYaOTTX//heTY1X6cHbt2Cq3cOQFKBLC9grBzgDLIASBTggcmoapIuAiQUkytIp6E2PF3qk/N5AQag0esCosB4jaMSh9F6V+ZhFGF2tffNv/r+mXu73d2P3379RuQ5cO8t27BlYuiZf//nzyffeuwC/unbrsWGsQpW1ruqeKh+jpAMWS4tDycpQVxJqemFZu3kxbXevYfHUeQSYagZrJC2OosQQktjoN1uY9emQbzzvr2nv/j3pxizB/6sLDBcAsYbbJPqeZvRFxolBsWMvHN2IPsqrauBJSWWoO1+zBJe2Ut0hRg0+y2sGcLhH4OuDG2ob4yTgWupa8S3r4YqG5VBvT5i9FWWclxXiVl7fXc2YIfCzJMD3bc8L/DxD7xudddohslTF9HpFcpTVxTIiwJGmgUBQ6A1ASEZpubbWGvnvxUE3KILJVAFemkGSVXVH6mYCWcCSRHhuTMt/PCFWTYxEuF333svPfSanZi+eBbHTyzg3HyGly40MLXQ3dpOxSIYQ8AAIeTi/HIDPOuhEAFYBvBAQnICcXVMLyDtvGFM7xMCScXAikJalE0gCM6hsq5KEGOIqgGEAI5fbOPpl9dwdLLF1jsqmWfMzXpTHx15ggce6mKOHrmfGKDE2Dwg5NMkDDhTvIgboyZjrByNqm+2xk2YRhXF+HDbdEAaN7S1k3jIzGtLLZpiZNVqhIICPHF0mX352xc+8chPF7DYJARRBCIgKxQzUylGCFkukBeqMnBRCKS5ylxZSJM5lZAXOqeSUGmgi1Sg18tQqVWRyhiziymk5Hk1jhFHEUYGa1huySe+/vg0+87Ts5ia7WDm0joO7B7CZ/+Pu6sHdg7jsacm0csZNozXQDIHg/JKCqkQWOHNlygEgoBhpd5Ljp5dRidTTC3LhE1+YQmGqyBZpomp0+3i1gOjuP3aTdRLMlWkl3PHlPs2n7MjGETTtzHJ27zkEJNBP0b1tiqgJiwi2MrKtk1NF6yvD5ehGzDLkqiPoZn2pHTxTiX7qWbCFv1pr6yhY7NRHKLzEdXlCMuhMG8vlJClv0nM1wyMKWdMkiR47W1X0RtetRtLUxfQbnWR5xLdXoakV6AozMkMBoCrM7GModUtcH62jXYicpvIkAicCFIQur0cslBjzQuBgEuEYQ0vnGvjB89Os5v2TTz97x5+Az306u04ffwMnn3hEo6e7+CJYytfPDvbYVlBi2Ecqoj6KMTyevrpF46vIAoildO+IGQ5Ic9J7Red3VVKUgkTC7WPMl37QUi1j/JCeSizrECWFQAHBGeYXkrwD08v4q8em33f06cbrNkjVKJAZynRxhCLhqm8pj69me8YLP3ZdQJZ+rmcCfoI3TwDXj4wQ/TmrS+djbR2mND+a3JTl5CYIVTWTzPeNVpySqHS6UjOMbmU/cnyTxf+5NSlTu/W/SPV/dsHMFQBSBaQpDJOgqnakRzagC9V/Epe6CSE0qAAjkIQsrRALiQarQTdRGJuPcdLF9fZSjsHmKrEbTh3LwW+9bM5Vm8Let3N2yCEwLYtNfzqgwfw2DNT+NEzczh87Qbs2FBFvZlCJaOGQmASCALPqB8wpEmGUxdW6nMrO8dqlRCtXg9hyCGlgIHOnDMIKwsYskKgGmd4461bcWJqHapMPLfSyzAqE0/VP98GCpaRcXlNDa5zSqGHbowUNMV3LWYy4QqGefjE6RpX/ZNWzbVqJNy6G2bp6M7rIjMon5XVWZSJ1x93eZjOeXEZbdu5c/11ti9D/3pmmKqQPlAN8OFfvQssWcHa2hrStEAuJdJc1Q5lTHvHiWlELhAHIWYWEkwtdB8VUqk5RBKM1DpyI+iIIGSBMOBgQQVPn1zB0dMLR9/1hqvpfW87jNFagWPHX8aJM+s4PtnFianOw6vd4gsKF0lkaaEEtCB0E8JTx5bv3b0heHywAhAV+km6WHSuIvi5qfFKQCYUE3DFadUMBlyVRiMC5lZTnJvt4sRk+9HJ5fSBXsbAgxBRoIS3Vx6j/LIA2oEaK5yMBgCCDZ3Qy+U7DEtrY8+leNoB2XxggD3X3W8fMLDSpwdPSpfa1PeQT6BXUGcc5tcbQzsF4kqMREgcOVevzSy0tly7fXjhut1D2LW5gloMMMqt5FU0ruvRSaCQEiCOggjdpEC9laLVyYACqA3VMDJcw6aRCGObgJtu3EmFjJFIiXYnQzcrMDffwOSl+sjscqv13edm2fnZ1u/90uv2fP42AFs3Ctx3105UKhF++sICbrxmFPt3VZFkOYpMoSmSPqIBuFTqwsWZ9fGXL6zRq24aQ1a0AESW4Rtpw3XxXeNpybMM+7bXcNuBCXri+Cqr1QaUqUy48mu+bcioZiUbEffjvBx5lWxdQEnSWelnnqHDB5yAglWFfDuGz8wYTBI+34HuDLpEZNNpE7MhozDqoAFhzO+r7qdl4rbjzpFB3v1l5qUdO8YzWponeBvEkbaxHXU7Pbz99TfQ9VeNYnHqLLoacWUapdgtKAhRoDznYIRcMLw82cTCavpAYGohQoV2CCJ9fpeQFwkqEUMhYxw7v4x2J8Vvvuf2w6+5bRda9TW88NwUTk91cWy6hyMXmrX59SQx0zE+FGLjcHRooBY9GHF2IIrDa2PODl+c72AkFogrQCViqMYhqpUQAwMVOw+FkBBkarMyZJmq8QiNPIUktHo5ZlYSTM51n5lfze5rZiwlFiGMACKhq6T326rcmnHznZkkchOsHG3GllsiJ7u2bl313HGVgNSaSXT7oS8JzYIbiVrWSWE3gjIswxnfTEf0b9+rZQbn06JdeGlPCqiNL1WwIA+AtY5YfP5sk52f7xzau7V2dPemKjaNhhiuMoSBlryBIgpiIbqpQKOVodlNEYYRtm7dgOtumEAlUKlDhmoBRocriAKgWo3BuUppk+cShWDo5kC9J5ovT67i6KkVnD6z8Kknfj6LdiPBTdeMYv++Qdz9ii2IWIQzk8sYHGDYvjlGKnIduwOEWrKaVM1BGGCtneKFlxfwyoMTSqoVAix0TIdxgBOBuPpAGXslKlGB2w+O4/nTKwBU6l43l8or6ycW9De7r947sOFCEqyE01eVaIB5CM3aoZwq5qMX9YURneQ9UYd+gJUN9oam+qS2+k6Pj0in/Hb988ddVl3NmDj8KkRG6JqRGEZF3hyUvJIa9dlpYAxSCFQrId7xxushumtoNdpK/YIKh4EEWKAdFiCAcwgpEEQcS2s5Xp5soZUSojhUbFyvmcp8wlCrMAxUQ2S5xKWFVYwOVfHGe2/Cri2DOHfmAo6dWsDZSwmeO9V8/KXZ9n0EYN+O4ffefcvOrx66ZgJbJqoYiEkdl5Mq/jEXDK1Ogk47Qa+botVqoRACaZIhzVNwKVGtBgijAIwR0kwgFwx5AaQFodMTWGvlWFzPsVDPP7Hezv8kyaDOGUcqDTxJCa949hXQtKcloExXJURsNAagRFMGfBusVgJTHq0agRQ6uifXmJFwPrb3rrGPI3JS1FC9kZQqMgNeYZIy0ejLTaUT82CSBHCGOA4hJGGpLV9au9BmZy51MD4UfWbDCPvU+HCA0TjCQC1EnhVYa+cQgrBx4yiu2bcHhw7vw+hAhLTXQNJrQxYFpMjRbqZ2gzAAEYNyYXN1En/rQIzNN4zj7us2YbV51WfXWj3MTq3i/HQTnV6Oq3dmuO3wBHZuH8Cl6WV0OwJAABYoia3SCCnXuBBAGHDkBBw7szJyZqrevHbnIFYX1xHxAOAELhRBGBRG0iBjBpEX2LW5hmt2DE6emE72RlEVZKuCkFWvAFMtR5c6s4jZqFZkmYGPSsySOS7m1rgk0si5xNVNzBKXEVX+upIlSL8vhrb6Iw4NpTLXT+Y6ZoJeHeIqv8hc6iCbJzz76dagPEfTTprDomcw5RjJkhy3XL+V9u8cQWPlAvJU5eoiHSbBuPXJIuDKG10IgSCKcfzCKi7MdxkxDmJK3WO6s1JIjIxUB8bHhtDtAisrXWzbOoFr920HkxmefvYkzlys49RUHaenG1+t1AZu/5UHrqObDm7BDXvHsWdziCgoIESOPM+UTThjyIsMIQ9QGQkxNjgIIQYgilEYBi6KFOv1DpZWGphfbIECgLEAvZxhcS3DYiPHciN7X71VfK2bqwwYQRAgjFQYciFN2nhyyNoIBsvE7MQ6QGNoz9JGHzLTVOR7133+o/6UjnI9tAZA1YU0EhNgMNl++93oFpw7kahvdd4LwHBPLxLI3xhMMzcrH8nVTyR9SJjp6DOpbg7DCEQSa90Cq53k09Mr+PTwQIRKmN+e99LTm8birxy+bvtDhw9uwYGrt2MoZggiQmNtESsra0iTDIwFOlEbR8iV5GRgyj2sC3FkmSqjxhhQq8Wo1CrYPMiw+cYNqLcyTE2uo1Hv4ZqOwN5dExi5bgvanR7mFjtoNNN6mhcYGajpVNR6PqUq6z6/2m099sIcrt11AEHIlI2MK9TCNHoJWIBCFBb9FjkwUAlw474Ne45NTkOlLVMqs0FGJjv5lTyAZWBNYCzQRVDKn3MEcHYwt2iW8Rgm4h3GZ/DrQtpLFCmaUBubW98gL0PcPu04aiyroobhlAWeedlYPK2WaUmIy7UJ9zxTz8A3aYCU4LBOLI0KAqig6Ptu34dK0MNSq6OrxiuEGAQMudCplLVNSeQCPAyx3Mjwwpm1xxvtHFG1AkEErrtYiSMUSY7hgehfBFKi182we8cmbNqyAc1GHZNTyzg33cTUXAu1oQF87AO3vO+ma7dieEClQE87LSwvrqDbTVEIqY3zhEKSrmFKtk9xFCEIOCpRgGocY3iogg1jNezaNorZpRZePLWIZ46vLKx28NudhL7RSATSTK1dGAcII6WhKKHooXlfSFkJ6OjGFjvp1w4MyvJhtX5JGIODJTGz/LpZ7xkGK+nPQudm9i62f7uWVF/7YpCY+brfgH95FRxuRqwRmn2WkbhWwptBMS0VlW7OAw7oYw9L6wkAPHvXjdvpnW8+gFsOTKDCAZGnWF9voF5vI+llYAEHD8ISHJVE4PZku0F9ChPzEMgyiW6jA7naRlEIjIzEqA5UMDoSYGm1wHPHlnBpsYV9eycwMhBi7+4xPHDX3rHJpdNYbnQQRSqHEvQpgTBgyMDws5cW2M3XbKDbD4xieXkdNa7Kv4MDJNTYmUFROg85kwX2bh/GWI2jJwtAJ3kkHSF92Xb1pJwlHJRVJgDa5migvkdXVsV0BOevlUU8tk1zWsKvgKTlqa8y+uor08/XxOO84JpOOEDEy+ouc32GNxbfy+3Rd3mDePRJZHKokwt7sUJUjVEx5wJDAxHuuH4L0vY6siy1qoQptgyDSsmF8FR4iBdOLuL8pfZ94BxEDEIALFTZUZqtBFlW4Pabtn9q37ZBxKKNMB7E0tIKZmZXsdLooTZYwZvfcBMOXrMdY6MVJO0WZmfW0Gh1kGcFwiBAHGpjPEHnwXOOC5XkEyiKFIwBCWdo8w6qlRi1OEStFmHvjmGMjNQQDQxu/dsfT9WXmqliBmGk5p/p4rU2oaBbQ8eAmKcae/RWslF66Nu24dGnRWzmH2O/7addBgOASiol0+l0LPryILU0hKWoF/4jraD2CNw3DlvY6BG7u8MRlaUwDRdNmSh7Jxk1QW2UPE0BEG6+ZvzpB19z3R2vvXUHNowA3U4TK0ttdDo9K4WCMNSxYorwBKRKz8sIAZjNDgEmrfogheprFIZAwBBVCEkvR95rYWKkgoFqFeuNDFlBmJquY6QKbNpUxWtfuRXbtk7QXz16Go8fmWcAUI0V4xRCIgo46u0M33py6pH92294aHCwhqSboRKb85WwRGiWm0iCywIbhivYsal25PRcenMQhZBMzYebI3IbzyYcvByNmBJ5PoNTa+Gjsn6WSI5e9dclE4BHuFZttEzLrbFDd300YmSa4p5WkJbo0dznoUtffXbCyY9v8+xlvmBlOkZQbyIlP5k9j0ekMqNkaYqD+zY9vWMiRHutAZErFYYzgmAECFXkBKQcSHkhUBuIce5SCz87vnJHJyPEEUchBcI4BAdhfb2DjeM1/B/vu5d+4VXbwHvrWFxuY3GtifVmF4MDg7jjFbuwY9soqlGIZrOD48cuoNnugkGnUA8DFbqjj/4QlBc+16FDKimEzswBdRogCLgq8yclur0USZYgCgIM1Cp40x1bcGDP6KM/fG4BPzmyyJbrmpFFERiXICguySSVScNDPP0mIQNQShqcp5FZKiBH7858WXauOCbmAJYjIX1dHEfuG8Od9KJq7Qb2YLDVVG3PTFIBp0LCH1yZIB3RexLZl75euACYVmd1twpRYDAGPvbOV9KDr96B8WGObifB8modnV4KIqndxSqmxcaF2XLoUqtbugBE4BwI0MSrYLg50sHAuJLOnBHCUCBgDEEYAQFH2hOQQiAKgOGhGjZs3IhMxvjZ8UX8xfdefvfFufY3wDjikOtU1AKcAQ/etYt+5f59aLWaCKCyA5hMr9L8CJ0qmwGCV/DIU/P40c9XWKU6gLwowLSKY/Ji+ajJGcSVWmgynHIVkuhWyRzKd5i8REQetcLGl3nXuGzkLhOqrwJaIE/QBFKGRYxBnf3z4FLZjlJG576KYUfhSemSZDXilhxCcHPhGCbgotIZY2BcxVR1u2285d4D9PvvP4iVuSm0mkq1L0gi9+qFkiSkuUAYMTS6DF//0cwzRy+07uScIQg5wihCN8kBIfCaV11DH/vl23H9jipmpy9ganIejWaGuBJhx44N2LxhHMO1GGnRxfzCKtbrXRBUPQiSKoiY68PVZpgSBCmA3FMjfRUr5AxhqKt6cYZA5+QXpKL/KzHD2FgNkgWYWkjx2IvLeOz5+WClLWTAA4d4XBkgNa9Gg0H5pezLTjgaG6H1wuq2FKkyu8wODpPSMmCuM55RT1Dq/6SqmqxsYOZeY44yEt1kB2BMkb7U7gGbR8rYQXRhTGY+KzEsH2I60695TlnVgKcySPc9AVIUGKzVqjs3DaEKoLHWwMp6C2mWAUzXViQCYxKcKXuaBNmCEeb8F5MMkhNCCbv5CS5NjoG5kghM6EnhQJETiAOiSBBFDCPDA1hvMVyYb2OoSlirL2JkqIZ7btiAA1fd9fXvP3sJ//sHZ1gnKVRBkihAkQn84LlZtm3zEL32lg2orzfAWKjlgITxqJFGB4IAxgkToxWLYJjduM6uZBGQTyilrc7KxOZvdntESLfD+2P6PElr8Y5eVzDrpOH9qhVKZADNhWybit5ciMblL3WNOo/n6ksaYu1HmaTPyqowDYcC/L672WB2I9n7PZAhJWHrRA1FliDPhNM7yFUWlyDkokAQcrR6HN95egHHJ1t3Ms4QRSqGqttJsHnDID70njvpra/djzhr4vTx41hcaSKOIuzZM4bBWoyhgRgi62FyeQmdXg+CgCiIdNYIHeKgz8ZJYlY8qTAIfXbYO0MMQB1nIxUcTdoIJ3U2GGiab3YLdJMOhodj7N8WY//m/RgAF1/58QXnPraAxBMKFjp75ol+GkMf8jIOHE9YEpE+6qjfm9qhzFupPvXUtqiZYKiX2uqZRnRq+aTVN/QRmlEBPCjvQztobgxmice3c1hi7mvD3u+3SVDqVBBitZUlf/RnT9X2bKj03nzbDhw+OIFqFUjSDEVRwGwuIrgDoYzp+CnDQAlMMggCEBgcQd4aucUSEgq3SAahzmKAc6AoOM7NdPDMyXVMXup+aWy09qEb9o5hx1iGxZUWtm8bwy+/dj9uvnYLfeuJc/jxczNMFEClEqFTSPzdTyYHRweCzuH9g2g0u6rAB8weVR4r51EkDFVVIkeDKPrja9QiqwIkKkOEjt8yMNssmR8LpRfZGq/7MHpZxXfvbfoTj0ko76NivuYe8jxHfhtlW6mxrZp1NnYOZvvnP0epyTocgby2rQpoVEg7DPs8rldaehvPV7fN3yYH+8gQR55lKHIBIq6dWwqNgwhSFAjDAK0swA9eWMAzp9aYYAEqoSq5BwBvuu9G+vC7bseNu2LMTJ7HhQtz6OUMM8s5Gp0e7rplDBsHqlhYXEKa5mA8hCmRXRSqsIYwa2KYlBuaQmY6DlIQtO3UIG6AuLe0msCJCEJKEAfiKEQ74XjxxTqmFlsoCobZld7jpNG6rvfsqfIehRgS9FR5s38UkGLemnq2VMPoLArz9r7VIuzWdXRollXfbNoMjfpB3hVek5oISu/g9g+5Lz0Vw9qX4B5Kbrfpy7XtwU4Sg6F/qz/bPaSGnRfA/Go3mV/tsosLHX7r2Qlx53UTuGb3MAaHOIqsQJLk+ryhmWjViDSnrxnAyR17Is6sg4GZDcQlmNDskEgTh/qukAynL7Xx9In1o5OLyc0ZhZhcb3744nKvemDbUO/gjgHUOwlGBuvYuX0DfvOXDuGuQzvpW0+effzo6ZX7AIblRt7928enPz9Y2fvwvm0V1JtdhGEATsqORdKcTVVUWYm5TnHi1kZF/Bs07KEJZpi3h4ZLUtKo6P46OxTumJojnpJNysgfj+dZGrKL7aR8uR1nF7HUZFAnXCZaI+R4HxokGALXg9RjNMjLUJl5vnF4qJAez1XvDdw4FvQDrPOpFjMUOl8X0yo+5yrLSZYLxFGEdgY8eWQJz52uMwkOEgKJAA7s33rT+952x0uvvW07eHcVT/30HJZWWlhqEk5MdXBypv7QejP75ovnW+tvvnP72NXbYuQyh8hzu54Ag7R2SydUjBZk9yxBZ3PVt5HRXJw3EOpjgKmSbJwCtFOB0xcb+Pn5Nk5OtYP1ViGzQjFeHgYATBizowe1an1eblN5qo8eLBOyq+Ls3yVrgglq9e1QdgZ8XGe0N2fEYmBglUpkmZbjkXCSDwRXqt2PLTJckGmJBg+Ge700KMuJxBIBGW5q7/FQARFsUKgxtnF9LCPTtfV2bqgcumn/xNFbrh7B1dtrGBlUjDFNBXpJgSzXUFurRwaCqkKoSkUJTEAsKUkmhLJ1kFCTpbJPEFYbAscmWzh6vnH/alN+n4URWBhACIkkzcFEgW3j1dtv3DfyzDXbBjA+EGHbliHs2L4RSRDhySOz+NZj5z90/lLry4xxHL5q9On3vH73HXu3R1ivdyEl05kslMrAGMDDCGfnMnz5kfOsQKxizYTQMWdqrtSpn7LYMVIOzHzgqVN2vbx7Suvi0LOBQeRDfXIeU8364exVXmyYQV6+SLRMyiEn208HnS0d2q/MwODoqkSvUExdfcI1kzWMmwAbQkEoEatHb0zny+r1evhXH72NXrkvQn21Dlkoji1IoCgkwihEoyvx45fW8fiRVbasvXg7Ng0Pv/0Xbm3ef+dV2DyQYfrCJM5PLmCunuL0XIaTU+075la6zwqpmASDxK4NlQdfd3jzI4euHsZgFTbJIQ9c4LI0aqGZGeXkhpQqar6QpFLhGO+uFvhhAMQBQxxzJQQ5R7MrcPZSBy+db+HYZHvP/Fo2bRhMEChh7nADswzeTL0jJUd/5NEN/FVzjMTxhRKRUulZqs0S1ALX5gOCEZC6LoTpTyWO/l8kpUtvwZiBp+XPyRKAa8NkkDDqGhnC9dCetdmUOLf5bdzy0GliYPVlgsuRJYhBFCrLw9bR+NC+7QNHr95Rw56tA9gyHqFSCQB9ADzLChRSSVAwxcCCQLUTcGVXUB4eslAdIKQ5Yame49xcF2cudb8xvZK+O82BOApAPFT2RyjUlOUSRZ6hEjLs2z78n2/YO/yJPRtjbJ2oYt/eCWzcPIaFRoEfPTeNx56d/+zpycan920eeO8v37/3qzftr6Hd6qHVyRDwQBn3SeWGml6R+NNHzrNURJBQBnwrRIycKlUEUlTmtENydiS7+GXPoeULRNqe6U4xKr7iNj55ar5xEpAhQm8xnaR2EtkP22HMs7/pPhibKRmOZVC65XwuDJy8c59OgfBVWTg60wzZOTLcPjK0rYQVRzdN8ce/eSvdtCtAq95GkXNIWSgDOg8wu1rgh0dX8ZOjK6yXCezYNDT80P03Nt/86gPYOsKxND+LUycvYm6piwuLOY7PtD8xudz7E3XWUJU0C0PlSMqyAqNVhlv2j9HNV49h5+YYtQg64l34x1EtQ1GzppmXICt0jVMnICCKVOHnSqwyYTR6AhcXejg51cWZ6da9C+v5E5lQeewZ00qj4yZ2TxvG0u8o8Z1w7j28NfezTGjspNeJQwkTm0DaMi+UBCAYAzdpxw3ThCfQQJqBOZQGwzENzShbBLPnl8ioYpbRGFHI7GbhzH9vNgtzRG73jYHGboHMLHngAKY6toKv0m0AHQEPqFzijAGDMbBhJPr45rHKF7durGDreAUbRysYqjFUAg59uTb0q2NJjoEpL2QvJaw2C1xaS3FxoYeL891PzK8mf9LLVHK7MOAAV1HWAAMMsemCoIXOgz1UDbB/x8hPbt43fO+1O2vYs3UQe3aOIx6s4vxSDz95dhE/fHLmE6ut5E/eeNsWuu/QKIYHOZqNBGkuEAQB4kqI+TrhS49ciBs9ljPGlA3D5Hq36+bNIUEzNfd1ee7dxjdLRWS8Q3DMwq0A3GJ6QI0xrQKW1UXThmMsqk/U580CXAanUv88WtCsx7XtE7s3FnUaAbAnBZyO4+bE0JcmIOM/5dagzwAeICty/NGHbqbrdoSorzch8gKVMEK3AI5eaONHP1/+4slLnd++asfIu37xNdd+/U13X41rdtSwtryOl05M4cyFZUwu9HB6Lv3G5GL33e1M6W+hLqkGrvZTEHCEnEOIAlxKbB2vfPyanYNfvGbHILZtrGBskCGKmI3iN+NWb1WMmSCtQnr7hhFBgKHVE1hpFphbSzG9nCzMriRXrbWKRAiFtgCddVXbXRm0wd9kIbGAwjfGu3UgTWeWuVgmZpifowl495sUOh7bsGYDx9DcZ4ZGLTUafZkzFUZh3JJG4+RaCjtzhmYo2oDJjepo+uRJZX+TMHP0BXDXW+TlOsktd2dwhSxd3I+NYTIcHY5nBoyr2pJBCMbUCXkpJAopEHNgIGYYG4p+Y3wo/MyGkXjr+HCEgWqASqxKu4UB08VDCGkh0OwUWGnkuLSSPTO3mt+51spRCAHGgDjkMCEe4CFIQTiVYFEUkEVuEwsCTNf6I2waqeLGfcN0y75BXLW5gu1bBrFz+yiiShVnZ7v4ztNzeO7I4lfjCIduv27D4RuvGsDgAEen1YOUQDMN8T9/eOnzU0vZJzkPIEThopfNvOj55FpCw7cflYiljJbNb2ZQmzG+wo/J0fYWE5LSt87wnmGI3Q9q9NVV32vl3POsRKAG8ds+Wr5jDMCmv3AbwQ0KZFzx+hs/2p68kyMEh/DVxuGQxBAEhD/6yGHaPirQbXZQSI6p+QSPH1vF6ZlWdcPY4BffcNfVH7r/rr3Yv3MQSa+F4y/P4NyFNVyYTfHypc7Uubn23kbiMy6LMwHGwYIAnCuBGjElpLOCEHNgw1D4rq0bKl/ftjHG1g01TAxFGKoFGIiVtsCYiossCkJeEJJcIMkleqlAu0eotzMstwos1/NHVlvFrzQT0U0KZSs0VYhI7xOhN7lRsy2GcL9gnByWiQJw6OsKHmFLjh5k8+jNU8lgdB0/4sBs8v7IBABWC7O0FUexvkZnOuAmtlcjsRLzNIuv0ZjmwIZAySM882QD/52aYWdFS2Vo7m9TqrsRlN6Siz/RBGyKr6poewbGFUNiUHFXRSGRpoUiWqgo7GqsvC9hyBCFvBoG/FDAsIWApBByKsnkmSSTSAqV48mEZDDdB0YMxAMVtq9r6XEiMCnAtAHeSgcWgDhHmhOqgcRVW6tfuXH3yPv2bIyxfUMFe7cNYsumGhDXcHaxh8eeX8T5s+uIK4QbrxrC3s0hxker6CUMf/GDGfzsTIdVohB5UdiNLfXJZyMDuInWt+RlGIq03xtj+5W8v8wQsZ1nVqIfZZ/z21dtGceNFUhwWU3Rz7y8TXI52vMEpqHYflqwIyszMNIbzD1HXcc1TTPujcVsRilt0Y8oCNHu5jh8zejTn/rQzXeE1MGFC2v42bE1nL3UfGZkeOSOu27diXtu2oF9OwdRFAnOXFjF8XNLmJ7rYnKpwKmZxoGFenpG8gBRwFVCG+YxXOhTJppeOVNzpyIIGEDqIDlIIIoYhmrRoZGB8ONDleB9A7WgWokChRgBiEIizSW6qVzoZfL73VR8s5PIb3QSgW6mRFykK3HzMNDP16nHpbTxhw79QO9v4+n27aCwjKS8PnYyL5t3X7OiEr0x95tBpReCT6tO8Bj133oxtY3MBKizShRrWOjOsCko6nro6FCnLSZ3Ds+H64zBOyPnBs4IkPqtkYaG8Ewgm0fnFvKXNon5l5xHyGw2zkObOE/3XpG+lCAdKyPILJh3upwx8CBAwJRBX0k3hwakVPYmksLrG8B4APAAQRQhDAMwCYgiR5qmKAqBy1/aW0AStQrHjg21j+/aPPDF/ZsrOLhrEJsnati6pYbaQA0zKwWOnKtjdbEJRil2bR/Ewb3j+PmZDr7wly+zoVoNuRAQQhWEUPFMzIIYzo2pF4qJ6mBRG1rB3TxbZGaEkCUhfx2otMYmo64lTN2OMf76SAv/yHvldTTzxOz+8OnIzrelAudBtXJb2SdK6ByWVvRIuELpxinBuW5Vj8Mg/IAHyEUBEjm+8Ae/QDdsZ3jh52fw8tkVdLIYN1y3E3fesBXbN1aQpT2cm1zG8TPLOHG+h/OLyTOXljt3rvSutPblVxBwxJVIoS8j+DUzAdP2WO5CDYQem1HxVPEUJeyFFPYMpBu3Gp8Kpg0QBYYwDFr31l7q9DTSLYPBpi4m0CAwz5HDYD/3EZhV+UywKvPmGldyqEAzMIeXPWUCDPrIl0HrblXtqRNWqRgbmBu8GYQJ/lTj9eJmDJV5KMwSnsd5fQOvkYQEaMOccxFbQyGcx+VyVeRyqMqYuY6BBaowglETFGHoMlUmyNXeRBq5BeDMVBrm2sPJIKQ5UyasbctKhYAjCAMwFuoMsYU6z8EYhmoRRoej4ZGh6h+Nj9Q+MTpcxfBAjChUzyyKAkmao9nuodvLkKfF6Y2jlQN7Nw9i18YIE4Mc27YMYWB0BDlxLKx0sL7WwubhAOMbNuAzf/bCwvMn17eFQaizBChCF8KUB1GFT5Xk5HptXNyYQz9OovoMzK6hx1CYfmPYvmFYJUxk73E0Yu4viR/y0Z3wpFMf0/TW10lPZq/XlGf/AzkkZoIlmAmf4FzZXJhjYExvcMOgCyGQpDmEEPjt999N73/wACZfPo6ZhRaCyiCu2rkRG0ditJoNTE4v4OJsAwsrKZYbEotroi54tDi+ceDA5g0xKpwB4MglkGWEXibR7OZYb/YeWa33fqXeSrvdTNgBRnGIOAwsxiCpz2sGXK9lYCbMi5OSuiyaSu1j4vDMXCgM4tRmpitpK1MRLKcwdlSCYebeknJWpgPDtDyBRnaNTJOuAT/VuWrD2MtNbINDKEwzPSkNDfmMsUxP/QKRxZVIx9IYsvApVUt2I+U9AjYLYOA4wbd5OVXCDEyFY2jxr8CIY7W6Zcc41XfckqST/MYTY+ia6ckycJcx2HgpMowI6jdgFkDHfnFFJDwMdGUm5d1R9xaAFIA06hoDGEeWC60mAsNDMa7aNf69A1dtun/f9hFsHoswOhShVglQCwNUAo6ASZUDjCvbXiEEslygnQlMLrQxNddC3i0wNhJiKAKqIQcLCbt2DGPLxkGAh5BZjvHRKs4tCHzlH87gpVOrbLmVGtJAFIcIjdvS4E/GtfTSjJeRQ8eGAViJCTunPjPrVwcZ0+qHQbqeFFVLxe3844qEZ2wsCjk6mdln2yoRsSVDOJ+loUUvkaRF3ZrWmEfknANMp4fhHGHIIYRAr5sg04h5w0gF737rbfSRd96M1amzWFtdR3VwAIUAWs0OFhdW0Gr3IEAIogEEUQW1gRgD1RCDAzWMDEaoxZredHZWIgaSDAUB3VSi3S3QaGVYqCeYWWzh3KXGoxfnGg+0uoqeoihEHAf62BeDZAZMqB+jjhphTkKgkMKpZ+StL2PKnKBPzXDOHYqWJrDbzR1BITG3lGZvevterzkMEoTmCx4QcTF83tY2KKxvzX1h5Ikei+AsavO8mIqheQI3jiPDldRkcdjBGDlrOqMRO4yyof43BGUYk3NjGwRlOLbuEpQ9yxP5dprUQ8iiBWdvK58ndUZFxYccAzOqkgRAwiAn0kzNqJ9KSjLGwMMQjAXqb8YgoTcyFeAkwbnyKvZ0dHUUcNx+aCddv38TDuwexYE9I9gwonI0ZalCVr1ejiTJkfUyVfSBlKMgABCFyo3OKwwSHL2exMp6ik5RIOsW4EEIHnKQLBBCYGy8grHhKqoRYWJ0HDmv4ORkB8cn13HizDLOT9cH59Z7XTMvA7WqYmacqcO9RJBCgCA1AzOLT5bRlIUCc8Rt1sV+ptcHjrEZxkNM29dg2naCz6E6hUTJoAQHAbVE9xmeQ9OGg3EPMSp52sfACDbBIIMyWvOAq1AB7X4u8hxpmgMg7N4+vOnA7s1Lh67bghv3bsShg1uwPD+FlaVlpAXQ7aaor6ukgNW4hsHRAQyPDGBksKZjCAUYCeS5UKmmc6HRsGP4Ieeo1iLUqjEGa7Eur8aR5gxrrQIXF1p46dwajp1ee/TMpfoDSS4AMAwO1sB4AOMdtoIGCjkp4azXlcicIzJkoK9XpgtGiiH5GlHZROTQm9tl2knkYLK3T40WA099Zw7QmPs9gGK0LdMHoz0wkM0K41VQc4BJMzDNdkqYRxLAKpXY6tgAQNx1wgQq9ukVHnMxhlqjx+qJsIe/NbcswUmyA7Cw1Cm9Fj0xN492Tp2x0Symut/a1Zjro84HoiUiAF14wG4eg754AFgG5m7nnCHPMnR7CulsHBvEa++6nu47vAsHdsUYqgowmaLIEjSabTTaCbpJjixTh35NUGoQGEmjKnpzAEIWyIVAnkuEDAjjEAXn6PUIuYTKLaWjFcMwR8QkRkeqiAKGjRvHMFAdAK9WkGYBFtcyPH92CS+dWcGJsytsqdHTgwgQhQHiKFTFTIl0MV0d1GuJ1KHngAeOoA2x2Pn3DPCSQFwfziFlaiCzUfRNLm8ZWcZpVHdjhiihfmYT3YAzrhG3ksZmbzE4WjGmBmPTdBWuTY4vtYaqeEVhiX7DSAU3HthJd92yF3fetAWbhxkGqgK9VgdTUwtYW2uhgEQnKZBmhFo1xsjwIGq1KsJqgCxJUKQZ8rwA6XqkPOBWTeNMRcuro2AqoJbrnyhkiANVELZaqWCwGiOqxEhyhuW1AufnO3jx7CKePbYwfmmlU2c8xPBgVZOzs1cSSUAKCIPEyLdlGaTrwkkYYLUjxQgc4DAakdkrzFIGwdug/ZfCbVKfEer1MRfDAyKe1mT6oUEYbJNGheQ+DTr7mxGOPjp3DMx023BvTTR+LE9J/9T3kOmY4RveNb7qaRiSlMar5MIxDPM0rn8qz52dCP1AtwksCvOeYWCsrUCtC3dqZGaj/TUDC4LAIkbOVNxNUQg0WwrUXLt70w333Lb/+Ktv2Y3r9o4hkh0sL85idb2OJCs0Aw10RlZdQKGQJWeG5pc6Tkkz1kIiLZQhPklz5IUEC0IAinHGYQAOiWotRJoRuqlyAAxVOSIGDA/XMDhYw+aJYcS1AfRkiNk1gZfOL+PY6XlMzjYfubTQfOt6O4dKOMYQBiGiKLTEI3U8mXHOmAKrHklCi0NYD7NdFKb3ijGi25s8VUWjX0/4OSnqhJhRIa31lUFrAGRvM+tcQg76O7fSHEWRa0eKu27ntrGxA1dtXr9x/0bcsG8jDu6bwIZhgmivY2lhGSv1OtYaPQiKIUSAlWaCai3G5g1jkEIiDDnyvICQBRhUGbwgCGy2FMWnpCVWAreZhU10f6D9OGGo7JSmShCBUIljjA8PolapIJEMM8sJnjmxhB8/P/Wh83OtL1eiEIO1CogYcgEQCQBSF6IlDxlDayDuJIJhDmoZDVNxe1jjATe/uhSh1WaYEXPMJkaw+epN267REtYp26uYu85jUvD4h0keYYz6hpfY5BFe/w0jY5WKDqPQ6WZ0GL3rBBR1lmJw4HuEtHqnYariHT7CKge3WT5qUZhDdE7GeC54lD1jPnMz1xqUaDMpQKuBJn7MSC+thyvvJddMJdDxMcqQ2ux0wUji8IFtkw/cfe2eWw9uwc7NFYi8h/9/X18WpNdxnfd13+XfZl+AmcEAIEgCXCQCpCnJWopMOY6oKsehk0qkSqriVKpi5yn2S+SnyE+2nixXpew82X5I2X6xlKqU5ZdItssWFdmkZYsiBYokCJAAZoDZ93+/93bnoc/S94ecUUkiZ/7/3u7T53znO6dPn97YfIi9g2MAQJamSGxC1dlhQCV1DnDckodKKjQUdsy54bxHQuUfJV0o6isA3iDNDaytYD1wNHD423eOcPdh/xvT7fSLa8stnJtrYHk6Qyf3mJlK0cpzLC9PY2FhFlNTUyhcgqOexcO9Ph7sneHt97Zw887Ot9+/e/iFUcFsxCCxKfI8sAduae291zsDiUwbCi2CMtN6cEgQOuCRPkSNLL1udde9NHtkRGGEkd1v8c6kA7KdD65xI+djgh4UpcNwPJa8JABMdxq4sr7wrWeeXH3l+lOreOaJBZyfMZjOS4z7fZydHuNgfw/d3gD9ITCsgKOex/6px9bhCJu7ve1mZlb+5c88g4VOgl6/iyRLA2P3nD8KoD8aj+FdKSkIa3kuVG/lg+NKUoOENopsEvTPOYPSVYEZlw4WBrMzTawszSJLGrizfYbvvvUQf/n6/V/+aKf/B+1WE1mWoyxLVJ5zX8RWHOg0BmrHgeJUlIcCgJAQYWpB6uzo6+SB1h8xgEV2K6cjoLrOYCfRFa1tpEswvM6kI0SKmK0xxkBQgHQjGpzJG3RLDp05DIplqWq6Tg8hD/dkmHpcQIRlosR9jWLW8DrSaUak+p9F4NF7Gb3B1DP6m0ahitaeqCd/ThtuBOBMSJGy1IZzk+Mhblw9951//bNPv/zy8xdxfj7H8ckR7m1uY/+4CxiLLE0DiXOc93FIaKMolDYEw3XOhDyF52Z4FGbwQiWh5UrwwqF/VJKkKAqH0WiINDU4OavwxvvH+JsfH5jeMMyxkRt0Gtaem2v975XFxqvn5nPMNYCluRRzLYvzC20szXewsDiHqc4MpjotHPc97u90cfPDA9y6f4gP7h1hY/v0Fze2z/64EMM3SJIUjUYabpRBSEhzmMIsRz13okyM9ZMuexF5x+wLwehj+RtjKP9hdQ2Dx0Fc32XJ8AGD8TiE33DKsjrtDJdX537v6uXlX3728XO4cqGN1cU2VhbbyE2FQf8UB4d76J2d4uxsiHHhMCosTgYeG/tjbOwN8XB/9M2DbvXvTntlvz+u4CuH64/Pf+fffv7ay2tLFoPBEGmeoyrIKSGcyijLAuNxAe+qEKpDw2NHumoRnFyaBjYWDNaSk1OjtomlcgmP+ZkWVpenYGyCd+8d4/+8voFvvbFtjnsOM1N5uFKwqlTXIwYc24+Buv+43MGzTUEjwpqtyrV2EZBxuRNbmkRJ/H6tI5TmCaQbk+xZQAzE1JmVe2hOzOtmTnCI/A5N9Js8y2r0Ms5HBcSNQIjmxaQyPrbha+gZC4iRGOR1nHho9gnSTSDKiRh5HzMqHV+ciHfcDlrGoOxQAA/MDEDgF4ScGIskMej2Brh4rv2pf/PK02+8+rkncHV9CkcHR7h9bwfHvRFKD3gXvFNVVsJQDCg05J5nxEBCrimWKW0Y2LDYiaEEKwKIOg+My3AAHT4czt3eH+Jvbx7iRxtnpnAGWZaBbhREVZYkPod202Kunb60stj69uVzzeaF+QyzjRILszlmOw3Mz7TRbrcwM9NBnmWokOJ4AOyfVvhw6wzvbhzi7sYxtve6X364c/bbvVEhChbO7KUSDsM5ObJibAIgUeAxrGFaeMr5KQ92JE4+L62oaYeQ9SdNQmqB31k5h/G4oLs0w8/8TAuri+3fe2x95pefWp/Hs4/NYW25haW5Npq2RFkNcXzSx/FJF0fHXfRGFXqDEqPC46hXYfe0xIPdAXaPR7951Kt+vTsEioqaWBI4AUBRlnju8fk//fnPrr16aSlF2Oo3aDRCE1DnHSpHiXtXhSJLUGrEcLvtmDlyjVc4BhR6eDFQWyQm7JBmeeiiauAw20lxbimw6r+9eYj/9Vcf4vUfH5osy5GlNnQvIdORnXZjYtVHfF8A26JjRxIBCgWhwb5oTXwEIJAoy+uzxWwJDImlP0Iw6F85KgNL2Qf7ASC6xcwwjFdxhHXCGmX8Jo9yIkoLg9Fx+KgdNQ20IigIXZBXRu/rB1AB+a7SQR8Wmz4r3UElfFAAFFkJnaVJCI3lscQkUwVHdFBuuIFRQElsgtF4hJ/7zGX/S//qabx4dQbd4z5ub+zj+GwI54NiD8fhxuKQS/N06j9Ml3NbCV3SEezUyGfD0AyNmag6ydjaBHBA5TwK5wFvUVQe72908fqPDr52e2v4a1WSIM8teJvEWKpbQzht4Hw4EOy9RzMFFqbz60uz2e+dW2j+9NJ0itWFBpZnMszP5GinHlPtHK12CzMz08gaLVR5iv44welZgc2dM7xz9wDvfLCHOx/tzzw46J/JStsEeZZoqAcD58J50MAwmJmAlI0YmWMb0nCaNcOYUOcUboYySKynQ/FjjEdjWcdGbvHkpaU/fPbJ5V/8+OVFXD7fwvlZg+XZFFOJgy9HOOkOcXDcx9FpD72iwkm3xOkQODgD9nsVdg6HODge/9HB6eg/9ca+GBeOjqDxRg6IEYdOu8ywi6LE+kLj+j/7xPm3rj8xizz1cKULZy8TG4yKSpwMQA0CUFPaAGIcsQR1qCqgLCnhDw/rDZ3NNXQZh0UzT2BM2HGcnW7h/NwUTrol/uSvH+Drr901/bFDapMAYgIbDEpk5BE7U8ZEHDImHYxTXhP54LROjd1pKkGCJ0+VBxFD4hSEEgmIk+ewV3SLfxcxNrV7rgqAYAQ7A+89TJ6n9CLq8xixhnB0JkjcMeJxfOq5fZ4OmgFG6KKRJZxQXkTVv54Avv6M8F2jwpOvxq5FZBZ2tIz+mZOodeHzWAFjQu5rNBrgv3/5C/4XPncOd+7cwc7eGUqXoKgcRuMSo4LaCIO6j7I0fQDRxIR2PJbPu5FyuCoU0JJPBte3GCq2kXxhpc88PHX4we0T/P0Hx2bvpAJsAktnNcN6WLmuzkoeiY9Dg/qih06hBh6N1GBhNm+fn2/9zfpS+8babILzcxbzHYupVoo8zzE100a71cT0dAfT022YPMfRmcX97T7eurOLH9/ex527e795e+Pw1yuni9FoNJBnGZ+Bgfel5D14YSovvB/eeLq8l+SWpEiSMKeydBgXBaoygFaaAOsri2tXLp17cOXSAq4/sYin1jtYX8pgxwOM+130e10MhgOcnQ1xNhiiN/ToDQwOug6bxyPc3etje2/85YPT8W+f9IrQ0w2hCDnPM2SptpNmZ+OkgNnD+UrytmVZYqZh8OIzC/4zH1vGylwOT/WBHgae8oRSGmI8UnYyweQh3XMRDuOHQtRwmLoqqeQioZ1ra5GmBonxcugb3qCRGDxxYR4Pjzx+44/eeu2tu0f/pNNs0qW0qugxa+G8Uy3XzJhkwo1J5NXhuSswot/5ut3G9h1HWBISesUIbUwXIajYr48pmdg7n1WNU1ZgwGO8AEdcgMnyTP6FeaIXxiApWxmE58kBtYHHsTJ/kI+tKKuLe0jVgYjh3PCr6B9q5+owycp4pySO9KMnToCfvJHCUmssjHd46srSD9dmcOPxcxmurE1hdjpDYoJRjQqPUelpZ5F4HmGlMeHa+HA1vM7fg2pg+S49aBI/tC4J8kgSgyyx6A8dPtzu4/vvnh7fvNubH5Q+tCUGwKUEgSUYafooh7ahITuDWkjEh+RwWYV8jk0s5loJlufy3zg/n3/lwnIbS7MNrM5kmO0YNBsJkhRoNproTM9iZmEOzXYHZWWxvT/Au/cO8M7tPdy5fzC8u3nU2j0a0ExTNPIEjUbY1PCgI1iuCmFSuHIJnORm5S/KEkXB4SqwNN/B45dWBh+7utb82JNLeGJtGitLLeSZQ9U/Rf/0CCcnJzg57WM4KjAuHCpncNKrsHs2woODMbb3CmwdDF/dPRv9WX+oIae1BmmahEuTjQmHvdlBkh6z/jvnqauIF2NOEoNRUcEaj6trnd/65LX5L19bb2FmKvSNryojKQprgt2E+Uagoiodjv84KJB5Vn8TymoSiyShXvZJcJyDAtg7HuLedh93twa4uzfO97tFkaZWWRXb6IQtxrdQ8WAkBBM7CRFETGBCqkZ9NjMSqc2L7KlOKqK/yW8U1OLwNfyqTnqE9PEHaGzMVnge1hiYvJHXXqRxtHr2OGcVJhAjMmiwsdQ0nHsEpgQohZcB4KRcXXj8E45/qfdg1fOIWF4EViY6NcC5qvA1rXJhFgYAw+EIBsD52Xx2bbH5xtpy86nVhRxLMzlmp3LqqeRQlhXGhQM7vNBVx5CBGEriMvOgnJn3VLRrYOCQ2HBTeJpYDMYeDw7GePfuGW7e7z61e1TdcsYgSQ15TvZyYd5h9ypM2HIIBnYSqpReclG0Y+TDhkJZVbT1Hkoyppspzs83//TicuvV1aUmlmcM5loJstTDphZ5lmN+ZgoLC7OYnpuGsRnOeh6buwPc2TzAB/f3sfHwGPe2Tltbh6Mh4JGk4R7CNE2pV7uDNaE0ZTgays5kYi0eW1964plr67efu7aOp6+cw5OXZrE8Z+GHxzjZ28HBwQEOT7vo9YYoxg7DwuC053HQK7F7NMDO0Rg7B4OvHfaKXzsZVBgVhhxDyCcZMbYQRYRFt9QsUI81sabyLmwAMMAYx8ki2CQAxWhcYKGT4MmV9uDpy1PNx1abmJ9pIktCR9ZwRo9PkyCwZ1Di3oe2N447SVSO6puohgyhUDpLgsMejBwOzko8OBhhY2+Ah3uDV3dPyj/rjyvAJGhkCeSMYMRamBVZYsds08JsTIgJvNcoRW0PEYBQbSTv4gt5YByAfkdCRs1nm4moS07ImLhulEmLlkXxfHgDLO7uLPhE45Y6MB6I450ivqVDUYdYJZ1XjOE8YmHyY2LU1Q1zLatQQNLdSsHW2kII7DBY8eRJSRgeAIjweBW8eNr6+xkYDDEo78MFCkXpkRiHTtNgYSr/pXPzzd9fW2zg/HyG2U6CJjWjSyykhxhXOcdXl3kXjJcbkDFwOgecDko8PCxwZ2uIj7aGr+wcjf68dECepnAmVM7L3COQ4vOagf3ZiK57kZ6xdAcA5UU4t5nAwiaqGFXlUVTh5iY4h3bDYHk6/fy5+cbXzy/kcysLORbaFtNtgzw3aDWamGo3sTA3g8X5aUzPdACToDus8NFWF2/e2sN7dw9x+97hVz7cOP5q6YEkzWEMUBYhNJyb6+Da42tfevrxlT+5fm0FT19ewMWVNjotg2HvFKeHezjc38HZyQmGwwLF2KA/DhsOG3sD3N8Z4cH+8CsHp+Ovno0cxnwNXh6OCCXUKsYhDgc1Z8thOJ8XlUJZNkAXAE9zNF4aDYASntYYFEWBsnSYaydYX8q//viFqS9eWZ3C6kKOdtOEy5PJyMHtwWVcYS2dD10pwsUdgZENxhV6/Qqn/QKH3SIA9FHxpb1u8Y3+MOhWSuUYYWhObC9Ov2iemMN7rhEjZ84AQkYbm60aDdM6JUJMPjQSZDtjGRp42gjhv2neGxDjiO2TQSYCVbYWZ6SpdQ03RO/h42vVoAPxhhxWmAxTO97p44/qADUhyIPz0DgV3tNRDt4NjONmBiNlX8Z7uEAlwkLwjkiNhTENjcasXBpaoySpweid0btI2Ia8rCXAKcoSZengqwqt1GC2k1xbnE5/d34me2VuOsPcVIqpVoqZZoJ2K1w2GvIWAa4q5zEuHcYF0B8Bg2GJ494IeycFNvdH3354WHzhuOfgjUEjC72huKsmM6h6voGOZ1nONRhhY8GRap1eWGOnumVCEl5ux4YJbZNo7ZxzKIoSxXgMzrrPdxKcn2/81upi48uriw2szOdYmLaYblu0cotOu4lOq4OFuWksL08jy5s4HQCbu0P88NYeXr+5hR/d3l/s9cvDyxeWfviZF6/e+MT1dTy+NovFGcAUZ+gfH+HwcB/Hp8cYDsPlsa4ATocGW0cV7u2O8NHDHrb2ey9vHxffHUvFR7j+LM+4TY7YQ+3IGIBw2Fn0VNs0CzPwPtyLgABejHeeaa1RgwryDvJ3DigqB1eWyDOD5ens2sXl1vurSw0szWaYayeYaidoZjacwOA6qwoYVQ6jkUNv7HDcK3HYLXB0VuCkV7510i2/dtZ3f9yn3CtMgjS14oSdr1CVSihiAOPQbjJvJQxLbA2iO3wvJmfx43SQ7BYymJuILdGOuG64WX02D47aFClJIVfuqWQ1Ij3Bxh1iIBaWR6xRpiw4aCgHxvOM8ky8o8ZFjABTRXIsQrc8vLdyDId+A8VtGnQN/GRUUezrxSjrz+fvx8CpP3IJAreepfdzYa2MyUfJTCKutZIMzilZC2MTckAe4L5i4wJcFtBIgXYzxUw7/fxsO/3yVDt5pd20aGVWlK0sPfqFw+mgGnYH7o96/eobp/3xn3dHFYrKIE3CUR854iEdOrxMko2R10TYApUgxN4tBjA+D8jV7JZOHRgYOmcKcDJNdaOS7htlyamE8O52arA0n790Yan52uNrLawtZlidyzA7lSPLLIwDmu025uemsbw0g5nZGZz0K7z94Sn6Q4Nrl5dxeW0aRf8UDza3sH+wj96gi8R4uMpiOPI4HTjsnRS4u9XDnYf9tzb2hs/vd7XoFlSvl3Dvby7DYL3kPmZSwU/GXHHpR6zHsUdHBAC+ZrS1Y0xR/k70ksCsch7jcQn4oBvTLYupVvovZjrpf5lup6+0cm3QXTlgXHh0B+Vbp4Pqf5wMqj84G1QYFY4pNBIT+tinaQoYQzcPVXJ1oG586W58mDWnboIeGG5bw45Q7FUBRUEJAKKrDJkZsTMEJGyLO4PwZSy1i1XoFAwEBMmKJaILNu24zx5MLY0W58LoFxAYUmIYvicA5qPShbCEgq+m9jR9CWG2qoZR9K8VNBBtlJwEjyZCYPV0kWeM3hd7hFiRJBYG09x6iMqMy7PQJD4XuQqYGWMAm0D2xeGCbJwLCVcf6L7jrCu0zofOT+shZwcUzqP0nmwpVP6nmZXPyAAiCh6iDqEB0VlTvbknjFfZROxxDYJBMQMLtk0nD5g9CGtWb+dd6IXF3SYCjlJVlHMA9e9qWYNzc+nnL55rf/vi+Q6uXW5jfbGNNAkMoNFI0GnlWJhtoTPVQZI2MOwNsLO7h5NuH4XzSOgugc29ET7YHGD/aIyto8EbDw+Hn9490To0YxPe5AR8aFVuABgqQI7XzZsAEixZJ8YULL1yThj3hGZNpDRisPM1u4i+IWGZsVE4BoOyCi1uKmrnkxjq+MvjcgEO4gJWaTFtIP3AwuusHNVz3kHiT3BIyPPnp3sWFs1QzyTzOsvUIjsinyjfjT5Ef/cyP2VA4XdcqmGsFQdgRKZsJQIBwvqUhRl9L4+LdN4JrYY43xhxQgiZZfDRJAV6qGpcOxhECTwSUXifjSaqAzUCUDHiewGYGMX5c7WcmHO1Joj6d4JNhniQ8UZHKeR3UA/LRYUhMuUF0c+G/1JuhK9UpwdwLsWhPh9rDay3upjyHUbmEJ7w5bFAYHV6uDliruxdoEBMd6vVnIi+gyr7YwAzgOGTAAjf52NT2vyRwAsMYpDeZ94VCB0eqGEeKY6xBlmaILXAcFzSpSJA2wI//9l1/89/5jIWZzOMByOMhmP0uwNUxRicRzHOI00TNDot2DRBmll0uwW+9/YevvXG/sv3j8bfZRPM8gxpklB5QSUtnwNJpgP4zCYItDjPaa2NulR7ZVRsB470V3bC1FBDmiPejZ9w2hFDYAATBgeoPhmwkom+Kj/y8kgDyol5SEdiBkrLIS1HBcbQrmh0FA3syOh5xkjHYqYpNbyC2llMKCDapYjjwbIgkJa5G2J2RnWUpx7Fg0wW4jIK0dPouB+/3U+IW6MwJ/KOEEfnA0SFrPRCDhlZ4Gz8/GOjhQo2GnsofpKP/ikGEeV0Ahye7b0uWC4kDPU1Jiqf1e96RH3MdGeX/s6UNvIkUgAa5QjE+AnELOXFxAOTkJnGy3xJ0HThCQQk+bmOiTcgff51jMw2w3Poj3xQHQCo/Y2xoStFXEvMOQh5luHr5mjI3lGFtpc+UHoagMcYPF/lKbHsynCmj5ib84FzJTaBd06OrWQp8NQTy1+/8ezaFz9+eQ5PrnXQbjj0T0/QO+1hNCgAVyFJE1Qu7MxOtRIkiUNvMMZo5NBsNtCeaqNKcjw4LHF7o4t37x7j/XtHra2D/jAoWoLUajQQwptU5iBMwwOeuq5aE3EwzrP6kOKQ3mFg8AigKMdTYs01mlqI69p0w8TTu5TZw7JjnDBsOZhF8+B0gUeo1jcMrNxVxQpT0RIi1kXN77FN8for8zFRcp90n0+/GMgGXO2ANEckPhp7RBrCxh7nXhlY2dzVoYvzJbsxBnrfozgWIL5Oj/Nv4ghioKphBsRe4ujM5Hk42+cIwCZPgv+k0I0nHzmUehhj9N/FcHnC0EWWPBTUU5pgx6qIiMKy8CJRMKHPXoUWcj7KLvQrNB4uoJX5cfxtJEGuxXMQ2graoZLckMQ2PD7NwbFHru+AafDC7/tHAcx7UQz1bJqkBY3LwtB5TBq7MI1K6ph4U4KBrH7BRZBDRfPyVRlq1Ag4RoXu4q2em21+/Km1wed+6iKef2oBK4spfL+Lvd1D7O6eYjQcwXgHGIv+uMLW/hDbhwUGY4fl+QYurzSxMB2aPII2clqdJmamp5A1mzgbGny43cP3f7yHt9/f+/337x39Z+6UnKYpstTAw6qiRwf1YQOgJ5aZZqRTCEZU0a6sxjXqwLzIUxarrvvkOES+AmCslUYcDN89EOzMiL6zQQNRY8mJLgt8HwXhnvxz+Lgm6ONcsrUaAcEY6XasOm4FOJ2Vx0j1ey3npSiioZ2BdKiIhFIjAEHnjTxCowTI57z3Anz6VWY2NVFGeMO/VBJUk5cxfLFt1LpCvAzkqYaorLa30Bf6eOLCqQ0NXpUjdBuJdjRo0t5ozCseoOZZaCENtzvSLYI6m4F4R81XmEeFEYGuPiLMz1uqmY+/bwA+XAyq2OYCXW7T66OQkL15WHieK9UkiVHxeOL8xWQuRmXvotBA6XYEtoA2rKM6L1F0w5+zUYfOYOiM0txWB/B0lKeUtb7xzNp3PvncpZc//dwqrj42i3Za4Gh3H9sPd9Dr9lB6j8olGI4Ndo+G2NjrY3N/hO3D8ZeOutU3hpVHu2Fxfi7/nUvnWr9y+VwLFxabmJtOkFoPVA5JYtFsNbG0PIM8b2DnqMQP7xzizQ/28e6tvZWto9EOADSbOdIkDTVtxIbZI4QQMqFLS2jOhPR8CiCAewhJnRcNFH0XVgVE6wLy+AInqt+MAswaxEEz0JBZ0Od0GbkuS/WcnZIxRpoiRB9RmyQnrSwnHqhR3RPvzbwI2nTSafcIfhWbZchl8QUwmiODASJ/zEooOsrjmtRdNjaWeQxotR1HmTKnkSZ+7xmUTX3sDGAiW8qbIBKWpQfrdVrRrsZEs7r4WdIPTIx5YmIx6DOAGVWq2tYrfHSRQwwy8rbapMNHFSB0J4YXXlY66u8WXJMySQmCQ71U7UfzcLz3E4eQzPoEdASs9No4/m8U0WmrEC8PAedbHG0LC3u1RmQTjlIR0DtltA5ejrkYGzqTekqAW/6eBcqiQH8QyiiajQw3nrngX3rhIl5+8SJW51N0jw+w9XALh4dH8M6j3Wph7BJsHQ9x50EPdzb62Nwf3Njrlm+PxuHkQJqlSNLQpbUqS/iywkzLYnWh9Yeri41fvHi+hdXFJmaaCR1ZK9BILc6vLGBxcQaVSfDBxgn+/sd7+P47e7/7wcbJr5YOyLI8nFRwHmVVCiNIktDtlNcgyCTIQhpb0uIwIHheQQ94DvcMH5COjIVQLe5dxwAIZuiRo1VDUOfJHRoMIYa4YmrmGN6NGoBJBw9xphAd5txfDGEQHdc8U3wNXmw3PrJntiEmJCyX+nd0WlI5UDeJMB0mDuRoAzyo3QoY8zrxeFjlhc2RA46Oo7HlgPDH5HnKv6IFjpKPZHABjrUoTssTdJG8V6Cj10UIHDyUsC8DjY3JAIMwmQ5LwY+EiGLkjiZH0jI8jkhwYuyPgBovIksb0bxZYU0NYC08deulvBoATdBG85SfyKsIC4DmDQjALPWsVwDz9HsK7SJPwHNQyu/CBSnCwlQ5uOMHG6kjDyqMzya0uxeS8lVZoDcYwnuH5YUOPnnjkv/sx1bx4sdXsNAxONjaxv37mxiNh2g2Gmi2mjgbeNzd7uHmhyd4b+Ps1e3j4s+GdPbaJBZZYgNTooZ+hs9zunCaoSxCO5xO22JxtvFfLyxPfe3ySgcrszmmcw+LCknisbA4g4urc5iZamFzb4y/e3cP//eHD/HOnSNzNizB1ei6xobmRmGzyNULg65YXShH6bxHIgbDTEG7OuiaqvEYBHuQDSlAjuvA6+6a97EjE00lu4kcoKce8gwc/FDjo7yd6pjoYnTHJfQVyiCdl11Mfp6kO+j9k0wuIrVBt6X7BL9Hc1S1G77iHxGXif5FIzl+Htsl5zQdz0fmwo7ccT8EebzMM8/TCdbEQlJxx1u1cXudes2Ij8cajFdCSkQtholLRaAhT/DqreqLZQSVa2yRBsrji8Mzx0zf18da80RRqMwLKvVVLOTaCxl0RQ1p3AxW9pH38bDjd7A6CjsVZQp/s8SieD10x4vptQIWr6icM2TlcuE8JAMZDDXcSwKAlaXDeDQC4PD4+uJjn3nh0kcvPb+K69fmkJZDbD7YwYOtffiqwFQ7R95oYP+0xO3NHt756Ay3NrpP7ZyOb5UVABt6v7NsDKgKnKverSW2xweew8+4DLcBwTlMtRKsL7d/54nVqV+5ttbCymKOVsPC+Aqz022sryxgfr6DnaMx/u6dA/zFDx7grff2zHFvDMAgzzJkaaodhY2Rs/wBSAKoV9LOyWueMHJAMS+LAUy2tTyE7YY1rSA8iB1PBBq+pp+iCOqATcQ4ak7LgBvMxAn04OwNfZdZi4Z54OJs0gFWwMkwLdYt1dDwXu6kG2/YydzA8zAwkwyspucC9YAaEORIlxqP2hkosqCwP0QR9J4aSYjmE7pR1Hcbg0DrYRxq81Tmwzwozl356H3xOIVtANBQCoLuwjDICFToNn5SjXvVXvaPClL/OVYowVtPTElQ30SAoq8JYwlvl2ezx4o8OIN/YAKU+5CHPZqji3QqGIjVw8FBoeItVh99Tr/ISXrPY4pyYfCeEsTAqCjhXYU8T3H96srWSy+sr3z6uQu4dmUaZe8Ed+5uYHfvFMYYtJo5vEmwezjErY0zvHuvO7y7PWod9ip4AyraBVxV0e1PYTw2oYPyhtpUC6gg5DANr3kwtbKsQqFwVcJaYH2x+dJTl6dfe/7JeTx1oY1GnmA0GiFvZFien8HS4jSOBgZvvneIv3prEzff35/f3O0dAwZ5o4FmQ52ypwJnXzl4Ce6cpKEUTFS8eocDA4curCSiuYJdkusQphvsLqyDdqEAuC7I2FAao7eBMfCpLfGz+FQMELExG7Eq0Sm1sdoPO1ED6SsfO/xHLRkSZXnnpc6Ss4CA1mfVnkEIW8MMflaNFdUBzEdjlL+jbqvxc2SzjzyhybM0Mh4K43xYZBOFU3G8zFMRBgQQihIoSbjE7CT+d/67GqJhadTmMAmqqli1kG/yR0CR/6WeFOSxgukqewoSYoTDdU8Rz4eHG7+flcdAqHW8Q1QPJ9RJRION3hG8L8tfE7LhxdzBkiUT7yyG0CaaKwJAFMUYgMdUK8NPfWzd/9NPXcFLz6/i6kqCw/0jvP/RQ+wdnMFmCdI0wXAMPNwf4r37fby/cfa7m3vDX+2PqZV2aiUx7ioqLZEDw1aAlTupBjFRcj1S3AAsALj3unMYlxVcFSrwLyw2rt14fPb9F68t4cmLbWSZR+9sBG9SzM11cGFlAWOkuHnvDN/74TZ+cHPzK7fuH38VANqtJhqNHJULtzN5F/rIw4cD1Z6dgveQHd943cWJxr+OvDJQ/94jqmhET4RZsZ1yT6RIlzxtcUqkISDBOqUAhgm9EDWMddVDiqANjT1mhXLrNXtf48EX14pDZj0T+qcOm8GK5yrFIuLIJzbsaoOMdk5F3EYEFEcx/DlhqS76mwHXgbFRBbbDuxxGTERROt7xUw4DATD46FhL9DnxEHUiUQvzxCTN5LuUHLEEPY81EoLsiPLTaouscT9TcUQ0NwY4XexaBQrUTzEwx7Lh8QAh11BXfs9HXExcfzSp9/pvGjpqnzbx7j60auHHM9thxbbWhmZ845LCRI/F2RY+ef2y/8JPX8GnXziPhQ6w+3AbWw+2EcKwBFme4WxY4oPNM/z4o1N8sNF7+cFh+V0Hg2YzRcqHpQkEXBWqw1nG0jHTgjq2GupYG+TsOcT1kJ1cV3nIXQGhqlOcZlGFFjaXz7V+6RPXFn7/xtU5rC+34CvgtD8EYDHdauHc+gJmZ+awudvHd9/cxPd/tIl37+yZ7ghoNhtIszSUAjgnYXVFq6vOINbraEU4IiCjdDEzEyPWzi0RatVAg1lF0F1+Fzu66N1GtS3WA1Wkuh09AmRiG4G5a0s8ZVeCWWQvHrQetTSPFzYIIGKlAKRUw4c7LCNnGdUIaBTm6VJrr7vwrO3GWglZDRELGa+Jnin2UpdVLYREfIaJpaX/IotJNspPBHiijPbRcorcvQonXjxWHkZZr4/U99dQL0ZBXQD5ffRR8RyC8CBB/YTxiLdhMelCCjU3gDLH2Etw0EszkDlBFs3USiyM0HBrJudgRX4G0W6vsMnYIWgegjssJHTjzXA0RmKBJy7M/bcXnl37zZdffAw/fX0NnWSIzYebePBgB4NeCZNmSLIM1ia4v9PH6+/s483bJ2b3KLCgZjNHmpHHrLi/mcogZl/BLxjAcrsfyH2MLDuVE83bhzo00qJa2+CEQtRxWSG1HlcvTH3rE9fmX3nusRnMzTUwKjyG/TG8AabaLVy5soqlpVnsHPTxvTfv4zv/sIm3b+2bk6FDag0aWUq7kdotV1qcy/hZf+PwRXtjivZNGAE7v7ATyQYXuScJsSD6J87Rg0Ii0jXSFy/6xn9Tpw4T6QKPzEOSjPo3GaLoOCINU2f8/4uaFPRUE+mxnMdlQdU+wzvz8TvVsSvbhMqGflcjJrww8uDIlvMsFRQX1EX0hUgAAgL01BjxAV7keHosAAUGeDZ3z/hDjzRyxGdym9mYmP/wkk0Iw3h4X8+VyTv5ebSooUmFfDGMhY7HC0uKaa5RgFXhRvLh8ekjZYzx9WoyT5JH7Ln4XXo/AEQOzBS9rx+2jbfAefPBVRVamcPHry76Tz67js++cAmPXZxH4oa4e38Lu9t7qMoSeZYGj5sn6I0Mbn54itfe3P3KrQfdrwIWjUYW2gxF4+WQg7fpJ5mXgaR5YBBAVbCf2IcUGXNXEiDqv2XAZelckmItX4QR6tOmGgbPXZn1n3l2EZfWpsMt26VHURQw8Og0M6xfWsby4gx2D4f463/YwOvv7OD92wf5Ya8qUsrJVXKJDTllPlvExiKGMrHLLCTE16oI2MnxdWEsLgNEO/gTu3ZGP0u1EzBOwYK1w0Shar1OU51mLdKAginrY0xSWKcjJEEN7AicI8JVQ3fjY5qi+TQGfX18HQsEAB1vWsVnNWM9h+o6CVfZHM2JD1M1cq4D4wHw+I1MTJBTHsaVrA5x7ZPYmwgFwkLqyTh5ZA3rZMKGm3Ww9yMl8z6qfdLnR1KPHuoh29dEeWt4UHun+jETCTJ+hzGT8wogRnyBcjs6BmMg1FiFg5oxCNSKptBI6q+nr0cUXlyNMmZ2AMvT9lP/8eeefuPzn7uMpdkmjrtDfHh/GweHJ/DOo5E1wro5D5uk2O9X+N7NA7z25q7pDSrkeRb6aglbsORUaHzMuiIHImvu9fxqbefY8Doi0h0CCdoi93J+NMIRhHdbBkA4jIsKVVlifbHxqc/eOP/G808uYrqdwFVFOHJWljDGoZEmWF1dwPRsC/unQ9z84BR/8XcbePvWoSl9IuWLLE0Jn8R4AK7rYgXQ0ggyZEDq9njHzFPtHzNwANo+nHQ/OnhRD/+gMBL0NSoripwqvJcOG9xxQnUSWuHPpR1GlAtwUa4KzPd5jdQW+HkaAURga3SUvLg8F07rMIxqSVKUuyaRqm6QXPgqOni1HwJdUwv5vK5BliV1ZsHsgV5qEAlRHhD9L9NlVnL6cZzPAKNqvLOgSi/ehheVwY69McTHiDBruxETOYAa24s9BhnAo6FstLvBMCZehIUVPU7a3+hWcT3PxiBIakgeT/McKqPaxCOFiBnmT9yoYKhlYDVh168sx/jZF9f8r/+HF/FgdxdbuyeovEejEXpnFSVQFAWtc4aN/QJ/+YOtt9784Oh5A4tQE4jovXQuj+ZsojXi/3fROipz0XWPd8xq/cjA8mG3wd+NxaObLMz6QGxpNC6QZ8ALTy75zz53DldW20h8iTT1SFOL8bhEVTmMS4ep6RY60x1s7Q7xP7/53jfubA2+ZJKwU+ki9qJ00Yu9P7IOpLDqiHXQAd+1TEMNgtde68t0FxN1mYkBW303/48PkAOjffWC46KHMBZN6HOYlhEHFKcl+Fib5JwN6sl7EjuDioHRyCEWVaTKsd0Q/sjaxg6bPxeXWPFQWb8iv4naEpBkUon1I8NncCB1EZ3SThAKKPrACUWMfmo9tIWWq7mKfP3E2a7oh51IHMrEn+PDzLptrdmWIFzOuSkl4P+EtTe6CGxUtAA1gGVWFdFdlY/TVQqjCnKJc7zxEtSofAzCvvZOlUAdKKUVFPMVm2DvZLz99b94b2XQPUSWZshaDTSbDXQ6KfX7cqicxcZ+D3/9/Qdf+mhn8I3QZytB5SoCDVtjT3BK52MmCxhMNqeU3lH8eTlIrDqmecVYuJEDNJPr78E1ANxqqJGnKMoKb7y7bx7snV3/3PW1tz7+2DSmOh62dOgNCoxHFc66Q5TbZzA2hUlbSFN7ia+0E1CIDEzYTAyoNdbsoVEIW+ykUZJsoP8cX/YMF+sIz49+bYLeiBpNOnY4PZIkiBXVBQi41h2m6KjRQl35bfR5PSll5CMxeeH15zER0uk8QCAerWe8I641bDoHE4vjESDkaelELIycaTZZlkZGowBk4glEk2QDN9Fb4/wQDYm8fKSoE0DFA1RDgPyE3/nauOQ9k/GVyJABIXqIUZYyybR0OeJxqLfzIgP9TDwGL++AeraIZekzfU0ZPepzQvQcXfA4D1iXXY1xRgrFoGNNiYtLrd95Ym3qV8qiwtZh77X+yH2z08m+mCfmxtxU3hwWDu/cPTGHJwXSLIX1jnYIQWwukfFpTkXzpDxGROxFxmXooLOfWOf4M6ivqeCAOMRJMAgy8p6NiQHfUH/5Es0MeP7qor90PtzS0z0bIwHQbKVodnKMR8Ct+8ffvLcz+IXShUaBYS3obCSjArMNTKwxeIwK3qqAOn7dtKk7bGX0JoB6sMTwWe8p1xiA0Rgel9EGjTXAC+8XFsjDUJPVX9V03uv8DKDdT3xghDW5e51ZjU3+BLAmeahzi+6VjJndhK5ISE6Dtyx/o8zrkVmTgUreNQAYMw7d5YhDuVjptJhO2/JDDNXowvPMBEFAz3K1gcSyjRWhLuz66gUhmQnBKhvQuJuEZmhU3LXVoNaaRtmDF5bwiMYIY0BNWZjJhXHZWBQTXwyAo0WAKmeeo8DqI3PQz0+IovZsrlj2rkQrT5BYg/6gxLAMcnHOoZMlcHAYO6MHn31Fa82td+L8Gm25iJNiIOG51T1+3IKZk7UwURLbRIttEF3AoooQe2f+X66aB0LYE+5CNKKjzjkY59DOQ2twVwHNRoqpqca/T1J7/uR08Nsn3ZLuFfjJN/nwejk2umjN//E18Tp+2emWitFontD+XuKYfKROmk+VZ0xIQYHVTzhuHSNEjyLsJUAUp2xYpuH/a86Ehs33qNZzr3UH6j03cwzzj3U/ToPITyRjHpintaxltrlA+xFWG8mKDPn/AVBhmOstQnHqAAAAAElFTkSuQmCC" alt="ForgeLab"><div style="font:700 24px Georgia,serif;letter-spacing:.18em;color:#f1d59b;margin-bottom:5px">FORGELAB</div><h1>CARNET D'ENTRAÎNEMENT</h1><p>DISCIPLINA · CONSTANTIA · PROGRESSUS</p><div class="period">${jDate(first)} → ${jDate(last)}</div></header><div class="summary"><div><b>${rows.length}</b><small>Séances</small></div><div><b>${totalSets}</b><small>Séries</small></div><div><b>${totalMin}</b><small>Minutes</small></div><div><b>${jFmt(totalTon)}</b><small>kg tonnage</small></div></div>${detail}<div class="foot">DAILY WINS. · FORGELAB</div></main><script>setTimeout(()=>window.print(),350)<\/script></body></html>`;
 const w=window.open('','_blank');
 if(!w){alert("Safari a bloqué l'export. Autorise temporairement les fenêtres surgissantes puis réessaie.");return}
 w.document.open();w.document.write(html);w.document.close();
}
async function jClearSavedSessions(){
 const count=jLoad().length;
 if(!count)return;
 const ok=confirm(`Vider le carnet ?\n\n${count} séance${count>1?'s seront supprimées':' sera supprimée'} du Carnet.\n\nLes brouillons, Séries, Suivi, Programmation et Priorités restent conservés. Cette action est définitive.`);
 if(!ok)return;
 const second=confirm(`Confirmation finale : supprimer définitivement ${count} séance${count>1?'s':''} enregistrée${count>1?'s':''} ?`);
 if(!second)return;
 jSave([]);
 try{await pushJournalCloud()}catch(_){}
 journalDraft=null;drawJournal();
}

let journalArchiveMode='sessions';
let journalExerciseSelection='';

function jArchiveSwitchHtml(){
  return `<div class="j-archive-switch"><button type="button" data-j-archive-mode="sessions" class="${journalArchiveMode==='sessions'?'active':''}">PAR SÉANCE</button><button type="button" data-j-archive-mode="exercises" class="${journalArchiveMode==='exercises'?'active':''}">PAR EXERCICE</button></div>`;
}
function jWireArchiveSwitch(root=document){
  root.querySelectorAll('[data-j-archive-mode]').forEach(b=>b.onclick=()=>{journalArchiveMode=b.dataset.jArchiveMode||'sessions';journalDraft=null;drawJournal()});
}
function jPdcName(name=''){
  const n=jNormName(name);
  return /^(traction|dips?$|pompes?|air squat|copenhagen plank|ab wheel|relevé de jambes suspendu|relevé de genoux suspendu)/.test(n);
}
function jExerciseIsPdc(e){
  if(!jPdcName(e?.name))return false;
  const filled=(e?.sets||[]).filter(x=>(+x?.kg||0)||(+x?.reps||0));
  return !!filled.length&&filled.every(x=>(+x.kg||0)===1);
}
function jExerciseVerdict(cur,prev){
  if(!prev)return {label:'Nouveau',cls:'j-verdict-new'};
  const pdc=jExerciseIsPdc(cur)&&jExerciseIsPdc(prev);
  const reps=jExerciseReps(cur)-jExerciseReps(prev);
  if(pdc){
    if(reps>0)return {label:'Progression',cls:'j-verdict-progress'};
    if(reps<0)return {label:'Performance en baisse',cls:'j-verdict-performance-down'};
    return {label:'Stable',cls:'j-verdict-stable'};
  }
  const ton=jExerciseTon(cur)-jExerciseTon(prev),kg=jMaxKg(cur)-jMaxKg(prev);
  if(kg===0&&reps===0&&ton===0)return {label:'Stable',cls:'j-verdict-stable'};
  if(kg>0&&reps<0)return {label:'Charge en hausse',cls:'j-verdict-load'};
  if(kg<0&&reps<0)return {label:'Performance en baisse',cls:'j-verdict-performance-down'};
  if(kg>=0&&reps>=0&&(kg>0||reps>0))return {label:'Progression',cls:'j-verdict-progress'};
  if(ton>0)return {label:'Volume en hausse',cls:'j-verdict-volume-up'};
  if(ton<0)return {label:'Volume en baisse',cls:'j-verdict-volume-down'};
  return {label:'Stable',cls:'j-verdict-stable'};
}
function jExerciseOccurrences(name){
  const key=jNormName(name),out=[];
  jLoad().forEach(s=>(s.exercises||[]).forEach(e=>{if(jNormName(e.name)!==key)return;out.push({id:s.id,date:s.date,sessionName:s.sessionName||'Séance sans nom',muscle:e.muscle||e.muscleKey||'',exercise:e,maxKg:jMaxKg(e),reps:jExerciseReps(e),volume:jExerciseTon(e),sets:(e.sets||[]).filter(x=>(+x.kg||0)||(+x.reps||0)).length})}));
  return out.sort((a,b)=>String(a.date||'').localeCompare(String(b.date||''))||String(a.id).localeCompare(String(b.id)));
}
function jExerciseCatalog(){
  const m=new Map();
  jLoad().forEach(s=>(s.exercises||[]).forEach(e=>{const n=String(e.name||'').trim();if(!n)return;const k=jNormName(n);if(!m.has(k))m.set(k,{name:n,muscle:e.muscle||e.muscleKey||'',count:0});m.get(k).count++}));
  return [...m.values()].sort((a,b)=>b.count-a.count||a.name.localeCompare(b.name,'fr'));
}
function jSparkline(values=[]){
  const vals=values.map(Number).filter(Number.isFinite);if(!vals.length)return '';
  const w=300,h=92,pad=10,min=Math.min(...vals),max=Math.max(...vals),span=max-min||1;
  const pts=vals.map((v,i)=>`${pad+(w-pad*2)*(vals.length===1?.5:i/(vals.length-1))},${h-pad-(h-pad*2)*(v-min)/span}`).join(' ');
  return `<svg class="j-ex-spark" viewBox="0 0 ${w} ${h}" role="img" aria-label="Tendance"><polyline points="${pts}" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"></polyline>${pts.split(' ').map(pt=>{const [x,y]=pt.split(',');return `<circle cx="${x}" cy="${y}" r="3.5" fill="currentColor"></circle>`}).join('')}</svg>`;
}
function jExerciseTrendView(){
  const catalog=jExerciseCatalog();
  if(!catalog.length)return `<section class="j-card j-empty">Aucun exercice archivé pour le moment.</section>`;
  if(!journalExerciseSelection||!catalog.some(x=>jNormName(x.name)===jNormName(journalExerciseSelection)))journalExerciseSelection=catalog[0].name;
  const occ=jExerciseOccurrences(journalExerciseSelection),first=occ[0],last=occ.at(-1),pdc=occ.length>0&&occ.every(x=>jExerciseIsPdc(x.exercise));
  const firstE=first?.exercise,lastE=last?.exercise,verdict=firstE&&lastE&&first!==last?jExerciseVerdict(lastE,firstE):{label:'Référence',cls:'j-verdict-stable'};
  const metricVals=occ.map(x=>pdc?x.reps:x.maxKg),metricLabel=pdc?'Répétitions totales':'Charge max (kg)';
  const best=pdc?Math.max(0,...occ.map(x=>x.reps)):Math.max(0,...occ.map(x=>x.maxKg));
  const list=catalog.map(x=>{const o=jExerciseOccurrences(x.name),a=o[0],z=o.at(-1),v=a&&z&&o.length>1?jExerciseVerdict(z.exercise,a.exercise):{label:'Référence',cls:'j-verdict-stable'};return `<button type="button" class="j-exercise-row ${jNormName(x.name)===jNormName(journalExerciseSelection)?'active':''}" data-j-exercise="${esc(x.name)}"><span><b>${esc(x.name)}</b><small>${esc(x.muscle)} · ${o.length} réalisation${o.length>1?'s':''}</small></span><em class="${v.cls}">${v.label}</em></button>`}).join('');
  const timeline=occ.map(x=>`<div class="j-ex-timeline-row"><div><b>${jDate(x.date)}</b><small>${esc(x.sessionName)}</small></div>${pdc?`<strong>${x.reps} reps</strong>`:`<strong>${jFmt(x.maxKg)} kg</strong><span>${x.reps} reps · ${jFmt(x.volume)} kg</span>`}</div>`).join('');
  return `<section class="j-card j-exercise-focus"><div class="j-section">ANALYSE PAR EXERCICE <span>${catalog.length}</span></div><label class="j-exercise-select-label">Exercice<select id="jExerciseTrendSelect">${catalog.map(x=>`<option value="${esc(x.name)}" ${jNormName(x.name)===jNormName(journalExerciseSelection)?'selected':''}>${esc(x.name)}</option>`).join('')}</select></label><div class="j-exercise-head"><div><small>${esc(first?.muscle||'')}</small><h3>${esc(journalExerciseSelection)}</h3>${pdc?'<span class="j-pdc-pill">PDC · convention charge 1</span>':''}</div><b class="${verdict.cls}">${verdict.label}</b></div><div class="j-exercise-kpis"><div><b>${occ.length}</b><span>RÉALISATIONS</span></div><div><b>${jFmt(best)}${pdc?' reps':' kg'}</b><span>MEILLEURE MARQUE</span></div><div><b>${first?jDate(first.date):'—'}</b><span>PREMIÈRE TRACE</span></div></div><div class="j-exercise-chart"><small>${metricLabel}</small>${jSparkline(metricVals)}</div><div class="j-ex-timeline">${timeline}</div></section><section class="j-card"><div class="j-section">TOUS LES EXERCICES <span>${catalog.length}</span></div><div class="j-exercise-list">${list}</div></section>`;
}
function drawJournalExerciseOverview(){
  const v=document.querySelector('#view');
  v.innerHTML=`<div class="j-title"><div><small>LA FORGE · ARCHIVES</small><h2>Performances globales</h2></div></div>${jArchiveSwitchHtml()}${jExerciseTrendView()}`;
  jWireArchiveSwitch(v);
  const sel=v.querySelector('#jExerciseTrendSelect');if(sel)sel.onchange=()=>{journalExerciseSelection=sel.value;drawJournalExerciseOverview()};
  v.querySelectorAll('[data-j-exercise]').forEach(b=>b.onclick=()=>{journalExerciseSelection=b.dataset.jExercise;drawJournalExerciseOverview()});
}

function drawJournal(){
 const v=document.querySelector('#view'),
       drafts=jDraftLoad().sort((a,b)=>(b.date||'').localeCompare(a.date||'')),
       all=jLoad().sort(jHistorySort),
       last=[...all].sort((a,b)=>{
         const byDate=String(b?.date||'').localeCompare(String(a?.date||''));
         return byDate||jHistoryTime(b)-jHistoryTime(a);
       })[0];
 if(journalDraft)return drawJournalEdit();
 if(journalArchiveMode==='exercises')return drawJournalExerciseOverview();
 v.innerHTML=`<div class="j-title"><div><small>LA FORGE · CARNET</small><h2>Carnet d'entraînement</h2></div><button id="jNew">+ Séance</button></div>
 ${jArchiveSwitchHtml()}
 ${drafts.length?`<section class="j-card j-drafts"><div class="j-section">À compléter <span>${drafts.length}</span></div>
   <div class="j-draft-help">Créé automatiquement depuis tes séries. Les brouillons restent ici jusqu'à validation.</div>
   ${drafts.map(d=>`<div class="j-draft-wrap">
     <button class="j-history j-draft-row" data-jdraft="${d.id}">
       <span><b>${esc(d.sessionName||`Séance S${d.week} · ${DAYS[(+d.day||1)-1]}`)}</b><small>${jDate(d.date)} · ${(d.exercises||[]).map(e=>`${esc(e.muscle)} (${(e.sets||[]).length})`).join(' · ')}</small></span>
       <span><b>${(d.exercises||[]).reduce((a,e)=>a+(e.sets||[]).length,0)} séries</b><small>Brouillon</small></span>
     </button>
     <button type="button" class="j-draft-delete" data-jdraft-delete="${d.id}" aria-label="Supprimer ce brouillon">×</button>
   </div>`).join('')}</section>`:''}
 ${last?`<section class="j-card"><small>DERNIÈRE SÉANCE · ${jDate(last.date)}</small><h3 class="j-session-name">${esc(last.sessionName||'Séance sans nom')}</h3><div class="j-stats"><b>${last.duration||0}<i>min</i></b><b>${jSets(last)}<i>séries</i></b><b>${jFmt(jTon(last))}<i>kg</i></b></div>${last.exercises.map(e=>`<div class="j-perf"><strong>${esc(e.name)}</strong><span>${e.sets.map(s=>jSetLabel(s).replaceAll(' kg','')).join(' · ')}</span></div>`).join('')}<button id="jResume" class="j-wide">Reprendre cette séance</button></section>`:`<section class="j-card j-empty">Aucune séance validée.<br><span>Les séances issues de Séries apparaissent au-dessus comme brouillons.</span></section>`}
 <section class="j-card"><div class="j-section">Historique <span>${all.length}</span></div>${all.length?all.map(s=>`<button class="j-history" data-jopen="${s.id}"><span><b>${esc(s.sessionName||'Séance sans nom')}</b><small>${jDate(s.date)} · ${s.exercises.map(e=>e.name).slice(0,2).join(' · ')}</small></span><span><b>${jFmt(jTon(s))} kg</b><small>${s.duration||0} min</small></span></button>`).join(''):'<div class="j-muted">Ton historique apparaîtra ici après validation.</div>'}</section>
 <section class="j-card j-manage"><div class="j-section">Gestion du carnet <span>${all.length} séance${all.length>1?'s':''}</span></div><p class="j-manage-help">Exporte tes séances enregistrées avant d'archiver ton carnet. Les brouillons, Séries, Suivi, Programmation et Priorités ne sont pas supprimés.</p><div class="j-range"><label>Du<input id="jExportFrom" type="date" value="${all.length?[...all].sort((a,b)=>String(a.date||'').localeCompare(String(b.date||'')))[0]?.date||'':''}"></label><label>Au<input id="jExportTo" type="date" value="${all.length?[...all].sort((a,b)=>String(b.date||'').localeCompare(String(a.date||'')))[0]?.date||'':''}"></label></div><button id="jExportAll" class="j-wide" ${all.length?'':'disabled'}>Exporter tout le carnet</button><button id="jExportRange" class="j-wide j-secondary" ${all.length?'':'disabled'}>Exporter la période</button><button id="jClear" class="j-clear" ${all.length?'':'disabled'}>Vider les séances enregistrées</button></section>`;
 jWireArchiveSwitch(v);
 document.querySelector('#jNew').onclick=()=>{journalDraft={id:jId(),sessionName:'',date:jToday(),duration:0,notes:'',exercises:[]};drawJournalEdit()};
 if(last)document.querySelector('#jResume').onclick=()=>{journalDraft=JSON.parse(JSON.stringify(last));journalDraft.id=jId();journalDraft.date=jToday();journalDraft.notes='';delete journalDraft.forgeContext;drawJournalEdit()};
 v.querySelectorAll('[data-jopen]').forEach(b=>b.onclick=()=>{journalDraft=JSON.parse(JSON.stringify(all.find(x=>x.id===b.dataset.jopen)));drawJournalEdit(true)});
 v.querySelectorAll('[data-jdraft]').forEach(b=>b.onclick=()=>{journalDraft=JSON.parse(JSON.stringify(drafts.find(x=>x.id===b.dataset.jdraft)));drawJournalEdit(false,true)});
 v.querySelectorAll('[data-jdraft-delete]').forEach(b=>b.onclick=e=>{e.stopPropagation();jDeleteDraft(b.dataset.jdraftDelete)});
 const exportAll=document.querySelector('#jExportAll'),exportRange=document.querySelector('#jExportRange'),clearBtn=document.querySelector('#jClear');
 if(exportAll)exportAll.onclick=()=>jExportPdf(all);
 if(exportRange)exportRange.onclick=()=>{const from=document.querySelector('#jExportFrom')?.value||'',to=document.querySelector('#jExportTo')?.value||'';const picked=all.filter(s=>(!from||String(s.date||'')>=from)&&(!to||String(s.date||'')<=to));if(!picked.length){alert('Aucune séance enregistrée sur cette période.');return}jExportPdf(picked,from,to)};
 if(clearBtn)clearBtn.onclick=()=>jClearSavedSessions();
}
function drawJournalEdit(readOnly=false,isDraft=false){
 const v=document.querySelector('#view'),d=journalDraft,prev=jPrev(d);
 v.innerHTML=`<div class="j-edit-head"><button id="jBack">‹ Carnet</button><b>${readOnly?'Séance enregistrée':isDraft?'Brouillon à compléter':'Saisie de séance'}</b></div>
 ${isDraft?`<div class="j-auto-note">S${d.week} · ${DAYS[(+d.day||1)-1]} · créé depuis l'onglet Séries</div>`:''}
 <div class="j-session-field"><label>Nom de séance<input id="jSessionName" type="text" maxlength="50" placeholder="Ex. Upper A, Lower 1…" value="${esc(d.sessionName||'')}" ${readOnly?'disabled':''}></label></div>
 <div class="j-top"><label>Date<input id="jDate" type="date" value="${d.date}" ${readOnly?'disabled':''}></label><label>Durée (min)<input id="jDur" type="number" inputmode="numeric" min="0" value="${d.duration||''}" ${readOnly?'disabled':''}></label></div>
 ${prev?`<section class="j-card j-ref"><small>RÉFÉRENCE · ${esc(prev.sessionName||'Même structure')} · ${jDate(prev.date)}</small>${prev.exercises.map(e=>`<div class="j-perf"><strong>${esc(e.name)}</strong><span>${e.sets.map(s=>jSetLabel(s).replaceAll(' kg','')).join(' · ')}</span></div>`).join('')}</section>`:''}
 ${jDetailedCompare(d,prev)}
 <div id="jEx">${d.exercises.map((e,i)=>jExHtml(e,i,readOnly)).join('')}</div>
 ${readOnly?'':`<button id="jAddEx" class="j-wide">+ Ajouter un exercice</button>`}
 <div class="j-live"><div>Tonnage<b id="jTon">${jFmt(jTon(d))} kg</b></div><div>Séries<b id="jCount">${jSets(d)}</b></div>${prev?`<div>Vs précédente<b id="jDelta">${jTon(prev)>0?((jTon(d)-jTon(prev))/jTon(prev)*100).toFixed(1):'0.0'} %</b></div>`:'<div>Progression<b>Référence</b></div>'}</div>
 <label class="j-notes">Observations<textarea id="jNotes" ${readOnly?'disabled':''}>${esc(d.notes||'')}</textarea></label>
 ${readOnly?`<div class="j-read-actions"><button id="jEdit" class="j-edit">Modifier la séance</button><button id="jDelete" class="j-delete">Supprimer</button></div>`:`<button id="jValidate" class="j-validate">Valider la séance</button>`}`;
 document.querySelector('#jBack').onclick=()=>{
   if(isDraft){
     const drafts=jDraftLoad(),i=drafts.findIndex(x=>x.id===d.id);
     if(i>=0){drafts[i]=d;jDraftSave(drafts)}
   }
   journalDraft=null;drawJournal()
 };
 if(readOnly){document.querySelector('#jEdit').onclick=()=>drawJournalEdit(false);document.querySelector('#jDelete').onclick=()=>{if(confirm('Supprimer cette séance ?')){jSave(jLoad().filter(x=>x.id!==d.id));journalDraft=null;drawJournal()}};return}

 const persistDraftNow=()=>{
   if(!isDraft)return;
   d.updatedAt=new Date().toISOString();
   const drafts=jDraftLoad(),i=drafts.findIndex(x=>x.id===d.id);
   if(i>=0){drafts[i]=JSON.parse(JSON.stringify(d));jDraftSave(drafts)}
 };
 const syncTopFields=()=>{
   d.sessionName=(document.querySelector('#jSessionName')?.value||'').trim();
   d.date=document.querySelector('#jDate')?.value||jToday();
   d.duration=Math.max(0,+document.querySelector('#jDur')?.value||0);
   d.notes=document.querySelector('#jNotes')?.value||'';
   persistDraftNow();
 };
 document.querySelector('#jSessionName').addEventListener('input',syncTopFields);
 document.querySelector('#jDate').addEventListener('change',syncTopFields);
 document.querySelector('#jDur').addEventListener('input',syncTopFields);
 document.querySelector('#jNotes').addEventListener('input',syncTopFields);

 const refresh=()=>{document.querySelector('#jTon').textContent=jFmt(jTon(d))+' kg';document.querySelector('#jCount').textContent=jSets(d);if(prev&&document.querySelector('#jDelta'))document.querySelector('#jDelta').textContent=(jTon(prev)>0?((jTon(d)-jTon(prev))/jTon(prev)*100).toFixed(1):'0.0')+' %'};
 v.querySelectorAll('.j-ex').forEach(card=>{const i=+card.dataset.i,e=d.exercises[i];
  card.querySelector('[data-muscle]').onchange=x=>{e.muscle=x.target.value;e.name=JOURNAL_LIBRARY[e.muscle][0];persistDraftNow();drawJournalEdit(false,isDraft)};
  card.querySelector('[data-name]').onchange=x=>{e.name=x.target.value;persistDraftNow()};
  const rmEx=card.querySelector('[data-rmex]');if(rmEx)rmEx.onclick=()=>{
    const removed=d.exercises[i];
    if(isDraft&&removed?.muscleKey){
      d.hiddenMuscles=d.hiddenMuscles&&typeof d.hiddenMuscles==='object'?d.hiddenMuscles:{};
      const baseline=jSeriesBaselineForDraft(d.id).get(removed.muscleKey)||0;
      const row=state.series.find(x=>+x.week===+d.week&&+x.day===+d.day&&x.muscle_key===removed.muscleKey);
      d.hiddenMuscles[removed.muscleKey]=Math.max(0,(+row?.series||0)-baseline);
    }
    d.exercises.splice(i,1);persistDraftNow();drawJournalEdit(false,isDraft)
  };
  card.querySelector('[data-addset]').onclick=()=>{const q=e.sets.at(-1)||{kg:0,reps:0};e.sets.push({kg:+q.kg||0,reps:+q.reps||0});persistDraftNow();drawJournalEdit(false,isDraft)};
  card.querySelector('[data-superset]')?.addEventListener('click',()=>{
    if(e.supersetGroup){const g=e.supersetGroup;d.exercises.forEach(x=>{if(x.supersetGroup===g)delete x.supersetGroup});persistDraftNow();drawJournalEdit(false,isDraft);return}
    const next=d.exercises[i+1];if(!next){alert('Place d’abord l’exercice à enchaîner juste sous celui-ci.');return}
    const g=next.supersetGroup||`SS-${String.fromCharCode(65+(d.exercises.filter(x=>x.supersetGroup).length%26))}`;e.supersetGroup=g;next.supersetGroup=g;persistDraftNow();drawJournalEdit(false,isDraft)
  });
  card.querySelectorAll('.j-set-wrap').forEach(w=>{const k=+w.dataset.k,s=e.sets[k];const r=w.querySelector('.j-set');r.querySelector('[data-kg]').oninput=x=>{s.kg=Math.max(0,+x.target.value||0);refresh();persistDraftNow()};r.querySelector('[data-reps]').oninput=x=>{s.reps=Math.max(0,+x.target.value||0);refresh();persistDraftNow()};r.querySelector('[data-rmset]').onclick=()=>{e.sets.splice(k,1);if(!e.sets.length)e.sets=[{kg:0,reps:0}];persistDraftNow();drawJournalEdit(false,isDraft)};
    w.querySelector('[data-adddrop]')?.addEventListener('click',()=>{s.drops=Array.isArray(s.drops)?s.drops:[];const last=s.drops.at(-1)||{kg:Math.max(0,(+s.kg||0)-2.5),reps:+s.reps||0};s.drops.push({kg:+last.kg||0,reps:+last.reps||0});persistDraftNow();drawJournalEdit(false,isDraft)});
    w.querySelectorAll('.j-drop').forEach(dr=>{const di=+dr.dataset.drop,drop=s.drops[di];dr.querySelector('[data-drop-kg]').oninput=x=>{drop.kg=Math.max(0,+x.target.value||0);refresh();persistDraftNow()};dr.querySelector('[data-drop-reps]').oninput=x=>{drop.reps=Math.max(0,+x.target.value||0);refresh();persistDraftNow()};dr.querySelector('[data-rmdrop]').onclick=()=>{s.drops.splice(di,1);persistDraftNow();drawJournalEdit(false,isDraft)}})
  });
 });
 wireJournalBlockReorder(document.querySelector('#jEx'),d,isDraft);
 document.querySelector('#jAddEx').onclick=()=>{const m=Object.keys(JOURNAL_LIBRARY)[0];d.exercises.push({id:jId(),muscle:m,name:JOURNAL_LIBRARY[m][0],sets:[{kg:0,reps:0}]});persistDraftNow();drawJournalEdit(false,isDraft)};
 document.querySelector('#jValidate').onclick=async()=>{d.sessionName=(document.querySelector('#jSessionName').value||'').trim();d.date=document.querySelector('#jDate').value||jToday();d.duration=Math.max(0,+document.querySelector('#jDur').value||0);d.notes=document.querySelector('#jNotes').value||'';d.updatedAt=new Date().toISOString();d.exercises=d.exercises.filter(e=>e.name&&e.sets.some(s=>(+s.kg||0)||(+s.reps||0)));if(!d.exercises.length){alert('Renseigne au moins une série.');return}const a=jLoad();
   if(isDraft){
     const finalSession={...JSON.parse(JSON.stringify(d)),id:jId(),status:'session',draftId:d.id};
     finalSession.validatedAt=new Date().toISOString();
     finalSession.forgeContext=flJournalContextForDate(finalSession.date)||undefined;
     finalSession.seriesSnapshot=Object.fromEntries(
       state.series
         .filter(x=>+x.week===+d.week && +x.day===+d.day)
         .map(x=>[x.muscle_key,Math.max(0,+x.series||0)])
     );
     delete finalSession.week; delete finalSession.day; delete finalSession.block;
     a.push(finalSession);
     jSave(a);
     jDraftRemove(d.id);
     // Le brouillon validé doit disparaître immédiatement et aussi du cloud.
     pushJournalCloud();
   }else{
     const i=a.findIndex(x=>x.id===d.id);if(i<0&&!d.forgeContext)d.forgeContext=flJournalContextForDate(d.date)||undefined;i>=0?a[i]=d:a.push(d);jSave(a);
   }
   // La validation archive la séance uniquement.
   // Elle ne réécrit jamais l'onglet Séries.
   journalDraft=null;drawJournal()};
}

function persistJournalDraftOrder(d,isDraft){
  if(!isDraft)return;
  const drafts=jDraftLoad(),i=drafts.findIndex(x=>x.id===d.id);
  if(i>=0){drafts[i]=d;jDraftSave(drafts)}
}
function moveJournalExercise(d,from,to,isDraft){
  if(to<0||to>=d.exercises.length||from===to)return;
  const [item]=d.exercises.splice(from,1);
  d.exercises.splice(to,0,item);
  persistJournalDraftOrder(d,isDraft);
  drawJournalEdit(false,isDraft);
}
function wireJournalBlockReorder(root,d,isDraft){
  if(!root)return;
  let dragIndex=null,pointerId=null,startY=0,timer=null;

  const cards=()=>[...root.querySelectorAll('.j-ex')];
  const clearTimer=()=>{if(timer){clearTimeout(timer);timer=null}};
  const syncArrayFromDom=()=>{
    const order=cards().map(c=>+c.dataset.i);
    d.exercises=order.map(i=>d.exercises[i]).filter(Boolean);
    persistJournalDraftOrder(d,isDraft);
  };
  const cleanup=()=>{
    clearTimer();
    root.querySelectorAll('.j-ex.j-block-dragging').forEach(c=>c.classList.remove('j-block-dragging'));
    document.body.classList.remove('j-block-reorder-active');
    dragIndex=null;pointerId=null;
  };

  root.querySelectorAll('.j-ex').forEach((card,idx)=>{
    const up=card.querySelector('[data-move-up]');
    const down=card.querySelector('[data-move-down]');
    if(up)up.onclick=()=>moveJournalExercise(d,idx,idx-1,isDraft);
    if(down)down.onclick=()=>moveJournalExercise(d,idx,idx+1,isDraft);

    const handle=card.querySelector('.j-drag-handle');
    if(!handle)return;
    handle.style.touchAction='none';
    handle.oncontextmenu=e=>e.preventDefault();

    const begin=e=>{
      if(dragIndex!==null)return;
      dragIndex=idx;
      pointerId=e.pointerId;
      card.classList.add('j-block-dragging');
      document.body.classList.add('j-block-reorder-active');
      if(navigator.vibrate)try{navigator.vibrate(15)}catch(_){}
    };

    handle.addEventListener('pointerdown',e=>{
      if(e.pointerType==='mouse'&&e.button!==0)return;
      pointerId=e.pointerId;
      startY=e.clientY;
      clearTimer();
      timer=setTimeout(()=>begin(e),110);
    });

    handle.addEventListener('pointermove',e=>{
      if(pointerId!==e.pointerId)return;
      if(dragIndex===null){
        if(Math.abs(e.clientY-startY)>8){clearTimer();begin(e)}
        else return;
      }
      e.preventDefault();
      try{handle.setPointerCapture(e.pointerId)}catch(_){}

      const dragging=card;
      const others=cards().filter(c=>c!==dragging);
      let target=null,after=false,best=Infinity;
      others.forEach(c=>{
        const r=c.getBoundingClientRect(),mid=r.top+r.height/2,dist=Math.abs(e.clientY-mid);
        if(dist<best){best=dist;target=c;after=e.clientY>mid}
      });
      if(target){
        const r=target.getBoundingClientRect();
        if(best<Math.max(120,r.height*.75)){
          if(after)target.after(dragging); else target.before(dragging);
        }
      }

      const edge=120;
      if(e.clientY<edge)window.scrollBy(0,-14);
      else if(e.clientY>innerHeight-edge)window.scrollBy(0,14);
    },{passive:false});

    const finish=e=>{
      if(pointerId!==null&&e.pointerId!==pointerId)return;
      const moved=dragIndex!==null;
      if(moved)syncArrayFromDom();
      cleanup();
      if(moved)drawJournalEdit(false,isDraft);
    };
    handle.addEventListener('pointerup',finish);
    handle.addEventListener('pointercancel',finish);
  });
}


function jNormName(s){return String(s||'').trim().toLocaleLowerCase('fr')}
function jExerciseTon(e){return (e?.sets||[]).reduce((a,s)=>a+(+s.kg||0)*(+s.reps||0),0)}
function jExerciseReps(e){return (e?.sets||[]).reduce((a,s)=>a+(+s.reps||0),0)}
function jMaxKg(e){return Math.max(0,...(e?.sets||[]).map(s=>+s.kg||0))}
function jSigned(n,suffix=''){
  n=Number(n)||0;
  return `${n>0?'+':''}${jFmt(n)}${suffix}`
}
function jCompareClass(n){return n>0?'j-cmp-up':n<0?'j-cmp-down':'j-cmp-flat'}
function jDetailedCompare(cur,prev){
  if(!prev)return '';
  const prevByName=new Map((prev.exercises||[]).map(e=>[jNormName(e.name),e]));
  const rows=(cur.exercises||[]).map(e=>{
    const p=prevByName.get(jNormName(e.name));
    if(!p)return `<div class="j-cmp-ex"><div><strong>${esc(e.name||e.muscle||'Exercice')}</strong><small>Nouveau dans cette séance</small></div><b class="j-verdict-new">NOUVEAU</b></div>`;
    const ton=jExerciseTon(e)-jExerciseTon(p),reps=jExerciseReps(e)-jExerciseReps(p),kg=jMaxKg(e)-jMaxKg(p),pdc=jExerciseIsPdc(e)&&jExerciseIsPdc(p);
    const detail=pdc
      ? [`<span class="${jCompareClass(reps)}">Reps ${jSigned(reps)}</span>`]
      : [`<span class="${jCompareClass(kg)}">Charge max ${jSigned(kg,' kg')}</span>`,`<span class="${jCompareClass(reps)}">Reps ${jSigned(reps)}</span>`,`<span class="${jCompareClass(ton)}">Volume ${jSigned(ton,' kg')}</span>`];
    const verdict=jExerciseVerdict(e,p);
    return `<div class="j-cmp-ex"><div><strong>${esc(e.name||e.muscle||'Exercice')}</strong><small>${detail.join(' · ')}</small></div><b class="${verdict.cls}">${verdict.label}</b></div>`;
  }).join('');

  const curTon=jTon(cur),prevTon=jTon(prev),dTon=curTon-prevTon;
  const curSets=jSets(cur),prevSets=jSets(prev),dSets=curSets-prevSets;
  const curDur=+cur.duration||0,prevDur=+prev.duration||0,dDur=curDur-prevDur;
  const pct=prevTon>0?(dTon/prevTon*100):0;

  let summary;
  if(dTon>0)summary=`Volume global en hausse de ${jSigned(dTon,' kg')} (${pct>0?'+':''}${pct.toFixed(1)} %).`;
  else if(dTon<0)summary=`Volume global en baisse de ${jSigned(dTon,' kg')} (${pct.toFixed(1)} %).`;
  else summary='Volume global identique à la séance précédente.';

  return `<section class="j-card j-compare-card">
    <div class="j-section">COMPARAISON <span>${esc(cur.sessionName||'Séance')}</span></div>
    <p class="j-cmp-reference">vs ${esc(prev.sessionName||'séance précédente')} · ${jDate(prev.date)}</p>
    <div class="j-cmp-global">
      <div><small>TONNAGE</small><b class="${jCompareClass(dTon)}">${jSigned(dTon,' kg')}</b></div>
      <div><small>SÉRIES</small><b class="${jCompareClass(dSets)}">${jSigned(dSets)}</b></div>
      <div><small>DURÉE</small><b class="${jCompareClass(-dDur)}">${jSigned(dDur,' min')}</b></div>
    </div>
    <p class="j-cmp-summary">${summary}</p>
    <div class="j-cmp-list">${rows||'<div class="j-muted">Aucun exercice comparable.</div>'}</div>
  </section>`;
}

function jExHtml(e,i,ro){
 const superTag=e.supersetGroup?`<span class="j-superset-tag">SUPERSET ${esc(String(e.supersetGroup).replace(/^SS-/,''))}</span>`:'';
 return `<section class="j-card j-ex ${e.supersetGroup?'j-superset-linked':''}" data-i="${i}">
   ${ro?'':`<div class="j-block-tools">
     <button class="j-drag-handle" type="button" aria-label="Déplacer ce bloc" title="Déplacer">≡</button>
     <div class="j-order-buttons">
       <button type="button" data-move-up aria-label="Monter ce bloc">↑</button>
       <button type="button" data-move-down aria-label="Descendre ce bloc">↓</button>
     </div>
   </div>`}
   <div class="j-exhead"><label>Groupe<select data-muscle ${ro?'disabled':''}>${jMuscles(e.muscle)}</select></label><label>Exercice<select data-name ${ro?'disabled':''}>${jExercises(e.muscle,e.name)}</select></label>${ro?'':`<button data-rmex aria-label="Supprimer ce groupe">×</button>`}</div>
   <div class="j-ex-flags">${superTag}${ro?'':`<button type="button" class="j-superset-btn" data-superset>${e.supersetGroup?'Délier du superset':'Superset avec le suivant'}</button>`}</div>
   <div class="j-labels"><span>#</span><span>Charge kg</span><span>Reps</span><span></span></div>
   ${e.sets.map((s,k)=>`<div class="j-set-wrap" data-k="${k}"><div class="j-set" data-k="${k}"><b>${k+1}</b><input data-kg type="number" inputmode="decimal" step=".5" min="0" value="${s.kg||''}" ${ro?'disabled':''}><input data-reps type="number" inputmode="numeric" min="0" value="${s.reps||''}" ${ro?'disabled':''}>${ro?'<span></span>':`<button data-rmset>×</button>`}</div>
   ${(s.drops||[]).map((d,di)=>`<div class="j-drop" data-drop="${di}"><b>↳</b><input data-drop-kg type="number" inputmode="decimal" step=".5" min="0" value="${d.kg||''}" ${ro?'disabled':''}><input data-drop-reps type="number" inputmode="numeric" min="0" value="${d.reps||''}" ${ro?'disabled':''}>${ro?'<span></span>':`<button data-rmdrop>×</button>`}</div>`).join('')}
   ${ro?'':`<button type="button" class="j-add-drop" data-adddrop>＋ Dégressif</button>`}</div>`).join('')}
   ${ro?'':`<button data-addset class="j-addset">+ Série</button>`}
 </section>`
}

const ranges={maintenance:{'Cou':{P0:[8,12],P1:[5,8],P2:[2,4]},'Trapèzes supérieurs':{P0:[12,16],P1:[8,12],P2:[4,6]},'Trapèzes moyens':{P0:[12,16],P1:[8,12],P2:[4,6]},'Deltoïde antérieur':{P0:[8,12],P1:[6,8],P2:[2,4]},'Deltoïde latéral':{P0:[12,18],P1:[8,12],P2:[4,6]},'Deltoïde postérieur':{P0:[12,16],P1:[8,12],P2:[4,6]},'Pectoraux':{P0:[12,18],P1:[8,12],P2:[4,6]},'Dos':{P0:[12,18],P1:[8,12],P2:[4,6]},'Biceps':{P0:[12,16],P1:[8,12],P2:[4,6]},'Triceps':{P0:[12,18],P1:[8,12],P2:[4,6]},'Avant-bras':{P0:[8,12],P1:[6,8],P2:[2,4]},'Abdominaux':{P0:[8,12],P1:[6,8],P2:[2,4]},'Quadriceps':{P0:[12,18],P1:[8,12],P2:[4,6]},'Adducteurs':{P0:[8,12],P1:[6,8],P2:[2,4]},'Ischios':{P0:[10,16],P1:[6,10],P2:[3,5]},'Fessiers':{P0:[12,18],P1:[8,12],P2:[4,6]},'Mollets':{P0:[9,12],P1:[6,9],P2:[3,5]}}};
const delta={deficit:-1,surplus:1};function derivedRange(m,p){let base=ranges.maintenance[m]?.[p]||[0,0],mode=inferNutrition();if(mode==='maintenance')return base;return base.map(x=>Math.max(0,x+(delta[mode]||0)))}
function inferNutrition(){for(const r of state.priorities){const b=ranges.maintenance[r.muscle_name]?.[r.priority];if(!b)continue;if(+r.target_min===b[0]&&+r.target_max===b[1])return'maintenance';if(+r.target_min===Math.max(0,b[0]-1)&&+r.target_max===Math.max(0,b[1]-1))return'deficit';if(+r.target_min===b[0]+1&&+r.target_max===b[1]+1)return'surplus'}return'maintenance'}
function hdr(extra={}){return{apikey:KEY,Authorization:`Bearer ${authSession?.access_token||KEY}`,'Content-Type':'application/json',...extra}}
async function req(path,opt={}){let r=await fetch(URL+path,{...opt,headers:hdr(opt.headers)});if(!r.ok)throw Error(await r.text());return r.status===204?null:r.json()}
function uid(){if(!currentUser?.id)throw Error('Utilisateur non connecté');return currentUser.id}
function saveAuth(s){authSession=s||null;currentUser=s?.user||null;s?localStorage.setItem('forgelabMobileAuth',JSON.stringify(s)):localStorage.removeItem('forgelabMobileAuth')}
async function authFetch(path,body){
  const r=await fetch(`${AUTH_BASE}/auth/v1/${path}`,{method:'POST',headers:{apikey:KEY,'Content-Type':'application/json'},body:JSON.stringify(body)});
  const txt=await r.text();let d={};try{d=txt?JSON.parse(txt):{}}catch(_){}
  if(!r.ok)throw Error(d?.msg||d?.error_description||d?.message||'Connexion impossible');
  return d
}
async function restoreAuth(){
  const raw=localStorage.getItem('forgelabMobileAuth');if(!raw)return false;
  try{
    let s=JSON.parse(raw);if(!s?.access_token)return false;
    let r=await fetch(`${AUTH_BASE}/auth/v1/user`,{headers:{apikey:KEY,Authorization:`Bearer ${s.access_token}`}});
    if(!r.ok&&s.refresh_token){
      s=await authFetch('token?grant_type=refresh_token',{refresh_token:s.refresh_token});
      saveAuth(s);
      r=await fetch(`${AUTH_BASE}/auth/v1/user`,{headers:{apikey:KEY,Authorization:`Bearer ${s.access_token}`}});
    }
    if(!r.ok)throw Error('Session expirée');
    const user=await r.json();s.user=user;saveAuth(s);return true;
  }catch(e){saveAuth(null);return false}
}
async function login(email,password){const s=await authFetch('token?grant_type=password',{email,password});saveAuth(s);rememberEmail(email)}
async function signup(email,password){const s=await authFetch('signup',{email,password});rememberEmail(email);if(s?.access_token)saveAuth(s);return s}
async function logout(){
  try{if(authSession?.access_token)await fetch(`${AUTH_BASE}/auth/v1/logout`,{method:'POST',headers:{apikey:KEY,Authorization:`Bearer ${authSession.access_token}`}})}catch(_){}
  clearInterval(poll);saveAuth(null);showAuth()
}
function showAuth(message=''){
  document.body.classList.add('auth-locked');
  let box=document.querySelector('#authOverlay');
  if(!box){box=document.createElement('div');box.id='authOverlay';document.body.appendChild(box)}
  const remembered=knownEmails();
  box.innerHTML=`<main class="auth-screen"><section class="auth-shell">
    <div class="auth-identity">
      <img class="auth-laurel" src="auth-laurel-realistic-v1225.png" alt="" aria-hidden="true">
      <div class="auth-brand">FORGELAB</div>
      <div class="auth-sub">ATLAS · ESPACE PERSONNEL</div>
      <div class="auth-version"><span>v1.30.8</span></div>
    </div>
    <section class="auth-card">
      <div class="auth-welcome">Bienvenue</div>
      <div class="auth-intro">${authMode==='login'?'Connecte-toi à ton espace ForgeLab':'Crée ton espace ForgeLab'}</div>
      <div class="auth-tabs">
        <button class="${authMode==='login'?'active':''}" data-mode="login"><span class="auth-tab-icon">▣</span>Connexion</button>
        <button class="${authMode==='signup'?'active':''}" data-mode="signup"><span class="auth-tab-icon">＋</span>Créer un compte</button>
      </div>
      <label for="authEmail">E-mail</label>
      <div class="auth-field"><span class="auth-field-icon">✉</span><input id="authEmail" type="email" autocomplete="email" list="knownEmails" placeholder="ton@email.com" value="${esc(remembered[0]||'')}"></div>
      <datalist id="knownEmails">${remembered.map(e=>`<option value="${esc(e)}"></option>`).join('')}</datalist>
      ${remembered.length?`<div class="known-emails">${remembered.map(e=>`<button type="button" data-email="${esc(e)}">${esc(e)}</button>`).join('')}</div>`:''}
      <label for="authPassword">Mot de passe</label>
      <div class="auth-field"><span class="auth-field-icon">◇</span><input id="authPassword" type="password" autocomplete="${authMode==='login'?'current-password':'new-password'}" placeholder="••••••••"><button id="togglePassword" class="auth-eye" type="button" aria-label="Afficher le mot de passe">◉</button></div>
      <button id="authSubmit" class="auth-submit">${authMode==='login'?'Entrer dans la Forge':'Créer mon compte'}</button>
      <div class="auth-divider"><span></span><i>◇</i><span></span></div>
      <div class="auth-security"><span>♢</span>Données sécurisées et synchronisées</div>
      <div class="auth-message">${message||''}</div>
    </section>
    <div class="auth-motto">DISCIPLINA · CONSTANTIA · PROGRESSUS</div>
  </section></main>`;
  box.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>{authMode=b.dataset.mode;showAuth()});
  box.querySelectorAll('[data-email]').forEach(b=>b.onclick=()=>{box.querySelector('#authEmail').value=b.dataset.email;box.querySelector('#authPassword').focus()});
  const pwd=box.querySelector('#authPassword'),eye=box.querySelector('#togglePassword');
  eye.onclick=()=>{const show=pwd.type==='password';pwd.type=show?'text':'password';eye.textContent=show?'◎':'◉';eye.setAttribute('aria-label',show?'Masquer le mot de passe':'Afficher le mot de passe')};
  box.querySelector('#authSubmit').onclick=async()=>{
    const email=box.querySelector('#authEmail').value.trim(),password=pwd.value;
    if(!email||!password){showAuth('Renseigne ton e-mail et ton mot de passe.');return}
    try{
      if(authMode==='login'){await login(email,password);hideAuth();await boot()}
      else{
        const s=await signup(email,password);
        if(s?.access_token){hideAuth();await boot()}
        else showAuth('Compte créé. Vérifie ton e-mail si une confirmation est demandée.')
      }
    }catch(e){showAuth(e.message)}
  }
}
function hideAuth(){document.body.classList.remove('auth-locked');document.querySelector('#authOverlay')?.remove()}
function ensureAccountButton(){
  if(!currentUser)return;
  let b=document.querySelector('#accountBtn');
  if(!b){b=document.createElement('button');b.id='accountBtn';b.className='account-btn';b.onclick=logout;document.body.appendChild(b)}
  const raw=(currentUser.email||'Compte').split('@')[0];
  const accountLabel=/^nicouleau[._-]?valentin$/i.test(raw)||/^valentin[._-]?nicouleau$/i.test(raw)?'Valentin':raw.split(/[._-]/).filter(Boolean).map(x=>x[0]?.toUpperCase()||'').slice(0,2).join('')||'VN';
  b.innerHTML=`<span>${esc(accountLabel)}</span><small>Déconnexion</small>`
}
function cloud(t,c=''){let e=document.querySelector('#cloud');e.textContent='● CLOUD · '+t;e.className='cloud '+c}
async function load(render=true){try{
  let[a,b,c]=await Promise.all([
    req(`/forgelab_state?select=*&id=eq.main&user_id=eq.${encodeURIComponent(uid())}`),
    req(`/forgelab_priorities?select=*&user_id=eq.${encodeURIComponent(uid())}&order=id.asc`),
    req(`/forgelab_series?select=*&block_key=eq.main&user_id=eq.${encodeURIComponent(uid())}`)
  ]);

  state.block=a[0]?.active_block||'main';
  const activeFpForState=flActiveProgram();
  state.blockName=activeFpForState?.name||a[0]?.block_name||'Bloc actif';
  state.blockDuration=Math.max(1,Number(activeFpForState?.totalDuration||a[0]?.block_duration||13));
  state.nutritionContext=['deficit','maintenance','surplus'].includes(a[0]?.nutrition_context)?a[0].nutrition_context:'maintenance';
  state.week=Math.min(state.blockDuration,Math.max(1,Number(state.userWeek||a[0]?.active_week||1)));
  state.priorities=b;

  // While a Series field is being edited, keep the local Series values.
  // Cloud data can refresh again as soon as editing has finished.
  const focusedSeries = document.activeElement && document.activeElement.classList?.contains('series-input');
  const hasPendingSeriesWrites = typeof saveState!=='undefined' && Object.values(saveState).some(s=>s && (s.sending || s.wanted!==s.lastSent));
  const editingNow = state.tab==='series' && (focusedSeries || hasPendingSeriesWrites || (typeof editingSeries!=='undefined' && editingSeries.size>0));
  if(!editingNow){
    // Séries est la source de vérité. Le Carnet ne doit jamais recréer
    // automatiquement des volumes dans une semaine.
    state.series=c;
  }

  cloud('SYNCHRONISÉ','ok');

  // Never rebuild the Series DOM while the iOS keyboard is open.
  if(render && !editingNow) draw();
}catch(e){console.error(e);cloud('HORS LIGNE','err')}}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}function rows(m){return state.series.filter(x=>+x.week===+state.week&&x.muscle_key===m)}function total(m){return rows(m).reduce((a,x)=>a+(+x.series||0),0)}function pRange(p){return[+p.target_min,+p.target_max]}
function forgeWeekDotClasses(week){
  const cls=[];
  if(state.week===week)cls.push('active');
  const fp=flActiveProgram(),currentBlock=flActiveCurrentBlock(fp),calendarWeek=flActiveCurrentWeek(fp);
  if(state.tab==='series'&&fp?.blocks?.length){
    if(currentBlock&&week>=Number(currentBlock.from||1)&&week<=Number(currentBlock.to||currentBlock.from||1))cls.push('current-block-week');
    else cls.push('other-block-week');
    if(week===calendarWeek)cls.push('calendar-current-week');
  }
  return cls.join(' ')
}
function weeks(){
  let d=document.querySelector('#weekDots');
  const fp=flActiveProgram(),count=Math.max(1,Math.min(52,Number(fp?.totalDuration||state.blockDuration||1)));
  state.blockDuration=count;
  if(state.week>count)state.week=count;
  d.style.setProperty('--week-count',String(count));
  d.innerHTML=Array.from({length:count},(_,i)=>`<button class="${forgeWeekDotClasses(i+1)}" data-w="${i+1}">${i+1}</button>`).join('');
  d.querySelectorAll('button').forEach(b=>b.onclick=()=>setWeek(+b.dataset.w))
}
async function setWeek(w){state.week=Math.min(state.blockDuration,Math.max(1,w));state.userWeek=state.week;await req(`/forgelab_state?id=eq.main&user_id=eq.${encodeURIComponent(uid())}`,{method:'PATCH',headers:{Prefer:'return=minimal'},body:JSON.stringify({active_week:state.week,updated_at:new Date().toISOString()})});draw()}
function forgeActiveProgramStartDate(){
  const uidKey=currentUser?.id||'guest';
  try{
    const fp=JSON.parse(localStorage.getItem(`forgelabFullProgram:${uidKey}:active`)||'null');
    if(fp?.startDate&&/^\d{4}-\d{2}-\d{2}$/.test(fp.startDate)){const [y,m,d]=fp.startDate.split('-').map(Number);return new Date(y,m-1,d,12,0,0,0)}
  }catch(_){}
  // Compatibilité uniquement pour les anciens programmes qui n'avaient pas encore leur propre date de départ.
  return new Date(2026,7,31,12,0,0,0);
}
function forgeWeekDateRange(week=state.week){
  const start=forgeActiveProgramStartDate();
  start.setDate(start.getDate()+(Math.max(1,+week||1)-1)*7);
  const end=new Date(start);end.setDate(start.getDate()+6);
  const months=['JANV.','FÉVR.','MARS','AVR.','MAI','JUIN','JUIL.','AOÛT','SEPT.','OCT.','NOV.','DÉC.'];
  const left=start.getMonth()===end.getMonth()?String(start.getDate()):`${start.getDate()} ${months[start.getMonth()]}`;
  return `${left} — ${end.getDate()} ${months[end.getMonth()]} ${end.getFullYear()}`;
}
function forgeHeaderProgramContext(){
  const uidKey=currentUser?.id||'guest';
  const isDraft=state.tab==='programming'&&programmingScreen==='editor'&&programmingMode()==='draft';
  const key=isDraft?`forgelabFullProgram:${uidKey}:draft:${selectedDraftId()||'default'}`:`forgelabFullProgram:${uidKey}:active`;
  let fp=null;try{fp=JSON.parse(localStorage.getItem(key)||'null')}catch(_){}
  const programName=(fp?.name||'Programme ForgeLab').trim();
  let blockName=state.blockName||'Bloc actif';
  if(isDraft&&fp?.blocks?.length){
    const selected=fp.blocks.find(b=>b.id===fp.selected)||fp.blocks[0];
    if(selected?.name)blockName=selected.name;
  }else if(fp?.blocks?.length){
    const selected=fp.blocks.find(b=>b.id===fp.selected)||fp.blocks.find(b=>!b.deload)||fp.blocks[0];
    if(selected?.name)blockName=selected.name;
  }
  return {programName,blockName};
}
function draw(){
  ensureAccountButton();
  const wt=document.querySelector('#weekTitle');
  const hc=forgeHeaderProgramContext();
  wt.innerHTML=`<span class="week-number">S${state.week}</span><span class="week-date-range">${esc(forgeWeekDateRange(state.week))}</span><span class="week-program-name">${esc(hc.programName)}</span><span class="week-block-name">${esc(hc.blockName)}</span>`;
  const bt=document.querySelector('#blockTitle');
  if(bt) bt.textContent='';
  weeks();
  const weekDots=document.querySelector('#weekDots');
  if(weekDots){
    const hideWeeks=state.tab==='priorities' || (state.tab==='programming' && programmingScreen==='chooser');
    weekDots.hidden=hideWeeks;
    if(hideWeeks) weekDots.style.setProperty('display','none','important');
    else weekDots.style.removeProperty('display');
  }
  document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('active',b.dataset.tab===state.tab));state.tab==='priorities'?drawPriorities():state.tab==='programming'?drawProgramming():state.tab==='journal'?drawJournal():state.tab==='tracking'?drawTracking():drawSeries()}
function title(t){return`<h2 class="section-title">${t}</h2>`}
function nutritionLabel(){return state.nutritionContext==='deficit'?'Déficit':state.nutritionContext==='surplus'?'Surplus':'Maintien'}

let prioritiesScreen='chooser';
function priorityModeKey(){return `forgelabPriorityMode:${currentUser?.id||'guest'}`}
function priorityMode(){return localStorage.getItem(priorityModeKey())==='draft'?'draft':'active'}
function setPriorityMode(m){localStorage.setItem(priorityModeKey(),m==='draft'?'draft':'active')}
function priorityDraftRegistryKey(){return `forgelabPriorityDraftRegistry:${currentUser?.id||'guest'}`}
function priorityDraftRegistry(){try{return JSON.parse(localStorage.getItem(priorityDraftRegistryKey())||'[]').filter(x=>x&&x.id)}catch(_){return[]}}
function savePriorityDraftRegistry(x){localStorage.setItem(priorityDraftRegistryKey(),JSON.stringify(x))}
function selectedPriorityDraftKey(){return `forgelabPrioritySelectedDraft:${currentUser?.id||'guest'}`}
function selectedPriorityDraftId(){return localStorage.getItem(selectedPriorityDraftKey())||''}
function setSelectedPriorityDraftId(id){if(id)localStorage.setItem(selectedPriorityDraftKey(),id);else localStorage.removeItem(selectedPriorityDraftKey())}
function priorityDraftDataKey(id=selectedPriorityDraftId()){return `forgelabPriorityDraftData:${currentUser?.id||'guest'}:${id}`}
function savePriorityDraftData(){if(priorityMode()!=='draft'||!selectedPriorityDraftId())return;localStorage.setItem(priorityDraftDataKey(),JSON.stringify(state.priorities))}
function loadPriorityDraftData(id){try{return JSON.parse(localStorage.getItem(priorityDraftDataKey(id))||'[]')}catch(_){return []}}
function createPriorityDraft(){const name=(prompt('Nom du brouillon de priorités :','Priorités futur programme')||'').trim();if(!name)return;const id='pd-'+Date.now().toString(36),regs=priorityDraftRegistry();regs.push({id,name});savePriorityDraftRegistry(regs);setSelectedPriorityDraftId(id);localStorage.setItem(priorityDraftDataKey(id),JSON.stringify(state.priorities));const activeDisabled=localStorage.getItem(`forgelabMobileDisabled:${currentUser?.id||'guest'}`);if(activeDisabled)localStorage.setItem(`forgelabMobileDisabled:${currentUser?.id||'guest'}:draft:${id}`,activeDisabled);const activeOrder=localStorage.getItem(`forgelabMobileMuscleOrder:${currentUser?.id||'guest'}`);if(activeOrder)localStorage.setItem(`forgelabMobileMuscleOrder:${currentUser?.id||'guest'}:draft:${id}`,activeOrder);const activeCardio=localStorage.getItem(`forgelabMobileCardio:${currentUser?.id||'guest'}`);if(activeCardio)localStorage.setItem(`forgelabMobileCardio:${currentUser?.id||'guest'}:draft:${id}`,activeCardio);setPriorityMode('draft');state.priorities=loadPriorityDraftData(id);prioritiesScreen='editor';drawPriorities()}
function deletePriorityDraftById(id){if(!id)return;const d=priorityDraftRegistry().find(x=>x.id===id);if(!confirm(`Supprimer le brouillon « ${d?.name||'Priorités'} » ?\n\nLes priorités actives ne seront pas modifiées.`))return;savePriorityDraftRegistry(priorityDraftRegistry().filter(x=>x.id!==id));const uidKey=currentUser?.id||'guest',prefixes=[`forgelabPriorityDraftData:${uidKey}:${id}`,`forgelabMobileDisabled:${uidKey}:draft:${id}`,`forgelabMobileMuscleOrder:${uidKey}:draft:${id}`,`forgelabMobileCardio:${uidKey}:draft:${id}`];for(let i=localStorage.length-1;i>=0;i--){const k=localStorage.key(i);if(k&&prefixes.some(x=>k===x||k.startsWith(x)))localStorage.removeItem(k)}if(selectedPriorityDraftId()===id)setSelectedPriorityDraftId('');prioritiesScreen='chooser';drawPriorities()}
function drawPrioritiesChooser(){const v=document.querySelector('#view'),ds=priorityDraftRegistry();v.innerHTML=title('Priorités')+`<section class="program-choice-screen"><div class="program-choice-intro"><small>ESPACE PRIORITÉS</small><strong>Quelles priorités veux-tu ouvrir ?</strong><span>Prépare les futurs programmes sans modifier tes priorités actives.</span></div><button type="button" class="program-choice-card active" data-priority-active><span class="program-choice-icon">I</span><div><small>PRIORITÉS ACTIVES</small><strong>${esc(state.blockName||'Programme actif')}</strong><span>Priorités actuellement utilisées</span></div><b>›</b></button><div class="program-draft-list">${ds.map((d,i)=>`<div class="draft-choice-row"><button type="button" class="program-choice-card draft" data-priority-draft="${esc(d.id)}"><span class="program-choice-icon">${roman(i+1)}</span><div><small>BROUILLON ${roman(i+1)}</small><strong>${esc(d.name)}</strong><span>Priorités d’un futur programme</span></div><b>›</b></button><button type="button" class="draft-delete-mini" data-priority-delete="${esc(d.id)}" aria-label="Supprimer ${esc(d.name)}">×</button></div>`).join('')}</div><button type="button" class="program-new-draft" data-priority-new>＋ Nouveau brouillon</button></section>`;v.querySelector('[data-priority-active]').onclick=async()=>{setPriorityMode('active');setSelectedPriorityDraftId('');prioritiesScreen='editor';await load(false);drawPriorities()};v.querySelectorAll('[data-priority-draft]').forEach(b=>b.onclick=()=>{setSelectedPriorityDraftId(b.dataset.priorityDraft);setPriorityMode('draft');state.priorities=loadPriorityDraftData(b.dataset.priorityDraft);prioritiesScreen='editor';drawPriorities()});v.querySelectorAll('[data-priority-delete]').forEach(b=>b.onclick=e=>{e.stopPropagation();deletePriorityDraftById(b.dataset.priorityDelete)});v.querySelector('[data-priority-new]').onclick=createPriorityDraft}

function priorityBlockStatus(b,fp){
  const week=Math.max(1,Number(state.week)||1),from=Number(b.from||1),to=Number(b.to||from);
  if(week>=from&&week<=to)return 'EN COURS';
  if(to<week)return 'TERMINÉ';
  return 'EN ATTENTE';
}
function priorityProgramPanelHtml(){
  if(priorityMode()!=='active')return '';
  const fp=priorityActiveProgram(),current=priorityCurrentBlockId(),selected=prioritySelectedBlockId(),week=Math.max(1,Number(state.week)||1);
  return `<section class="priority-program-panel">
    <div class="priority-program-kicker">AFFECTATION DES PRIORITÉS</div>
    <div class="priority-program-title"><div><small>PROGRAMME ACTIF</small><strong>${esc(fp.name||state.blockName||'Programme actif')}</strong><span>S${week} en cours · Priorités indépendantes par bloc</span></div></div>
    <div class="priority-block-list">${(fp.blocks||[]).map((b,i)=>{const st=priorityBlockStatus(b,fp),isSel=b.id===selected,isCurrent=b.id===current,snap=prioritySnapshotForBlock(b.id);return `<button type="button" class="priority-block-row ${isSel?'selected':''} ${isCurrent?'current':''}" data-priority-block="${esc(b.id)}"><div><small>${b.deload?'DELOAD '+Number(b.blockIndex||i+1):'BLOC '+Number(b.blockIndex||i+1)}</small><b>${esc(typeof fl176RangeLabel==='function'?fl176RangeLabel(b):`S${b.from||1}${b.to&&b.to!==b.from?' à S'+b.to:''}`)}</b>${snap.inherited?'<em>Hérité du Bloc 1</em>':''}</div><span>${st}</span><i>⌄</i></button>`}).join('')}</div>
    <p>Chaque bloc possède ses propres P0 / P1 / P2 et ses groupes actifs. Les réglages d’un bloc ne modifient pas les autres blocs.</p>
  </section>`
}
function drawPriorities(){
  if(prioritiesScreen==='chooser'){drawPrioritiesChooser();return}
  let v=document.querySelector('#view'),counts={P0:0,P1:0,P2:0},off=disabledMuscles(),cd=cardioData(),selectedBlock=priorityMode()==='active'?prioritySelectedBlockId():'',currentBlock=priorityCurrentBlockId();
  activePriorities().forEach(p=>counts[p.priority]=(counts[p.priority]||0)+1);
  if(cd.enabled)counts[cd.priority]=(counts[cd.priority]||0)+1;
  const cardioDone=cardioTotalDone(), cardioTarget=cardioTotalTarget(),isCurrent=!selectedBlock||selectedBlock===currentBlock;
  v.innerHTML=title('Priorités')+priorityProgramPanelHtml()+
  `<section class="priority-overview">
    <div class="priority-counts"><span class="pc0">P0 · ${counts.P0}</span><span class="pc1">P1 · ${counts.P1}</span><span class="pc2">P2 · ${counts.P2}</span></div>
    <p>${priorityMode()==='active'?`Affecte les groupes musculaires au bloc sélectionné. Désactive les groupes que tu souhaites sacrifier sur ce bloc.`:'Définis ici uniquement les groupes musculaires à prioriser et leur niveau P0 / P1 / P2.'}</p>
  </section>`+
  orderedPriorities().map(p=>{let t=total(p.muscle_key),disabled=off.has(p.muscle_key);return`<article class="card ${disabled?'disabled-muscle':p.priority.toLowerCase()} priority-card muscle-order-card" data-muscle-order="${esc(p.muscle_key)}">
    <div class="priority-order-tools"><div class="priority-order-buttons"><button type="button" data-prio-up="${esc(p.muscle_key)}" aria-label="Monter ${esc(p.muscle_name)}">↑</button><button type="button" data-prio-down="${esc(p.muscle_key)}" aria-label="Descendre ${esc(p.muscle_name)}">↓</button></div></div>
    <div class="cardhead"><div><div class="muscle">${esc(p.muscle_name)}</div><div class="range">${disabled?'Groupe désactivé pour ce bloc':`Cible · <b>${p.target_min}–${p.target_max}</b> séries / semaine`}</div></div><button class="muscle-toggle ${disabled?'off':'on'}" data-toggle="${esc(p.muscle_key)}" aria-label="${disabled?'Réactiver':'Désactiver'} ${esc(p.muscle_name)}">${disabled?'Réactiver':'Actif'}</button></div>${disabled?'':`<div class="priority-meta"><strong>${isCurrent?`${t} séries cette semaine`:'Configuration du bloc'}</strong></div><div class="prio-buttons">${['P0','P1','P2'].map(x=>`<button data-m="${esc(p.muscle_key)}" data-p="${x}" class="${p.priority===x?'selected':''}">${x}<small>${derivedRange(p.muscle_name,x).join('–')}</small></button>`).join('')}</div>`}</article>`}).join('')+
  `<article class="card ${cd.enabled?cd.priority.toLowerCase():'disabled-muscle'} priority-card cardio-priority-card"><div class="cardhead"><div><div class="muscle">♥ Cardio</div><div class="range">${cd.enabled?`${cd.modalities.length} séance-type · <b>${cardioTarget}</b> séance${cardioTarget>1?'s':''} / semaine`:'Priorité cardio désactivée'}</div></div><button class="muscle-toggle ${cd.enabled?'on':'off'}" data-cardio-toggle>${cd.enabled?'Actif':'Réactiver'}</button></div>${cd.enabled?`<div class="priority-meta"><strong>${cardioDone}/${cardioTarget} séance${cardioTarget>1?'s':''}</strong></div><div class="prio-buttons cardio-prio-buttons">${['P0','P1','P2'].map(x=>`<button data-cardio-priority="${x}" class="${cd.priority===x?'selected':''}">${x}<small>${x==='P0'?'majeure':x==='P1'?'secondaire':'entretien'}</small></button>`).join('')}</div><div class="cardio-modalities"><div class="cardio-modalities-head"><span>SÉANCES CARDIO DU BLOC</span><button type="button" data-cardio-add-modality aria-label="Ajouter une séance-type">＋</button></div>${cd.modalities.map((m,i)=>`<div class="cardio-modality-row cardio-taxonomy-row" data-modality="${esc(m.id)}"><label>Qualité<select data-cardio-quality="${esc(m.id)}">${cardioQualityOptions(m.quality)}</select></label><label>Engine<select data-cardio-engine="${esc(m.id)}">${cardioEngineOptions(m.engine)}</select></label><label>Format<select data-cardio-format="${esc(m.id)}">${cardioFormatOptions(m.format)}</select></label><label>Séances / sem.<div class="stepper"><button type="button" data-cardio-minus="${esc(m.id)}">−</button><strong>${m.target}</strong><button type="button" data-cardio-plus="${esc(m.id)}">+</button></div></label>${cd.modalities.length>1?`<button type="button" class="cardio-modality-delete" data-cardio-delete-modality="${esc(m.id)}" aria-label="Supprimer cette séance-type">×</button>`:''}</div>`).join('')}</div>`:''}</article>`;
  const pback=document.createElement('button');pback.type='button';pback.className='program-back-choice';pback.innerHTML='‹ <span>Priorités</span>';pback.onclick=async()=>{if(priorityMode()==='draft')savePriorityDraftData();else await load(false);prioritiesScreen='chooser';drawPriorities()};const ph=v.querySelector('.section-title');if(ph)ph.insertAdjacentElement('afterend',pback);
  v.querySelectorAll('[data-priority-block]').forEach(b=>b.onclick=()=>{const id=b.dataset.priorityBlock;ensurePriorityBlockSnapshot(id);setPrioritySelectedBlockId(id)});
  v.querySelectorAll('.prio-buttons button[data-m]').forEach(b=>b.onclick=()=>changePriority(b.dataset.m,b.dataset.p));
  v.querySelectorAll('[data-toggle]').forEach(b=>b.onclick=()=>setMuscleEnabled(b.dataset.toggle,off.has(b.dataset.toggle)));
  v.querySelector('[data-cardio-toggle]').onclick=()=>{const d=cardioData();d.enabled=!d.enabled;saveCardio(d);drawPriorities()};
  v.querySelectorAll('[data-cardio-priority]').forEach(b=>b.onclick=()=>{const d=cardioData();d.priority=b.dataset.cardioPriority;saveCardio(d);drawPriorities()});
  if(cd.enabled){
    v.querySelector('[data-cardio-add-modality]').onclick=()=>{const d=cardioData();d.modalities.push({id:cardioModalityId(),quality:CARDIO_QUALITIES[0],engine:CARDIO_ENGINES[0],format:CARDIO_FORMATS[0],target:1});saveCardio(d);drawPriorities()};
    v.querySelectorAll('[data-cardio-quality]').forEach(el=>el.onchange=e=>{const d=cardioData(),m=d.modalities.find(x=>x.id===e.target.dataset.cardioQuality);if(m)m.quality=e.target.value;saveCardio(d);drawPriorities()});
    v.querySelectorAll('[data-cardio-engine]').forEach(el=>el.onchange=e=>{const d=cardioData(),m=d.modalities.find(x=>x.id===e.target.dataset.cardioEngine);if(m)m.engine=e.target.value;saveCardio(d);drawPriorities()});
    v.querySelectorAll('[data-cardio-format]').forEach(el=>el.onchange=e=>{const d=cardioData(),m=d.modalities.find(x=>x.id===e.target.dataset.cardioFormat);if(m)m.format=e.target.value;saveCardio(d);drawPriorities()});
    v.querySelectorAll('[data-cardio-minus]').forEach(b=>b.onclick=()=>{const d=cardioData(),m=d.modalities.find(x=>x.id===b.dataset.cardioMinus);if(m)m.target=Math.max(0,m.target-1);saveCardio(d);drawPriorities()});
    v.querySelectorAll('[data-cardio-plus]').forEach(b=>b.onclick=()=>{const d=cardioData(),m=d.modalities.find(x=>x.id===b.dataset.cardioPlus);if(m)m.target=Math.min(14,m.target+1);saveCardio(d);drawPriorities()});
    v.querySelectorAll('[data-cardio-delete-modality]').forEach(b=>b.onclick=()=>{const d=cardioData();d.modalities=d.modalities.filter(x=>x.id!==b.dataset.cardioDeleteModality);Object.values(d.weeks||{}).forEach(w=>{if(w&&typeof w==='object'&&!Array.isArray(w))delete w[b.dataset.cardioDeleteModality]});saveCardio(d);drawPriorities()});
  }
  wirePriorityReorder(v);
}
function wireMuscleReorder(root){
  if(!root)return;
  const cards=()=>[...root.querySelectorAll('.muscle-order-card[data-muscle-order]')];
  const handles=[...root.querySelectorAll('.muscle-drag-handle')];
  let timer=null,drag=null,pointerId=null,startY=0;

  const clearTimer=()=>{if(timer){clearTimeout(timer);timer=null}};
  const cleanup=()=>{
    clearTimer();
    if(drag)drag.classList.remove('muscle-dragging');
    document.body.classList.remove('muscle-reorder-active');
    drag=null;pointerId=null;
  };
  const begin=(handle,e)=>{
    if(drag)return;
    drag=handle.closest('.muscle-order-card');
    if(!drag)return;
    pointerId=e.pointerId;
    drag.classList.add('muscle-dragging');
    document.body.classList.add('muscle-reorder-active');
    if(navigator.vibrate)try{navigator.vibrate(18)}catch(_){}
  };
  const moveCard=y=>{
    if(!drag)return;
    const others=cards().filter(c=>c!==drag);
    let target=null,after=false,best=Infinity;
    others.forEach(c=>{
      const r=c.getBoundingClientRect(),cy=r.top+r.height/2,dist=Math.abs(y-cy);
      if(dist<best){best=dist;target=c;after=y>cy}
    });
    if(target){
      const r=target.getBoundingClientRect();
      if(best<Math.max(110,r.height*.9)){
        if(after)target.after(drag);else target.before(drag);
      }
    }
    const edge=120;
    if(y<edge)window.scrollBy(0,-14);
    else if(y>innerHeight-edge)window.scrollBy(0,14);
  };

  handles.forEach(handle=>{
    handle.style.touchAction='none';
    handle.oncontextmenu=e=>e.preventDefault();
    handle.addEventListener('pointerdown',e=>{
      if(e.pointerType==='mouse'&&e.button!==0)return;
      clearTimer();pointerId=e.pointerId;startY=e.clientY;
      timer=setTimeout(()=>begin(handle,e),110);
    });
    handle.addEventListener('pointermove',e=>{
      if(pointerId!==e.pointerId)return;
      if(!drag){
        if(Math.abs(e.clientY-startY)>8){clearTimer();begin(handle,e)}
        else return;
      }
      e.preventDefault();
      try{handle.setPointerCapture(e.pointerId)}catch(_){}
      moveCard(e.clientY);
    },{passive:false});
    const finish=e=>{
      if(pointerId!==null&&e.pointerId!==pointerId)return;
      if(drag)saveMuscleOrder(cards().map(c=>c.dataset.muscleOrder).filter(Boolean));
      cleanup();
    };
    handle.addEventListener('pointerup',finish);
    handle.addEventListener('pointercancel',finish);
  });
}
function wirePriorityReorder(root){
  if(!root)return;
  wireMuscleReorder(root);
  const move=(key,dir)=>{
    const priority=effectivePriorities().find(p=>p.muscle_key===key)?.priority;
    if(!priority)return;
    const visible=orderedPriorities().map(p=>p.muscle_key);
    const same=orderedPriorities().filter(p=>p.priority===priority).map(p=>p.muscle_key);
    const from=same.indexOf(key),to=from+dir;
    if(from<0||to<0||to>=same.length)return;
    const a=visible.indexOf(same[from]),b=visible.indexOf(same[to]);
    if(a<0||b<0)return;
    [visible[a],visible[b]]=[visible[b],visible[a]];
    saveMuscleOrder(visible);
    drawPriorities();
  };
  root.querySelectorAll('[data-prio-up]').forEach(b=>b.onclick=e=>{e.stopPropagation();move(b.dataset.prioUp,-1)});
  root.querySelectorAll('[data-prio-down]').forEach(b=>b.onclick=e=>{e.stopPropagation();move(b.dataset.prioDown,1)});
  root.querySelectorAll('.priority-card .muscle-drag-handle').forEach(h=>{
    const snap=()=>setTimeout(()=>{if(state.tab==='priorities'&&prioritiesScreen==='editor')drawPriorities()},0);
    h.addEventListener('pointerup',snap);h.addEventListener('pointercancel',snap);
  });
}

async function changePriority(muscleKey,priority){
  let p=(priorityMode()==='active'?effectivePriorities():state.priorities).find(x=>x.muscle_key===muscleKey);if(!p)return;let[min,max]=derivedRange(p.muscle_name,priority);
  if(priorityMode()==='draft'){p.priority=priority;p.target_min=min;p.target_max=max;savePriorityDraftData();drawPriorities();return}
  const id=priorityContextBlockId();if(id){const snap=ensurePriorityBlockSnapshot(id),target=snap.priorities.find(x=>x.muscle_key===muscleKey);if(target){target.priority=priority;target.target_min=min;target.target_max=max}savePriorityBlockSnapshot(id,snap);drawPriorities();return}
}
let saveTimers={};
let saveState={}; // per-cell serialized cloud writes; latest value always wins

function programStatus(programmed,min,max){
  if(programmed<min)return [`Reste ${Math.max(0,min-programmed)}`,'remaining'];
  if(programmed===max)return ['Maximum atteint','maximum'];
  if(programmed>max)return ['Maximum dépassé','overmax'];
  return ['Minimum atteint','complete'];
}
function programDayMinutes(entries){return Math.round(entries.reduce((s,x)=>s+Number(x.sets||0),0)*2.5)}
function programOptions(selected=''){return activePriorities().map(p=>`<option value="${esc(p.muscle_key)}" ${p.muscle_key===selected?'selected':''}>${esc(p.muscle_name)}</option>`).join('')}
async function generateProgramImage(){
 const meta=programmingMeta(),p=programmingData(),fp=fullProgram();
 const dayCardio=(typeof flCardioDayPlan==='function'?flCardioDayPlan():Object.fromEntries(DAYS.map(d=>[d,[]])));
 const activeDays=DAYS.filter(d=>(p[d]||[]).some(z=>+z.sets>0)||(dayCardio[d]||[]).length);
 if(!activeDays.length){alert('Aucune journée programmée dans ce bloc.');return}
 const selected=(fp.blocks||[]).find(b=>b.id===fp.selected), blockName=selected?.name||meta.name||'Bloc ForgeLab';
 const W=1080,H=1920,S=2,c=document.createElement('canvas');c.width=W*S;c.height=H*S;const g=c.getContext('2d');g.scale(S,S);g.imageSmoothingEnabled=true;g.imageSmoothingQuality='high';
 const load=src=>new Promise((res,rej)=>{const im=new Image();im.onload=()=>res(im);im.onerror=rej;im.src=src});
 const assets={};for(const f of ['auth-laurel-realistic-v1225.png','footer-mountains-man-v1225.png']){try{assets[f]=await load(f)}catch(_){}}
 const gold='#e4bb68',gold2='#f2d38a',white='#f5f1e9',muted='#aaa397',line='rgba(228,187,104,.30)';
 const txt=(t,x,y,size,color=white,weight=700,align='left')=>{g.fillStyle=color;g.font=`${weight} ${size}px Georgia, serif`;g.textAlign=align;g.textBaseline='middle';g.fillText(String(t),x,y)};
 const sans=(t,x,y,size,color=white,weight=600,align='left')=>{g.fillStyle=color;g.font=`${weight} ${size}px Arial, sans-serif`;g.textAlign=align;g.textBaseline='middle';g.fillText(String(t),x,y)};
 const fit=(t,x,y,max,size,color=white,weight=800,align='left',serif=true)=>{let z=size;do{g.font=`${weight} ${z}px ${serif?'Georgia, serif':'Arial, sans-serif'}`;if(g.measureText(String(t)).width<=max)break;z--}while(z>11);(serif?txt:sans)(t,x,y,z,color,weight,align);return z};
 const wrap=(t,x,y,max,size,color=muted,weight=500,lineH=18,maxLines=2)=>{const words=String(t||'').split(/\s+/),lines=[];let cur='';g.font=`${weight} ${size}px Arial, sans-serif`;for(const w of words){const q=cur?cur+' '+w:w;if(g.measureText(q).width<=max)cur=q;else{if(cur)lines.push(cur);cur=w;if(lines.length>=maxLines-1)break}}if(cur&&lines.length<maxLines)lines.push(cur);lines.forEach((l,i)=>sans(l,x,y+i*lineH,size,color,weight));return lines.length};
 // Direction artistique ForgeLab : métal noir, architecture antique et lumière or.
 const bg=g.createLinearGradient(0,0,0,H);bg.addColorStop(0,'#020304');bg.addColorStop(.46,'#0a0b0c');bg.addColorStop(1,'#020202');g.fillStyle=bg;g.fillRect(0,0,W,H);
 // Texture très légère, déterministe : évite l'aplat noir sans gêner la lecture.
 g.save();g.globalAlpha=.055;for(let yy=0;yy<H;yy+=7){const a=((yy*37)%19)/19;g.fillStyle=a>.5?'#d8c69e':'#ffffff';g.fillRect(0,yy,W,1)}g.restore();
 const glow=g.createRadialGradient(W/2,100,10,W/2,100,660);glow.addColorStop(0,'rgba(242,211,138,.24)');glow.addColorStop(.34,'rgba(228,187,104,.08)');glow.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=glow;g.fillRect(0,0,W,590);
 // Colonnes grecques stylisées sur les bords, volontairement très sombres.
 const column=(x,flip=false)=>{g.save();g.globalAlpha=.20;const cw=42,top=20,bottom=H-92;const cg=g.createLinearGradient(x,0,x+(flip?-cw:cw),0);cg.addColorStop(0,'#070707');cg.addColorStop(.45,'#66583e');cg.addColorStop(1,'#050505');g.fillStyle=cg;g.fillRect(flip?x-cw:x,top,cw,bottom-top);g.fillStyle='rgba(228,187,104,.22)';for(let k=0;k<4;k++){const xx=(flip?x-cw:x)+7+k*9;g.fillRect(xx,58,2,bottom-92)}g.fillStyle='#5b4c33';g.fillRect((flip?x-cw:x)-7,20,cw+14,16);g.fillRect((flip?x-cw:x)-4,38,cw+8,9);g.fillRect((flip?x-cw:x)-8,bottom-22,cw+16,18);g.restore()};column(4);column(W-4,true);
 // Header compact pensé pour un seul écran iPhone.
 // Identité : le laurier est désormais clairement AU-DESSUS du nom FORGELAB.
 const laurel=assets['auth-laurel-realistic-v1225.png'];
 if(laurel){g.save();g.globalAlpha=.98;g.shadowColor='rgba(242,211,138,.22)';g.shadowBlur=16;g.drawImage(laurel,W/2-36,10,72,63);g.restore()}
 g.save();g.shadowColor='rgba(228,187,104,.35)';g.shadowBlur=12;txt('FORGELAB',W/2,94,29,gold2,900,'center');g.restore();
 sans('DISCIPLINA · CONSTANTIA · PROGRESSUS',W/2,126,10.5,'rgba(245,241,233,.70)',650,'center');
 // double filet antique : donne un vrai bandeau de titre sans prendre de hauteur.
 g.strokeStyle='rgba(228,187,104,.42)';g.lineWidth=1;g.beginPath();g.moveTo(90,148);g.lineTo(442,148);g.moveTo(638,148);g.lineTo(990,148);g.stroke();
 g.fillStyle=gold2;g.beginPath();g.moveTo(W/2,141);g.lineTo(W/2+9,148);g.lineTo(W/2,155);g.lineTo(W/2-9,148);g.closePath();g.fill();
 g.save();g.shadowColor='rgba(0,0,0,.95)';g.shadowBlur=8;g.shadowOffsetY=3;fit((fp.name||'PROGRAMME FORGELAB').toUpperCase(),W/2,188,W-96,49,gold2,900,'center',true);g.restore();
 let range='';try{range=selected&&typeof fl176RangeLabel==='function'?fl176RangeLabel(selected):''}catch(_){}
 const sub=[blockName.toUpperCase(),range].filter(Boolean).join(' · ');fit(sub,W/2,231,W-120,22,white,800,'center',false);
 const totalSets=activeDays.reduce((a,d)=>a+(p[d]||[]).reduce((s,e)=>s+(+e.sets||0),0),0);
 const fixedCardioCount=activeDays.reduce((n,d)=>n+(dayCardio[d]?.length||0),0);
 sans(`${activeDays.length} JOURS · ${totalSets} SÉRIES${fixedCardioCount?' · '+fixedCardioCount+' CARDIO FIXÉ'+(fixedCardioCount>1?'S':''):''}`,W/2,261,13,gold,800,'center');
 g.strokeStyle='rgba(228,187,104,.68)';g.lineWidth=1;g.beginPath();g.moveTo(72,286);g.lineTo(W-72,286);g.stroke();
 // Grille dynamique 2 colonnes. Le contenu, pas une illustration, est prioritaire.
 // v1.28 : le cardio fixé à la journée apparaît dans sa journée ; la trame libre reste séparée.
 const cardioTpl=(typeof flCardioTemplate==='function'?flCardioTemplate():{items:[]});
 const cardioItems=(cardioTpl.items||[]).filter(t=>(+t.target||0)>0);
 const cardioFrequency=cardioItems.reduce((n,t)=>n+(+t.target||0),0);
 const cardioStripH=cardioItems.length?88:0;
 const cols=activeDays.length===1?1:2,rows=Math.ceil(activeDays.length/cols),margin=30,gap=14,top=302,footerH=112,bottom=footerH+18+(cardioStripH?cardioStripH+10:0);
 const cardW=(W-margin*2-gap*(cols-1))/cols,cardH=(H-top-bottom-gap*(rows-1))/rows;
 activeDays.forEach((day,i)=>{
   const col=i%cols,row=Math.floor(i/cols),x=margin+col*(cardW+gap),y=top+row*(cardH+gap),entries=(p[day]||[]).filter(z=>+z.sets>0),fixedCardio=(dayCardio[day]||[]),daySets=entries.reduce((a,e)=>a+(+e.sets||0),0);
   const rr=(xx,yy,ww,hh,r)=>{g.beginPath();g.roundRect(xx,yy,ww,hh,r)};g.save();g.shadowColor='rgba(0,0,0,.65)';g.shadowBlur=18;g.shadowOffsetY=7;rr(x,y,cardW,cardH,12);const cg=g.createLinearGradient(x,y,x+cardW,y+cardH);cg.addColorStop(0,'rgba(17,18,18,.985)');cg.addColorStop(.55,'rgba(5,7,8,.985)');cg.addColorStop(1,'rgba(13,11,8,.985)');g.fillStyle=cg;g.fill();g.restore();rr(x+.8,y+.8,cardW-1.6,cardH-1.6,11);g.strokeStyle='rgba(228,187,104,.82)';g.lineWidth=1.5;g.stroke();g.strokeStyle='rgba(242,211,138,.16)';g.lineWidth=.7;rr(x+5,y+5,cardW-10,cardH-10,8);g.stroke();
   const headH=Math.max(46,Math.min(58,cardH*.13)),hg=g.createLinearGradient(x,y,x+cardW,y);hg.addColorStop(0,'rgba(228,187,104,.13)');hg.addColorStop(.55,'rgba(228,187,104,.035)');hg.addColorStop(1,'rgba(228,187,104,.09)');g.fillStyle=hg;rr(x+1,y+1,cardW-2,headH,9);g.fill();g.fillStyle=gold;g.fillRect(x+13,y+headH-1,cardW-26,1);
   // petits angles or, signature graphique ForgeLab
   g.strokeStyle='rgba(242,211,138,.75)';g.lineWidth=2;[[x+8,y+8,1,1],[x+cardW-8,y+8,-1,1],[x+8,y+cardH-8,1,-1],[x+cardW-8,y+cardH-8,-1,-1]].forEach(([cx,cy,sx,sy])=>{g.beginPath();g.moveTo(cx,cy+sy*11);g.lineTo(cx,cy);g.lineTo(cx+sx*11,cy);g.stroke()});
   g.save();g.shadowColor='rgba(228,187,104,.24)';g.shadowBlur=8;txt(day.toUpperCase(),x+18,y+headH/2,Math.min(25,headH*.46),gold2,900);g.restore();sans(`${daySets} SÉRIES`,x+cardW-16,y+headH/2,12,gold,850,'right');
   const cardioH=fixedCardio.length?44:0,usable=cardH-headH-12-cardioH, per=Math.max(1,entries.length), rowH=usable/per;
   entries.forEach((e,j)=>{
     const ry=y+headH+j*rowH;if(j){g.strokeStyle=line;g.beginPath();g.moveTo(x+16,ry);g.lineTo(x+cardW-16,ry);g.stroke()}
     const cy=ry+Math.min(22,rowH*.28);fit((e.muscle_name||'GROUPE').toUpperCase(),x+18,cy,cardW-92,Math.min(16,Math.max(12,rowH*.18)),white,800,'left',false);sans(String(+e.sets||0),x+cardW-18,cy,Math.min(20,Math.max(14,rowH*.22)),gold2,900,'right');
     const ex=(e.exercises||[]).filter(q=>q.name&&+q.sets>0);
     const exerciseText=ex.length?ex.map(q=>q.name).join(' · '):'Exercice non renseigné';
     const exSize=Math.min(13,Math.max(10,rowH*.145)),exY=ry+Math.min(46,rowH*.58);wrap(exerciseText,x+18,exY,cardW-36,exSize,ex.length?muted:'#6f6b64',500,Math.max(14,exSize+3),rowH>66?2:1);
   });
   if(fixedCardio.length){
     const cy=y+cardH-27;g.strokeStyle=line;g.beginPath();g.moveTo(x+16,cy-18);g.lineTo(x+cardW-16,cy-18);g.stroke();
     const desc=fixedCardio.map(z=>{const t=typeof flDayCardioType==='function'?flDayCardioType(z.type):null;return `${t?.label||'Cardio'} · ${z.engine||''}${+z.duration?' · '+z.duration+' min':''}`}).join('   |   ');
     fit(desc,x+18,cy,cardW-36,12,gold2,800,'left',false);
   }
 });
 // Carte cardio libre : thème + fréquence du bloc uniquement. Le détail reste programmé semaine par semaine dans ForgeLab.
 if(cardioItems.length){
   const x=margin,y=H-footerH-cardioStripH-10,w=W-margin*2,h=cardioStripH;
   g.save();g.shadowColor='rgba(0,0,0,.65)';g.shadowBlur=14;g.shadowOffsetY=5;g.beginPath();g.roundRect(x,y,w,h,12);const cg=g.createLinearGradient(x,y,x+w,y);cg.addColorStop(0,'rgba(18,19,19,.99)');cg.addColorStop(.55,'rgba(7,8,9,.99)');cg.addColorStop(1,'rgba(16,13,8,.99)');g.fillStyle=cg;g.fill();g.restore();
   g.beginPath();g.roundRect(x+.8,y+.8,w-1.6,h-1.6,11);g.strokeStyle='rgba(228,187,104,.82)';g.lineWidth=1.5;g.stroke();
   sans('CARDIO LIBRE · TRAME DU BLOC',x+20,y+24,13,gold,850);
   const themes=cardioItems.map(t=>String(t.quality||'Cardio').replace(/^\S+\s*/, '')).join(' · ');
   fit(themes.toUpperCase(),x+20,y+54,w-210,20,white,850,'left',false);
   sans(`${cardioFrequency} SÉANCE${cardioFrequency>1?'S':''} / SEMAINE`,x+w-20,y+54,13,gold2,850,'right');
 }
 // Signature ForgeLab très basse pour préserver la lisibilité des journées.
 const footer=assets['footer-mountains-man-v1225.png'];if(footer){g.save();g.globalAlpha=.66;const fw=W,fh=150,sy=Math.max(0,footer.height-footer.width*(fh/fw));g.drawImage(footer,0,sy,footer.width,footer.height-sy,0,H-footerH,fw,footerH);g.restore()}
 const fade=g.createLinearGradient(0,H-footerH-30,0,H);fade.addColorStop(0,'rgba(3,4,5,0)');fade.addColorStop(.45,'rgba(3,4,5,.45)');fade.addColorStop(1,'rgba(3,4,5,.90)');g.fillStyle=fade;g.fillRect(0,H-footerH-30,W,footerH+30);
 g.strokeStyle='rgba(228,187,104,.72)';g.beginPath();g.moveTo(285,H-39);g.lineTo(410,H-39);g.moveTo(670,H-39);g.lineTo(795,H-39);g.stroke();txt('DAILY WINS.',W/2,H-39,18,gold2,900,'center');
 const blob=await new Promise(resolve=>c.toBlob(resolve,'image/png',1));if(!blob){alert('Impossible de générer l’image sur cet appareil.');return}const safe=String(blockName||'bloc').replace(/[^a-z0-9]+/gi,'_'),file=new File([blob],`ForgeLab_${safe}.png`,{type:'image/png'});try{if(navigator.share&&navigator.canShare&&navigator.canShare({files:[file]})){await navigator.share({files:[file],title:`ForgeLab · ${blockName}`});return}}catch(err){if(err&&err.name==='AbortError')return}const url=URL.createObjectURL(blob),w=window.open(url,'_blank');if(w){setTimeout(()=>URL.revokeObjectURL(url),120000);return}const a=document.createElement('a');a.href=url;a.download=file.name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
}
function flPdfDate(d){if(!(d instanceof Date)||isNaN(d))return'—';const p=n=>String(n).padStart(2,'0');return `${p(d.getDate())}/${p(d.getMonth()+1)}/${d.getFullYear()}`}
function flActiveProgram(){try{return JSON.parse(localStorage.getItem(`forgelabFullProgram:${currentUser?.id||'guest'}:active`)||'null')}catch(_){return null}}
function flBlockPeriod(block,fp=flActiveProgram()){
  if(!block)return null;
  const from=Math.max(1,+block.from||1),to=Math.max(from,+block.to||from);
  // Programmes récents : la date de S1 reste la référence normale.
  if(fp?.startDate&&/^\d{4}-\d{2}-\d{2}$/.test(fp.startDate)){
    const [y,m,d]=fp.startDate.split('-').map(Number),start=new Date(y,m-1,d,12);start.setDate(start.getDate()+(from-1)*7);
    const end=new Date(y,m-1,d,12);end.setDate(end.getDate()+to*7-1);
    return {start,end,from,to,label:`${flPdfDate(start)} – ${flPdfDate(end)}`};
  }
  // Compatibilité exceptionnelle pour l'ancien programme actif.
  // IMPORTANT : ces anciens programmes n'avaient pas de structure de blocs fiable.
  // La migration pouvait donc transformer le bloc historique en simple S1.
  // Pour le bilan, on reconstruit la plage de semaines depuis la date choisie
  // jusqu'à la semaine réellement atteinte aujourd'hui, sans modifier les données.
  if(block.exportStartDate&&/^\d{4}-\d{2}-\d{2}$/.test(block.exportStartDate)){
    const [y,m,d]=block.exportStartDate.split('-').map(Number),start=new Date(y,m-1,d,12);
    const now=new Date(),today=new Date(now.getFullYear(),now.getMonth(),now.getDate(),12);
    const elapsed=Math.max(0,Math.floor((today-start)/86400000));
    const lastWeek=Math.max(1,Math.floor(elapsed/7)+1);
    // Ne jamais se limiter au from/to artificiel du bloc migré. Les séries historiques
    // sont stockées avec leurs vrais numéros de semaine (S1, S2, S3...).
    const availableWeeks=(state.series||[]).map(r=>+r.week||0).filter(w=>w>0);
    const maxDataWeek=availableWeeks.length?Math.max(...availableWeeks):1;
    const exportTo=Math.max(lastWeek,maxDataWeek);
    const end=new Date(start);end.setDate(end.getDate()+exportTo*7-1);
    return {start,end,from:1,to:exportTo,label:`${flPdfDate(start)} – ${flPdfDate(end)}`,legacyOverride:true};
  }
  return null;
}
function flActiveBlockNotes(blockId){return localStorage.getItem(`forgelabBlockNotes:${currentUser?.id||'guest'}:active:${blockId}`)||''}
function exportBlockPdf(blockId){
  const fp=flActiveProgram();if(!fp){alert('Aucun programme actif.');return}
  const block=fp.blocks?.find(b=>b.id===blockId)||fp.blocks?.find(b=>!b.deload);if(!block){alert('Bloc introuvable.');return}
  const period=flBlockPeriod(block,fp);if(!period){alert('Renseigne la date de début de ce bloc dans le pavé d’export exceptionnel.');return}
  const priorities=activePriorities(), muscleNames=new Map((state.priorities||[]).map(x=>[x.muscle_key,x.muscle_name||x.muscle_key]));
  const allRows=(state.series||[]).filter(r=>+r.week>=period.from&&+r.week<=period.to&&(+r.series||0)>0);
  const cardio=cardioData(), ymd=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  const allCardioSessions=(cardio.sessions||[]).filter(x=>x&&!x.benchmark&&x.date&&x.date>=ymd(period.start)&&x.date<=ymd(period.end));
  const weekDates=wk=>{const a=new Date(period.start);a.setDate(a.getDate()+(wk-period.from)*7);const b=new Date(a);b.setDate(b.getDate()+6);return {a,b,label:`${flPdfDate(a)} – ${flPdfDate(b)}`}};
  const weekData=[];
  for(let wk=period.from;wk<=period.to;wk++){
    const wr=allRows.filter(r=>+r.week===wk), byKey={};wr.forEach(r=>{const k=r.muscle_key||r.muscle_name||'Groupe';byKey[k]=(byKey[k]||0)+(+r.series||0)});
    const min=priorities.reduce((a,p)=>a+(+p.target_min||0),0), done=priorities.reduce((a,p)=>a+(byKey[p.muscle_key]||0),0);
    const under=priorities.filter(p=>(byKey[p.muscle_key]||0)<(+p.target_min||0)), over=priorities.filter(p=>(byKey[p.muscle_key]||0)>(+p.target_max||0));
    const reached=priorities.length-under.length, remain=priorities.reduce((a,p)=>a+Math.max(0,(+p.target_min||0)-(byKey[p.muscle_key]||0)),0), pct=min?Math.round(done/min*100):0;
    const sessions=trackingMuscuWeekStats(wk).count, wd=weekDates(wk);
    const cw=cardio.weeks?.[String(wk)]||{}, cardioDone=Object.values(cw).reduce((a,days)=>a+Object.values(days||{}).reduce((x,n)=>x+(+n||0),0),0);
    const cardioTarget=(cardio.modalities||[]).reduce((a,m)=>a+(+m.target||0),0);
    const runs=allCardioSessions.filter(x=>x.date>=ymd(wd.a)&&x.date<=ymd(wd.b));
    let trend;if(under.length===0&&over.length===0)trend=`Semaine complète : ${pct}% du volume minimum réalisé et ${reached}/${priorities.length} objectifs musculaires atteints.`;
    else if(under.length===0)trend=`Semaine complète : ${reached}/${priorities.length} objectifs musculaires atteints.${over.length?` ${over.length} groupe${over.length>1?'s':''} avec volume dépassé (${over.map(p=>p.muscle_name||p.muscle_key).join(', ')}).`:''}`;
    else if(pct>=90)trend=`Semaine presque complète : ${pct}% du volume minimum réalisé. Il reste ${under.length} groupe${under.length>1?'s':''} à compléter.`;
    else if(pct>=70)trend=`Bonne progression : ${pct}% du volume minimum réalisé. ${under.length} groupe${under.length>1?'s restent':' reste'} à compléter.`;
    else trend=`Semaine en cours : ${pct}% du volume minimum réalisé. Priorité aux ${under.length} groupe${under.length>1?'s':''} encore sous leur cible.`;
    weekData.push({wk,wr,byKey,min,done,under,over,reached,remain,pct,sessions,wd,cardioDone,cardioTarget,runs,trend});
  }
  const performed={};allRows.forEach(r=>{const name=r.muscle_name||muscleNames.get(r.muscle_key)||r.muscle_key||'Groupe';performed[name]=(performed[name]||0)+(+r.series||0)});
  const muscleTotal=Object.values(performed).reduce((a,n)=>a+n,0),muscleSessions=new Set(allRows.map(r=>`${r.week}:${r.day}`).filter(Boolean)).size;
  const cardioTotal=weekData.reduce((a,w)=>a+w.cardioDone,0), cardioCount=Math.max(cardioTotal,allCardioSessions.length), notes=flActiveBlockNotes(block.id), maxMuscle=Math.max(1,...Object.values(performed));
  const muscleBars=Object.entries(performed).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`<div class="muscle-bar"><span>${esc(k)}</span><div><i style="width:${Math.max(4,Math.round(v/maxMuscle*100))}%"></i></div><b>${v}</b></div>`).join('');
  const weeklyCards=weekData.map(w=>{const status=w.under.length?'À compléter':w.over.length?'Volume dépassé':'Validée';const cls=w.under.length?'warn':w.over.length?'high':'ok';const detail=priorities.map(p=>{const n=w.byKey[p.muscle_key]||0,mi=+p.target_min||0,ma=+p.target_max||0,c=n<mi?'low':n>ma?'high':'ok';return `<div class="mini-muscle ${c}"><span>${esc(p.muscle_name||p.muscle_key)}</span><b>${n}</b><small>${mi}–${ma}</small></div>`}).join('');const run=w.runs[0];return `<section class="week-card"><div class="week-head"><div><small>BILAN HEBDOMADAIRE</small><h2>S${w.wk}</h2><span>${w.wd.label}</span></div><em class="${cls}">${status}</em></div><div class="week-kpis"><div><b>${w.done}</b><span>/ ${w.min} séries</span></div><div><b>${w.pct}%</b><span>du minimum</span></div><div><b>${w.sessions}</b><span>séance${w.sessions>1?'s':''} muscu</span></div><div><b>${w.reached}</b><span>/ ${priorities.length} groupes OK</span></div></div><div class="week-progress"><i style="width:${Math.min(100,w.pct)}%"></i></div><div class="status-row"><span class="ok">${w.reached} travaillés</span><span class="warn">${w.under.length} à compléter</span><span class="high">${w.over.length} dépassés</span><span>${w.remain} séries restantes</span></div><div class="trend"><small>TENDANCE DE LA SEMAINE</small><p>${esc(w.trend)}</p></div><details open><summary>Détail musculaire</summary><div class="mini-grid">${detail}</div></details><div class="cardio-week"><strong>CARDIO</strong><span>${w.cardioDone} / ${w.cardioTarget||0} séance${w.cardioDone>1?'s':''}</span>${run?`<small>${run.duration||'—'} min · ${esc(run.pace||'—')}/km · ${run.avgHr||'—'} bpm · RPE ${run.rpe||'—'}</small>`:'<small>Aucune donnée détaillée enregistrée</small>'}</div></section>`}).join('');
  const pdfLaurelUrl='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAATAAAAEJCAYAAAATjnuWAAEAAElEQVR4nHS9d9xlN3E3/pV0zrnl6dubt9q767o27hU3TDe9t5BgSF4wIaGEJA7J+wskJEAILSGYhARD6NVUg8G9d3u93vX2+vR6y2mSfn9II+nc9Xv9WT+3nKMjzYxmvjMajViSJAAAMAYGgDEGDQ1oBq01uPkSWmvzm9ZgTENrBsYYAA2AAYD5zVxuvtUMYBpKa4ABDMxeaX9nDNAa2nQA0NrdCw3XPv3un+caOP759jk6+J6u19BBDwDNbH/tpYwJ1y+tJBjniATD3HwLm1b3v+vP33X1jb+5azd+8rvtrFZLLK2CcWiAmw5Aa/NPcECDAVr5cdr/M0ZjgqGRo6EGGINUfjy9L+IF7LMBbcfPg9/pZ+2eU3kRTxFeQ39t+wEBNfEIAOPc0hSAVuaZnFOzbryMM3CYvgSctAymbtjnOr4EsqABxjgYAKUlNADOeI88MmitKnx3dFX2me5Znia9tPTP83KmlO2nNs8lAefc0kfByTjTtl0GJ2n0HMaod2FHYOnN0emkeN7p6555+0vP3vL9n92Pu546zBYPD6EsJUqlwIRwNFFK23a1k2vPv+pcDfln+lzlv2kQAAdoLvm2lB0DC6YSq8iKGx+4pT0RmJmmtQJzNIXTJVoDnMPNG9Bc0BqWZeaRjOa2ct8RDRlj4NwKHaMfjaSBMfMAGq9jOgON1nWE3rPgO2YbJcFwekf7DuhAedFk9L+zoK1A6WhmCUq/V5WX1ixQFJ7AGjRZNTSDFyVtJ4zVZMT4OEnAGDA338KLLt2ov/m1d9746mtPhi5SaK0hBHf9Z1ZbEY1CIXGTnpFi145W1G8A8Hxg0HbCc+avYW68XoETw0mAOLi7htS3G792es60Z+lK13uB7xV8uO/dwByfiIcautI/Q2MAgLKKi3khps+GFjAK2/EJVqiDsTo+MpK84/pHijvkg+0qwHQwzmDSMeZoQLLllJcOhgs/fxkzfDE89MbK8C24xinT0Nh4e0OTneQS0ECR48oXnon//NIf4vIzlump2TnEUYQ4igODXlXGGl7pevYEPNREE/+7k1G6LlQkbsREbe6+0zqkFckxt8rL36uVpzPNXZLJkC/uu5CXltqsRw5YQLtQl/BwMqlAaEIEQ+/D7wg9HK/p/SR1CAE8mGyEw0KtTsIUKCsWcApOHYX0NW0yVIhHE8XdWrGq1GSASNw4uLOS9VqCoijRbnXwvj+4WP/bP7wK529bjv27DmDfoYlbwnECxvp6cfQ0FCLsB3eWqcKuHhpUvqhMfD8ZjqNBOHy63nK6d9ykpBUhoOCRVUNB6I8+E0uC9ph9hlMsXi4IBTEGaBUo0KA9NymPGzddFPTH8f746xhjDsFW0ZQ1Dp5YjnCebjqQ5YCm7jGOq5XfQvk/To4JqVV7CaW8zAAMSpvJTp/HZ1oX7Nt/FJvPW4UvffyVePVlJ+rJ2VmIiCNJBAhFUb+cYg+H5xSW7zspaj/3/GwOBm0Umn/rFGQoY9QWI7cl+J6MHylLZ/iYl6yqJ+D5obWGUqoqCowmt9Eh4S3mOm0UWGjtvAUKlJl9zxmvfE+/2TfQTngded1v3oLo4PsA0pJV4h559D7DuR6uz/DtBySpKFQHHqrf6eptri+1eoxWuwOmMnz8L16pP/kXL8fieoH82DHMTrbQSdXNxKjef0rRyLRlsJ1AnNtOMMcgFYwhREGCM0QRRxILJHECwYx1U0FfHZLs5ZF5mrvu+EntBctPcO9CIviOJoeGBmfMusZVBedcCWfEbH+0rlyvHerxfSXF4XlLk82P0TIz4B2hgOpEIERJiJyFvHXj9S4dod1eJAdUFW3EBeq1BPUkQS2JEUc8UBLeUDtaO1qYecAZ924lya3S9NahHqVMnybn0tmjB8ehjhzDprWD+OLfvRLXveJ0PTMzA6UU6knkFV4FiVTliGjlee/l381jq6GqtPIG73h+ObGw13gsHFKxwlNLLAZm/cVqu5UXgRFNYSirTDk7bk4zEO00IhcrAatMdG61XyhU+rgBPsfAAWOByGJpA+8VCZdtS+nA8oGe490Yp6wQPib0vQNUQQTQBuiElsDRnSwsKTSl3ASjyVxPapiemcfa5YMrbvjQ6479wStPQzl3DFOT8zjhhBHMtTLMd7Ivggkio0UJVbcx8GbAWXWy0bWEZrkQiCKByAQEIKVEXkp0ujlkmUNEMZIk7kG5Rih0MMF5YD29kmIOM/daURDNEaDE8DptFA+5pXS9trIR0tdNBPQIMEx4BfYZxxlJeOEkOaj2IXDRuVEeSlUFOVS+5A4yzgHLX4c36BrH8xDd2T5wFrQq0E1TlLIEwBDHEWq1BEkcIYoEtNYopUJZKpRSenlkXnYZyJX2SEQrFRDb9k1piChCmmbYPzoNXjLMTrUwPDiAf/7oy7BqWb/+3E33szRuoFaL0e3kMOiXOm95ZYgFH48iEfco0c/f5zACjAU09fMilAlnlCq6AJXXcbIWKnH3ezV8Qe1TeKEKeDzBAtEAAESA0XK6gpICjR38jyx/gIJdhyjw6mAoESFUJrrSoP9j5SYU8F5hJ8EMlZgTcHs9BYu93+NBg+9Pj3Wx39dqNUzPzOHkdUs//8mPv/P6a6/ejPTIXsy3Oqj3NcEQYXy8g/l2ARYlti3ew2zAKVcwMyEqk9WMgTODypQCsrJEq50CqnBsioTAikXNgaWLl/5mcqb7otHphdk4igOLT8rYs7ZXefgfCNkQ7WjCM3DO/T09ygEAmGbOsKgeWjvBBCkGXrWUgRLT4ff2vUNBjpVExBDo2Xs475EH304oL84IKm37w6C0AlgY/ICjgxU6P0U0wJkGwFHkBRaPNPkZm5fIvNPGgSNz107Md2+ebpEC4oiT2Ci1WgytFLTWkFJBMztHwPx7DWgoPyZUeSUigSIHDhyaQqurUe8fxMTEDJYtG8Jf/p8rMTjQ0J+88XY239Hoq8XoZhkohkhCrwFwzWxMi4bEwoFX+K2dQvLGroIHAiXmDbYHNcQzr390RQZCGakaOP8gFj6oItc+pgggnNIu5gwAUYB8/Q0h8UHhyWq8y8kRWbSK8vIISWnfSRI+WtgJn+mCfa7ZIGBIA638DYSe7g8YR6OuaHgErhjzJKolNczMzOO0zasv/szH/+D6ay7biHT0ILpZDh7XwBmDKhhGp7pIS42kzgNrSySzWMPxWrtfGOeIOIfgEYpSYqHVhVIlACCOI2xdt+TMk09a+eiGdUtwwvIhLBuOsGbFEKJGHz7y99+fOTw2w+q1BFKSRSLk5IUqFExo67Y6S4IK/UlgSbjI7aPvFEyMwyBIv9LqqBhYhedaIfX8AxizSCTo73FK1jHL8pdpaIUAHVo5oNVKN1ZW6Xd1rgYThOQsGINS1C+vzGguRYKhUxbYsmGl/JfP/jlqbAFjB8d+OjXZwoGj0zh0ZAq7nx3Hjr0TH991dPpvCFXFSYJGvQYhGMpSQkpCrIDWCmZlNpR0zw/BDaofm2hhYraL1cvqaC0kmJ7pYGBA4k/efhFqtVh//N9+PzzZkXPNWoIszewcMmNVRAPdM16rqDSs5wM/VaqAIOiSx8OwEdNw0lt6VY2Su94pIQ03YicrVrYcWwMlyGBd5Cr68ohd2W56YBARYqCZF1onM0e1ExwnM6pqjf0DSXkRJRgA5ZBPaLGJXuhpxxPDCDwF9oKxeqtJ4wruC4FJ6Peb21n1OgYkUYzZuQVsWb/09M/843V3XXPReswfPYC8LBAlDahuF0k9QburMDbTBQDr7qnKs0CG2UqPhonLxEmCSHDkRYmZmXlAK6xZvmj49FPXzpyxeTW2bV2BDWuXYPXKAQwlHLFOwVgXSZLgltt3Y+e+cVav14Klczu2HiXkLCeCtIhAuXiUcrwScZbYGi4e0hBEb4AI3st3srqVKUlWtMIf+GsDher5zJzRsT+48Zjn+liP7w2c++efaSecC3Uxt3II13dN3n8P0gCUUmjUa9ixd5xNHjisL3/xNpy0vA6U5uJOXmJ6NsWRsbkbdu8du+HxJw/j4ScO4tGdo2xmfgHgHIP9TSRJhKIooWQBaAltES0ChUk0Nu6rwNRM55aJ6fY169f0AxAQUYTZmRTNAeCdrz4HkZazN/zb7Wy6naGvEaHIc89D4r2y7jDJIeNuzBWeB3LhdELAO+9Chug6XF2tXg+nR0Ba28igkzuSHwN4nH11v5NMW1nnhne97qdfDeWIOLMwm8Q9UBbhiocHO8GSrNOq4SIAnBWoEsgjpQAQ9Wj1qjKk9949I2Fjtv1AILSdxDxYGg8RUo9yAzTiKEa708WaFcOLPvUP73zimktOwPyRg8hLDYgEeVlAMiCuxZicncXEbApAgEcCWgKMKYO8yDWDT6kRIkIUxcizHDOdDgb7GrjqkpP1VZechrNPWY2NJwxhcZ9AI9ZQqkRRtNCZ6aDdbSOKgemZEp/44i2YnMvQN9AHVcqANl4x+wkRvrySYYFkOv5qR0hnHT3B7R9NVtMoemcPA75W+As4FA7qoVYBEoNF5PRcEkpyJe19ZIFJIpyb0mMsA8UYonJCZNbW21hr5RGVe54LQCqlEMcCE1Mt/NXf/zd+sOHDWFQv0E0XAK0guMKygRhrFg/i/JNH8Oqrt+DIRIad+2f0A4/sxW/u2oEHtx9ipVSoNxqII4Gy0ICdZwR1aPSa3CcRYbadvXVsuj3OkhqYiKHBIOIY7fkOdL2LN197Moqi0H/773ex+UwhERxlKS0Z/Zj8WMP0DkMXFdDIm/bqnAP8XOv1uphmwcIMAh4HsU7tjam5x/4vMBSV2Br8W+bkjdkZrip8J4AFABEYwMGhKPHQwXEKTJMoILDEtjOae4VnH28GwivoKAza+UUDe4dDa5aUymjeXvki5en6xIIJE1hsQpCBt2QZytwqoYaCiBLkRYG+Wox/+Os3T73s8i1YOHYERVEiSmIUeQGtAckYBI8xPZtiar4LsAiccUiUTpGSEtFKg3NjNbOiQKvdwZLhQbzqRVfoF129DeedvASrlzahVYqiu4Buq42ZdhdlWUJLBaUVopghivpxx4O7cd/OWdbsa0IqiV7k4zjJAChSNtUUgnDBA4BNPrVBf+7b0kFzzrqSBXeohay5TU6EXZnUAYRhNp2B2nf89f0xMSqLyoVHgwxhn7lXln6+V16hMg3bJ+RLffVGK1Tqwa0BRPQoFShLhcGhJu59cpT97Gd36T+87oWoz+TotlpI0wytmXkwDoiIo97XwLoVfThx7RpcfdFavPHas/D7+/boH/3qMfzuvl0sBVCv1cCFQKlKAw6YnyvWa4aIBRba6cTkdAtABCYSI61lAcE52q02VKnx5hdvQauV6v/71ftZgQicC4c6mRtHMG8oyTcw6n7Bw8+yKpmJb36K+cUST7dw+oV0dF6S1aYVDB/wlXRRAJXcPUxrm+4TKBlWjY1FWtE88LGO0KiHS/HhY45bzbAdoqAp6Httrbx9kFOBFe1LxFIu9UcriwCp727UAYmdDx6iCG/x3fdkmc2IIDiHVgpZVuBvb3ijfsPLnofWxFEUhUScxCjLAlASXPjUhtGpBUzNpZ9mkQBjhLhszg80tFYQIgYY0G63IRjH21/1fP3G116Gs05ZgWVDHHlrBgszo2h3OpCygJIlZFFAKwXOOQQHms0aRie6+N9fbk8hBLjgUKUKdLxHRs4wOIVNY6QYVhDf6EG1x60iBgi51/gocikCO+2Rt2en1saoMDCXfa162nfIz8ocWTNanCMrrpRBJkyT0jx+BTxE6mQgSRzg0BdzSDC41MlTdVGAyEttCdTrNXz6a7fc8Pwrz/r45tVNlHkKEcdgvAslC0hVotPqotvOEQmBerOJk9f3YfPa5+Hqi0/Eb+/aob/+gwdw/1NHGJhArR5BSRPMF8zkDDGLTCIRoZt2MD3bAXSEOE6gtUSZmbFwLtBe6KJRV3jry0/FselUf/57j7MkiaueDo2BQAChrdCQeULZ67UTE2+TPG04Z263QXX1MVwZrLqFzBo1TUFvANruzuGEzlzfQjTHfKDeygAQgBv4PDtOsJsUidfK8AoteEDo73pr7+nBjLQF1ju04qHW1sf9Y+TS0CO0DzAHkucgqtYG7tNEChdcw3tpPvoVM4FuN8U73nC5/pO3X4aiPY6s20EcCygpocoSJpCsITiDAHDk2BxmFtK/iCKbQuGSFQ1TkzhGludIu11cfu4p+qZ/+4D+1N+9Di++eCWGojlMHjmA8YlJpFkOBg0lS+RpF0WeQckSSpaIIqCQEX522048vnu60eyrQ2nDJA6zqsZ7AlReWXt0GsYgQ5RVQW+O7Z6vWin4lU57JfNKJUR2zCEIFsSfzOTgggcrhyQDcAJqvvOx0l6E5GWht98erfkvwjchoutBrNr33fU7JCX1lejJGMpSodlXx66D7U/8+42/QZc1Ua/XASkRJxFEJGBShIzpUDxCp5NhcmwCCzNjWL8EeOcrT8G///2r8JF3XKyHG0DWzRAJYVCTFSMwgzjjmCPLJQ4cnkGRlqjVE3CmEUUCSikopcCZQKuTImZdXPeaM/CiC9frPC/c6rYntHkfoiMeuHiGFuH8CmhHSLmH7tTu/2seE47TSnml5JrwytIpr4AvcPJl27APMPDA88wDHutJaG09TGu1Km6HrmpVEkCzimBjCxoBIayddv6fCajCXU9D9C+aGIQmiHjGgjA3sPBfKMHeStAStQLtmwoBG10VRRGyLMe5p66d+ej1L0Ufm0O6MIM4EpBSQsocGso4MRqIhUBeKhw4OodWp1BxFEFqDm1zwRhjSGo1LLS66E8Ebnj/6/V/fvl9eNPLtmAQ05g4tBezk1MoZQnOgFJKdDttZN0OpJQQnCMWHIJrcB5hx7MT+NYvnvo44xEYEwY99MqAoyMpgupgQyr3oiwSBM65tW7wAuto6XlAnlqoWMx7ew8QPN9cK7WyaJpQG7eI1UwWDoYKeGae7+5L7RWp7v2d81AEgkkXfBfKGOfWGHuZc8rbBWsDOmgKQzDIUmF4sB//9cP72B13PgM+MAwem+0zURIjimNESYJSSmTdzOxbjATyPMfU5ATmpidw0soEH3rXxfi3j12rz928eKbbTaEBm09mOqShISIOzRj2HJjC6GQLjf4mwBhEkkAzYVJZbG5eu93FskGNP33jWdi0auBdRVFCCHGc3NNEV+TSVZCOmbvhq2Icer7nrDqZdChj9pmMCEy0JHfO6gZekc6gDTBA0+o+YYNAzwQ6xxhZw29OKItiF1rD7s3VcF6sE1SPuPwyp3Jd8Xd5C+c1ewCklB+QowhpzECJMoe0zJ4stzoC66raO9xGaKWdKxJqf3qu4AJlqSGh8MH3v274pJUNtKbHLXOAsshQ5oVVugwaCnEkMLeQYv+xOWS5BhcMSgNKm0zrei3B3PwCTlqzZOtX//V6/bG/eCU2DnUxuf8ZzE1NmPgWFGRZoNvpoLMwj7IoASaQxDVEUQKlGEQUY3ZB4X9+8hh2H5r/m6RWNxaX6MNDdldfWiuPxBzaDTiodZB86mlCwkZ07g2Oezr2CvlziHnQsLZy5K+ysUcVIGPmc9AqK5Ikh8Hd9M7E7kwczyglbUMWzD/TIkJoIw+0e4T6rGy+FiFDgFWo6pCE1cxKavAoQjvT+Pt//QmOTuRo9g8CWoFDIBIJYi5Qs8nGaTdDN8sNywSHLCSmJ6egshlce/k6fOGvXzT80vPX6jTNIKVGHEfQVqFzrRBFAofH5m/Zd3gGUT2GAkMc11Cv1aFhEsIZZ9Dg6HbbOP3EAfzRq8+4UUoJJbVRYoRqEBp4OGNESi2UA9ohYGhUvdfT3xtOHciMdjzT7powb9BdR5LAaPvlcyA89zyfNdeL1mhtWhu5Zr6zBAkDi8cZpVOQdQqHZJtSHnbSr71LrU6LOrhYFVC3csQsgmLhd9RGGAwM7q/MJ9Ja5Pb4fsVRhDTt4g9fd7m++rKTUbYnAWmC8aXMoWQOpaVx8TQApZAkMY5OtnBgdAESDJyRNROI4gTTM3M455S1x77+73+64/VvPh9ydi+mjx4CmILiGmWZI+t20VmYR7fTglYKURKjVk8QRQJMa/CIo9AxfnH7Htx8514WNxqQ1pBQkJcHyLaCWEJjQopA9/DDuQNeaOFgvPYxtOB+pcyiAmPWheXcJb4yO8NpMYBcCZIXTvtKAwRNSN185RVXpX/a9CVEQOErHJtRcVZGAznwhjZAU/Z5UobtWrc8oKWP25itX/ScIi8wONCPux87wL7wH79CIRpIGjUoBfAoBgOH4By1RgTOgbSTIs1SaC3BmIKIgTxrY3piDKeeOIDPfOQFeNs1W7QqUhRSI4oiGEdJIYkZpmbbrz062YKuxQA4ooij3ldDlCTGN2AMXHCUSoMhx0su3Yirzluj0zwDtyiM9cgLp3Gihy/+Dc1ENx9DHtHcYoxQO5zh8IjJNxeGnkJk7R3NYF478KTcKjS1SXFX6qrTPfY9r2pqO8jQ6oaC5iaPt7IIbSWhqopmDbQrKT/tPpAudfc4JOFGyQN0BtCl3uAbSxBmkSulKzk+0ICIInSzDMsXD/Lr3vEiDEYddNotUI5MkeZQZem3UCkFKI16FOPZ/TM4ONpaywU3yhoaSRTHs9NzOP/UE/R/fe5PVlxw1SloH9iFojUH0YghlUaWZuh2OpifnUe73UXEOeqNut3jGNlkTY04jvHI9lF85QePXtMtGEQUuZU6B7UtfQhJOYHqQUMOTWhKWAyWsgkTkxKiB1g6cQp+Vl5eEAM2m7ZcX4JeBIKvNfGXlItHhpU+275a4P+cyKy3D9TEcUo6QOY+/he4IvAxt+Nia87TgFO0sKixVBLNRhP/dtNt7OZfPIpkaAnimIGVEjyOoTUHU0AtAeKIodvN0e5k0EwBTEJzoxgnp+axbHGMv3//FXjTC07WZZpCKwXBGbTUiHiEqdl0Ye/+KbDS7MoolYSIOJoNs5Jpus3BGUeeZVg6JPCOa8/Con6zsh6RK1mhccBOR1dvfEzKlEXrVBmFVWNmId0d5YhOQTEEQnq9MkM/+NQWX8XCeV2Akx3n7jmGOFUWGEw3ph6hYj5w6wZe+UAdYzZg67+utuQJ6KYbozi/V4yKkVa2hLUDcI91ghreb/6p455GYzDXasbAeIQsy/DO1z9fbt04gLw9BaUZFDhkWUJKCVrAMOBLI44EijzHo08fwZGp7qE4jgEl0YgZWvMzxSkbF3/lc598O06/dD3ae3ZA513oSCDtdtFqtzE3M4/Z6VmUZYF6PUG9HkNwAFJDl4aJcSPB7kOz+Pw3H8SB8fZvmo0alJR22pvsbUdc7WnkLJ6jmacdEarqVnEnxC6Q7trqsdY8QK+Bha4YO6+xKoqmip48f92L7g2QT9VVCVBAj3KG5bV/hiGCCmWXMVDiJYJ+GiTpdyeEHocz3D39IXShGYMsTeC+Kxn+8pM/vv6xxw+iuXgpCq4gVQnGbb0uSNQSjSRiyNIcc3NtZLkxjCziEFGMmdk2RoYjfPS6S/DiC9frdrtl68aZOGiaKezYeRjduQ7qAzWUpUm9SGoJ6rXEPIsxgAlIxaFkjvNPW4KXXbJJ51kGEUVuovh4dDgvCGRY/miDjEIkGsqV5681TLZBg359zS3jQjoSu8d640EcpOfB8cm4lsxVctBOBkg/MYfi/RM0xeV6VI7TpIaBPEgONfEWDVcihwZIv0PbrGIvaKEQhRaQfFp7sSewVV4uj5ZQYUAUABCCIxHCfVbaxsAYc/zRGmDCBO77B5p41cvPw1DURZ6mBt1BQ5Y5tC4hhEFFWmloJdGoJzhweBIPbT+CPIVZ6eEaabeDJQMCf/mBV1x3/tWnobNvL1jRhmYanYUWZqfnMTMxhdb8Ahhj6OuroV6LAKWgSgUtS2hVIIkFDh5bwJe+9TDuf3qcNfoaLhbpCaHdpLWDrCgm75Yz6EDAQo4yut4WtKNJS4F8khK/IumpTG32unMhMmTBe8Mu7oynUj7RlzN6vvmR0LMLMhuxCjpetf7kZpJiCz2DXiVKE9J91oHicwgs7HeY8BmMz0AGQAN5UWCgv4HdR2a/+IG/+z527Z1Bc9kylEoDWoKbNRcoqZDEQKPOIaXC/HwXrXZqClQKjjhJMDE9jxNWNnH9m87ByesGvzK30DX7YzUDILBr/2i6+8AEan11QJamC4yj1myAxzEUubpCIM9LLOrTeNVVJ2HxQA0U0OfcrDQ6byWUCwYIYVZRacO5SefwVxl6cbcHOQQpwbS2tCRDC8dbx5dAjqgjFHMLFaYzhhbAkFwbmfB7Wg2PaBXSdafnxWjAzDUc+qBenv3n4GeE8s7AKkSsGHD6jt675wDQrDJxKAYDAFHEkWc52p2ug2CMNLSHGgCAmHMUWYoXXn6m3rB+Kco8t5tuGaQ01QS4iCBEZOGXEchYcDz4+EHs2D2xmEXC7I4oS3S6Gf7gzZfrV7/pYmSjo5CdDiTjmJudw8T4FGamZlFmJZrNOgYGGogEgyoL6FJBlRKlKlBLBA6NzuHz33gQv773EKs3m2DgbrJX6G0VSjjBvCRY2hAh6QLtV+aqqZtVvOqViDpOSXn2+tXLUKF56+5jo15pMMd3HTYVyELwZWCxmQ1SB6uBgfz59uGRXtAg014edTCRAJsXZa8P+xvGv0LUR0bQGGFDpyIvMTIyhDsfOcDe/7ffwf69s1g0sgh5WaAoTIoMlIaWCpEA+poxIiHQauWYnumg283BudnCNjW7gAvPWo0/ePlZ1zVjIMulKSEoOPYcnGk8tv2IiWkFfRZJDXFSB5iwRl5AgaGQCqdsWozLz16ru90MEbeFBjVDmBkeRJSQFwWM4vI8I0NXoakTqyCdgWgELzcGkQW/Eb17BMooVbOi6vUB88TWFqOx53DpKa/UhgU4oRQPlciKGyjuUEzF7QirA5A2pPIloYBVJZUCyc7Ck9V3z3dXVikHGDfVEoRzDiklGglwyokrvsIgHVr008Raa86glIRSCq97yXlY1CeQprlbzSryHOACca1hu6GgdAnBGeZbKe589ABGpxamkwSIOTDfTnH1Zafr9//xy9FgKbKZCUhoTE/MYmJsCu1WByKK0D84gL7+BoQAZFlCFRJFkUOpFI06w67D0/jMTQ/j5rsPMZ7UEUdhpQ3/qqAEOx5tt3K4eGc4AW2KAQmbW8YG/L7SAJEYEaT9poHy9+Jm79cBrzx/nQV1cuDlIkxRIGTIedCWfSYpIWfktEcNLmAcypBTZMfnkFXf023eXfGxNV55nncnifCovrQvMVVKhZGRIfz6zmfZ+/7qf/HwY4cxMjIMBoU864JZNKKlhmBAsx6h2UygpcbcXAtz8y2AMUipkRU5XvmCM3DV+SfpVqsFzjTqNY6Z+Q4efHwfilYKEdegZGl5x5DUG+BCQFFdL8aRlRIDfTGuPH8dIi7tfkju6nCZdDPzmVtElXCJvNsJ5ptXIBy+SjCsXFVlQ9scTPOeat7R+nFvOJXSdchgOqGsoGMjWOROhgtP0NzygNCcaYGTcHKY7Q3OoDnZI0UDB/nMmHomWmCd7Zid0IWW2qq3ivbtdRXo2QomGM85t9qXJg2QpTk+93dv03/5npdexwVtb6HHeNQouEA37WDDuuUnnHXmOgiZIc8lGI+gpVFsSdIEj0zg3Ty3RL0msOfQJB5+ZiwtSoV6zJB2u1i+ZIi/990vw+oNi9A6eBR5JjExOoWJ8WnIEujrH8TwoiE0+hOAaVOVoCyR5jkUKyBi4J4nj+GT//UgfnnvIRbFDURxbFa0emmmQ7ro6m8gWnDjIj4XegocISsrCHY4e+FyTGDPGU+kbHimw5Usn5LgYnIIhVT7/lWdDa/8nGD19DoQaGvyTAki9v++jtCYsdg+DseckjtedsOFAnJZlDYJow6oMKrgEMTHtEkXGBkexG/v28v++GPf2/mjX21HszmARi1CmrWhysIjaaXRSCIMDjQQJzW0uzmmZ+dRSoWJ6QWsXNLEG176PKxaMtBsdzpoJGZr32NPHcC+A5Oo99XMhnCreEQcIU5qZpIzgDEBqRgY19i2eSm2nDD43awoAC7M/OKwia6m/6VUqNcEPn3Dm/Vbrj1PtztdRCIC3Oykt6FB9UFz7UCN03eergy2Fr1f4Q2l115oSOtyCUmFVt1+ap9imr0xUROBs1qE4gCoMMo0YGAa5UaFwkNCwJx1w3P8JcH1h2fYEVmr7K4LLHX1Tm91GeNotbr4wNsv0u98z6txyqZBs4KD3kH6e8qiwIsu3npw+ZI+ZGnbKleGoiwhkjqiWsMoL5vCUUqFOI7w4BOH8ez+yQYXAhxAmhV4w8vOlVddcTI6xw5jenIGY6NTmJmeh4gSDA4No39wACKKoAqD7rK0i6LMkNSAha7Ed36zF/9444O33PHoKEuSGqKYm4qcrMoeF1x2BoE5PjFGB1vAWUVH/wBN+FUk85nz0AgcH6ylRW4dKMRQLuAfV+VQJYZhv2OOc4H7qfy1Ng7m3EN3P3GfjJ6fGAbB9dT9D8ZBaCzsS9BSxSvoXYEE85OHvnPkdUYWjl5SKigFjAwP4pGdY1s/+E8/H/zkjfdhbB4YHhkEmEaWpZClhGbMle/pa8RoNusocomF+Q66nQITUzO44PQVuPLCE9uZzUNknOGpZ0fZ7fftQSMS0BbxMM5NblijAc4FABOjUpqhLCRWLmrgglOXvy7PC3BmfqcKrEYBMZSlRl+zNvyuN1+Mv/7Ia3DSmoEPplluSvpYhacDyrn4lyOvrtAo5KEDGvTeU7SCsrzHBDcfe9168x3zPAj6QiXgHY72Fj94ICi4SrEIJyUwqwEm1YwsDXUkFJYKsiKBRrDKpP3zg9pvgSD5SSGEQJ4VeP55m/Rf/eU7kS1MQagO+mtxHbAw16Fekx8klVGwF513IvoThSzLDcOVBliEWmMAjEcoi9JeXyBJYoxPtfD7+3ZjZj5DvRaj08mwYvFA/PIXn4kB0cahZ/ZgcnoWaaeDgf5+jIwMol6LASmRpxnSNIUsS0QJg2QMj+yYxuduehL/+o3H2dP75l/YaNTM/jKl/GIy4xaKB4Fxx2D7YqT7taOoCoQjAHH25Q8L8RY1VF7+cBJSkFR9ohoPolQEXRHoysqn6zF1gJRUFcGTEiKh8ujNI2yfIU7y5BFp+KJmzF+bOhIoetMN5gwnLUT5vnvkFk4e744aS+8nm4ccSprcspGhARyZTBf++b/uZn/2qd/jZ3cchUQdzb4+aAYURWGQuFIAJGoJR19fA1prpGmO8clp9NcLnHfGavQ1YrTTDPUkwsxChp/95gkcOTaLen8/ZFkCgoMxjqhWh0jqhmfGfUKhNJJE4/QTR9BIAK2Vy8mDJwMAjUXDfWfKsoO1KwX+7v0v+nR/VAK6hCC30U5EZXMySQEpW0bKZeX3KBe61lpCx/8e8GwNnOcnZ7CLTV45KuduEpKqImggqImPYCIopW1elW3MQXPql/IC4jphtGUodP7l0yfcJ2sVqOQyCbSrcKCIADDoinFIWaJZF/jnv3kH+ocGkE+NYvnIABYN1L6i7XWGGmZic2HSIEYW9ePkzasgVAolFRg4SqUQ1foQJX3GsmkJrRSKQqJZr+G3d+/BnQ8fYmAMccSRFSWuuGhrfsr6IRzZsROz07OIhMDQ4DCajQYgFbJuF2k3BWSJOALSTOGxHXO48fvP4u+/+vCnv/3b3Wx6oQTtcZRKOffMEbhH8VP6g1M4mtmdzjRBmacpWTDNnIBpTUfj0RI34SKajJTZHD4DttKHYRntegCqKMQbLu0mtuuT1lQ9BRT3YOAuyG5CKiRfAdoh+dH+eccj+wBtQsPXqyM5DIwqWfaQhj0ozLdVVWq91pRxfy2zhFJaoShKDPQn0Jzhlrv2sY/+6x19H7/xIdz72AyUrKG/v4m4JqChkBcSeVpCa42kHkNwhk47xfz8AtYuamDlov73laVCEkfgjOH2h/exn9z6DJqNup0SDIxH4CxB0uwHWAxoDsYFpK0Os3HlIJb3R2+VReEy3okOhq0Ky5YM/T6u9aE1NY2XveAMXP/GS3SZpYDzZQBFBQR76Ec0cwYzQFOEljwi8zx1NGUWuCjlnEdC7ND+kBzQd/RMwMR4CYE7OWc+QzZcXXLWEH5iVeMIwaoN8508Pn8E7lraUGo65JyMwArCE88KCZjRZ2m3gz958/P1eZeegWJ2Almh0NesYcXixtuYlTBufX3AuBtFXuC0zav1qpUjKLLU0E4pQHPUGgMAF5ClCdrLskQ9iTEx0cYPfvU0xmdT9DVrSLMCtSTCZeetxQBbwPTkFPoGmmjWazZIn0IWXTCdQ5cZxsbmces9h/GFbz2NT3z1sU9/9cc72DMH5z4s4hi1WoxSSlugMJgczJHwOV4VrF2hsaE5d8wmxgelCABwX0LdSiMP8m0okOHdTvrNC6GLbwSvKhay/SJ0zfwVLt5VEciwsarM+HtsL7Q3cGSR6fcQ9Vs15r6jhQx3PSNTWnUXPU11z/OZOy4uHLRxr+1GF20WrcvSrFrXajGOTnY7/3XzDvZXX7z7hk9+7VH84s6jODaZg7MIjTiB4BxlXkDJApEw2edT0/NYu6KBU05a9gUpNaTWqDdizLVz/PjXj+PI6CwaAwMo8xKcR2CMo1ZvIKo1wHgMziKjyDnDkpE6Vi+u3SSldHON4v0AIBiwetkQ0NcPWQp022388dsuwzXnbtJFlgdH/JFxVaDFljDZ2dPUBtOPwy2MLFqwuwdO4Tkd4oxfoO6YWUUlY06VZAFLf/vgyKEj+lETfCfLFoqZFwYnGIGgOGKBFC1z7bgKHtDOElh5cGOF0lZgSFA8hC/yDCeuXfL3H3jva1G2F6AVkGUZGkmEFUuHINiETcDkUEoaYnEGrRVO2bgcfX0CMi8ArSFLCR43IZIGyqxrNLrSKMsSi4cG8L83P4y7Hj/EojhGITXyrMCbXrpNv/yyTWBlGwMNU01AlimKdgfdtMDMQo7DYx08s38aj+yYxPa9M5cdnOzcCQBMCMRcAMwc2mG25RCdYSvcMmtIlNuaRRDbnFHBgHASW0vHAhoSlHO0D5C8Q7ZGZCrGxc1PZ1hcU05QQ6Gtyqg3vYS26PleWMMUkGrsjdCB9zhJZgIlQveGltn1n5Ag84OtHMQa5qmFqNG7ih4Z0HVVhFr5DtWwiFIGhWlrkDRjSOo1aKmx6/DCJ549uusTtz50ZOnJ64fGzzhpCU5evwgrl/ajv8aRJBpxwjE8GGNhPsXSJXW8+3XbcGh05rFHnxk/s9aoQcQR7n/yEPvZb7br97zjUnRaXcNXLsCZQKOvDwstDSYVGDcBhf7+GtYsH8QD+8aNrNn+GuUjEQmGtSsXA3EMsAhp1sVADPzFH12NJ/d/461jc+U3XEY3qujb6A4Ony/GHd84s2jan5fjEBnJhl8Eqa64k73zOqNq0Ol+BHwDFCK32uP9QzdpQkECtN0bR5rIb9nwD1aOieEAWEUwvNDooJdUUpj+skAYpVTQWuKv3v+aG5atWYZ07KixenkXqDWxcsUwhGB2qdicv8e5PwR15dIBRCihlFkCl4wjbgxAwVhCAOh2Mww0+/DUs+P41s+fmF3oSCOuRYE/euWZ+iPXXYoD+w/hd3fvwkKq7ZYiiSzPMT2XY3w6w+Gxzk1Hp9O3z7QlwEyVCs4ZlJSgfV4+mVQBEI6GBhkGkxyegWG8iiA2QFYvQMeWnl5o6IP25xC4ILjhqdUBgDaFLcGsQvVGzt3LK6fdePRtYiOw7nCPgDI6WIO5E7UDubTtaIcefKE/Wp1Sjg5UhddKmr3fzQFLRzpopfocv6rpJw6tptKYKM5G/fLtBwsFdpwAbPmh4Ckk00pCCIFarQEAGJ0rJg4/PMoeeHoKKxY1Pr9qaf/1yxfXMTQQoa8ZoR5HGB1rQ2uGV7/4VHzqz6/a9tn/vEf//P4DDBCYL0p87+dP4Jrnn4yVK0fQmU+R1OsAA2oNIMtLFHkBDgmpJOqNGlYtGwTDGFEZoUAJwbF61VJAG2QexTXMzc3itJNX4N2vPu+m/+9rd32DjhnUwQQ2qTsGqTohgzHEYWwwXHAKX2GoyLmBjIFTKIC4qwFm+e5r0VURP7fGLAqtkA46pUlYqDCeZWZovczKCv0Qoi6vrMJ26R5Qd53l0/6ZIcQEIMFRZB1ce/Xp+g2vfz7ymQkoVUJnC9CqC40EK5cNQgjuSnRxzt0eNgAY6EvAyhJSK8hCgiV9SGo1U4urKCDLDEkkkHZL/PePH8NTe6ZGAIUlQ3W8982X6D945Rm4/YFd+Ox/33vHzgMLz1ciBgMQC3M4aSmVm3RRHGGgPwYYQ1maooWkmbjjgoLWZqmcknUNcjGJgLLCKprQqAoEGRv0IInwHlRfmohs73ViEfCfwW8l0qFQ2WdWVw0R8Nq/9zE8jzKdcJOEMetWuIPXqN+BgrGanXKLwLy34BAUtOuf6xvz17hjzFiohILVMGqQ6qwR6tPkZtsJxfy+PUNH5ehpXBxrEOAP8ZDSLDz11RNwnkApjYMTnfcfGGu9X3CGKKbdJgxpYYzoA7smfvKBN5197d+/91KcuHZEf+1nT7L5LvDwM2Ps2z95VH/k+heDRYXpn4jBOUejWULKljlAQxl0v2gwQVRBu76vseBYv3oJUEoIxiB4BI0I8wszeMu1z8PvH9mjf/vgEZbYE8GVRSnk0XjFZeex5XMlXmVliU5l0o6hllPMyyMZ8KocB3Lv5Nl+H8iQd+xsK4z5Wvju/ww2kO/RVyjCDEY7V+A1I8Xt1DLcgZ/caH4OQhWoTCDqj9JAWeQYGUpww/XXImYZZHcBSuXI0gWzxUKWWDRQRyQogE+4S7tH12sCkBJaSZRSIopjCKEAmULrArIs0IgEbv7ddvz0tmcHu7nESesWffCTf/Z8/fprNuG/vncv/vyfb2WP75l/fgazz4xxAcUERCTQ10wwNFDD0GAd9VpklY2EthTjnFd2yDiLJv2UcC61NRa+JHMVBYToQQdt9cYQnfoJDE7wE3xMy6kE9/zKdUFVD7ewEAiYDiY99YOQnffAqgqRXEqjM+w4A+Tl++FOlax0tSJ7lUGHiwleht3IA8VWoY97gp8gdIPWNh/R8YLQhe9LiFIImZrFKbMAU0oFqRQ4A/oaMQb6arxeiwBwFCVDNzeNxXGMJ5+dfMVffv429pO7duO61z0Pf3PdpXrFSCOe7xT44a+f2vnwY3sxPDyEPMts6k2CuNaHJKmDMQEuGJiWSASVDfd8YACUkqjV4vr6NUuhsy44N+eSchEjzXI0mwp/+oZzsKjJzQo+YPjAPK0ZvDyE/CJaeLTrmcUY3OJSANYcMEIoP0YgEMbZdcA/Z2g0EJE1clotsOqw0J4sHaEoK7lOQTmGO8XlkVUolBUB404FW0GxdbuVdgPUymzBef1LztdnnbUB6eQYmIiRddsocrOLvywUBvpNPlVZMJeKEU5owc2maFkUUFDgApB5AZWnyPMWGhFw75MHcOMPHxs9MtFauOisNfqjbz0bK5c38Mkbb8e3frmHlVqg0azZVUwNDmWtl3XrJKBLbfesmfFSSoRWyoQU3MquEWzOOJ2/ai1kcC4BaCWNFLunY5iGwOBRD80qxzvlrRX9rcR1lAIqy+xV9EwBW6Wp3xX5gT2AzU1kMmR0qXbYyaMAQpq+bj0lQMO5D2R8qLQO9a2iWwMXsTJpdLWf6B2bVVr0bOMea7s6qp0X4OeEn5ihEWGM2RQd24+KUQBoUw0tNhgUo6AVA7d5HNzWo+fcHMMmuEZfs4bx2Rz/+LX72bGJjn7Xq5+HJcO1/FP/c9+Nj+wa3/qf/3uvPnXLKjQHYmRZilqtH+A1xM1+ZHnuFIKpQ2fe+0ItDEoqDA30bV2+fAmKThdMRCZJWHBoFWNhoYVzt63GKy/dpL/6i50simO4JT6at4HMke4hNEXPIYUWCIMDOKSYqFyThy1eETIwe7CMuZ9iuJoxgHtZ4B5+W70UWFodKiFt4L5JoQhWIy2TeKA4XGwhtI6ha2GXzSs5Zoy5uCENXaoSS0b68N63X42sM4eyyKBUhjxtoSxSKC0hZYm+RoI4EnUjInAWPkzGZFyjyDIIrhFxhbzbRaezAMEkntozhs/edD/2H51f+eYXbtaffO/5GGoI/N2X7sJNv9jDFI8w2BdDeAwBLgQYj8C4gIhiiDhBnCRI7BH0wqEub25o7zRtfKUV2NDKh+6XmdjawYgweOxQlf3dTVw3ie2qT5hzFbz3E7GK/gJ22Ux7qs2GYELqyrWwCs4fyE7xExvLDGTBxcicYlBWtgIHITCCJGeuvj0ZU+Zl1o+bQCU7nk4kB/SXFKJDBF4hkiGn6piulpZ9oI99aZiTsE0qibuZxhzQiTOGiAvEQvAojuM4jutRFPEoMgtCPv9PY6AvRlECX/nRE+z//vttWLdmBJ/+yNXXXXDyEv2dXz7G/uPrv0ccaTTqAnmRA4xD1OpgUWINEkdaSpseBGddlDaLDkuXL3p0cNEgym5qxs+5QW4MkKVClnfx9mvPxAnLGpfK0hhccvV8VdaqsXMItofWLKCdtoBIWb1iruVOZoDgLV3vuOLljZQd4wwRaTUHxaldew8LJMWjA4LNVgCCI7hCBEcW18s5Ne4RnAVzoPgYxQSkNpnHr3nhWXrL5hXoTBwGj2KUeRdlnrpjxrQs0VeLkcRiWLXLUSroFvpsC50MRVFCSwnGOMqsi067C61K7Ng3jS9+/T7s3Tt5/XWvOl2/9oUn4dCRKXzum4/jjscnWBTXUK8JMK5R5hp5LgFdAshRfZmqsSLiqNUixHGMOI6htYKSHEqWKErpGMHg4b0/ezOgK4Ag/SrAuQFKIIEJjYP9reJuhsmJgfLqjWXR80OU5q6nZE6LjKj/PijrLjex0ePkBK5vTrZsW8fJVw/ic3219NK9fXXegu0LdYSuodYYHMJ3bQOgBQ1avax0kz7Y95QkGx5e44Eeuf/cVIMQZqWQcQatJPJCopRSmZcupFIGsSvjITDOUIsF4kig2UyQlRo/v2c/G5/uzHz03RcPf/LDV+GfvnKX/uxXblsXgR946xsuQXNoAJ1WhigWiOIaoCNIxbDQKd1Bt3ScGyHbxSND4PUESpbQWtkN5MIaCYFOu40T1w3itVduueNfvv040yoCdydIVXWA51eo0AKewS/oBa5axWjygL7+Pou2tJ0fth1DZq8QI+IdGLNrTOQ2mhstNnRCGzzJdUxT2gV8vg3F+np9ZaqaQGfhBeIYuH0m1WHRUBPvfsuVKLNZaFlAgaEsc8gicxuTpVRIEoZawv8IDJ8g5OGtN8feg1NIswxRDORpjnRuFhHneGTXGD7/jXtw5PDMT9//pnO+cPWl63HvI/vx1R9ux9P726zRrKOb52i1MifsI30cw4PN1/X3N986MNC4ttmsoZ7EYIwjyyQmJuceP3Rs+syZ+Xm3t5ILgVocIY5NtQta1SNorzQC9OIZS4JAbhXRkorP9S5Fmxt88DR0d3qD28RHii+QC+9cLufiezeVPpFRq+zBZGFRyR5hRhDHoFCBs69GDhghUkJZdjOyWREluTSCzzkVlgyRk7Y7LHx1hNBFDQPAVCSTO1cknGHMybf7zomogk/K8GkugHEYRWSQjAaDLEq0OymUlI4G/X0NLB5qLhrqq325Xk8u5RzDRSl3drvZb9qt9B/nWt3p+W6BNCvtMzjiuIYHn5kY+ei/3PrBP3vbuZ/+y+suw79/68ED//Cl37FD4239/usux/Llw5ifbZu4V5KgowXG5woTnoBdIaYhMKBRiwFb5MDIRbDyD5NcnZcdvOLyzfjB7/esODTRHRUwqROOloHxMIpPH2/0rFLX3kqZ63osNHHHGQyQ2tFBkN4bCk38BkNkhJ0sFbOlNPzV3vIHWpcHsRfQSgM16+UAQYecUATCEa6QhD+TeJx3xgn6lJNXI5veY017ibybmVODlKlyKbVCLDgSwbYpa9XBmDlnkZsYz6M7xtDupBhpKKhsAYNDI3j02Wl89mt34tCR2U9/5I8u/tClz1uJn966A9/+5c7ZPaPZSLeQyMsUNQGcftLq+047ee35p25eirUrmlg00sTAYBP9fU00azGSSEBwgayQmJhub9uzf1zv2jeO3QfGceDINPYdmuw7OtnuEC+YELYqazB4R/JwNVjZCcvAYCdnMIE8mmcVZeHnoa7Qma71fPTVbgkYV/gDXT1GS0koxirPIGH2RQWP71dVZrxMMYu2HRKlvpISs/cROkPlGhIrXVGknHG3c8DrVo8ewH1MMaSHUuQCkwm1qtXRMqjkQcTUMEFwwVGWCq1O5iYl5xyrVyxatH7NkqlNG1Zj49oVWLNqBMuXDWJkuIF6nYMzhbLIt3Xb2bbWfPdD0zMtHDk2jV37JrBz7yie3TeWjE63CwB49vD8Zz7+H3d/712v2Xbgujedg5Hhhv7ad+5nM/Md/bd/fg2WLxvCzOQ8+usMmsWYXcis0lf2lCCrrLWC4BqAtMf5aeR5ASEAIRjKTIELjjTLsXblAK4+Z92xr/1iO1OaI6yy4w2ceVGiKat+7QhFydahknJfeOEMzlklo2avs38ULL+tGYzMXKHAeSCYFBuxQmpiVySUlnv0niw1C4XLoyu/wkjf6OMGye3+RMYAJYFIMLz0ijPAWIYizxFFMZRUKPIMZVHYktFmmVwIBi7YEAVBlDb9EEpDCIZDY62+djtrD4kCA/0J9o/N4xNfuQ17901d97E/vuzGK85fh2/+/HHc9JNnbjww3nq31BrrVw799QVnb/n4hedtwdnb1uHEdSMYrCmUWRtZkUEpsxdOlRpgEoxJ9CUMKxYP4qyTF0GWW9FJS4zPpthzaKb95I4jeOipA9i5e+zGfYem391Nu2AsRqMR+4nI/ETzAFV7voAmk2WwEw/tlEEAaCuuEgkIPcsZJOatn4VV1bNAwz2Iva4DoZWA3eTReWPcu3pplIHZaIxAIixGq7i1JDEG4bh4EuXSwSRn0ibxAAw6YxAeUMECuQxEuKL8Q6RL2eOmz0QvBErfTPRUGcS0eGQQp21eoU/fuhZbt56AEzevxsYTFmP1kmE06wnASwDSGN8yMydgyRq0bILJIUBqyHITFloFjk3OYtehqfzBJw/hnof3Ydf+cXZ0Oj34mf95kM3MdfQ7XrkNI4NN/bmvP8CU1vqTf/US9DVjZJ0FKA3kmbYoXwNQUJrZYp3GEEFLMFvxV5elq/bh8u4UoFHiivPW43u/34l2TiXHLdBhLDAUZtIRzenA6VDOKHPB/MSdIdIa1YWBwESTXASi6wy9sWsMEXHFoCjlOuDUjVNwYcxEgxwD57JYFOGW/5W36hr6OI3tBt77mTGUeY7VSweGr7zkVOTtOehSQ3OFIutClimUKm1ch0OpEhHjEAzLYd0M45OZtjgXkApFUaRo1DnGZjT+4ct34YmnRht/938u6b7g4g34+k+fwJd/sP2ascnsN1s2rrj9hZefftkLX3Amztm2AYMDCTrtObRnJnDw6DQ67Ta0kqbyprabr7k53l1rI5yARqNeQ1+zgeVDQ9iwYhWuOe8ETM6fjj0Hxq47cHTuukPH5nHzrU/joe2jrFaLXYnsUPH4+KNlpXONLReC2IZLMGawq4vhMrSH5E5dBG1VYxXMW1LLe6100FaAyS3aVfQ8VNuimIYHdxTUDk7e5jy4z+QweTHxsZLA+rmYlZM7RiEPVPoCbWJWvgy1g4Ze+Ye0stdQdRCENCMFDVL6HGVZYNFQA5dfsFmfvnUNtp6yFudsW49Nq0aAhgZkgaLVRjp/AONHO8iy0ixcSRtD0yYNSJYltCztoglDLY6wYqgPG1ctx5Vnr8TBF52Me584oH93z3488Oihy/7je0+yTifX73vbRdCM63/9n3tZX6OuP/aBK9A/UIeeaINxs0oKjSC2rCGVRFFIiugDTAK2nh7nRjFIaTaB53mKkzctwikbRvQDOyYZWOJkUpvJbuijvcA814p4uCjFKGjPAj4498tcQzF5WgwMy88jmBOMaUReszGLvGgWeERF7fOenC0TgPNLmuROBCoJ9OgQlFWEEo4OADMJqIJpXHneppkN65YgnT4IZuvWZ2kGKQtLeA4oBSlLxCyC4Gy5NjrYIQqC+wIyZjyHaCzFZz/3e/zuzv3iI390oXzpFSfhP3/8KL74rcdEszmw+v+84zL9yldfjEvP2QDECgtj49i/cx/yThtQOWSRGsulNYpc2hI8tpS1Nhn3xoVQ6LZaGLfbhgQXiJMEA4N1nLqhH2dtXoEHHmO4415hQSO395EVs/x0wYvqxKIgJ6Fj5x4ErpkOJr+Lc2rt+M+oICIJCg/QNPNcC1eTjHByB/MVaAUxRHXVVAO3yky20AqtsoMj8Qv0BXxis1ecvcHh0PaRoqyoPjKm5C6GnkPgLTjxD91sGoqbnH6SkcIUgqPbLbB8ZOQr733HVbji5WcBukQ2No7pY7uRLbSQpynKojAxqDhBHCUAE3bHgbAs14higCUCUMqEPmSJmclpTI4r1GoJ1i0awIkvPRVXnrcedz20744f/mYnfvS7vazdLvSfvev5KEut/+2b97GhwZr+2z+7FI3+BpoNcxiIKbNuDZ02sprmhcmLZNYdU6bmvgh8RMY5dFlg0WCEK89dg8d2TVTmqo/NkiH1dHTVTKwQ+4wFczyzciEHrxCcC0pxTyfHPhfQhRUCeYiIb9wGIcKtPKFg+BUfEjISRIMB7FOckDqhsBJCOsdrs/BFypNDlhJ9jQSvuOpMCG73LQqBrJuiLEuUpfJurDbTCEyBczaswCDAYOp8W9SoNPob+s+WrlmFX9+zHz/79Y7r3veOi+TLXrAVn//m/fjRb5790IVnnyr/4O1X4dorzgBLNGZHD2BuchJ5mkPJAloVyLM2srSLNE1RFtK4kDChRLO30eTYmBiigg2/oVQShS4hZY75+Vnc+9AC7n7kGG5/5Nj1R6flF2s1U2XApxd4g0R0cjwCq0y0kJCMeWRC8QPilffqrWWjZZ9wG1JgWb1L5VFgBX1ToEP7h5MSczk+yihJUsBGLuw2HxVsSdOBsDqNa95zXpUjElzGQuQVrL4iqBdGNpuUTwUVPrfycoddUOoQybTtoFuksmOo1RKMTS68++8/++Pr7rv/Kbzkyk3YsLKJoj2P7kLLZmEwMC6gS4lS5QDn7vQlKUsoWUCVhZUz2HI22gIIjm5W4tDRSUQixvBIH155xQacffIS/OL2g/rbP33yp/964++vfffbLkWrW+ivf/fuLVvWNne+5MpTMdBfd3TXdvGBNiW0uxlQSnDOzM4UbWJlzmOxW75MCfcS5562EkMD2/lsWytTJDHggWOZhtt/pmDLgnvDRKZWWfoSjz2shS+FFcgmcckF+i3vDJU4ItdAKJvO6nqGOzQWTBzXdBgb6Smb6WMnpgKE0gE8h7WoboAm92vF8kWnn3POFkiZodQcNcFQFKXZEykVWCwgpTmKChooSgUp1RhtGyHbTlsf4iTeMj3VwaMPb8efvOXcG59/2Sb8+3fvwcPbJ/Ced7zg029+1UVYsriOY/ufxvTRY9AooTkzqQ95hqzbRZ5nKKwCpX4zJsCjGBqwCbJm8svS1tJQCpwxxHGCqdkc9z85jt89dDh9cs9cIyu5PTreK6VwInu6cyhJ22ECzGKtW2DHPFoJeMLCe7S2oQLin1dOoeEBqGAiISHqi0c/OuAaJbo62QnQkFE6QVyDnkUyGyjp45bnSX6opeO+89eSC+q/878Req2iQhfad0jCyb/Z2AlfOt3BUmeElVYQUYS5VOL39+9it92/C7c9sF6/+WWn45JtqzAy3I9Wy2z0F3YRRioJIYwhkkqBMYPWiyJHt9NFnpktQiZuxwFmUjFEFIGjxPR0C406w/CiGt7+8o04eePia7/3yyfwq1sewBtffAGGk3Ln00/ux4VnrsVAf9NSiFb6fMXi+Vbntboov88jgTyVdsyGCFEcoSgMfzjnKEqJtatGsHb5wNTM7tkRMFPmh7IAwj05oeELBZpQU6hn6EIeHNZLgIgMMBk9d5MGAA5a8WQAIs6DB4VMJKkCg9b2JnrZHeew9QNJIENYiVCwbL1k0vLKiVrQpA1+cGhs2bT6iRWrlqK7cBQ8qqEoM0hXowx2f5u1tIojLxXSXN4BmOPZmDIaW2sgSSLMz+UfeOyeJ9/2ostOAeIYP/rZQ1joMNzwgVfggjPXImuN44l79iPPc9TqCRgHim4JKUuUZWGVpxkl59bt47C5PmYqOh2tDG00U0hijqwAHn5qEr9/4Bge2D7OZtoSzb46hpsChVSVWlvHu0cE5/0sN9U2goC1Qwt25gXxHGc7KvJ0PAw3LNUuWZQQrgmQk3IihdizIMN8QNX8HggyY94N7jValc55lB/+TuMkuaJlfLqGAS7xmtNG2FCmnOKy+VvkPhLIgTV0zPNQK+ZQWwAw/SR0QNQg7loi0N8cQlEUuOXuA+yx7cdw1QUb9CuvOBHnnbES/SN1cz6kVBAihgaHD89IcGYOXFa1xKIyi+61QfhSa5S5iZ0xDXTnJcYm59DXZDh142Ks/aPzcf/DezBz7BDe9fpzMTU7g7nJeUxNt72sQiGs0DEz13qi2+2CixhgsGDAbHky3oSwNfiNmzsyUMemFf3DT+yZMSuRRILAEoXRUb/Q5+NvlArjYqkOHrvdfx5LBbIRGiGSEW8etSmnE1phBEJtGrdKSXuhMT61BtMcPV2319igXWA9tZ31bic/uakwwsVhtHkScZx92kbEA4OYndgPLiIUaRr2yDhuWhs0xoCsYEjz8g4PNw0C5ZwjL0qsXbJoauOm1Vi0tA8//8VDWLVqBd72xudhxSKGI3t2YWGhhXpToN7oQ5EbpAfOwLQ5x89kC+fQpsiEqZjAAMqwEcLueSukscyxUcZ7DrZw2yPHcNvDY1uOTKW7kloNA4N9YAAKSeWVGXyxLi8Y7oBdYpXNVrdGyCsAgvEBLUMW0mJKeKRab7yo+rKTGcejst50jHBic0YrXv53ZX0lUoSUkmHSQQJFFrRNtahC9Gfag3NZvJsYjBPBqpuzwJ6ejPQSdEVitYv9enhQDfiHfdCVeWASVBWy3JRjHhwcxGwnw7d+9Qy7+9GDl77mqi13XHvFidi6aQm01mh1C6gCECICCw51jTgDkghxLEwgXwHaZtRrxo0y0xpFoSBzCc0EWu0Odu08imUrhnDZhRsxfmQa48eOYe2GJZgaz6DyAkpJCM5hz5qHsrBhbrb17MxMG0sXJ4G8kPLhECKGLE3St4JEI2JYs7wPsY2R0aKcKhW4qYHR4/6H++OIiP4ZFi/ZnFAfNvG89P/z3p95w2xqEb2iUMkYXeUHFCZAkvXRwd4kBwtDK28ZDKvIwExNeiklRCTARWSRhEdurgGtEccRTt+6FiwSBv0Ks1dP2WQ4Zq25yc5V4CxCq1siTcvvGGhvWhORQJGXWNTH8b53XojNJ63A73/3ELadfQpO27oJ2dw8Du+dhoiBkUUDKLLcFRpUZB1o2ZhQCRjMnilSHBpaS5SlBAOQxEZQRqdTPPT0DH5z39GfPrl/7hWAQF9f3Vg2pRwDfXTdm4FwBScEKW4Cam9MGf1Aiq6il4IPxqy5FTmltK044XOwnGiRMjSWyqUShOgoVJogpQpvGUNl4PrsFCOhHvj2SCh7nxMI9nEKG7AungrktCJN3qIzFoQuCFGGtPSSSLKutaZSV3BGJjAUIbJlYO6Ak0Y9RqMe4eB4eucXvvMYu/+Jw/o1V5+Gqy5ah1Wr+lGUCt1uYSc/nflJ/bXImtncPyv7oLMZ6wyyUGg0EuR5DVk3xexMhlZrAoODTZRpiYnxBfT3DeD1LzsLjxyYf9/uw3NfHOxLkBfaoZ5uWmB0dBbLVq8xioRzaC0dTbnggFWc5kuN9WsWI4k5Cq0sspNBQJ+DtpwpVaIsJOKIg4vYGznOAhSoAz1B46+CIN2zyHOc+2m/oiOMHbQD7HJq7xEwgVBwzmDOpTOPpewNDgbKtDU6zKQXLF3cH191wSlaQBrNDtvBHiurtEaSRFi9cjFUkUFD2NwTQ1BiJNX7ggYYjzA5l6KTyQUN661yDq1KKJnjz95+vn7JZRux59lx3P7IDAZHlmFgIEZWdMBjs30iz7oobd1yxmw5GdIHGm61UQiDOGWpoaQRaKYVakIjEQqzc13c9eg4vvrjZ/HlH+1mT+6fe0WSJGg0E5i+mZgHM4M1E8nOCLc1DNq426BZ4pGTY0BYgicwMDTxQmziEHTAP5qUBmkYRcwcFy1PlLvQI8WAWWQ1OYdD3CGSqa7++bihUQw21cbx34zHlxsCqnFAWIMYoKgARfrYi1nlMihfBzT0ffZDMLx0xpRoaV8uHKL9pmtNRtu2HqJDar+UpuLJQH8Nca2Be56aYf/fV+5lf/vFu3DzrXuw0M4wMlRDX5ND69wcqgzpaa4pcZkZd9bKPh2Yy5hCHGvUE45ms456sw+CxygK4MiUwt2PjmN6posrL1iP/++9z//CxpWDb51vZ+BRZE+oN67vgSPj4PV+AAxCBErYzm2X1gOjyNauXIK+enQefIn8Cg+4MKvwiwZqeM3V5+pFg328LEunpMCYLXboY3Fa6yB+auXQffZypWl+aFcH17XBw7Kt3ohVGeksEiNuGatpr/AbRul6q7zAOGRZ4IKzNuWf+8d3Y9vmVTNKluCRhc9KwwcZjWTV6vGiocEGyiwzh3qCWTjtlazzsZUC5xEOjs4hy0v7m0lJyLpd/PEbztZ//LpzMX1sCj+8dRd+cMeh5G8/9Uvc+/gxLF61AkuWDaHRjMBZAaW6UGWGoswhy8JknSuTxay1MsislMZyciCOGOLIiPOxyS5ufWgMX/nJHnzpB3vF7x6ZYmmh0deoQQgrGL4kAPwWCji3L6wL42MJqEwqBVJWXqkwC+l1eG/AC8dHmwFPG5PD2IKnbTAbYdVrgGrCOvtOKDUpBK9eAuFxnxm5fyEKsoq50k8bzOWk0EjGnGcAx3/lzmbwcT/SeG7iwMpiQDNU2qr+NatvqNCEFCwtOPl7qnExNzINlKUpnzPYX0cOjp/ccYD9zefv7PvEl+7Er2/bg9mFDAP9NfT3JxDCpjLArAbSMW6CGzfSzC8DEVSpUKQFyjwFZyWa9QSdlOPWB47hKz96Cl/89uM3fv3mpzExNYeXPP9EfOL6K2/auGLorZ1OBhGZfZZFqbBr/xh4lIAxOtnIjk/ZAVp3USlASqC/r4a+mnhduNPAudMMEFGMsizxwos268987K0446SVUkpbFNQxkpEgezXi6MnIpIBMlcf0gQEKcJUGTCKrnwweEYUxDi803qoy5t01WnYmUQM0GBfIcon+RoLLLjwJp567Fi+97OThB58+amRM04qYAGO2kqtSSJJopFGLbHawiZ0Iwa2p59Bg4MLkhRlYKvDM/knkhQSLTQWIbqeLd127Td/wRxeh7LTxrV8+he/csv2a+a4qfnHvHnZkcvaZl1156pbTtyzHikURVi3uw+BAHWk3Q6dboJRG1TOpwSNztmTJNSQDuNDIC43p+RzHpjvYe2QBT+2exo4DLTY5V4ILjkajDgYFqUzQjAeVV/3c1768jvPhgrhS4E55t4YY6HlCblmVBwGTe8ooA4Tk/aINJSOHqI6UhCZ3y0MjOIVSkR3YCcgCodTOUgdqzW/3CpAdbWgnYfauHnM0835f2JoXZzsUZ6HDBN8qYqV9vzhOkXkKBgbFEsq5PCGfiKc0+5S/X2tAaoUoEhgajjDbKTr/+6vd7M6HD7/8wm0rfnrx2Wtw+omLsWy4gb6+CFoppLlZ6aYtQNDKpT8Y70AjSUzpm/HpFE/unsTdDx/BQ8+Mnz/TlQ9IBXzjN7vezeNYX//Gc/CiSzaCa9z011/6/fDuo7NfbPY1kHZTPPn0QTDFIOo1qLKELEqzlUiawTAIKFUATNvzKUqQuOgqecAFRyklmvUYr3/JmVi3LsG5Wxbj9ofNFqsk4Tap1ss1GVS/8KcDA+FlLUS3xgBytyAABDEw2rjtmeOJBhJUFk4O/2BnfGHcQKroKfMC609advE1F2yBnD6Gi89YhXoiUOQKEWcOhpPhVFohicRwUovcoRecmxNXGBNOiZnsYY0oijDdzvH4zvGdUnMkgiFrLeC1LzpD/9OfXo0YGb5569P42s+e+dDkvPxNkiSIowiPPDO29ZEdo1i1bKB50tqR9lmnLMPpJy7ByqUNNBMj3KSIpTLbMuY7EpOzXRyd6ODwWBf7j85j79HW6tGp9GhWlqjHMQYGGlBKoSy9FaU4IeWkmZAGqwhAb9oADxBn6BKy4NrQ2tMkMtdUVxe5E4pqfIn6QzWZjk9/CSa1ZjZv2JeXQaDoPHrxCNADIBasbgaxDydb1NeqwUQgb+4+W3batGEWkfymdaJxgOiJpoHCJyWmrZtmLaeLe1YXLazDyEiJeMRrxshdJj891DoAAf+M6wfNkSQxavUYo/P5zd+6ZR/79X2HcMbGEb3tpKXYumkxTlg5iEXDdTTrkTmVSESIuEEwpVTIMo12WuLI6AJ27Z/B/Y+P44Gnx/pGp7udKElQb8SoRRydbon/+tkOlsSxvu61Z+KKC9fik+LKL3zkc7+d3Tva+kacRHh0+8EvtGZmr4+ag8g7XUBEkEUOLgRkaVYjlTSgAkra0lV6lDwlX8vLLEq0Wgt4xaWb9OlbliMdO4SLT12Jrw/Xzzg8lT2RJLWAz4avptQXc9YmNDwIFlZocQaa5qRtwxq7yPFZB3kX3jRXJg991gBcNh490F8EcGaC9kLh7G2b7jply0rkM4dx4qbFOOvEJfq+HROs1ohRltJvc1AmuBxHYkBEkS+2JziYiM1xSvaUZ4NiFWpJH+7bPo7dh2a3ijhG1m7jigu26E9/5EUY7lf4/i934j9++NT9h6fyz9RqNUiloKTEQH8TeSFxdLzdOTq+wG5/6CAWD9Wxbs3IM8uG61sG+mLUEoFEGAXWSSWm51KMTXW+Nzbdff1sq0RRmATbei3BYL3mJ4b14akcsbfShHLsxuEA8VS0Bph/C+3uM3PNmWJ7TYjUguCng+akAOFcH0Jy5E5KHUD2Cto2DDVnV2pTPZaxytFi4TOcFXMnpDOYPBsNKN8ejcOMyRrBSuyJRJQHCk17WjqkR3JLipAQKrMFJLnPsSMDS55FqHw58zsSevlhNbHTqXbicM6c91FdbNAuHKA14BWrWTUtpQZTDLWkhiSpoZVluO2xcXbbY+NYPpTwtasGp9avGRpetaSBRYNN9DUT1BIBwRnyQmNmNsOhsQU8s38azx6cYxNzqSkp3aiBRRxSKegSSGoxsqzAf/70cdbsi/UbXrAZl563Bp/4P5ff9MF/veWOo1P5wSMTc+9/7PFd11946fOgpibA4xiqa904xuxBMtrtm9RKQyo9ZtJblJv6ZMwE53jnq8/GcF1jauIYtm1dijM2Ln782PQRJoMjGp2GV9pvrNfaJhFXV7YdQmZVHQVGhoUjcvam16oGMLgKvQg9+JWcCr+5WRnoZhkWL+rDi6/YBh1ppO0FLFnUxEsu3ox7nx7zp+TYAokmHKbBACF4BCAHE8K4jFEMLoQTRkJnkiW49Z5n0UklSlng5BOXn/2Zj74C61b147e/eRif/84j2DPauaBWq1kLy8GYQilLcGg0mzHAOJQ0LuHU9mNbAZMNHUUMgjEoZU4yLu2qCGcccRxhoD8xVSw13J4zoyC4Xc31gW0Hl6x7FNaJd5PGzkhSduZNeIgK3W75FMRoDN09qgnjYCGTSCxYoFx92oJHRKQcvOtJPTBrPor2zCLkf6DQQKvUptec+4UeEkKyrL6bofLwSoGUlOkHd24IcDwapXtAaRsBoiJPwY0NVpEGSAnk0pDhCFahHRKABmxeZCUlJTA+XlsaFAdG+ZLM5jNKgGlT+LKvD7KUGJsv1Njc5MiDOyYRAWgkArWaQCx4XYPJUusizyW6uUShTO5Ys1kDYJGxVBV5bNQT5FmK//j+Y0k9jvNXv2Aznn/BevzddZce+Ojnf8fm0hy/vOVxXHLNFRBxP1Q+jyiOTAoRGR+tAG0SXbNcodTs10oZmwRLD8EFOp0M5562Vp9//lYwPYuFdgurFy/Gyy9chweeGcN0R6GecH9UIgEh7XUIrQSHCJ3CF9UJgApfeW8eTgVmu+BlaE28sNqm0NuGVhpSlti8cbW+8qJTkM7NQ0mBRqxx+QUbMdyXIM9pQ7YRJApeFqWcB6RZytUwFs+ubBrimkCniBIcPDqPux4bu66UEotGGvjkR17+0FmnLsUDDz6LT3/zITy+f4HxWh0m6dXBQyPgWqMozGkuSknU6wkG+psYGurH4FAfmn19qDWbqDdr6OuvY3CgiYGBOhrNBCJm1lWUDmGRsGqrTIhu3Cr8cKFEa28siGH+pGKaiT37yyo+HU1AQnxV5EC1x8P2KcitLU1x3L2ep6EbR8+go+DMhA75rbxc6F6h88+gnB8zKUKU52lj/vrUDuqTC2s4fyCQNR2U8iEZNqWr3JAo5sLcNZ6OhCYYKRu6nsHRz0qNe6bSymWih9c4xGiNFh0Q667RwakSCpDSHLMHALVajFq9gXqjAVGvQ4oIqeRYyEXaKkSRSgEW19E/0IehwSZqtQiEhvwqrDdopdKI6w3MpbL44g8eHfz5PYew0Crx4itPxZ+/9VzNpcLNv33istb0JJJFq6C0gIhjWxXGhm6sYtZSY2q2jW4uJ0ppVhKV1O5Qnywv8I5Xno3FI01kqTlXcrbTwiVnr8GJK/s1ZOH4FuYKUvTJ0MjHtnRAa1Jq2gEQOHuhtcXphLJYj7oLhSj8zeyRCq81gkC6uywLRILjnG2bsHTNIqSdFhDVUZTASZuW4qpz1+msKMG5MC6V1egawFwrfWZyagY8Mod4mZQGm7GuNHSpIFWJWlzDvY8cwJHp7lcjBvz1n7xAv/yqrXh2+x78y9fvwgPbJ5iI69Cag87OMDJt40vuAFyjEGVZoMhz5EWBopQoS4VSakgNSC3NPszCZOdrQkC+UQe0wHoOASU0W0E4dgOGc4e8IuldFQzdFD9Re5BvgJYo4S9EKjSJjKfF3PONUvN7X82qHmwM7nh0FAb4zT/uXT4NgNvf6EguVGWEeOw0fgVJhWgvNKbBIIN7GdXyt/qo4ir2IClPNKKnrtDYP8/1EF7+CUVxh1YrhH+uFwFobZQ9oVZatNGkxEH7W5VdqaYaXebEqygRiGoJoiRBFCfulHZZKshS2pQECyx0bxcYCg1EfX0Ymy8WPvvN+xbf8dAhZHmBN117Jt7+0lP0k7sP33nb7Q+hsXgleNwEYxF4FMHpAmWUopYSu/ZPop2V0NAmX9JuxTF1wwaXXnHlmRCsgCo1kriOhU6OJUv6cNlpy9FfAwopj0fOFn1RIjuFSlyqBPM8IIxGckOI2lWh98wKArPhe9CkqTLNM9xeoIE8l1g80uQXnbsJSmZQhQIXMbJcYrAvwjUXbzadt2VvGCEFzjE/v7Cw/ak9Fg6bk4SMgjFop5AmXWKhXeBn9xxAmhX4w9ecq9/z1oswfmQU//Gde3D7Q0cTcHN6ECkvCqg7N48LCCEQcW4KIkYccWQ+c0skmg+M0ZK2DyOSMnDHoNvxk7JypAqAk1cAlnKhexYIveMDehlenfSmm/TZP5DiXqyiGHw+WfX5BNerRsq7VL7vysbXHOIglmtKUA3SFQjVOeQXBtt5cI19utPN2imkcIwV18LRCAFPAmWlvVwyd7+uuJGern4Mx3shXsqpf9X0Ch38CyrS2nkQ4EX7fBUgPuqPqVknmNvJCViPBFpDKUBrATCzkMV5hCgy1X3jOEIkBISwylUzQHvDKjWDVAz1RgOjU53pf/3m3Tc98tQYGOd4/zsuwcVbR/RX//tWFJlEfWAEPKqBiwQi4rb/JrcrzQs8tXsS3dRs/FZSuqIPnW6Gl1yydXz1CUvQ7RQ24VxAS42iLHHRWSdg6XD9XWUuQS6GMzxOBliFL974Evon4oSxRSMTHI4hDFT61TGTe6seiIljpBd2LyzmoA6FdasXty84Yy3KuWmAmXwuE3vPce4pq7FhRf9b86KE4P4gUsEY0lzi3od3gakSgmsoWUIpU4FV6hKFzFFParj/qVHc/fhRduG2E/QNH3oxoFL84FcP4we/e/batEDBSUEaBwRRxBHHAklsjpHSmkFKICs1ummJVrfEQidHq5OhkxbIcomskEhziTSVaHUzFGWw4kTjZhpgyhzKYZWaQSH+d62V28FgbqxOyNBIeMH2mo0H15k35numfV+ojVDR6cAdZDCI0JREImXukzMZmDtCTdMxWkEbFcQdoCU3mRl1ywojAgXQg+xp7P6wDL9S6lZu7X2uDcr6DpQ6rAIIaRAiT20ViX1gUGPKFzoMDbKbWPB0JANGMZvwWg1UaEBjM6rKK1mfbuQVtGWt4w3xjDOOiEeIowiMcUipkeYl2p0MC50cc+0U8y3zb6FtvutkEoWNXUURN7G1yChF2FzGWqOGZ4/Mvf1fbroLu/fPYNFQgo/+4SXI5qZx8NndqA2NgMc1MB4hig0Ko7k+MdPFrqOtL+ggbxOAPWUeeOlVp6MvMnuGFcyKKWMCrU4XJ65fhC1rh27kUD2FHAI94nbZBKlCgf0jLpGeYoFMuiC+riAFyxinGW1INLBkxsIr/2C7f7CQpgLDGVtPqK9ZOYTZ0cMAF1YRCuR5iTXL+3Hl2Wtv+urPnv6G4AkK65ZxZrLc73viINpzLfA4RpF1wZWEUhJFnoNphm7K8d83b8fioQY++ZGXYflwhNtv34H/+v4jBybns5vjuAapFQTjiIRxU4uiRJbl5nAPJaE1EAkg4QxJPUESCwjBuFZKFRLICloh1SZhtSZQlBpKKgOzNSqltdH7N7DeLoBtGUMuJrmO3m3yiyZuLjkQU0UH4d/QFXKKkRAEWTIPcRAWoTQT6zmMEYmY9quoHLzSj+BsHmOZLUD0lR+qckW1nnzBLT/GXto41IWwP8F9WttkSi+Dhlb0HZwCZKRciS5hixq+nQpdPfF7aU8vKlnkJiI8OrCdd/3TgNNkdKqRU4yA9QpMH7tZiYV2jkgINBp1DDcT3qjXV0SC9wnB6lAKpVSdoijn86Kc7RZlkecSabeAzuxCUxKbf4Lb1XeFOEnw8I5R9uVv3a//6j2X4fRT1uCtL88xO3YA2LQc4HXwWINJqopRIhYM+w4t4MhE+n5mIbeG2XWTZTk2rBzZdNoZG4G87ep4SVtsIc1zDA/04bxTluHep8axUGhEsUApZVDOHFCMZEzZ2K03aEYoNHzZCMs6y2KbyBpKESrC1yPfRnADCO+Pu9JgnEMWJYb7arjgzI0AV8iyFEmtD0qVUBBQmiNOgPO3nYCv/fxpt4zvgr+c4dlDk8neAxP51i2roWbnoGSBPM9QlgUGm/341QOH8eiOY+yGP7lGn3fWWux8ag8+9/W7sWPf/PqkHlvFwlFIibTThZQSA40IG1cOfH7F0oHrVyztx6LBPgwP1DDY30T/QB19jQi1REBKjXaaYX6ui7wooWWBpCawdu0J+NEtT+H7v3iEJVxAxAJwUT+/Euao6HSKjYMR85kfL90bvtzyMb1jzNs8mohhHhmhC5sISsvfLuPddsagDhNdcAe+MW+UqCeGn9yVTnaKzD3fW2aQsiTdbCctZWkDcP1xo+RwypNygVwxReoy9RnB2l+AWENESIourKKq7XmCzCkb5l06D+4AMLfVyn2pKdBu2nDyravP1daFCnC1G79v3z29ojgrXoythkwpQqUsMTIQ47QTV+oztqzB2hNWYMmiAQwP1VFPYkTC9LEoS3S7Gbpphtn5LsamF3B0bBZHRmdxdHT+/mNTrYumFxaUhkC9FkEIDskYRBzjF/ftYyesHNLvft1ZOG3rCmTZLPJOC3GzH0VXQXfaLhWqXo/w9P4ZdLuFXcSxxypCQCmJK87dsHt4ySCy7pQDNGY/sZHHQiqcuXUZli9qfGruaPphJJGv8xbQnOYOApYFPjyYKwOlK3SOelfRgLAVK3E9QuME21l6bVZ+rP++ctnQ588+Yy3KtOPKqSitoRiDVgwRl9i6fglWjNQ3H5svd8Xc1ErSMFZ1br5d3Hn/HpxxxkYwmSNNC3TTDJEQWEg1vv3Lx/Di52/Rf/TmC3Ds4AS+9K178PuHDjMlYmgm0MkKpN0C9brApjUjnzp586oPXXD6Opx5yipsPGEIS4bqqEUCsdBQyqx+cKbBIwambI0qpqDKHKVSSIYHUaQx7rh/j9m1Zl0d5SgeujUhU0JoESoRknBvCLzAe3TkrtHe+hOLCKn457LKpAk5SNdwC8FDg+ZjbSbG5ZSPBUoh+gjlIPyegcrWhALn73H9DcdmrnIlyJ1gwhtUE08M6UjIy5fJQU8ftTY7N8yp0qqCkFlQTVQpT7PwVHnqfIi0QlaEfA4VESE5pfRxCNtdGRgLl5ALQ2eTBS/BUeIPXnme/tifvhj9gwmgYyCuAVoBpTRAQFIpagWtpTM8WS4xPdvBkWOz5+/YOyYf2H4AT+wYPbB7//T6uYUS9UYCqgH2zV8+xTasbOqrL9+CuclZHH52FzZuPRky64IxAcKG3SLCA89MoSglhLAo14MnXHXJFjR5gSwvXCqPgkapNcAFsrzE6hWDWLOs70O7j3Y/DBg6SalwPKKF1QFewZEb7wwe4BQZAERUTsO0Q3DcyZe3nMyyQcPDP01HU/lTtQFg9arF1687YRG67QWDIKQ0gy61ESwmsXpJE6dtWrbzyEOHGI8SSLNrwtTiKjV+eedO/MEbLwLnHGmnCy1L1PsGcfPtu8CkwAevuwaAwnd+/gB+fOuueskSUy53voOBZoyzz1yjL7/wJFx2wWacc9p6LBpqQMkc3W4bnU6KdiuFzAt7VqPPXeLMlPSRqkDENOrNJp54egL/+j9348e372K1JDGVLJV0KIdW74hQ3qAHsRMLjatZ+D1I107bcDL2Bq79BIevq+bsig9yUhuVdqwyqFYGsHldYIBFAa49O+lAfwNFSnpZ2eqqFJ8w/TA9Y86FCoQoGBvtEqg8K3TDmX8O61lm80Fej6bIZQ6/88Y5UFgBXakyh0+uDXmH4P6enDxHlyo69DY+nEt+XMyT0ru2AQoXkcD0fBe7j0xhEx+B6sxhfiGDFomJZ0FCKqvIygKwhj8SAkkcY7ivgZWnr8ZFZ67D6198Op7eM7Hud/fu1Tff+tToYztHV5aao1aPMN0u8eXvP/rp1asGPrR54xoc2LUDA0OLsGjpEPJWhKIoEYkEOw7OY9fBucTu2gdgDugtZImhvj6ccfoGMNUx8TAmzDqC8ichFaXCYH8Nm1YN4N6nJ6E0IMgjCRQ9C4hXqQMHBHJHcgIwGxQ1uMky1TDMKCayrGbJveoyOJviAJu5Vtos7A1rl2FwsI600wbsFhQNW5CQmUS7ZjPG6VtXODTnLTADWISHth9gjz+2F3HSRKvdQk1wzHYkHn7qAN7z5vNw6oZh/O62p/C/P9/+05kOy/KsQFkUOOvklY/91buu0P/xsVfib/7kMlx+zmqgmMeB/Qexb98RjI3Not3OkBdm+wiPOETMzUbXWoxaswllayKxqIbbHziIP/2Hm/HNX+9gnYIHcRdAam1XObVXVAH9Qg/GCT4Jsw4nFln06ov1vKlOEquQAuVlp4fJ2QrRMXMUds8JV49dEBleOYaxMPeZhd/7RQPznaKGbXBee7QZ9J3aqtb98i4sfceCcXG30dD30RTiZABjLjbnFfjxlU7CZ4Xj888LFq9CXjzX/aHr6N74fKweIA43VYiG9r3jIwyCEkJAaYH//MGD7A3v+Y8bvv3Dh5DxBpojQ2ZuxRHieg1REoELjiiOECcm6M44Q16WmJ1r4+iRaRw6NIHOfIozNq3CB9/5fHzxhleuuO7VZ+tlw4nJ1Ypi7B5NP/xf33sE7XaKgUYD2x98DFmeod6sQZUKQiS46+GDmJ/PCiEIdjEIISCVwsVnrNVLVo1AFpndwmV3YWiYnRsadkcOw8bVgxhoiCGptMuTDCeG54z51Ct/bueDnV+kybipnkvSwpyc9E6m3i9IwdF7zjmkMgl5G9Ytg4gFiiw1D2QKpZTu0IBCAyxmOO2kZYgEQ2lLL8PmTUWRQLvdxa/v2oE4jlEWOeJaE/c+uhsnrV+OF12xCXv2HMI3fvowdhxqvyLPS6xc2qi/6zXn6s//5bXb3v/WC7BiscDhQ0dwYO9hzMy1zGTiDIoBSpYosxxZmiLtdJGnGRgktCrRml9A2m2j1e7ie796En/6yV9fds9TY6xeq5ls4mAbRZUeFX44utipbv4yZnfiM8CWFvHXWTJXEAjZ53CCWT7RMzStHgbICAH87nX3QiSFKhohiaFTiBiYO2/RxXsqCtOiiB4U4sYKIKzkEPalV0BDonqFi4qMeTDo6Umrd46mQekev8LJ3P0OiXlN4hVNIPte5Xsj4MZJ/SKU5gahPbJiPSOj/sDTyEIJBwqUMjXCBgf68eyxzic+8umfsk9+6ec4OtFFXz1BqzWHhfkFZFmGokiRZR10u11zeEieGyTNmYnPCoE0zzE2No7Rw0dx4poBfOy9V+IT77tcn7V58WNlnqFUDPc8Pct+essTWLpoAHl3Drse2wHGgYF6DWmmcf/TY6kSzJZutuOwXsTlF5yI/r7IPFuVoFMilEX6SktomITdjWtHMDxYvyGsRccYvACF8hnIgCM4fBoMyFdhQATtV2LgUFgAeZkP2ofLl9yd4w2b3M6hpcLAYBNrVi4yia2lsqVCJLRmMOu6Jj4huMSm1cM4YVn/6/aPtr5XSzglaYMxDSmB3z+4F+99w/kYGR7GvtEFHDsyj1e/9ExkWY6f3LYDdzw6ypQscOl56/QfvmIbrrnwRCQocOTIAUilwCOzR6zIcyhp4nTSxhGgTBldrY3PLrslyrwEUwpZIfHLu/fi3777ROPYdJbWazWTJiF1ECPqnXAerVKsi9kN60xbt40o5pCZoQdtaTHyzBxCcUpMA37bC46r1VXZiB3w0NgjhVARkKI5fmWtqmBoFofQHk7ZkXK1Y7a3uGVyV1nCt2cEl5JPtXcb7Bi0UyaWTgF6pXVcrau/u0z30KKwnjHBr6L6PlfH6J5vh+YRsflecDost+qCEiILUZ5DfgGNKJ5EStMZO/ssV0UWBtUrWWKwv4FOVuIL37ybHTg8ra9/x5XYsLKJqekZZGWJei2G0CUYo3LaGrxUELGEENos9HIGHQvIvMTY6AQYA15y8UasXdm37cbvP6hvuecIm+sU+P6te68/f9uqL5y8aQ127j2IkcEE65Yvwj1PHcTeYwsNHpktRoTUi7JExDnOe95GJKrAQi6hpIYWpv/aljmiNKY8L7BiST8WD9U+tOdo+mHjJZiQSojSw9goyQehVYqLheXUlVaIgjMe3GShKwJeOisRWleAVRfEoNGoR0uXLmqaUhwwFSe5MgXPQoSglMTSRQ2ccuKy7+47tsAYM2V1wJj1Dzj2HJxMntw/mZ+6eS2evv1XOOf0tThpwxAeenocP/3dnsf7aiz+4zdekr/ztduwdnGCybExTC+0AB5BaQGdl1BKQypu27XJhjZRkGmFslCQUkGWGSLBUEiBW+49gK//fOe6ifkybTZqZoFBA6Y2E6N1DZhVP7+C0uuGwE4yHSZws4BBZIU0ldqm1Vgzyd0Ep7YdAqm299yBdj8BQ/ewNybmmulpk9p1irTiBvk0Bz/3THvm5GRmzgrQsImYfrU2VDcVIMtgPQHbPqh4uA7G2KPEAoXvx9FrwWFDu8ypktAVJ1Tpae0nCOuRdQT0N+dPAiZ8UkUGrmFNLXoES2ia4JwHB54QWpvy0c16glLH+OHvd7CDozPH/vydV6w446QRtCZnMDGWQTAOLgDOBGr1GpI4Qi3mqEUcSWz2EVOX4kQg7eQYG5/BxjUD+Nj/uQRb127X//ur3W/bPdb64rd+tfMLn/rQBixdOoT9+w6jr38Dbn/8MNLcVD1WoLgUkOclNqxYtH7jiSuh8g5kWZpKv1YgzF5l+w9AXkj0D9SwZKQOzmYsiYJ0F9Ixjuo9ghH85XQ9M3orqqzABIJZgduMuax5OmuvIjCBG5IkYnigGUGVJdwGP7JoyqxEaQ2UWqNRZzht01L8/M498LMG0MpsZ+l0suJbNz+Ba6+WWLVsABecewKkjPC7e/ag081v/uPXn5u/5RXPQ7s1g99uP4JOq4NGzJAkMaAFRGySAUUUO6FRUkNriaLIURa5OelIAzUB5Frg1oeP4oe/P7BiuqXHao0apDSF5hgTpm+c6GWQIkCxruNX5wgdheiBjj5zexXhZNldT4iA9opW6OzQASpap/fZbgoSwqAJGvCKrJsP8HvBouv8qilcTXuN/5fSJKXI7FZOp9rteH2lDOpQiDKrBygzEgfbR69vKzGrAAF5NzpQR66fPofNNgLQ9XRQrnM7q5beYTlHIx00Q8/TjpbHxdeo+J9tJ4CeFYTr3WrD97woEUUCw0MDeOSZ0ZUf/fRPL73+rRff8fyzVqDTSTE+Pot2Ciws5MhL8ngAzjXiSEBEJt0nYgy1GkejlqCvniCZXsCKxQ286zWn4qLTlt/02e9uv+nBp0Zf/9CTh7577jkn4eD+CfzoF4/iN/cd/TTnwlbrsJ4XE9C6xJmnrNnXt6gfeXfeyaumvco2H0xro9SoVthAn1kLIHPWu5p7PD0oIwABj2ERvOF3FFpkJzeBVXfsYwThbIyBVycPLdEnUTxci2No6eupkxlgoKqixh0TXGPz2iHUY2aT22yZasYgBINUArfetWPZqeuGxl/1os1oNGPcetez+O29ex5fvmz4htmuxF9+9hc4dHQCNc6wcfkgztg0iJXLBxAxCRaZZc04Kl1dMcBA9DLP7WqOQhwLzHaBWx86hF/ce1gsZEzVGglKKd34vER6GhnF7g8woO0V4UtruLMYvfIIUALR2mkyO1lsENy48OYAWV45xdozMXymV5zewXIxI5tzVJksHm44SfFKiUSNrgsWBSpy05NYC+2OJjPzlTtko3U4iUk1BM8nAkO7E5nNmJ9jjIyUmU9ydL/RxGBVm07jDo+zCxUd7LNCOpMydYtarvAiwEI07nvhJ5rtIwfFwGi3inYVO6oGgXpk55tUgGYYHBzA0an2nZ/4j9+zo9c+T7/syo1YvYZjejpDs1lHu1NgerqNdlqg1U7R7hZodXOkpUaWSZRKQcsScSzQ39/E2qV92LJ2AGefugzve83p+NL/PvTd7/zsSZx6ygk4cet6PPbMFMYn2x+OIlOUkAkGKG6rJANnnbwa9YQhny8t8mJu9GaO+aC+LEtwKPTXOSKbAiMCr8SFJUDGUTmRdGW8neKqwDV/sC1QtXKOkBWj5a0UnDX2zAEYRCTqSRy7Rijmw7UAi0ypXQOdFRgUVi3rx8rFjdftH+t+L67F7plaMTAlseXEFeMvuOJ0DDSAux/ej3/977vTw5P5mZicxh0PHwADcOqWFd89feuK1114xjKcsCQBZxK6LCE5BwM3yX+M2WoXZlMtEzDfI8b0gsKvHziC395/lKXSbKBVsrR04m6yGATKveukfZ5RNRheVVSVuFfAqJDAHlFUX8wqHlO3KlitI+VFbfRM4mrzQd5ewMdevtKE825ZqLht2+RSKtoXST2mjd0UFzUYn5FQ2tYYQ3DyMgvQjInj0HY2Qn9Uj/65znU0dOZh9xx9HPJRyi7tE+1NhMLtw6VRBsYkiAQ7o15V+JRHpnv6Y9MxQuWoLbetwZe0WkvPBACtbMIvAUPt4nsAXG5Zf7MPC+0OvvjtB9ix6Xn9phdtxshgjL5ajvWrhsH5EqRpgU4rRzeXWOgWmOtkmF9IsdAtMT2bYWq2i2f2zd70wNOTH4BWWLUknjptwxI0mnXc8+T4th/86qnH3/uuF+C1r7wQP75jh77v6VHGIwFIw3sKn2w+cQViVSCVZFyIUJZfUprN/dqcE6C1QiPi5rBqbT0a2JLTIX3JlrvT0KwR0gFNAwMWMW/+rBD4HI1QeYXCHgoOIS9CIZyzj9OWCG7/aZslzbmtsWU3tXKhMDzUwPLFA9/dN9plDMz62gKl1OhPBN720jOxdfNiPPPkAXz563dj99FuQ0cCnXYHJ64Zft9LLj3pC1dfsA6rRhpQsoMybaPMJXQMKAEUuUSWKVtFgplDZ7UEYwYhjk5m+Pm9R3DXExNMsghxLTZldXU4LqIboRFDLJqEXgnBCjHcP8AWbHRuOkk1TW3L9ECoK24o/LIzq7hHXoFpci2prwHfHLIGTHE6N4bnRoxhuMCp49DNc226DnvaaLKYpNAp41/bpFg4Q8Co/6S4ta64V+FexUAXeCUYKOGqMvbBZrP2zivXu7BIkIxZfQXoiwU890MFGXviqWk39Dg8nSr0CnjzXNdVGAcHOixtGQql0Gw00O108e1fPs1mZrv6D19zBhY1EszPttCs1dFsRuiLBLTkUDwGWB+kLCG1Qqej0elKjM2137Z9z/Tb7t8xecdje1vs/meexfKhGhdRXP+fnz1xw7nbNnz8BS85B3/+jovxzr/5IW+XWnGbB6Y1g4gEVq1eDCYzY8cYc4nDBrSYxSwtlS1WauZ7FHN7FF1IaYuyGYcOF5wIBcMvgDB3TqllhdJhTXxviarzxFtt/9dzwqMAwBYHvEFKeYdzMRVMTkgCs4XFWm9CG826wLJFfU4omHU4SiWxZcMy/ZIrNiNtpfjVbU/h8d0zSVKvxd0sKy48baV+/Qu24uytS8BZidnpcUArJJFBEVkqkZUSpdIAhLUIRjlzwdDNGHYdXMCv7zuKx/bMMR4liOPY1e52rlyPwIULEZVAOGN2pc3QjjK9uQtWElG1mzyhK0InZh+/OuiVTZg7Vf29qmScWDhE75EduVuh8vJuF/OHj9j2yNL5MuVVJBa6mxWFWjlIg3Qr9amqqCiWCCBI4QjGBVahv3c5nkMJkQVnwWqsUzja0cW7xDju5dFcgK4qRt2u2FfccavAQWkcPGivGndkPXOKOk7iZJqzMmiRCBUDVFKhXq8jzTL8+t59rNXu6Pe/5TysXjaM7nwbZcnBtVn5y4sSUsHV0QOAZgJsPqGJTauaOOPEkctue3xKP/T06LUz8+nNDaGL8cn2Jz7/P3d+/IxT1+HFL3ke3njn0/LGm7czIWKAMciixMhgE0tHmoCtSmGY3rOaqI0C08LwWJbKeSJaApo74bTTTTv97ehf2XYWxuo9X7knIjNZHH6eWTKHCXqBVSRxCAwxY0ApZaeb5+CRCHx7u1EW2mQOK0UpX6gnHMNDddcDAVMXqR5rvO6FZ2Lx4j7sevYobr5zFyTjhZaFvOrctfr6N56H008cwOz0FGZnF8CFyWJOS4a0UOhmpuyz0va0Y7vyWJQlxmdz3PHEBL71230ff2T3HGNRgigSpric9sx2SjUAKb3uYkgRqvTgrbeHw2HFVBZUg/C0Y/ZZYS5MVZF5QxMgQQbjIPagItJDrj03EPODOzbPukzu+QGi6o3ZhSt0dE1IJ2iSCreb0AkGKWyvjJjd1GzdxgCdhJU94P8EirsHGQXIhcZB1xh31/1aUbgh7T2DSdnacQHW4Pr+Ey7wiu14voUv10dNQWq463ou9cjUKvkKXrBMLaVEHMdIajXc/cQY+5f/vBsHDy+gf7APWV4gS82htHESI47NP4AjLxS6ucTMdAfthQ5OWFzDS89fhhdesOanW9YNdYs0KxqNWv13jxxi3/re3SgB/OkfXo6t60aeUbI09fmZxlB/bVNfs27jc7bPsKuQDECw6V8pCQWNTCp009Ju9CY58bGu0JIwBnfEXggYfIzVhmAYA2cuyzmcJNoSL1y9CnhMmc7aL5cS+fOimG0tdBGRa2TbkWUJqUp3TBnjDJpxiChCX6NmO26tsSyxYfWiS1/5gtOxMN3GT3/9CHYfaiWRYPWXXnKSfO8bzsJAkuHo0UmIOEYcReAMdoNriTQ1xQgLBSy0c7TSAt1MYWa+wK6DLfzqniO4+a4jg/sn8r8RSQ1CmLLSjkjOUj+nj+GrMpBicddaZGlp7mjjjItlKtH4OMPgSA93U4DC/LXeqBCT3UdietC2Pu7+gKmB4nANBteFf52Oou97nm0koLrySYqtstig/e9uA7bSFsVV++HGEKBOzv39FeEOh8GCA/uY54Onb7Uvlfc65GlgpMhNpr7YTep+vKRtQqIy3xbRgJ6hArTirjH0ou1pXoYkHJKHhlYSMQcazRoe3z/LbvrRkzgy2kUcx1BaIctLtFsZsqJAqYwB5xEDFwJcmBLt8/MpZJbj1HV9eOnF6+pnnrREF7JMk0Tg33/wyA17Ht+N9ZtX4T3XnrUltkmqHECzEf1LFEfQymTZ+TJccDwn5K5Ls0cwywrMzmfIc2V1sXZoU2uqXBzQvBcoBHON0jVg+2OFSwRG2iIEzp0bxXpWr46zHdq4ZnlRzMzNt+13RhUoJVHKHLLM4CslAZoBIuKo12Mn/FqZ8jUvf/7Jd2xYN4zHn96H396/H4xDvPiiTd13vPQ06HQBY+PTaDT6wThQKolumqMszKpZJ1WYWSgwt5CjnSlML5TYfXQBD+2cwG/vP4iHdkyev9DRC5GIADjD1qNQNHkFlYnUI/tWKGHbIcTmbzShGGKMnzpuPjnIy5zro+BrtR+/ykh6J+wLrXAxUD2x0D08/r0XDldqORifey4CFMP8xKSKpuFzeoXtud5T284fJZc3oCFRyZ1fCc8DBuYOS/F0pBhJwCdvOavjJkTbQxf00MjpIEbjDWFnFZ2GEy1Eg72xRU9kOB5QThgdaEGXhYiT0Kt3r/yzSqnMRvCohvu2j7Fvfu9BHDs2i0yVRg4FhywVut0caV4gzUtkaYFSlsiVKa4gFcP8dAdRkePq89Zi69ohzTjDgfHWJ77yzXuRZhKveuk2nL5hsdaKkF20hXMO0MG7GmDBsoNNojClt63iS7MS0/MZCmnGbbL1PWLVAdL3JLPyYf8zjVsqWxfbuZDMSY8XcEsxR73Q+mot3UQn6yEYR5qV09OzLbhtHUpB6xJlkaHMMi8QVmsLHqEWR7bLZjvSsiUD61//4tMwOdPBd375OA5PdBdfeNaa7ttfdip0dwFHj00jqTUQCyDPCnQ7BbJMI801Fto55ts5OpnCXFfj0HgHew/PYHKug5JpbNq4AidtXH5/FDEUhepBSHBWwLkeVvE4C9qTDmFoQC6TVSsBc0K3zyvGquBDV61NiFAq4MjxwOdikW5x2fxgx02eEC054aA+BGfw+QnjFUwoB0Y8zPkCVYQWpC2gB30GdAjlh7l7AiVHkxWwUQeb2U99Z75P3rXWoD2RHuX4+JyGRzphfpunXZgyESIej6N8Kkcv/QzG43SSV0VxO+rDnaZFY6D7md3l4pQaGbYg8YPkMeSlJTJjDGUpIcsSp560Qp9z5npMz8xhbmYBc/PzKLIUWhY2vUOjLEoU0hQwaLdSFLJEmktoFqG1kCFrt/DSC9Zh49Lm/loc4Ru/fpY98cAzWLp+Fd78srMQc0eXOtPMrCYKcwihppgn/PzRdvM5AMx3JKbm8lQqPy7SLd6QB2Nk1bYcemZW+rVRYpyEQyGwIgTFegSrEipwwuiFjjOOblriyOgsdCHBOIMsTTqCLEsUZQEpjRbXMKhPRJHNvPfC9KJLT9m37cwNuO2u7bjjwYO3nLBicOoNLzwNzbjAobFpSMVRjyNoJlEUEnmhkOYac60Ms+0MC5nEsZkM+0fbmGsX2LhuKa66cBNefc2peNvrLsC6E5Ygywu798y7bL0Kg6YfA+yxbt4SkLtzHLpxcR643ysxKwSBcboX/owBQgdeWKvoJUQSqPSFQWkZXGfHpCkFxD9ba59JTkhK2zG6yRUaMep8AJxCpOCUpg5sYHBbKFIeoYTX+SPmuaWXtv116NLKoHZFcVXQlpdV6jNtW6puGof1CKhtWOUYIrLq8+hzZSEgMAYBfoU/kjBU4Hb82qM/N8G1pwU0rcL6dJpKTI2UNQ9/N21neYEtGxbjrz7wAlxz6YlYu6wfCVNozc9jod1GN8tsXpYpGyVLE8pJ0wJpZpK5k3psKhF3U1x11qp1K0bqfz3bTfHlb9yDhU6JV738eTh5/YjWWkJLnSqbCuPKWIcAygNKQCkwwTE128XkXH6d+Tk4qZ6EKZSXwGC5E8MdYT1PmGYGgTk/PBRYwxLvrrAq0TWhBGvVpFYQgqObK2x/9iimJucRJzFkmZlVECXNCcBSWdTJwHkEgCPPCwBAKYHliweWvuctl2BsJsUPf/kQ0lLd8YKLN2LVogae2TOKrCzR30zAoNBtFVhoK8wslDgymWH/aIrdRzp45sAsxqfaWDzSxMuuOAWvesEp2HxCE4uGIkwcncZTTx+e7aZ0DJWGj11VfXBaNaP4ClnhCsR3f0kRULY5tWcZ6pAcTR5W+Z2IGrol5iu/OZn6QvR3THfoLkQ7fnL4+/T/cww0SXonZkWZhuNw7figOawBMq40rappghXBs8gt8m3TeYQWzx/nnqHSb0It3CMhFlSI7ZFlDXuqEhP+Gx2sfrHgHuZ/e66xU4zPjOO5V4W9og/4AU8Lp7gDREmYtHe8IZe129niSAohBMA4ntx5NH3ggV1YsqiG009ehnPPXIt1q4egVIljE7M4NNbCsckUU7MFWh2FrADyDGCRABfaHCHBBSYmF9DXF+OskxZ9fKAe4yd3HWAP3/sUlm9ag1dcvhWCa3Sy4mYtFSC4L/gIA2a8GTY0K+0eyoPHFjA9n3+DAvxKBqEkVdUpzhIGvPQGvsdQoceaekG3yIFbQQF3Qkkd9C4RoJWC4CbMt3Pf+E+f3jOKRqMOpXIAFICk0jrwUJ9FWOjk9tkKL7jstPEzztmCW3/7KJ58Zvx7G9cMf/zkDYuxe98o5hc6aNRrYIJhei7DwfEuntgzjYeemcBjOyex+/A8pmZTLF40gKsv24I3v+JMXHjGKjDZhSozRJrh13c8i+17pkYAWzO8F2kEAlkNPGsn7L3CSc4GCT1tcDb3U4zGXMNYlSnhRFVh26wnlcAakgqyo3/cnukS9hekhKqxNO3u761t5RVWpX8IEV3QH0JIpJCZX1ntRS9wR8GT4qZ76KsQZfo+BAyxaIpkz8M3T3NSatUxqPA0HKCHRtVVVc9PujqgT4CgQv6HPPQIuRpT45y+87R2ZsLxxj9Tq+Nlo+JeEZ9sTmwUR9h5aK7xk9v2A7wfWVZgeKSBs87aiPPO2oQN65ZAaonR8Tb2HZ7HnkPz2He4hcPjXUzOpJjvSnSyEopxxLUEC50ulozUsWio9sGFrMT//uAhdDoSL7lqG5YM9711aqb94VYnhYgTODvE7XGFboKY2DcA5KXCzgNzaKWl2RNtk4rpP09okgsOzXxhTUcZ1jP/GMxWIoawiJjNE9LaxHukQpYX4FwgtmWUfZIhoCXgD2pViAXH0dGFV9z76CF95tYVUFJBRGYPIm3W1jb5jcNsU5icM0H/4b4af+drL8LMTBu//t0jKCTfuWZpP/JuC/Nzcxjob2K+nWH6WBdTsykWujk0Exjoq2PV8iGsXjmMtSsGsWHdYgz2N6BlinbaBavVcOKpJ+Om7z+Gn9+9e7hTSCRxYojYU4XWW1MEU85bX5DFBwuEySsZisMEVK/Aa7/Hzis9T0zPTmYRHU1Kbfnh+xiimQDtEHOdNQsC5BWURsJCFtDHjMJ26X5LHbisa0JP0GDalpEGXGoEo01vdgDu6h50YhQzq/bd9SGwyscZDATjDs5msJOd3MrqfRVdGdDB52CxEKUFiNW1oVHZ0eDGFmSOV+gIwG+zYe55rpjjccaz903w/OA6wxNDz4gzzKUlvv3bnW+76Nx1N734ivWYnZgA5xxrN6zAijXLcNrEAvYdnMWRsXlMTHeQ5xJpVqKUJRZaGRSAsmRIGgkwrxBHGiPN+OOTjeQzv7j7wOD7ntg5f8a2Tbj47PU3feeXj3/j4JFxrF+3BYxraIlKuR2AwSQTaDAmMDGdYeeB+e+VEohj7Q9GDonkChWbo9qglTlgmnb1kBIn1GwpEjnSOhMLZ0lLKRFFHMv7B/hCK1O5UogEN+VoNIVhLaJgZs9eHDPMdwrc9fA+vO7Fp6Bej5F2U1MGWCqbH2YmDucMabvE1HQLjHFcfPaJ8uKLTsZddz2EZ/ZPpQON6F1LFzfQygq0S2BhqovWQgtxLLBm1TDWrB7GimUjWLp4AENDTdSS2PjXpUSeZlBCIumvodm3CPc8vA+fuenhD43OFnNxXAuUiBeS0DozI7kmUAmqfEqW2J/8bISfhDOchGaSe7p6VObat5bYuWuuRT9JiVHUH7I8/vkUt+y9x1upymevSqA1gm1gngZwfWQ997pPCCdjoCE9srBVO7RFjmCu3F21l4zG7A2Fe55zuZjbU0i0oy2ohOYrbluP8jq+/zhuzH4LUGgUmDNcTomy6u+eE8Rnq0Bd/XbLP7d3OCzyGCho1ydC+sxtq7FUdnPTSQjn7vpaPcLe0dlvfOzfb7thzQmv2nL6KSdgYXYCUmrwqIa1JzSxZu1KpHmJVsfkinU6KdoLbYxPzuPYRAs790zh2EwXMzM5li3rw+KRen2ilb/u6OjC9265/Umcev6peNNLn4cf/WY7djxzAM+/9GQIAUhpaM6ZR6RMm+RbEcV4at8kDk10Xk8S7lxmpcEiK5NMI+IC3SzDYF+CreuXd8en5jcdHp8/GidxoLzJmJjWgkRW+t2uKApTR2vN8kVbP/HX75Rvec1luixKmINhTdo/s6cykwRKy1SlNB7fcWTxQ48fRrOvD2VRWsirLXxk0MpsM0o7OSYn2zcO9zfwrjdejEymeOjhXZiZL29YvGRwhQTHo8/MYmxaodmo4fJLTsXbXncx3vKK5+HqS07ElnUjGOoTkHmG9vwC0laKMi8QRQIDzRqSpA/3P3AAH/yHX93y7KH5z3ARwaZKHmf9aOx23jhNbyZQdRWJhN8lNwaWn2IeoEl3nNUPkAgxVHtpDYWaPvdeGy4mkDIKkYIObq7E9+w/5/4D7n0lZkOTqvK51932E1PpoDSMNWaOdtobUId3e9qnF0OVht4Y+P6ZQ0KI7se3SYUiQ1r3PoO+IwRXUe6kzJRHYFWgrCt/HfrtMWT0f7/h2/Zb+9Qaj3KrMTRf0SFElMEze+SDKY04qeGRZ8a3vu///gSPb59Cc2gxkiQG4xppoZCmJbQEGkmCoaF+rFy+GJs3r8FF52/Giy4/Ba9/2TZcffFJ6GvW8Oze2Z3dAujvq7+VRRy/vGsvJg5N4bJLz8BJGxY/9vAT+9AtJOIoNgsLjIEJc3yiWZVkgGbopBoP75xGq1sCzJ+jSvMDyij7SEQopATXEte95TJ90+feU7/4zA1HSilhavR7OQxRLjfaUofkBuD2nmLt4saO17/2YvzFX74RF2xdprM0BZgJiIauERljU90hwrGJ1vRPf7cDaSkQxTWzlUdQ8BemcqQQaGcZZuay919w+lp99QtOxcLkOJ7ZO4p6X+OyqFnHU8+Og7MEL3/hmXjLa8/HeaevQT3WmJmdx+ixSUzPzKLd7iJLC0AbN4ZzjkYtxlyb4we/eAZ/+Dc/vuyJvTMvjG09ew34VKRwAgXoiNY9aFXMAzYTqPcxIgrE24BygKZC4aYCf+QyhcrAxzvsCeRu8pt/LtmTjBVZOTCEgWTuYilwDHYo3Slgj++4V4PQ2paADpCombgeVXl3liYjIR7zJMrdCp9XRXVeCRLCqgZoq7re30ffMviuhKgFlffM/W4reDgNF9COe6UQKg/Wg7BIibq2fVOVFyFqH+PSAa/9KmYQhw+e1yt/rLpzo+cfeQFOiTv+A/VaDXc9Psr+8KPfuf/Oew4BtX5EiQAEB+MRtE1VKvICaZqj0ynQWiigJLB08QAue94avOsNZ+HSc9ZtydoZlMLc4uH+gcd3jrGHHngKfcuW4A0vPHXbvgOT6HRSxLUYnMHqA7s/mjNoLRHHArsPzeOZfQvXSAXwyNnPYPCAEBylUsizDG942fP0n//xJVgxkkJn7Srbe4CACUMFkMzB/cACjww10R4/iE3r+vGZv307Tt+w9CdFnpuMXu5hI01uUyrDHBp7xwN7Ft/98GEMjwwjz3MrEKZMCpiARoxjUy1wzta+540XIxpo4IlH9uLR7UdTcIbRY+MHzjx5Nf7ifdfgvFMWoTW3gCNHxzE/v2AnowATsalcwTg0s6WpucDT+2fwzzfejj/71G/Zocnszlq9Dq3NViEWjNdbeVQmkwyUiwvDBy5FWM+rKtK6IuVaa2ctldJOCdFEdv8INQRuQxhrJDQXIhr09LuK2qj/VsHZlJEw3uXuDWmAquJxMUJCMgCobhcYt6haO2XniBv0g2yuR13M7sgIF4W80gWqPKG7CE2xQM3R42hih88J2wqVMhVdZAEvQpr5l0fk4YtZelR4Qfdrj5RJ0ZrvKQ2kd5WRubGFfKDVTj+uoC2H8ugH7wZxaDQbdTz27PQFf3TDD6797s+eQCuLwOMYUklIBSjNwLidOzB/GYtRZAqt+Q7WLK/hrdeegte+8FQ0I/nyiEd9aarws1sew8LcLF75wm3oZgrTY1NIeAzOhUt6N9Jm0iSKUuOuJycwOtP9DbmVrttaA7ZKr1QaeZrhTa84T3/8r16ORZjHkWd2oJSFJbiVAV3lo4Y9pS+YC1YYPFP7BvswPNCH1tHDOPesNfjCx95y7dYThj+VZRmEiFxNIwsNTPcVkCQRjo4vTH/rJ4+ik0eIG3Wz19DWhuI8glQcu/eM4aQTFu285iXbMDcxiZ/97lEcnkgXp93OHa+6+rR1H37PizAQ5zh4cAppOzVHqguBspCQhUSZ54ZxHADjmOkq/PKuffjwP/0KX/7ek0xpgb5GzZbvIWH2KMsJZYC0QtjuEYR3TcjKhpZZO0wMp4Tc1GUkph7xuUkXICZqhwcrhMQJrW3Zb/hnKh0iwd5++cnmUhTMRQF6o45Z1B2glXDsbpwMLnOfOb4/FxLyNPByRe6aaYdToUflkU+I1p7Lrew1NCx4Txf631iAfrWjVzg2QpKkFKuo0ff5eB7pyng9qgTCFVfmiGFQllNI8ArKoHn0tPdczwgQsxMmQpM+7kT6oa+vgUMT2c0f/Kdb2Jf/514cGk3BosiWEiqhS2nOcWT/P2H/Ha/JUZyL40/3zLzve9Kes3lXK+0qZyQkJCSSAAtEMAgEJhmDAxZOgCPXvgYc7sW+xgZzbTD2JdiAMRgwJggMiCAkoZx3V9LmvHtyfNOEDt8/uqu75j3r3+/VZ3XOmXemp7u6wlPV3VVU8tBCJgmaQ0PodSv02x38zHO34+2vfubESMP+r1argR8/cPIP9jy6BxdetANnbBnDoYMnIWWGNEmCV2VhYZRGM0vx1JElPLx3/oZCAVnmsVJYSbTB5Sx6PbzllufYj/7lW7CukWPq+DGMjGTBCyQrQaaMZE1YdpSIFFfQ655/Ws0msmYGVBUWpk/h+dftwN+9741/cPbmsVd3eznSNHVIiBHbWu1WpUSCux49Ir7zk32YWL8eZWVAIXEpJVZ6JfYcmsRLbrgcQ1s34PGH9uP79x76lIU2v/Dqqz/8rre9AO25WcxOzyNL4bZpKI28X6KqNKw0fh+LRK/Q2HN4EZ/40sP407+/442P75sXa9aMQiSJP3LhNhqGWAdZe/LJg8UM0DQW4KDvPdPxwh7cDSR0VltVC/S3NcEM7Ro+KX6MQE2IAMsytQ6iBIZSmLKgPwwo4SJALiAhQ7L6g23y/sPG1dfo2pAFNOF+3he6EuM0xFUiIHwI4U8BRJQjqEakMYyenrYe6QnB0O8g0mMKN6KV+H2N5mJg7sJYo5ERMXgVflpCr+HZ+hAtG3MtkTb1n7XjOiEYDeoxMR5TDLFOT8OA/sKcwQX1hXCnGAww1BpCr0jwkX99UPz1J36ER3dPo9RuoU1I4zaVk2tr/BYna9HIGpCJRHthAc9/1ll4y8svvXV0KN1yfKH/ke/+4BHY5hCuunQLdu46itzYkKpdCoGqKmC0Ri83+Mmj05hZKO7OstTPI2lYgyQRSBKJbreLV770Wfav/9dbsaFRYurIUaSpRKUswpYMC6a82FyQAiOhddd1pAqANEuQJAlEIgFrsDA/hZe+6Hx89H++9lubJ4Zlu1cgS9PAWKQEjNFoNlLMrxT44m2PYmauwtDIiMu8miRIRILjp5Ywv9DBq266ElVH4zs/3oXjU913vvFlV/R/7U3PRXt+Br32MhIhYSsNoxXKwhXQbLQyyLSBvBI4cKKL/7x9Dz74D3fgi996QrRz9dXm8BCUsTVXkMdIQnylxowi3uuVLBErVLrmLgLqVtXR0gl2iAfRd9IjGP5+sPgW4p6kILTxL4ApiYCYvEImxEUCz7ONCoG4bM2Lf/gmg7phGU/D8SJEq4pwH0kNpyu8cmTKwyvdSFMZFAQEKyzr6x8QaqJO1+KSTEqD6A/SN9AlokkgKjQZTlKsRpc1tBQnKI5ZxPaFoErrkVfAnuXvEKxPwj9ryRh4EtLrOIoTXrEHlBynPPAOfRf+E+xvT3etLdI0hZEpbvvJfvGX//BjfOMHezA5l8PKBhqt1ClGqyGl3wpjDISwSLMEWdpAZ3ERNz3vfLz2RedPNlKB2368f2rqxCReeP35OHZyAe12zy1SSAutDfJuDwIC9+6aw2P7F28wcPrDwh1BIz5MkxTdThfXXnne4l/82a9i65oEC0cPIUtSKGVd2cOAEow/7E2iah2Sk7QKGWIGzAIFZpbBKiaJQ0DLS0t49cuvwF/+7s/qsVaKvKyQpSmDb64FIYFGo4Fde6fEl779OEbH1kArA2kSQCXYf3AK69eP44pnnoPj+47jJ/c8NfW8q86y737r81G059Btt11VoapCWbjKJ62hJoaGUvQLhQPHOrjthwfxkc/cg0/8+2NDOw8uiSRrQiYptHKKWPKJDowsg8CRQoJHVs6+RZeDRNf4lCohCmvjCiRZLk8xOITC5YoEn1AYKRtCCsYrGgSrG+IppBRYjCzGX6IwWzaHMQBtV8VcgpCEvxH6QEIUaAOgjmo8qzAFHFbLEHVbCP4zRBF+Ar7oqdt+EpC/jX0dRLVBuXPIYfl768ipHsMbSAfFlSM16a+TUonIlCFM1kYdXROSsiEllg3BnkgL9yIHjfi8Od4QwTWvI0mO6CLUs0DYAW/pCo1LUDvubqUsABfAf3z/rPi7f7nvjX//L/fi7oeOY35FQyYZsszluTemcqnMK+V2ynse7XVWcPONF+OmZ2+3e48sbr33p0/gGZedg1QILMzMe/ky6HQ7MMriyPEuvn3P8Xy+re92e0ddv918CKRJhl6/wOb1a+Rf/ckvT1xxyQQWjx+Ay2bl3l9VLntNYPlgumh+Bcl39P1BArrKsImQqE+mKcpco9/r4c2vezZ+/xd/xqIqYIyGTBJ2r4A1QLOZoKcsvva9nR9++qlprF83gSyV6CvgyPE5XHv1RcDGDbjr3keR9/O7f/1N12M47WNhdhal0SjLHK0MGB1roDHcxEqusHPfLL75w3342Ofvw//7j0eG7n9yWvQU8qzRcGWprAuWa6VgjHYCK5kldIOKlpQhCFo9srWjUzayj/AMKhm4koQ8Y2xLsOdrMD+8WsCyPUGBQYUIzBncXTAhJyMTrG9UhrX7ASTBZSa0SHPNUTdppGh7AmrhTMB7GjInkADWFV6df2ghQJCcB6ak+YjXYjHcWvxHRMVeU57gwi4CbTnzxjHb2s8a2h4YZwypMPQZNmoizLVnpPh+Ujgs2MzHYFn7YrCPA8VeubEZ7Fvso/XGLNKTiEBzK4QzDBqASDPMdsqvfv2OveKv/ulH//pPn78HDz5xEkvLGiLJ0GhkyDIJmSUw8AtZaeLAgOrh5191Bc46Y80nf3TnU2iND2HH2eM4OTmDFAJWV1C9HL2Oxr//6BCePtEeko1G7XwtAGRZAmMtmmmCP/n9N+sX33gxulP7UeYdlEZAaQttBCqtA18I5kJyWgNAygXMoTOvsT0hy6rywXcBa1O3gTBN0FnpYd36DO/8xedi/9FJ+4XvPiEmxtfAGKpnGGMbrWaGk7Pd937mG4/8wV/9/svQaErMz/TQaffx/GsuQndyCff89FG88jnnvuHi7Wtw4tgJtFoZsgRIZAYLgem5PnYfm8f9T5zA409PHz081Tm7lxukqUtxa4U7dwULFFpBqwpZIpAJCY3EwVefNj4wRTD/AyjG/wzVrRGFggeQg1AFpSF8tlUTrtfaIoTDUFhEbNGSU9ei2xpgir/FhlLFAUHToMi6g70vMFB9JZDDxOAWDyCgiERIaXikHuo+GsY3tW4EV6hGCy/0sNann450EEwhWJYxllY5ha9daihvGNFIiICeiU7W8zH1mM/r6eKI4Tqh3aBYRW18NEZCriHzBbiQ+dtNVC42zJFg76O/TC1ehmBIufaK8ydovMJvWTAxNufYyI8TFkopaG1d5fk0QZqkkEmKo7O9tx//3u633/v40W9ec8nWm6+98iycf9Y6jI1IJEmKBgTKCtDGuZdl3seG8TG89sUX3Hrn/QcwPT2H87eN4+jBWTzrmedCWIXuSon//PFB3L1rWhjRQOLHJgWgrauvCSFRFjne8ZYb7Rvf+nKopTm059qobAqlelAGENZCaeOyI8Ozuo0hFSEQYsdpQAJ0EFMKTlmEoyNSAImr6gMByCzDwlIPmzeuwe/d+iI8/PTxvzl4vP3ekdEhFJUJChBwOb9Km+Injx5fc8e9h1Ze96prsLR/PzZt2YgLLzkfux57AqOpws0/cwl6HRewV9piYanEsakl7Dk0j4d2T+HJw3Mj04tFzwqBREikiVvRrCqDShtoC6TCYt1Yll167tbymivPxY/v3Te1+8D8VpmmhPkDaqhhbSag4XtGMGPrwezAUl5YQp6qYDYIEciIwoJVD2/yt7pngwtAigp05MQrWZZFFYT2gLCKHtCfb5+vutErCXPxsdpAiyheUaFHFBCC7USDCN5i/5mrw9GE0zN+kd0Y1k9SekxYSZGQKpYuTfLgvYRk6/0V4KgooDuad983Gkf8OyrvOEcM7YXn6V4/HkJA4Xs2fnbcC5Q4lBRQmCNbM5KSzdUqo8n/DgVZIxqJ7/LPW40sAZqJQFVVKJSCyjK0shRZI4OwFsfmuq858uOn8YMHD1xx/rZ1T1x6/iZcuH0CW9ePYmwkRaPhMlg0sxRl3sEN1+7Arn0ncfDAUZx11nocOLwX3d4yRpoNPLTrOL72k/239ksXO3dnIWPfkzRFt9vDtVeet/j7v/dmrBvKsXjwGKwqoSqnaI3WkAIotXW1KUAYgzwnzmNAClgIg5BOBzZCcwBIUxmQiEwSl6TMGrjdsRZLSyu44qIN+N23veAP3v0Xt73XGHeGSes4sdZYNLIES52q/e17DuFVN12NVEpc96zzkI4ZHD10CM9/1vnIUovjk4tY6lR4av8ydh5dwtNHF26emc9vKwoX/Hel0dxellJZaOUOgg+3MmzfNH7eVRdvPvDSZ+/AS154AdaOrcMjTxzdUmmDZkplUqMrwrRUtMpBeAgFMbnyZOQW3AMA/yg/kxd5MMTAau9iK2z8/b7RiBaYQPgGydoHIbRMKQU0wBia2g/ajtGB+mCjBeeLFBj4nVxjytEvMLhaZoPidcfNIuqJZIiCTv2yfne9K/oQDsatUjzGIGRkdUgkLqQIcFdTuPABV4w05UwRceQdqMYAbVDSIs5RTfG5QdTuXUV3V90PIe55GiTodB8pXLIkEUnyy9YzZ73v8SOsy4NvjMYN119mb37ps3Fw33489Phh7D06Lbp5Aa0kskaCNM1gkwxLebXz3ienxQN7pjExnG4+a9P4kXO2rWntOGMUmyeGsH5NC0NNi7XrGrjh6m2YOjaFM6+8EJlVyDsdNMQEfvzQEUwv9j8t0gZi9lhH6yzN0M9LrJsYwQf+6BcmLtqxBsvH9qAqeqiqClpXUFpDaYtUAqqyroKZZxd3xjbyPtE35S6F9ZVFEpmEiRdC+g1vEkJKJD6oDuFgaVloWKPxihddhJ+94yn79Z8eEOPjaxADoO5/UiaolMKufVMfO35q6d3nnH0WksxgZWYOi8sW/b7E/U/tx4Fji9h7bP5jh0/13pNroJlJjLRcoLFQBpWy0BaAVgAMNowP47KLttkbrzsHL7rmHFxx/jpkiUXWaODfvnU/dh2YEjLJPNRmKYutrQt5TVAYM7OldOG1VWzCqTTHmI7RBClGrkUCQw+srtFPY9nKIXuQ9TUoGSCUCyNrO7h6FxRnKGtma++OGA3hek2JwXpD59GniajLeBfFXXf7iCQX1gDd4ZWRe4sM20CIFl4hwrmhMtR7oWrg7lQA/e74SZ6msLIfN23Q9Repb9zlpzmP8UJaQIl0c52N/BCuWcQD2OCokjksRENfUo4UFuXwcveyfV80bTXUGj+RV2jBh3UP/F30bOQDAaCqNJrNFL/2q69DI+tg9wOP4Zu3P2p/dO9eHDg6t36pky90S+lS8kiJ5lADwlos9dX03MG5oUf2z6LVTLBuKH32ts1jD5y5eRQ7to1j0+Z1/nhghc0b3WHr/UcX8Mj+2U+VRqDpfLzIYYlDn9Yo/M6tt9gbnrcD+cxBVN0VKFVBVaVzdZWGMS4rS1W5PPqcPlw8A8DiK3BkZ0OMAUC/X0IpDUhXmTpNM1TKlUlKpIFIEiws5di6oYm3/9xV+NHjx1BWClma+tiZTyAngDRJsNLN33fvrhPvfuPLr0arYfD47hP44neexvHZ5T+Yb+cfWelUgHArFcMZIIQPyvtjLlppAAYbJobwvGedZ9/w0itx43MvwNo1KbrtDubnFlEYjawxii98dy8W2xWy5pBjXstWsxCtKtUcDK6NqAs1JxoXkBgjIuoyF2uA0KQYaEUtIKeaBa23EYL2AWm4Vl2mEF/zEPS+KLSuJZbITwwICCGtgfFxdEDfGeZqWWtDhCHUaeRK2fc3IFh2JtEppoh8JA+KG4/i/A5/ypdOJfkIbTrlhfB8DTWzPsPEY+McAWLADePzWpuGAYTkgKtYdS3yBAXUjZ8Xr0wH5pjQp/RME5M2AhjY0MqRZzBKCA6Cb98jV6ZICS1LKSBkgh/dtVP8yyf/zf7SO34WO85aj9/7tVfi9a+4Bg88vH/+Rw/sxYM7j3/w+MzKB/p95yU1MokkkUiTBMa4A/hTbfPgqfaieHj/Eoabp7B+3dBZN1+/9diVV27F2okmluZzfO17+3BscuWdViR12gLI0gzLK1285HmX2be84Xq0ygUsL85DqRKqKqC1QlW6WLtSCokUqJRCWVJtVjBjRJwqYAViWbVgkYxDEvSpygqVVi5zqt+vk6YpqkpDeYiulEU/7+PZV2zBa194gf38t58SzYlRGChEobRIE4mF5aL9te8+gZc8+xxs3rYOd92/Fw8+fUq4Ih8JWq0GrIGHk9qfs5JQxiIvKowOZXjuVefZt7/uOrz6RZei1QLmZxdx8HAHuqxgTYnhiXHcduc+PPzkKQGRuL3/NiqR+ImancNSHnOoBbRrDIdwffD3GpIhxvIcTIJFdHETEd0ZUoTxnf4J6ZCKYHMTkJQdDNYT89gwtnAWMwiB+G/uZ9e58hN85INxFz/GoNDjNgH+iXzNXEPGlGEsIqIk4wWbTglw5cX7WFMspEAHULVAfW79oEHL86GOpacFLJuDAcROqCuSh6G1MIWRDkGBAghpZb2y8TAy9M/Rl3auM/oSrU9DW5oHPqY0k6iUxl2PHsI732HQyyv0qi42rRvBW255Nl590xV4dOfh93/19p3vv/2e/duOnVo6VSmJNE0g4cJKUkgkKZBCurCNkTh8fPn4V7v9HS978UVHt2zehENHZ/Hjew/c3q8M0oYDLi4+DSQyQVkpTIw18RvveCnO2pBgeWoSVVmiqkooVaEqKqiqgtXGr0InyEuFslJHiQBBTiBCEkMBQHIL7mjpIDvFEoqiQlkqlwbHJxpL0hRWCneuymgICXQ6JdaNpnjtSy7F+HgLZVmBAtjGOEthYFEooFsYrF03gpWFDnY+dQraHwAXFtDGQvvSa4ArtNYtFPp5hUvOXfv3f/aem+y/fvjtuOWmZyDvLOD4kVNYWGpDaQWtS1gYLC3l+Nr3d2KlWyBNRDhyE7ZIeP6qxSJsXREEZMYY35gY/zndZxC9gNA9yHWICsH4vFnEcFwI+e9kUfnfJMhWILQRc4W5JowlF4rrIRoNavfSH9xyGspX499NW5tCF9mYDXjQfIAG/m6OEmgGiCbWN0w/pXXYiU48JCz4HwkWURWnDZ9byQKY3B3k8xzJsTqeRAgqbM2pEywgN0JWLgyz+pRGDaGaWJWH0ywqx0ifUE3pdP22iGmZUZ9L6peEgNYGj+4+8OHJk9MY3rAWaUOi2+1gcnIaea+N668+Cx9676vwsfe99uQtP3OpXTOUoSwqt5HUuOeNMjDKhYqE1RgbHcKpheLYPQ+dRGt0DOPrxlFo+6DWDjEba12hW29sut0+XnnjZfbaq7ahvzyHvNeDriq39aKoUBal2/Kk3RlKYS3K0qAszROk2A1lb7Tkx/j2hRB1QSBr4FdQykqhVBoi8bnrpYBIhN/8RscRAGWBXBk848KNeOk1O2yv13eTY4hRjc8vZnH5xVuw/sx1ODW7iBMLHWjrlk1ZXV7IxG04LYsSLSnwxpc9w37ub37x3e/5pRciTbqYPX4EK50e+kWJIi9Q5n2UZR+NZhP37zyBXftmBCBDHikacJhnxmRxzLJu2VYZOboP0Q0E6n8TjBdw+6UCrBervg8uJQlaQAURwcU+MEVlEZRYsNZkqbygciXK+0pzLITLFMoVTcKRiYhnB2mfW+QPBDRB6IRnsqDzsRHxuAYJ+QmIEJ8LdKF+0UZjiNq76G9+SQjU3P5BBVqbQvZs/MIroAEFHLmQkBjRkfd1AL0KFz8WAnH8A2daaRY5Ag7jBrnHRDjPbdKFYGoKt67tQhvR/kV6yiTBqZmV99774JNorh9BIxFotVouA0SlMDs9j4WFOVz/zC342z++Be//jZfayy/Y+BVrFFSlACGRStquoWGUq2ovhMD37z86tdwz2LF9K7afsfb9AtrXivQJUa2AqiqMjAzhtT97HdY2SnSWlmCVciBJW6iyglIKqnJFcq1WkEKgKDVype+CEL7ieYwvW2tD9XgZJojoETS8I0JRVOjnFaTf1eESWAikiV+B8kufsEC3U2DdmhZ+5rnnI0sFqlLBWgTkopXGUJbgqou3wRQCh48s4MCRxSEppDta4ifN5S+XKIoS2zatGXvfb73CfvpDv4xLz9+Ek8cnsTLfhoJEv5+j1+tDVSW0qgBroQ1w+7170emV7uSAYVaeEQCoW0hHHB+sC7xiw7NOhpwydveQcqb4iUdWbPd23SggvlOEroRrq/pELgz1N7h/XvkNWObIxHWUGUbCLD4XxBqqiBCp5mgH9MrZg9COjYahnh/d95kZR9ImpLg5jclNCEiY0a5+0iG+k7J1hD5YW1tQ4K5sLc5FiC9QJ94fQikYeJ6B7sGYGdGclFBEr0TJOh8J4qMAF6MhDUYOFPt1m1Hr8bDT8/DgXAEWWZqg0y3wlW/dD7WSIx0aQqvlF+mERJJmMEpjfnoWZXcBb3vV5fjY+29+wxtecrEdbrqcgJaN0cLls0+yFI/tm916+OgcJoaHcOV5W5Gl0sWojXEp5tME7W6O5z/7Anvl5dtR9Doo89yNVQJKaRTkPvrdDbRdqdNTyAtzd5LQgiKFgVgSKGMgaSBuuNGK07VOv0C7V0JmzjLy/OtpWkdhRVnB6j6uu3Qzrr5ok+3nhbPe1rmEVaUxNjY8cc2V29HO+9h54BTm2mUukxTaW0L4hIlFpXDFRVu//49/9baVP/ztG9HtzWNuegqAgrYW3U4P/X4OYyoYVcLqCkMjTezaP4sHd08lhGxiNWUAJlopsqjEwCQkVEk4uNXhDlE77e/Ixq26I3ItvhKuRoEXMrZbt+irA+qEDMk9CcqVQEEYQ9360n+yJkRg70FNKRDyiUIkA7oK6BQ01qhMAW9s5ADSGECSJKCUZYNifaS46HnjE00KYdmqpa3ROMa6RBh/RGX1BZjad6v6JwKNAx0FxS0J8clAw1pSQnqPp2Gks58jQWELg9rbB+YqZGYQsW1vwlFDoAwhcoRc06JxcH6KXMMOPSe465FDyX1378LQpnVIE6DZSuGODykIuASmquxj5tQJ7NiU4q9/7yX4vV+41m5e25RFoRwyThJXaUwbNNLEJy6dgrYSV11+NkaGGt5rcLyntYaUAre88tnYMJ6g22671XOfF1BVhT/8rWCtgvb7xqwxWGjn6OX6wTRJajQg+gYvwhpvjRgTWCt8nFFifql7xezcMiBlhL7WOhSWupVJVSoYrQBr0O/l2LSugRddew4ApxCstVBGAVZj/dqRb27fsgbTJxbw0M7jLqsEJIzxykYIFGWFqy49Y/KTH/nFm17xM+fg1KGjKHttQABaVcj7PRR5AaUdpIW1kEJDQuBbP9mL2aW+SZMkhLuJ6ePGzjrqAWgrgAjsE+G8CG6EUz4Iq2u018W1F3erG2P8zvDIt1Q7sIZkAvhlyGeAJ4nmXNkYY0J/KUbGx0SZK2pusm/M+Mro7t5YGs4aEw5u8/TKHHERnThaqSOXuJotQo78qBAiYorCLbywG2PiWUiQa+jf7f9v/W77sOoX6B37aGx9hdJahlBZa/B9A/uG9HOgOSLKRA3FM0WGGFujGB2hZ3glG/rqjZj0BiIiR4S5DCgN8bkwx+waMBAqYO05BUpPCGSNDIudwnz2a/fBqARJlqHZyiCEgTEK1riTK4BBmgLdhUX0V+bxnrdehT/79RfrszaNvDQvlJcFF6eG7/cT++extJLjsovOwBnrRz9PaDNJJPI8x8UXbLv2+mvORVJ2UOQ5EpkE97Xfz6GqEsa4+JfRLmddVSpMzq6gWzgUV48XRt6xsFTRO0JgbnWzrIHphc6uE6cWAK+Btdu077Za+H1hxroVQyEESlUhSwyuufRMrB/NUBTKJzh0An3xOZtv2LBpHIdPTOHpg9PXSV+ayc2hQFlWuODcLdf+04du3XLtFZswffAEhHAdVmWOIs9RFCUqo6GUe6eUBq1WiqcOzeOuR06OGO3zTdXMbuDTyLAs8C2E8HufZDyXxgynYKv+lOmArtS9MB6wZvEUMh7etaSzmbxzg2iC/6QPCWgtbsQRn4hbPBhWCQw+2DYJAJWY42OJQfCorIyNG3AJxUV3kBBgfQyeSsEt4ojCVW9220KkTOL9fPw0P7KuyHk8KsyT/4Nyp9GHK1oeH6QxD9LQMveUz2tw92LLdcNBFPd0iKu/cUHItUexPmqjngYbREfvbnlHlLnIq3mjzgs2/F9Ktxh2xwP7tz/92BFk69YhlUCr2QCMQ2HWaufNGOXrVyhMn5rGa190Lv7k12+8/cwNI+uqytV0BXvPgVPL755fauOsTeO48oKtbxPCHRsSQkBpg1e86BkPnrG+iV57BVDO8EoBVHkfZb+AUc5Ntn7jbZoC7V6BU3M9lArIEjp0LFbPH1hGVpqgYFlh0WikWFrp48ChU4DPM+/Ki/s9R74WpDXOLxYWMMpAqQLnnDmOay8/y7o9ZRJGu+MIl5+/BaWQeGLPSUzOdh9sNpJgWatKYfPGNWMf+YtfffDqZ+7A7KHjsImEqjTKvI+iyFEUFYqyCnn2HUTWSGQDX/3hPkwtdHou7z1TTDQuDKAHWmUUcVMm+dqO4cj9cX+RmFomhPWEfAbcQgLRknIkJSBqOamCZWdoIaCage8JXVA77t6BjAsgpBfdtMHJDwrEI514iJqEqI4Q+Jhr/QPrN0Nk1IhDrIFyQbgZEIIEuWoMkdToMICIB2jEaczfz2Njbmyyhsii4NcV1ep8YRhoB2xVkhlKS/zD27f0RfBy6m3xUEXkHKp1CeHjb2FeB9rk8z6AlvkcpEmC6bnO8a9890GItAkIg+Ghhss/Z3VAwaqqXIFk7zVMT83gJc/Zhj95x/Pmt4w3WlpF+W+kCU5MLn18amoJCQSuumgbRpoZjLGolNsQ/4LrL8RoWiDvdQMIUEWFfr+HsqzciqU3jEa5UzzzSzmmF0oYkXhFzpGyrc275IghaHDhBCDNUsAYHDw8hc5iG61W6l1FH5T3zJ8kriq0tgZWCJRVhYnxDM96xjYIuGM/1gKjIw1cfcU2dLoFdj59Egouc6sUFlWl0Gom+MPffcPKy296BuYO7YIWCapKoSgK5HmOSmuUVYWyUjBwJdyErTA0PITH9szhjodPCGsFEkI3AdFEwXMWQAR6EH4IyeACg4hg9ejmgKQir0bEYcmqini/lAwEMAGxEdHUPgFB0Ibb+kbVGP/gK8c2jJPHiyjwyeNTJBwU76E+1vshAr3IQHDe4LwSniC+YePiq4MQIuAPysQK3gfSUAiXgus2+K5AQ3Kp+GZehsi4ey/ISgkwOkYXjI888gUbW0Cxns78fYLNO6MNodWQA4ve7RU9V8RxYqJqIqVco2/tGlPgZJiCcIfhQiBugs4rja9/98FvTR6aRLZmDYRQGBrOQAiQPCGlDTQstBVIGinmpmfxiheeg9958zX90abbaJxIgeFWhry0ODbdQWUsLj1vM0aGMmktUBQFzt2x7eLzz9sKVXShisLnr7Po9XvIezmMNlDGhEU+WINUAKfme5hZLt6YpmmQnWCowhRRDMwypIFYkp1gspAZDh2dweFjc8iyBEqVToFpV2lbwAVcjXHBfFiLslBIJHDpeZuwZkig8Dtqx8eHzrvo7I2YP7WMp/bNPiElHGozBkZXePVLr7HvfsdLsbBvJ8rKoCwVVFWi6BcoK4uiX6EoKlhjkSUphFUQCWBKgX/7/h4srJTIUgnhNz+GCT8NekBAMPFaRBUiCMAgc0c05C1+aI+u1RVK3RhGBrOsbe5Jhu4SMw4+F7J6suuMsSNiYX0PyAtxXoGQJZTucc8bhng43UgxrUY6UbCi5NfjY/WB0jGhVbEbT8eaIrHsKBPdO4A+6v2nWgJxzHyOqU0ScGovokmGHplipUHQajkQ94aFBRGGggLdYWN/rHXVrdg8xXmONBZh8L4/ot4mH/tqlFnnO87XaZrh4NH513zuK3chHVoDa4GskaGRSVijnSdl3Eq+y4jq3p8kCaZn5/Dzr34GXn/DBda5nQZJ6rY27HpqEv1eiQu2r8e6idb/hT/3efXl5zy9diRD3uvAaLfSWFUKea+Hoiyhvefm9o1pWBiUymL/8TZml4qvpokM+78CLLBMWcNnZCXLL4l0IroXzaEUh04sNHbvOwGkzj64HfgWRrukYzLxAuucX1TGQkDh7DNGsWPb+PfJPTnrjHUHzj17E6bmFnFqduXqVKbQRqMsK5xz1sazPvhHb0Bv+RDyzgrKSqMoc+T9HMpW0KpEUZYw1iCVAomwEEJhdGgIdz58Anc/MSOsSOPKoIhj4a5ajG2xsbIKMI4RojskgIBioivk2U1gQNgsY0DfnhCcp8O7BX8/U65CUBAeAFu1C0rJv5jHiILyGBh3YHYfdKV5prqW8e/V7QmPLEjAuLXngsQFi5hq8DvrkRAdoTHs3ZxmgpCljXThQmlYvwREzAVfQ4P0vzp6C0jM94iPQZBWo28tG0OgIas/IIBazc/QPlOCgn3hDSLVRgiY2CKMkVhjEHlZEbfrEN/U0bDHWYEORLeI7kiWpZQoNfDpL997/uGnTyJdtxGQQGNoCFmaQAgL2ipkjQ1IjOi8tLKE33zzdbh0x9o7japgrUCWSjx9dA4rvT62bl6Ds7eOvztL3Agvv2grxpoKqsiDoaiqEnleoqoslHE42hqX9ifLJGaXSzx9bAXdyuXRd7p/YH5tHKWM8Qgbko2SYBpj0Ww0MDvfqx574jBMt49GJqEqV0jDGAOlKghfMENbDaud9jeqwmgzwRkb19xErsz2M9ZDNIdx8NgiFpdyI2SCbq/CcCvD77/ztcfOvWgdlo6eQml8kC/P3WpjqZy/7OtKCiEgtEIjFViY7+EL39+71C80Ml+23CIKNbfAbiIDQPdERTjZwa9R9SIQfaxHTYy5TBAqtmkUFB/0POTRBmdSvgK3yo2E8HmkBPF4eJ5cRh4DswERIPaTlDAYuuFuDSLyouZDrUUCk2GszJqTIuQCVkNBTCkFbot9CgrOj5M/G+pKWlJYUQ9E10jE8QX6MDRmCVn7Nk38PSIWE9/nDStfPSQFzFGhsYSqRUSODOUS0qP7wPvpRsr4ISpwC7CzplFJhXlznMwQGY8vhilmz7r23XMi0JMbiSRJcezU4sGPfuYHsKIFiARpkqA17Da3UmZYwGW0UJV2C0dCot/JsW5c4p23XHXDSCtFWWmkSYoj0+3G8ZlFDA8PY/vWta5aNoCzzlwPo1zM2lhH56osURQalXIKUhntTt9ot9i3/+QKDk22351ICs3ETMGCwIBwx5xcHn6y/l57x/iQ+5lICQOBx3afwKGjCxgZHYItC1itAatgtYb2gX3AZVS0HhIOD6XYvGENAGB0pIkrLz0LNgGOT82hNACEhDEaz73mEvtbv3YTlg/tg7EKVd5HURRQqoK1ClWpXGoNX27cFX3QABJ86fY92H14YW2aZXEcNrrCIfZFKItWHsFRhA2wXvpMAt50IcS9AnAjwsaAtCUrhWj5ra9OI4Ws5a6PPGrrAh/QBcJchPaZsHDBD27oadBQFFYbxkzf1eJTodWoGKgWJi0EcDqF9kWwgDWlIYSnNbkxDA1RG7y7AV2S+yQIh8SOCT9vgtEEGEBKsUGmWPhKJF+8ILDqeYPmEKK+py2wgaj9i2SvI9LTodJg+GiuCXNZNnYb6RwcZOIVzy92oM2oKDkfmWBEo7dB/XObxYUEFAQ++41HxF0/3InG+Hq3+pc10BjKINP66q02Bkort8sgSzGzMI+XPf8cPP/KM6zSJWSaYKVfVCenF4FMYMcZa5FIoJE1sGXDGhhdoipLxyfGuPTwpYYygLUCxsDLtttHuuvQAiYXi483Mioi6YcrBZszx50QiJW5hZA+FbQXTLLmxmBoqIHdB6cb9zxyGFmawFoNrd2+EasVjFIhb5b2+77KSqHRkDhryzgAYGKstfHKC7ags9LFkaMzEEKiqhTWjY/gfb/zepR6Bd2FGWhdocj7KPMCZV6gKt1OXbcNQwJGw0Kh0Ujx08dP4ut3HR0xIkMS+I4mzVtz1JECt+YhFuaZghSMm3OPWDwSoSyd8MjLeikI8YYBa2yZ9adfQtzDxr+5sFgb7wnuoruxppSI0YPghLbriMf9HoUdgm19CIikjgBPF1tx5KnfLwi9RhgQXLGQqUKsbo82aVJaGQTSESqprzJRzv2AXH2btNt91VjYPMaq5TbSjeaLjzFISQCd7v0DbdcRl13VFr+P8xwpXjcHNvzkyKkW4ogswjwAW1POAXEOzPfg+zkyg6dDI03R7Rb4q0/+AEvzOdLWKIx1lb3TLHPnnk1su6oUKlXBaANdWfR7i3jn66/CponWC6yxKCqLU5OLKIsezj1zLdJEYNO6sYkN4y2osg+tSwgBaKVRFq6imPFAxxq370smKQ5P5nh83+LRbuESP/DxES2iuy8grICkfR3RCriVM1rlMtqg1WpiaiGvvnvnk5iZWsTQSBOV6sPVtNMwfhmWQ3drNRqZwOYNYwCALRvGjj3jos1oLyxianYeUiaQMPjZFz/Tvuhlz0Dn8D5YCBS9HGVRQOkKunIHPa01kHB+srEKWUPg4PFlfOobe29f6JpekmRhroWIFWioIKa1bLe0jQzIYxZCEKOh1hbgXGuqoBnQwIAltqi3RRXAOVPJqNKCJYnC6pEKxb+40JAVJfTB0B/dF3aMi/jegB5RRyoRDbL8aGHMJAx82wUiZegBghHBBfLKh+ANQ2URxQ32wXq5FJEGbH7InROk2OVqo4PanPn5Yqgk5CyTcUf36nierM1nIFsNfUba8gSOHJWGMAL73aEvhtII1nmUzxEczSXNMa+5Wq8otZqPavEvP5G04h4UejQFEDLFXY8cFh/9zB1Ih9dCZhmsTZBmTaRZCpklwaDSP60UkjTD4mIHl2wfxsuv3XZXCg2tLWaWuugVOc47cz1ajSzbuG7s+uHhBFqVIb2QqiqUReU3elto7SoZGWhoCzzy9BwOHF8+O8vSILdCAPz0CpGPfpecEI4n/SCFhITwp8sF0mYL9zxyZO0P7tuH0aEGdFFCVyVgDbRSIW8+nWDXGlC+wK0AsGXdWGvteAvTJ2dxYnrpX4212LF1/Xl//LuvR7kwhX57AZXfZa/KEkZX0NqfUNfWH/ZUSKTB7EIX//ifT+Lgqe7L0rTJuE7UmMpzRN0acUEfsGaUwYGukWWmbKGBqN4KcPQRn6HfRe0dwT2wTmAItUW0YN11E1enDOtDQJakNN1bIjLyfE1503h/rcVAT2vkCc+TcJPy4gw8KDgghE70Q0RgJEQuPhj3cdXfSZxYRzaUptn9qyOdgEoZsuON0jYA6Q+8r85ZJuLYKM8+61yI+wl2rpMDHU4LNu460mFKiN8XlB8jHurtDrqkMcbqARsiCqsbwDiDtapWdLVGe0fLLBVIkgz/79/vE1/9+kNoDo9CetokMnWutBAxjkhKzGhAJFhYWcYtLz4fa8dbrwYsjk2voNPOsXXLONZNNP9h07rR7zaawsXIYQCrURYFysLtvCc9U2mXO/DoqR5+umv29uWedmEr48MfACiLMACvDAMTuHQ6EF7DCwFXnNwrM3+fURrDrQwnZjpL//6tR3HoyBxarRbKft9X/jGwRgPSAD4BoUtn7eI/DQDbNo0jGx7C4VOzmF8q39HKUrz2ldceuPiaM9E5vhc2ESj63aC8jDbQzlGGUhraKCSJxVJH4V++th+PPj0v0qzhrY37IQWtzLC9T3LAQrMJJqUdmE1E2YnWkggR5df4jY6UzYEEiLcVCloIciBYH4i1agqXMa6fJFnrA07TBkcvUcAZkFglSDUhGVAgVsT4VERGcVsNvY9WCsHa4t9HFOQVUs1skvHg72CKkVSyn0s+RkIa/13cidMC/H42/tAPzyexlmlEtQKihmgjTdwYKU4W3jfQnxieGPjbd6tmUDiCZfMj4hCiIQOnk3s4tr2aDsHNFAAlixRsLrJGglIBf/LxHyV3P3AUQ2PDQYallEgSt8czvM3Ltkwa6HZznLulhasu3PitJBE4Mtm+faXTx7rxYZy5Zc2t42NDkNbEY3fKIM8LlJWCDosnGkJYVNrgzsensffoysuSNAt9D28WgHeBXEacSDhnrKQlDQ+nwKwE3wVFB1MbzQw/ffiQ+PK3dwI2gVLKnVb3O3jhoaKDiACshDFAkgJbN48DSYajJ+awtFJUZ29f/6zf+tUbkc9MorPSQVVUyLuFzxOkURWVz+vt8jHJBFhqa3z66/vwg4enhBGZnxBDR1/jaP2E1nZeB6EdsJyBueERhScGs4oAIYCoyKyl/UaxHfonAnJFMASG9YFiNbCW5X/37XiLF/rN+hwsuY1vCmAFq9FBRHYinAPFQNs1oQj8Xlf0JBThbxPhV8ASIq7EURsCHP3ZgE6isq+jF2ttQBDUTwEKZnO6RCVS64NvQwcUGekQelFDO2D0W80X4VpoTwT0VqMHQ2t0zXtxbo59a9bSyicZHJYTjtm1+GO1wqrFtwb6HBSaYbwg3Hv4x/XdyUaWZVjpFuZP//aOb+3at4SsOQQNA60dmHGNC1gtAON43hgLDYl+keMVzzkba8daOHxi8WWTU/NoDbWwdeMaqLwPVRWQkpCWRpErFJWFNS6bsFYaqUjx2L5l3PXEXKM0bluG9eeIOYe67RYynH8PYRkhBJAIyMRVSLaQIX1umAXraiw2sgTLPY1/ve3xd9/5wGEMDQ2jLApo7QL3Wju4KOiQsJQoS4VmlmL7mRuBNMHUzDIsJF764qsePufireiePAwjgG63j6Ks3CKAqnxWCA0Ng0QCK22DT359L/7r3klhsxaQpgAsEuF2BUuPIslq0dy71LoxvbJFFEbBxhmybPhjLcKPnVuCQbdlFRIgpvZUJ6VKsZzBZ/kztW/j5frfETzUEArNNp2vi20D0ZpxC+3+GXAlTTrL9ycgcjZWEVFeRC2+PXh30aMYh05jhlMyBIG2TO1Qf4TwJyV8sZA45vhOoK48tDW1McDPYth84PvNKUzZXYUIeC/0ywwIO28zzHfYf+Y6T5loiT5cfCAEpJWQInEAglADIroFUFNchEzr76Vn+OJAfCbGwGz84jRMJUhWhITb+WnQyBo4MLn0mj/9yI9w4lSO4aFhCGFC6T7hjbpbRHFx70QmWOjkuOy8tdi+eXhPu1fi5OwSRCvF5g1j0FbB2hJZ4uSpqirkZaz1qLVGkgqcmi/xnfumHphazKs0EYA17rRCMDoC1gpY65KpwvedkktIY9zKgAoHNSO/gLIEwEFBozWajQYOnFz6+Me//AgOHF5A1shQ5AWMr6obM04CRgO9vEKzkWU7zliHQkvMTK9g3cRo6+aXXguz0kZ7pY2yrJB3c2ilUZUKZaFglIbRGlYbTM/n+Lsv78TtD5wSaZY5i+lyATli+PNZgjOtjRM3GLsITD6AWIhpQlJNsm6oB365VT498iFIH7mSW0rOeKQQaHWwFhPzfQj7lCwpYT++gRVG+j0uWEQkubp/fp7JmttIt4BaAuqxATXWUJNg4wLFd+BpaEKSQ4566LtoTGJXSeJiHBC1vgbkw9sEH0NdC0S0Zz0qiQfxXTyH78cjceFxt9Xok7aNgNNo4H4+DsCnCbK8hgKhw9XKlxR7vGdgzuJEMteStYnTzBujczQw0dgBGo1GE48dmhV//NHbcfhUH62hBoT0MujpZwx81lS3glwUFZqJxvWXnXGREMDRk23AJti6YRT9Th95XyPLMsACZVnCGJc30LjcWchLi28/MImdh5eup1BDPAETZYiMBaWXN9a41UxVQa5bu2b4grO3PKuRWvSLEokQSBPGQEQcYjxoJEmGe544Jj7+749jblFDJqkrjeQy6jgBEwKVAXr9CmPDzfecuW09cqWwtNLDjjM39a971gVoz0xCVQpFv4A2CgYWZVFBaQWjKlRK4+kjK/jQ5x/96k93zYnWUOaQg4lL4mWZI5EWsNozsyOEFHVrRYzI411BIdU5o4Z+eAyk9uFaKPBUneEj0nAPRHchSi3ZTQIKPI5C767vZ4ovHVSe9E4KZofsCByd1NAWuybq/a/F9lh/OBKIyiOW5ROAs6D/DblC+z5pJf+Qi2XhD/cytw00Hhsb40aL95voXBu3pHOYvE9sHL4lMZDpg1Ao0TGg6YF7+PsdOf2EevoZREMjBduuI6JiXBULtLQIEnk5uobEGzFe5u4f6D8G+ckjTeN2DyR0BlgYtJpNPLJnRrz3Qz94YPeBFWRZAggNq91+TGu128ZkKhfzFkCR93D1xZvQbGQ4NdtGkUjsOHMdhNBQViDJMhirUVWVU3xaA1bDQOC/7p/CnY9NCmvjfsI4evJkHFpOEtfvvCihdImrLj/r8ec/6zwrr7hoR/dr//KBh//sD95gN44h01UOa1wxDaqEDONSXRhtoZVBkgAyTfDtew6KT3xlF1b6CWQiobUrTmnhrJKuNKpSY2ykdevWrWux0imx3CnxnCvOxuiaFqYnp1AVCmVRQVcKRV5CGQ1lNRZ6Gt9/cBIf+vwTye4j3TcOtRpIhICEK8GltUFZFnjBdRfZ33vnLXaklbWMNkExgSmvVdaLKETf+e8NuUcMMdiB3zlqcQrIR3t4bq3ae6PLFPJdDVj3EBMT8eCtELSiJAJzhvvBUVBEB7W2bcxYWhv2AC1WxdkwkP+dtRlRIqOfj5b6DFcDyCoiCRJUC+6u+RiZiXMggvCagCRt6Ad9FzoPWjmk/oOUAUPYlrl/htGHZMbR2dZ4Rng+CP9CvwLjhB8cPYb+ifpcBUVsKS9dbIfHs2pxOP47aDrqKtiyfoS/GXp1t5PC9MpWCLQaAg2pQSlyhO/X0HAT+04tXf8//u+P33jHoy5ZoRDGL6xV0IaqB1UAgE6/izM2DWNirJGdOD6PbrvA1k3jsLpCnmsImbn9X6UL3rsTEMDtj8zgtvtOirzyfOurk1tWgdta5+QmQkDpClWVY3w0wS/93HPtN//lt698x5ueD9lbnoUdbeJ3/vQd+I9/+LXypueebxuJy/pgqDgt+89RxiATAlZI/Mcd+8TffeFxLKxIyCT1xyQIBrs0sRPjrYtG1q1Br1NBQeK6q7fDlEvI+z1UVBdOlzC6hILEgRmDT3/7CD7xtYNiZrk0jaY7MS+k2wtUVgaJtHjdy6+y3/3PP8XrfuYKVErnbqvroAUaQBR0PSiFuGdIegbjFd25+xDRWkRVRJ86Kokgi38Gd8TXWqqhDKYoBsYQXEu6PsjYto4QTve+QVRK4+N5xmB9OCAkGeQKF5F+Pgml8G4tR3huczRL/+NjRwYICR9F6EMdHYXzp3xsA/2NY6yvBqJO2ajcwJBKyBfGVruIdr7/geP9vNL3mmXACIi9hqDh6EJ5/0VUzOQS1ftNY4v9q80poxNXhuF+kGGN9zj0GpG7FMKhLQACBre+9Ub7p79zix1quvzztIVHa41mI8PsUvHVP//kg+Lfbz+ElS4pWLddqlIK2ue+L4oco02N888YLmeXeksrnQJbNq9Dq5lA6wpSSlRaQ1UKSimUCvjhY3P4jzuPi25f+dkxoBocFnFhSsLlCiyrAs3E4OU3XGS/+Zl3209/5K1oT+3Ht7/5I8iT8+1bl08dh16cwXUvuAzf+Ny78Lfvf509/6zxbxZ5jkq5ssLGr6q5BSg3EVK6SkXfvGuf+MvPPITDkwXSLA0wWykHOdeNt4CRYXSXulDa4LytY1ienkGv00VVlTA6h9EVVkqB7z08j498btfNP374pIAQkGkKo7Xzv41Ev6wwMdbA+971Gvv5z7wbpqXxpW/8F3o95fszsPEy8GbdojmeI38kxp0iy5OARkaLa1P/vVA58ggM5mvn8SX+bIx12BpqiG2aGgiI6NL/XhM664t+rEaQcWx1VLoKYbJ+AWCbR1f3l4QO1lUTiAgmKlCGHeC1HijOwZEFucPkFrp+kbvD853V0SYJMlfMEQVyQxXHWs+pxvkj9iPMEz3v6e4ORZ8e9ZIiAeC3HNSP9hiv7zlaqveN2uTtijDP8X00pjBwEPKj9qRYzUvBOzEal50/gd/937+Bv/nj19kNE611eVGEOTLaIE0ltAH+5VtPiw//2048emAZvdJAW5fFVRnt93paWK1wwZZhLK3kH1xe6GLdxDharQxlrwB8yvmqUOh0ge8+NIN/v/O46PQp5m5q24W4zOVVhaIocNHZGx//xF/+kv3mF38XV18+iqNPPIhj+w5jdilHOjXX+fTM3MKnkkRgaXIZSVLgF3/1Rtz0kitv/tP/8w37xdseFd28RJq4ZIYOCVF2BgUhEsgsxU8eOyYWlrrf/91fuOqmKy/dgCQBIA1GG8CW9cNAo4Fuu49ms4mN4xlWFqahyj4sLLo5sPtgD9+48yTu3zUltLBoNTNYIWC0hoZEpYGy7OPKy899+Uc/8PbvvvDGS9GbOoyhVgv79s9A2wQpErg67kEqovVknyCsxPkkiKdVIAx5MYRhrEVC0hvy7kdxhGDxkqgX6siLLKYxkJQhwnMaPSckuZUx0B5QoI0KJrwn9JFbe44+qH8yoANqPyKBelwwxr6Y8ouvQIz1IAi8gDgt7WPQGQGxOjcUnmaENmKwnfrNaUJxI2tt2OcYBB11xMrRKFW3Ybra9Umg9h4m80ExC1FPNwUhagsOYTTG/R7mxlJ7HjULcoNXI0YqRRiVDjEonw+ifUSIpMwCu1mEPW7uDxnGpTSw88kT0DOn8Na3vQznnLV1/n1/+e94fN+UkKmre2G0OxfcaGS4a/es2H1kOXvOZRvK5z1jHbZvGcZQKnxRxgQwGtvPGIN97FTRL3Ks2TCBc86YQCZySFQwSmN2XuHbD8zge4+cEt3culTR2tWVpX4qF1bz5yNLjIw18CtveL79n+/+OWza0sTCwacwOzkNY3qYmu9gerH3QdntVzi0/wRQANnEOFSlMf/YHowNtfDJj78Ln/s/P2/P3zbxLpepERBJ3OgqAQirIWEx1Myw6/D8yz74yQduve/xWTRbwzBWY/14Ezu2jANlgV57ETs2DWO4KbA0O4ciN9i1fwWf+tZh/J/PPSXu3jkjRJah0WhCwCLzsTatNCQ0XvOyZ9vbv/Qn333+8y/G9NN7YUpg8dQcnjo8+ymLBDbs2OWIg1vKuiiF3xjCCN9xBvffx0CjY9qYfSCIQWRk/wwFigeRl2sXtbgY76BTKnFnfi3WMYAchBckcnm4koioiuWtCqJGcTQeL2NxK/D3mtrftPDgKueA/e6+5xlLqR8RZUQla3wtgRptAloNFwJNgkDyOWZIKSAv8LHX6RfGypEWGBqlV9TmKvbdZUEQfrGCVG68h5JABr4KxtHU7o80Zu9BNA5ikA6WVj7j3NXjbKERR2Om9SJ5BbS1ODzZRiIketPzeN4NV+Frn/kdvP7GS20C6zK/QPrcYBZJmmGhU1W33TMp/vbfD4z8+/dPYM+xHsoKsFaiUgqb1jTRFHh23s2BQuHsMyYw2pIo8xLHjq3gy3ccwfcfmRR5JZFl0mew8eEb2jYjpatzYUo86xln9v/z/73LfvRDv4ymXMT0k4+ju9JBXpVYXuhj/5EFTC/0PiABYO++k1jslGiOjkCkTVStIXQmT2Dp6D68/s3Pw3f+9Xc+dsvPXGKz1G1ZcPPi978IOAEAMDw0hEOz3U//7b8+eOsjO2cwPDyMbZtHccHZ62GXF7C2VeDlz92BQhU4cmwe37rzCD70xd1v+9Y9J0W3AoaGWjDwFV2k28tT5CVGhhv4o/e8zn71C3+EoWaJucN7UUJDoYGnj8xiYaX3W0LW3YUwk2CIa5Ar45yG6th0geZbcAUVUAOZuRhYrjEbs7bUZN3tqjNWdFciB7o+m3Avj3nwNoLbGdof2BNFLgejxaAi5cooti3Y83UXkwuea4+9l1BUeE/8ruaaDdB3MLcXodc4frcJ27A2amPh9w70vf5ORqtVtIjxMiFiZgpyO/kOfJ7TTAjU+kPrmnQyJM5L3QAEGvOx1nVinVZwtLYeQnCUOGigqSkyoNSmkICGwMmZRZiihGwMo33yJNa0DD770V/FH7/jhXZ8uCHzPA/JDbVyZxWRCMyslL1v3HNKfPTLe0e+fddJtDsSVWWw/Yw1uOTc8bcJVCiKDs7fPo71Ey08vWcWn/2vI7jrySVR2gSNLIni4fnMQgAygVEaQ60Mv/OOl9gffP2PWje+eDvm9j2C3twpFLCYb/fQ7XQxt9zD3pNtrBT+LOQju45OHT0+jbSVQcgEQkgYKWFKhfl9B7Bj2zC+8Knfwp/85k12ZKiBqlJQimIGAKyEtW5VaXSoieMz3U9/9F8fmnpy3zy2nrkB27ZOIF9ZxplbxnHFJefgjjv34B++9Dg++4OjYmqx+kKz2XCw1WtlN4munt2WjROtf/7Y/7B/9qe/iMXjx7AyfRIWgCoKQBd46qnj6JeqiqWESGZiTKBmrQaQAfE0Z5rglpCQIgbrg4pjzDnIOPTTR3PYO2P7g7/b2t9krRFyOtFNhBAsE8Q6sqTD9NSeCc/yd9rBhxAMf03oeYyGxmUZ0iIkRJlKYwwJ/nrMjRZFtjYgd/DBIH7L3hnHQXPhFYgZoGEwFJF23GDU4k38WTC0whBc6DtDhzVaWN7fSMDwnACsjbFK+t1asKpWsY1Vk1jrP4+Vhf+FuWJPxJMMgV8ZDY2FgYQQGU5NLa2fnV1ClrhTN712HwvTM/j9d70SH/2fr9FnbBh+dr9foVQ0t26SEukSDc6sVL1//dEx8ZUfHsbRmQJZkuKGZ27BsNRoLy5g/UQD/eU+Pvefj+Pu3TNCJQ0ImYQEhfGImgREgqJQ2LR+RP7z373TfvhvfhGqPY3ju/dCKQMFiZXFNtrLKygLhZOzXRw61X7CWEAODbWw++D01oP7jgKpQJqlSATcAWqlgMRi+eRJlAun8P73vgqf+5u327M2j61zKWAFIFK4IwcSxroVpmariaeOLmz92BcfxPQKMLFhAqgqJEkDdz14EB/6zL3/+sC+BSFEiiRNXaUj0CqVBJCgn+c4c8v6if/4wgf7t/zcMzG3dxdUfx7WapT9LqBzGFXg6UMnobTb9kHxgpor4ZkzlNqKvheD1TTndcsN6/ODUTvEoKsYrL46RNeEgN9k4K29w60Mlvm3sr07LkBsSfWF+yIS5DxPKACrwCXFlwgFCcpLBgTEAPCffmMj+HVCLqL+/jC++E/6MmpCSCRJEpHJgAKoI7NYmSfirqgoOdqkKkOENEKcjo0FqI8JYPnKgsUfRDVeIfo5kSLu+wKhW7iFh9OFAQhNOPn2i0N+lzhHwz4i6oUXsKAtPwGI1BE6KZ2Io2jSfewmos2Axgb4Q/A/QDSTkGmKfr9cOH5iFunIsEsnDYlSW0wemcRrXnY5Pvvnb3rgvO0Tv1/5ZIQSlFHXbWxPpICUGX6wc0Z8885jOHxyBefuWIc1IwJWFRgbG8G/fuMhfPu+Q1eWogGRZMxjk7AigRCuxFpZ5Lhwx/rLvvzPv6Pf/PpnYHL3Q+jOTUIkEkVeYWlhEcsryyirHFqVOD69gsn57guTJIHMsgx5qbD3qYNAXiBpZD5hIFCVJaqiBKRA3mlj6sBe3PKSC/HPf/OL8xeeve59RmundGScBePzN6VphvsePyb++asPY3h4GEJqPPT4UfzfLz74wWOL5duTLAmn7S2bikRK5EWBs7ZuWPe1f/uzxauv3oSFp3cBNofRCmXehar6sEaj02ljz6EZKG0BEVe26DMYy4lungWfcf4MD3oT1gnrjxEm1YSxxtiEXGjPlLVBMdASsWMkixDnoD6IiDLc94PWP76vbnlj0J3a5217cxwFkz0ad/kzGqCOfrj3Fd1dhGywFIOjB9yzJrTNn4toWNZQbaisFBBLdNn5XA4iwhBbY0qmdj20F8cVhNnzwSAarb+jPte0iTq8g7uCpPxMfU9gMKjEOxDO1hrK1ktbU9jCA7/fxn4JbxVriIwUKKdXbeJoDhCMTKkUnjpwCkmzAWtcUlJjDKywmDkxiWueuRGf/MBrP3zOmWNvMD7TDKePsRpCAmmS4ae758V3HpzEiUWFoswx1Grg4JF53HbfiW8tdOzOJCWF7o0hnDJMkgRlVeKZF55x/xf+8Td2P+/KDTj6xONQZQ4hBMq8j+XFBawsLqHX7aIqCnS6OY6eWsFiWy9nWQpJeZKe2ncKC7MLyFquJpwQAtq6DIqqLP1EG5w4chjPuWILPv1Xb//glRdsurMq3Qpl4na+gvK4SynRVxYn57u+MxWe3DuFIzP5B9Is85lbY8oMWo2oSo1tm9eO/edn/3j+iis3Ynn/biRSQ5eF2zdWldBaAcJgenYJR0+tfCoqlng0hGbNMEESA5MwGJOqMQUIcbnJD4VvGcqiNvnf8Rwp3AF6Keo7070QRnRE7yJbGl2akHdsYEzxb/ePhLuWOULAnxMMt/n3ciTFEAIpB0YTAb5pdiANNgkLa5dW0Gg3PQb6HOAf2PUoeZFGQWHEeSJEyenFbg8oSwjUaleSeZRytaGhfX+8TV53U3h4xfkjxMGAkK8rzKX/R6v0sVRdbCPE1YTwC2IsZQ7rBw9XBN9+FcLkMbbVyLJGKz9v0rrzw6rS2LV/EsJXvnaFVrQvcCwxP7OAy85fg0/8j1d/5cyNIxOV0uAuMbnqVghUIsHD+5Yan/jq07c/eWAFjSzDXE+hU+ovQIqQCih4IHCKL8/7ePYVZ/U/8/Hfuu7Kc8dwat8uwChYbaGrEp2VNhYXl9HtdJH3e7C6wkK7wPGZPkqdIE0zSG0FkAzhiX0nv3rw8AkkidvX4UJ97ixUpTSqsvBLq8Ds5DFcccEY/u7P33TDVRdtfDwvciRp6rY9WOdKEsLIEoFUuNQ4ZVmi0gZKu9UNQijOVUugFTAx3sI//u17Vp557SXoHnoKSUO6RGh53214VQqVKgEAh4/NYnq5eidkCoQVnriiVlNExqw6qEtoK94nYnYIRDQEi8Bkgwgvrvi5ccQsngztof5cnStZrI6e9XIVA/QkQCbszh9Ej9xK08/gWgQEBEaDoPVhLduNDtaX4O56xUfKhCtBr8xseLffbuBRpzsS5JQrFV0Q1obzdMIbvlqMqkarSPfYR8voxe06R3oDvxu27YLeAwRECMQcYMaY2vtrSA4D/WQIP/AQU7qcNwCETAvOWwHIpRwcd6A/IS5iGTZz8MjO8mcY0qH+0Mchc4METgZ37z0OWxRIktShMKX8jnsFCGBhbh5XXDyOv3zXSxbHRpqolIahwhk0VgAQEnmFaufhxZcdOdWDRYJEZjAaS1YbAAbSakgf425kKbr9Pp51ydYj//jXv9q6YkcTM8f2uTnUBlZprCx3MTu7iE67i6IoocsKMBpTcz2cmOnd6oCXgNTaYqjVwJ5Dc2985OEDQKWQNhNYXXk6uISFSmkYq2Dh8rwvzkzjqosm8KE//LkrLzpz/O/7eYE0SZ12ph3nVkFp5etaGPSVDhtiCc5S7iGtDRoNiQ+89+ftq26+Hu2jDyLJMkBVqMo+KuWQl1a+Taux5+AU+qX2Fi8ydogBeAtKBJdsJ3z8cESCcBbOWfwQBuV3B6VSq5Ad+SsopIBimAtiLWo7/YOGAXMRyFWEreUzAyISDO8ceDGvsCTEakbmQIfHo1afxQOjQ3yW3L54j/R5/wnt+DhmoLlHI7Spk6AGWQbUV/HovavdZBpi/dogIuYD/O/aqaNdu+q9NSWEOnInxF0zOIy+p/ud2NBpb4BcRUJwNYXHjC7t5BdS+BoL5K+4Bql3RP/BOGW9z57ctH1BSuw/OnP+3OwyWiMjLtuxy8gAWA1jNJIkwfLiEl5w3Zl479ueY5tZAqXdxnZKeEjGLxh4AFZINBoZRCJbFs5gCbhMFlmWosgL7Ng6tuUjf/62HVefO4K54wcAq0NZxk6vh5mZRbRXuu5sdOUOWWttcWyyi9nF8tNZw2VtldYYZEkCpTXufegQ5ma7GBpqQpUFqKKOtRZKGVSlP51uARiBxbl5XHvZJrzvN1/57vGRBEoVcP6uH5gBykrvrbSB0QZVWQE+txgXcmsBoxVueeVz7Lt+47VYOfokIDJYA5R5H7pSUEWFKi+hKwWrDcpegSf3TaHSPncQ361tWPwlKDW+ImTr7hJjopqQiNPEJkioV6EUZvW58JC41+BgZK3BEvZ0L1lTyu0UhZBQI0NiloQmtkdtchRJsRgupKGqEvXDW30x0Kfa+wgZMmlblQmU0OogqiCUYCPCjLfYMHaCHNaTzpkTU7s/xDQ9WWroM6AfsN+ZIhNx20iYCz4HNIfs78G5qsXC/D/D4nDg9w3ykf8X9rY5mImQM5+5h46niJYcEUZ9TdMeeZnRnFA+GXnjQMPcXPvg3qePoTE2DKtyaF2F7MpGaxilIYXA8twc3nLz5fj5V1xiE0G8HvkgjhsQxsBUrviONTbnciilcLE2q/Gn73nt5POesQ3Tp06iqBQq5QbR7RWYmV7CykoPVaVdaTetIYVEu6twZKqLTmGRuvYhnUY2EEmKB3Yfff/jB9x2CgunjYWwkMLlxq8qpyWN1bBSQiuL9soyXnzddrz7zc+1tupBQCPsyQJQabtXKQNjATWQFkbALaGrssCF52698UN//ivoLR0HKg1hJZTqw2iFIs9RlQW0VrBWIU0sut0eDh1fmjKaAql1pMT4Z4DR4hk8uokjpMC4p2FSYu5o5GjVqc7oCHua3MpZkkRUKgbaFF671MBP7FzNLeC5vjgSCu0NIBlSdo7T60iDv4hKybsrcYc+vz/usyOaUryTBM/dR6u9QYkj9im6yIMojGJAdfTIAYUPfSOsWjL0SBPD0WIgJfVZ1MdkazQXvg/1OYr/+cdZHC1Wcuf0trW3C/9y6zviFLZ7g3OtfQzYlzIL/FtDvUS3+rxyfqkp5qC8bY2/+AIHhKsRUFQKD+w+DDSakEJD6xKlKmC0cnFwn+lUpkDen8Pv/dLzcN0VZ1hjtDPuQkD4PTCk3NOmBISGTAQg3KZ3kpkskei0e7j1DS+yr3r5leh1JtHvdKC1hYFGUZWYn1vC4mIPZaF9QlOXPz9rpjg1n+Pwyc4HhUzgQL6BBAy0URhuNrDvyMJfPPDwAehSI8lSGOOq6QIWSSKgtUZRamhDKW0kiqICTIHX33QRbn7hRbbX7UEmsVx9Veh9Re4SHiodeM1/JMrKYHSkhff//tt/uGHrMLqzC0Da9FleFXrdAmVZQfk8RLAWiQUmZ1ZwYrZ/sRHCIUWvMVfHEVDbMxTRSkQVgy4Bt+SrXARCLczNG7TsGHjOGKDO6BGpcWQVFSftGRqw+KxP1kMTa+rMC94f2ktmjBMtpmU5SojxIyKjUxexbwwZDQiOsQYGqzNxuBeZVc8G0fToMiBDW1cqhLys5fNQV8AhXmmDKg9CW5sSEat10/vq1bsNMDA3hE4J5tTAGp+TgPzqMa86ah7kK1q88gsf4G35efZbgqhYTj3dTOSLuIpsgnH479/rM6p6eqvS4N4H90L1e0izDNZolEWFqnI1WKvK5QJLhYDpVxhqlHj/rS/Alo3DE8pYp6AMoUM/F0o7AOIRFe0PTJMEvW6BKy7ccuc7f+llWCMN5qaXQ31HoywWF1cwv7CMoqhc1W7frBAuZrf3WAfHZvofyBqpc3dhIQWsqwuXOsv2wMMHcHK2i5GxYWilfGVp6/MpSSjt0kjDGhirAFi0u31sXNvA2295FrZvGX110cuR+tWNSpt/KkrtNsgywjpQYKFUhec950r7cz9/A1aOHkSjkUCaCsIq6KJCVRZQlQssuhiWgpDA/mPzaOd6OZHpAEPFuA1B91oWCLafiMcMThdLiWlZ6swb4j1M2RBErsWwmMXj7lRw4Qbea208aEwKoSYYtfHReDAQdGbozsfoXIZT33e2m7xGLzZ24ZUwdzMtRyQ1OtEAGWoI7oV/zyrkUN+Xhdo4624J72v4negZnmfjgQjvCWgJLP4p4hx6QgWkNEgX7pZSqCOMhGlaIQbpuXrcnNa1T+CFiLIsGRXB3xX7E8MZg0ZjoG+D7wqKzyk7IwQeefr41skjJzA0Mgq39UX76l+U+saZsyxroL20gqsvWou3veKyxVbqsnJQjJbsaJJICClQGQMDPOK2SwjAuFj67/7G62+47Nz1mJ+ddN6ctx3tdh/zcysoCuVjatH4NrMUs4slnjiwnPeVTzttnfcmCUEYr1Ef3HU8eXjncTTS1FsK4+MyQJI55i+KymlJHbOm9npdXHr+Orzp5c/8VlUWkNa4HGFK9/v90m/TipOeCCDPK2xct6b1h7/9ZujuAnTRhXOTXI79brcDpZxfDrg4jbAGSlk88vQMSmWQJDJMDLc43D2gmAqPS9UmmH0XBNoSYOGrj3XFZK31KMBdNxYwqDN+jOfU82zFGBJTOMKtggaFw4S0Ft+JnBqUxCq0dhrGjmg0KuWoNOrPxLiYjX3h7bOxkQCaWs1KJmhMCYccYGHkfrHExu0XhLq468nkLx6gJiTKaEjE4YLO43MmrAISQrcehUbkFONUEQlSBwbn0NiYLcRlJObKzBkYjh7pXVFnRrcyKF26Fuak3kbYi2bjfJDq5sgQ7LuICo1HRQaJEJiZWZp67IlDaAw3IIWGFQZKuQSE2hh/6sa5comUmF1YxJtefjEuO3dt36jKZ85y2ZoBuJ/GoNOvoJTpSSmQpQlW2j3cfOPV9qafuQz9zjS67TYo7VaeF1hcXEavX4WtccRPLvtHiqcPt7HnyOKQTBN3j3e6QtIlpTWGWk1ML/TMD+/Zi5V2idZwy+W5FxJWOOudZRmMdVV0ldY+97VFXii0hMFNzzkHV1+48Ug/z5GlKbS2eamcT5ylNLHWKT6j8LzrntG//oWXYunEUcjEEdEYjV63gzwvUFUu8O/wikaSSJya7eLRp+c/bCzlyBa1iSJBceiD0EsdodmBySbEQtcJIdLHteX6LoTwyNQJPyEvASrbOogaqHfEZq5HcQe+iGlrvBKzgIulkSAMKCmOnGooDmDvrbtFg/G8Wv8YWAhKR7pYSdhfFmJV7hNWvhgYCsbBRjo4QXcrTGHllhmIEICmmJrwlhyyNtY6AiEaxkHX5jXQnLmJjDrBEAzQpI7kEOhPNBmMtPL4FwKS4jFV9j29jwGk6PwKrm8Q9t0RamVGkVcPr78/0gCIMViuhEkxWuvSAhWlwo8fPAghgDR1O+MtLIym4jxu+5E2GoCEqhTWjgBvePF5rbFW4sspRoqUWsNIi3auUGmbp6nbBtXMBH75rTdi64jE0twcrE+zbYzB0nIb7U4/hlocDIDRLmvFSkfh8X3zWOm7VUzaTmOtdZW5DdwqIZHi7gcPvv+JfbMYGWpBlX47BYRrMEnQbGbQxqDIK3fQU1fQyqLT6+OMTQ287AXn76hK7VSOMXnRLyCMQZbGw7H9QmH92jH81tteCbU0A9XvQAqnwYteF71+B6os/OFxZzGsrpDKBA8/NY2T8/33JlkGgTjrNeuJaFFpYINVqTkzAwh7dBya4pbb30cJnYJ14/EzYqaoQFf1A3VFyi0+CXzNlQlWs97XyKT1/jslevo4XkSY/Jl6bImjO+PHasP5VC5oMTAdlB2JvKVRxhVPwO8LE3EOav0O//doSPgTHUHp8pXJOnolax2uMXoOvicg5fqS3UA/bERmQGgnzDFEKLQLEd9tbf09joZ1OlMYIfa/rjQ5X3C+Wu3K8jnlSjrOoWX9prkjmhIShTceP7r/wIenplfQGh5GIp3xMMYpMQtA+cU7rRVggKWVDp531ZnYsXXkm1r5XH3+HVWpYEqLufku8lIhSSSW23285meutM++ajtW2nPo9bqwMBDQ6HQ6aC93XV0LwCkv4UGOqdBsJNh/so0njyxtIZTKQyYyMobbwNdsNrDv2OJf3HbnfvQriebQEIzRbP+RyxGUZRkqrVFWbk+WhUFeFpC2wHOu2IyLzhn/SlmUAAQ6pUKWSgw1XbxKeyY//7wz7YtuuATtqaNIswRCKBiVo9Npo9/ruWpHvnacsK6obbtb4O4Hj6JUFjJJCZ5ElOIFi6OSRCagWBAGmAXMvam5UPC5nySH+86hDuiOoZFQBxIk/AOMSQoWCJWGxeA7hfCCHpEl3Xc6Bq6PI7oZ8W++KbcuxPxZOjAu2BzLhILLNuzoj+7hIA0HXBf2oTEQDVxshz3vszxIUlRERRFdKlLultxZMGMgGJ0t7xkCahMitgfAr5ANCP9pOh+MX7gsaj/Anh/8OAVDBoMhYdAcCoTlExvU5Wk+pMQiL9T27NX6RyiWcBddi//CuOD4I0kSHDw5/977HzuM0bUTyFKJRjN1tCeDLBDjUsIiz3OsWyNxw1Xbbm6k0h3lozmWEiKRWO7m7iC2cqN80+uej41jwMLcDLRyqK0qS3SWl1GUOQQivRIJCGuRpRJFJfD4vmVMLpbTqS+5FvnfUrVI4f1NjTRxRPrJvfs/tWvfPNaMr4GickhCwCFGgVaWIRECVVmhUgrGuA1neb+PrWuHcN0VZ74BcAhsabkPAYvUu5BKucDcy198DeyQQLmyCGENTFWg7HfR66ygykt/pky6IrfaVR7avX8Gjx9YGALSeOQDEfJzJqY89fz8GlnoaK2YD8KYD56pBaXQtDEW6IhhgrBxxgjuJxM+WF/CjL4gizWgjIwxER7H0khBUDnzUfv8H1eaXOmGfsVGQmEJBlDDvRT/Cu4tCTnFMQfGS0IJIDw3iEytjTUHiCxCoM6QVkR5rCEWsN8pRmRX9Tm4pYwOAWFGIAJSh4KNgfgl0Dz01YaVXsZCnGDh10Flbi0Qyn5y5ERuIa1+ChZYYKhRCOqL/44PwtODj0EQcQkB836wMVIQ3xqLLBFQlcG379gLiwxZ6sBJ2nLVv7QrJASjBbSyUNrAKINet4trLtuK0eE08jmAlhCQRmClk0NboNfP8bLnXGSvfdY5WF6cQW+l491DjU63g36/50CKdxud/hXQ2mCo2cDhUx08emDhBsApNuNTWRuf7lwSDCZmNVqjkaV46vD8O7/904PQSiJrpi6G4bWksQZCWjQbKYR0mlT7EuJVVaHZNLj0/A0QAIpSmeVOjiwVaPhFAKsM1owN4cbnXwjTnoeEgYCC1hW63S7KPPc+t1OqzohZdAvgv+45hsWuymWjGRhDCBHODfJq2Txoz/NI1ZjRxy547IOEwUFsv+QtSJSjQLrrsXguoUDG0SCEJxF3XgvYOkOz+4QgHBIcjPD/GsoMaluE5/gufD5+otHgql5UBFEIJXuGx2folf89UqD7KAAd42V1JY9VdKrFn2roEDXkFOOXg/m5pEcxNswV/5BCo/YDv0ebx2hrI13DuAcQT2wZ5OoPolpOFT6ewDukZFcZAR5W8HPstJTPuBLnB4PvFICFi1lRe6QESdGtmjHf5nfu2S/27JvH6JoJJFKg2WxAJBaQCMkyjU8PbYVAr+hjxxnDOOuMsfuBuAq5fsMImkMJjFEgbnn9zddhfUtjYXbWuY7SoswLdNpdVJVCAhuOUbsarxaNRoLSAA88NY9jM727kyRm+AjevQVk2IvjB6i0gUgcY9x+154PPvzkJNZPjKIqVThuaIyF8iln08RlTC2KEtpoVEUJXeY4e9MoLjhrzfs6/Qrziz0IC6RZFiZ+fO3aCy6/cDvypVmnBIxGVeTIez2oqgSMgdJOeTliJNj59Bx+unOmYZAy1y0qnLg0Hn8PbpnnpUHLTSgkookBVBOYUAQt4i6Tta2fneSoh6SVuyekLla5hGABaIvAtFzpkmKg9vmY6Fke8xCo50YH+50QhgMChADjHjfrzLZHSx5JWYByU9XcXlApN1qxNf64WAwg0/Owg/S1IWtypGFUQnV0iCCY9DcF6CONYzC8XmMwNlJDXgIMjUa0Rpp3lQuPGGcE0WnAGAVFFGact80MXWCvAbTI5oe3a2zsRw2RCk7ketiBx3Hr/O5erbVBI8uwvFzgc197EK3RUSRJhkSkaDYaji/gEJzWbm+YMRZ5v8JwKnHxjvXXpWmMK46vGYVSQN5XqJTBhdvWv+/ZV56F7sos2isdQEgYpdDtdtDv5WGcgIVMXJp2a1yG550Hl3D/U3MC8PUg/fnZMJvCr0JGYXNMZ5RBq5lh75GFD3z5e3uw0rEYHmpAKwMLWqkzsAJIpHSbXI1CWVbQ2kCpChsmGrjkvI0fVEphqdOHEBajw83w5ovOP3Pf+LpRlO1lQLqjRFVRuCK5Ptjo6lNoaGOw3KnwtTsOYm65qmTY4uE+zhq7w52ExuKu9Lh7/bRHIQNfc7xDPBUVlxPiuGGTxhGEMFyrC/fp3jEoncENZkqXLHSohRjxQPhprAl9Cgo7vCsY8JhJAwzB1ZR57LsfQb2fRANByoU0bHTAKbZFCibuu2Jn/oicjCwBCdGzAZ3GfkWEFJ8huvOstXQzR7HU/fqcxN8DevXjofHT2U0+R+wVsQ8DY3FKw9RQVug7M55BaQdUXutuDblKn9FB0JyEf9QuG0v0E0JnI9sxugrpY1z+vkTii997Qjz82AmMjq/1Ow6aSJIUpI6dEtNQyh3xUVWBC3dMoJmlsFZjpCmxfu0ItC7RL1zChRtfcOkH169JsbK8BG3cjoV+v4dOu+3yDSIaLKe8NJpNiZnFCj9+aAYziwXSJPEGUvjx2EClWmVRZ3TdkrdLtC/x7Tv2iO/dcxTja8ag6aS6v1dXGtZqSClgNNDvFyhKhbxfoZUCl523CQCwtNKDMQajY8OAAJoNiQvO3QIkBrrqQlgDXZUo8hxaVd5tdHEgpSpom+AnDx/DvbtnBUTq94FYb82kq5CiClLkkcu8gjF+P5Nh+eXryKa+Z4hbXE5gLjhg91g7uL+K7x1D7R28Pc5ctXvCJBHnDVjeOMBwjepJ1sZG7TDhryFLZsE5Dfi7Vilj4QLQHuvEfrI2OJ0CSvTvcwqUFDWC8BGCJJEiJBcRV1Tuxufb4kYs0IZp8BDr5Ak4GMoJtLOWPcZcX0KK/HdGJz/Tq65x/R/pR8o6ruI6hcNcyLDlB9QBRJRXpxPoa8aLZGQDLVfNudPuypcytGSHrEEzy9Dplvjwv9wDZVNkjSaEFciyhisso2NNhapUUJVBr9PFWZvXYHjYlT0cbiYYGW5ipdPDwkoOALjumWchMX102m6XQVUVWFleQb+f+3O+8TiV0RZWANoAP3pkCo/sWxRSSEhpEVNyoEbremnkwFUS2mgMDTUwv9LH57/xGJ46MI+JiREoXbGJtb5YpbNWShv08gq9QgFW4ZLtE9g0MYQln7x63ZoRDLcSNLMU5521HtCFK6ILC1VWyPtFWE51QqlhhMT+I4v4t+8ffGO/0JAJIEDxOAFlDCbWDLeuvOQcK0XUzHUrz61mJAL95HGx+JyzZHHFR4Dwa4wtRLQRlABiLvUQTwvtcrQW+xkZLNpeOl9JHF0TGmtD24PIr36NjZkp0PB+P2ByG+PIB9hBRIEYRAu1B0TsM7nugM9EMaA4woOCNSEQTn4MoptACqaYQudYX4MLzpRkRFjxGA2np4AIh7Ap9sSz5CIYsPoQAjLibdVozBSN38QtQIrIb2cgfgJqFY6sjcVBAjIkBV9Df5GAvA+ni9lZAFZrXHHxjhfd8sIrrVVuj6cULu6UNlv40cNHxee/9hBGx0YgUzeHiUxD/4w1LiMFBHp5H+tHJdaPD/0NAAw10heMjg+hnxeYXex9avP4sLzk/I0oi7bbjmUMOu0u2m23bSLEWC38Yo5GIxW4Z9c8fvjwtFBaIsvSeOTM84tgvCxpwNwqkKwaAzSHhnHPzknxiS8/ipVOgVZToioqHwfTKHOFqqjCjvS81FjplsjzElvXNnD2GWv6s0s9aGsxvqaFsZGmTFOJMzcNQ5c9T1YNVZYoiwqAgNUIK59LKwqf/c5eHJvqfTVNEwirIfzhY2UshCnxD3/xa/3f+KVXO2FkO6FrR2wGUc0A+iFGdl/Z4IbQdkKnZPz3Hm2FVDE+VhSKOLB9RvG8Hykq/4bgAjELTRbUa1wuGHzv0iBK4qiHjTB8TwiJn5sL6Ci04ywcxYNIaIlWpPQGMzIQuhpEkvG/eEaP0yYqBxJwNjWkZCBPP67w6rpg01gpiB0qm0OEFV6PYeLZSLDFCkJ1TBnUxuQVY5yTOo05KuR1CYDT7Av0L3SKgUIBZNT8oouJdA3POEYaQPDkYooazwCor6BaQAiL19541R2f/7c/w7UXrrdlWSFJ3TG/NJEwSYr/+++PDN332DG0hpuANZA2FsXVysIYAWMF8lJhqCGwYaL5BwAw2szeNjTcwEonx+xC/53PuGCr3jjRQt7rAFahzEusLLeRFwrGCLcarwBlgEprpKnAg3tW8PW7J9+42DVoNlM/l8Kv4Fu/oEA8Z2MMzAVj/UcKwJ/JkzJBa6iFb/xkn/jUV5+AsBJCWJ+nR7vd+ModKZJCIElSFKU7StBIgXPOWNvqFdVdlTEYmxjBxGjrz2UisGldE7rMIWUCpRV6eQ6tFQQsDBSsMOj0DL78vYO4f/e8EEkahFx4BaurAh9672vtza+5DrOnDkAb7TJMknaWHHExoXFzPoB+EJ4jqM5XiRxzMIVDjFePtjCOjz/IdXWMuVr5xEfiqhZ3yQaaZLCirtz4CmwYB+tcLXYHsHTeETEQouTXQ4uEfhgNASCExLyCCHrPugB9QkhCCOYmRcVGSpBqQbr7mHMQwEQ0MQSHCA3zWSAhpm0F3NUczPvP3VOsaiPSLPADa996w0BzS8qEpohoYOtMGF4XlJgQQTHydwYER++vzSGbN8HaJtTPlTLiLVIAQw2L0VaBP333qzDSTKAN3L4/AaSNBhbb/fwvPnkPjk/1kDQyZ8aFO4kSecMp2DQx2DjuYtvrJoZvHVo/jFxXKIsKV1+xHWuGLXRZwlQa3U4PvW4BrWIac2vcymaSSDy2v42v/eTkp07Nl19tNtMwai99jmtprqMLGVR8GKgjmmcXo5FlCYAUX/j2k+JTX9kFaxJoo5zLVylUSrtDmNoiEQkEBPJ+AasVtqwdQa9X/FqnU2BkeBjjw40/SGQqN4w1YErnh5dFibzvNr0qyveVA9/56XF8574TwkD6YLZLQGIgURVd/P6vPM/+yq/dBDu1B+2FBdDmQGLDOtoBG+rqlTTLrBm3evSh+oeBoYJFjBsLa/GnYAltQB4RgTHmtFGRcreHxzmsjaOKDG5JqkL/OFM75qjveavToo6EwpqZF0xCNOSq1GJw1tZoRvQI/SUI71uKFXnYuy3104S+gejDIF0NTSDGiwKipg6Q8kdUPIMoSta2vPDvqV8Mwfh5obhPRHgxq22gEaMLp9Eql84ioHc2ubwHQeHU3skMx+B8BLqB08uGcfK5hnULXmtGRoAqx3XX7sAf/9LP2LIs4XUDrDVI0wZ2H5wTf/2Z+7DQ1hCpdEcGWV1O4zeYJwDGR9zugi1rhzHcamF+oYfUAldefBaE1igLhaLUWOkUKCu3EKgUUFWAyxUo8PDeNr70o1MfPjRVvDPLUm5L2BgEiIdJlmScQG89aT+ViPEfow3SLENPp/jkt3aJv//SQ+j2nItXFIXL22Pd6XQIiyxL3EFQW2HtRAPCqNdPL+UYWzeGMzePtrIsXTMynLl8+8YgzwtYrQGrAShUGvjJIyfxH3ccTfLKunTV1npBSFDmOd508zX2Tz7wVmDmOFR7BZmMFodcuWiFqNhIVCjBJDHG4VaL3IsaAwq4rBxi1VpPzcUhBRBiYIHbCUXwdqNSIrkl0afnaIWPnolWVgRFIOkcIT0rAAgfkxOxHzF+V78WR4Ja/0go6JbBGNvpP+TWyiCEhB4sda32Pvc/Z54IkURixHtpDiNNI62i6yXppIOIe76C0mfzHvmCIRnL3xSfde2R8hKMjoFLCIYGAxYAF91HBXAswr5Ay8YU5iMgjzricnQS4S8eywzrwWQ7whOc45ybuO3MjdDQqLrL+NVfeC5ueeEFtqxcPExYt20CWRM/fOiE+Mhn78fCkvOutNE+GaL7l6QCEBZrhlzmmXPPGsfY+mHMrPRx/pY19qJLtkLZCnmeo9cvUZTKs6WFNQrauK0W9+6ew5d+fOKNh2aq9yZZI6DUGv38P6eXAJp5J/YDlopgtpsIp+aMtcjSFMpk+OLt+8WHPvcojk8XEDJFPy9RVQpaAbp0bqC1FrrSGG1KpBA7jp7KMTExhovOOQNpIobTNEVVFMj7OcqiAISFURW0An76+CS++MODN6/0lEmzzOfNFxAiQVWVeNaV50x+7K/eCbu4hOXFFSgYNBt0TMnG2Aehk1p1a898p7Hy0XKSEHohMXXLDwBGDCA5a0N+f1jBDEb9EPHqjw19pL9jnAnB6tXRxEAfTzOGIPLcfWLPrlJC4XlalImoiZQED6wTWo0WMbbjnuMIzbpzCzY8EREiUcA6hERZgAPCEjx2x8cfoJoTT8vOOFrWX/Y+jlKtjecBBaFupzFq9CRaMqDH0CkG6M/m0BvciPRozCY+EwwdEEML9LO+PcSyl50eYUY+pH5Ej4CQnUWaJli/bhxWWeSlhrU5/vfvvQbnbBn5G1UVfuuSgLYCMk1x+33HxEf+7VGcnHcVuo2xgDZIBC1iaKTe3T9z6xoIMYSTJ9q47JwN2DA+gvbSCrorPRSF9iELA12585Mr3RLfvncKX75zcmJyUX01STJQ2oZAF4sY3+O52P3QJUgw4RiS0FewZiKB8MyojIVMXJzrhw8eFf/rk/e9+86HZ1CpFKpSKHK3igjr93BBYc2wxYbR7NbJ2TaSkWFsP3MzksQMCbitE2WZw+oKiTCoSosfP3QCn/vuwVvn2/q21G+kk1IiTVJorbF5w5j87N+/e8tIE1iZO4VKu3JQWTODiDlwolVEhOWD8aE6AglfoPax0XIKjxK0NbWVkNBGMBdR0LkJjkqFLDvvI1/JAiRi3i4WqWL9JGQSERmfx/AtV34MScY+rxquV14MuTCXL2JDT+jYdFB2HLlZWG81JSioz9EX6YxoNP1zIgoshAhbHWpzxXKQEfLhShYD93M3P15bfV8IA1iGWP1cnQ59xrgofxdCKh2OxC37P58/ugJEvuD6ic8jj2XGG9j1QeTn0bC1Alkjw9r1a3zG1QTdbh/bNg/jb//wdX8w1Ep96ipWAT1Ncedjp8T//ueH79p1pI8ka8Ef4EGWuGzDWSIxkkqcuWMzIAQWltq47vqLMdrQWF5YQlmUPlauYLWCNhp7ji3hX753LL/tgVmx3LfLiUwQTD2JMZcpNge0omutR2AW/igAu89tBnWrDdq6k0rWwh/EBFqtJg5Otj/+9195Qnzutv04PqOhjIOZSmt3tlIrTIxIbF6bYXZuBUgSjI6PAdaiKvqoqhxlUUJCoNNWuO2eY/j0fx24bnpJf1okjWBMaGUsTQQ+/n9+XZ9/6ZlYOnUQpapQln13Sh7CGW84lW0RmYfxTA1VcEtFzMotKVkv61EVFWIld62OSOrBfGqTXiq8pEbDHhFP/W83EcZS2S8uuMyigqEMy607t/o+pM7QIgkOjwuSdXe5skRACWTQo0IiFETjdu/g7yPBd6tHlgnj6nfX43MmrDhFxBnHJ62tv4dIS2iUGQAeiyT0fDoFUI99+n4allTSX62VPWNtA5YhZ6zajhJQ7QDtLJyCpkUUCkq7hABuE6xk880ajDwFRp+AWfzYbOSzYNiE44UsTYdHh5owhcu9pQ2wOD+P667ZgV+/5Vpr/UKatLTlxEAkCfYeXXjhX372kZGfPLaItDEMSJddJEsEYBTWjsgrtm7ZiGphGa3U4tqrz0VnYR6L80soS4N+L0dZljgx28V/3nUS//jt4+Kh/Z0hZZ0saeuQn2Mt6/ubALSdxfOjy7kX05mnZB1E4iCaILMdLIOIp9IpuaFPiJZlKXpa478ePC4efHoWz3nGJnvNJeuwfesQhhsSShtMjDVxzWWbUKIAKo2R4SE0U/GHRhUQtkRZWRw+1cbn/2sPfvLElCgqC5FmbjCg5H4CUDl+81deYV/z+uehd3QXrFYoi9IVIagUksQSF9H5gsDgoCFFhyVMfIwlceYT7LsBdFSzsnULSEwUlBJi7CRYFVhHe+/y8LOHbTskRwAA4yFJREFU8D/JhTNemGjyYl8iqoSt95MEJwghQRwwhDQ4JtYHa20oiUYKyLJ3wF8nxUrKJvzOxi/9wdwggwJxWZ/VVwSim8/RI/8M9nuw/5S+ehUtRIynEe1c38gAEXH9eCXRQIT+xtMQsf06io7fBVc5alhPl7ryDAaG9QfsHndQGdHoBSRHBod1nfsbQfGF4YduWAAjo0PbR0aGYVTbnawwFpUy6K4s4Vdefz3ufeyQfWDvjEiSDNZaaKKdTDC3XPQ++uVHxczSRfbVz9mKRtOg0UhgLbBtY+uJjZvXYmZmERds34gNayQWF6bR61Xo9yvMLHfwyL5l3PH44pUn5/KdQgqkaeIwOYEKr8CJaI4CFkJqCCN8fjwJY1yVNCkkUuvPHDoiSjSbLSSphIT0gXk/fGtDeAJhB61bItc2xWy7xG33HRd3Pz6Fqy9ea2+4egsuOXsEmTHYccYIOqaJ9uwi1q7JcM7Gxq0CFYp+jkd3T+NTX9+VP3V0ZUgkKYRMvKZ1widFAlWVeNblZ9s//aO3QM2dgir7qIoCqixc3UqtQIfMXRaH08FvzjR1wY33RIauM1poKTIy8ad/hkSOFzMlRhJCsGM4tJeqLoRcKCmRX83YMgQwuFJ2uvFYj6bA3ktt1VesCKUzVOPviS4X7wgTCkKHniLCspgW4OYBEbEIUqADSjtS+DTzARl+N8YpfwkBbcgQILRRa5f1D7xPtaGIGj1XKUczyCOyVjeU0/O0vIT4jsgTpOBjzwaNxKCCdtPI3N/QvljNZ+G675t1Ofws3L618bGRi4dbGape7uRMayQC6HU6GB4F3vsrL8Cv/q+vZ8tdVQnpD1B7nk8SiUpbfPa2p8RSu7RvfflmDI0OoSg1No4NYWi4ifbMLLZtGkWZtzE7uYjJ2QKP7Z/DT3bNffjAZPe9SlPKqOgxWO8HiqC8LAQSn87KQNgE1roszdZajDRTrF8/tnFhpZhNh5op3vUrr7CjssDXvvPQ3r2nehf3Oi5Vc5KmSNMMQgi/495huLBo6898JYnL5GiswHKucefjM2L3oSX5vMs36JuuOxPbNo9hfHgIK4tz2L6libfdfDkMBHbvn8c/ffmxozuPd85uNRvBegC0Fc2l0pkYawx/6M9+CaOjEu3jC9DGou/3jRljoLXxWIcgOLUjeJMMvdTNY4jzBJBBKCNaOxmUQY33mKmNzzomdAjEencwIdfOc2RgWv+M8IzrLL8AlzgewCVrTgIb0ccgZvGCNYgYmcKgd7v3xqcgiFaGvYMWJuqu6GpEWKevIBRvbYgjUgcsHJEEZaD1fXRbVmw8T8kEGRYhow8paADwW9przmV9WgdoisH7GY0Q31db9SQlwV05plwEJ0JoLw4hTCOb34g6mTF0zMD4JbRGVqyG/h0darMaPrEWqlu927Bh7OutoQT9pdxVF7MKyhoYIdBenscVF6zBr7z6GeXffvFRYZF56+aUijVeGYoWvnX3ETHeVPadb9qITRMNbHvWWRhuSeTSYO34MA4dWcAPfnoUP37sxNGnTnbP7isLCAmZSEiwxSdC88YCcMcSKW+fqhSKqoRVFaSU2LF1/Iybnn/2yV943bWYnsnx/o9894Npu1fg/LPX45d/9WW49VduvOjIgRP2vsdP4O4HD+Lh3ce3Tc51ThkLd6gzSQEhoXVcQXIvdBMqhWdIkWCpZ80PHp0RB4+v3HnTc7ffcNMLL0VV9DGUNnDxBTtw+Egbn/36E3j88PLZWasBZSwSGSdSkhCZCr/4xpd2n/vCK9A+tg8QQLfTQ1mUMD4wqP35TB8Eg/VHQRAYzUYUI0hITIT37EAwt6KRPUR01yCYgqQPCXVEGcSkHMKHbjAlQFqR/oquihuO9ql/KQk4VxJkkYM75Nvj6IbXffS4Kxz8NjQmwZVdpEOI43mh8nI1gBaI9E4JSRn3WkWl67QOjc2RJyJWQn8BqUWyQgjuVCDGBvknoFh6HTNGTAEFJO5ndRUsC0iu3jT97Whp2XfUtmV/hz8HUBnNF9/egdpzAe0EJepkzFA/GK+IQSIx9Op+1JU5zf34yBBkaqGqAkb5s82+gIdVFu2VJfzcSy7CTx48Zh/aNy+SrMEQpGvcnX1O8MMHp974gmcuf+WF15+Hic2bIVWFXq/Crj0z+Oadh/HT3ZNioacASGRpAmtdiiyHrASsjtl5BVziUViDsiyhtMHGiZHW86+5tP+8a8/DFedtwnk71mBsBMgXZvHt/3wY+47NfyAFgNu+fR9ufM652L55DMPnb8Hlz7gIv/H2F2Nxvn3y0SeP4/t378Z379zzwUPHFz6gjIUQEjJJIJA4T9VbFdprJSCRpAmsBA7OVS/8l+/ux8n5wn7gPZswtmEExyaX8OkvP4gfPzYpRJoE5UDMKYQ7ASB0ifO2r7/zd3/zdVArM1BlCVXlKHo5jDF+BVL7U+5Us81AInEuhiDUUWf4ENwXkQFq0JucIhFsdxRIgaikaoJhVwlgEB1mbTgKpDbrMSaySqgxZs09CveKqHwEU24Iu4Jiu8Kuek8QKtRjcbXxDSh27jKHQLsfaczVzoPeXp6ZIo9U5QhlsG+e7h6JaXbPad3E4DMhVGr3R8GdamYCz7khxrLo+cgHtfCBjXMXeWNg7iygrUu8SSm0w4zWjA4YnwhYYZhRQjBKob+eFyJ/xS0cvE/x/5F+7g0C8OXPsiwBrPLei5Mf+E2p1hiUpkJrWOCXXn0p9vzDPehWJoAJop6xbjvGTLv/1Z/snMK5516OscxC9fo4eGgB//ydp/DI/kVRWYEkS/2KfUTzjH1hpQSE2zda9jsYbjXwnGfusG96zTW46QWX4IxNo7AqR2dxAXPTJ1DO5Xjq6Wncfv/RB6y1SJMkwXfu3i9uvvtJ+8uvuw7dbhei00EqJdY0MrzsRRfgpS9/Jv7nTP/9d9+z5/1fvu0B/PD+fWJxpQ9AIEtSJIkIsQFyGYy1SJAgbTTQyUvc8ejJoZsePdh/yxuej8WVEnc+clz0dYKUnhU+7mMAkQiP6IB3vPnGGzaeOYb5g/sgYNHvdGB0BaN0SE1rtJ8QT2JX3Saeo6tBdCAEuMPqFJv0aHH5ClXAR1EZ+mcRGIhBf99YWCEDPWZr/YnCWBdOAC4DgM9IGwUNAwLkmdYHmmHrghIEIigUrnhISbvYiBFghVsRdowP0sy9VgSbHkSE9Z0UCXfTYj9EoAOp2bqesOF+0p/GT0Q9dkao0RsPT8/g4gbynE7x+PGJOBeDysoyJBSRlQ00qymNwAuWvC1A8IWJeG897hn7ZGp8xvoz8HydH0Wt33wIANv/6LdzuDJpGlYrV3lba1itfdzY1cWwBui0u3j2lVvw3Cu32B88cFIgyWr9cDTXyGSKr//0sJhoCfuuX3gOTFnhgZ2nsOd4WyibIkkQ4+t+nh1bWUiRwIoMRlfQusC2zRNjP/fKq1fe9JrrccUlm9EwOVaW5nDqyCSKXoFet4Oi6CKzFnc9MYWdx3rXSymRNhoJ+n2Nr9/2IF74rPOwZcs4FufmYaRFWSrIvICU82hlTbz6pRfjFS+9BEePTNtv/2gXPv/1R766+8DUG41IkMoUgljK53U3ENBGQCYZVnr9fOfBRbwNFtu2rcXYmuYVKwvVzixJUCodXAnrmbaqFC44f8viL7zlxejPTcMaf+C7X7oCA5Tx0Zd0UuRGCgErbFA+wZJ7AaaPgIj1Ij3DB4FifEOC7xE9jCCBJgtM99GzpLhMLf4Q2mVK1dq4GuYUlQk7tekauZJxdc111/DyawxSBCUq62N1feaMHjQ1AqjzgyG3k7XqFbMIihk1WjILHVZgI0blAefgqtb9uSCTAQ2FY1ukNKLCjYsdDN0F3el4KIJYhmQC+mXPUJkEQop+/gJA979wg8A/RH+O4GtZbYOLNLAAREqWzZuteQrsOY4ag/Ks9cBPJZsXzwOkuKwXCG1M2KuJkF5aOyYjomsDKQq86aUX4oEnZ9Duu1xd1HvKUiwTgXY7x+RCH82RYXS7XRw6tYRcG8g0Y+hYB7oaA8jUFQVSqsB52zee9xtveeGBN772WdiyoYnu0gLmju5D3nPZWpW2gDaoygKNTGDvgRXc8ejMXgOgkUpIGKDZTHH7/UfFf935NFKZuE2jxqLSQFFo5IVCp9vG/OQRLJ86iE2jBd755mfi25+99Q0f/5PX2XM2j7+rKAsvkO4sJJUd00bACol+aXDg6Cz63R42rV+Ds7dNPGG1du6nt3i0p8b4gN7rf/bqibVbhtBZmIWuNPJeF8Y466G1I6L1FqUsVVAyAEKudUc4YhJmbWvM4zia8tRHoYusZMklsTZAeHKhULvfACaeu4sWHuE+jrzCO6hwRvib/eRWG155EQqhMVIOe+9KcpeWCwR3mbg7E9EmEDyp2JsgfKd7PoyflFxAT9FNDgqSFIWNyCYoRstoKYCwgsk1lEV9XNaCb2zkK6zUl0FFRoMV3BVmCJm7hPU54miZuW80Dm/szMCchSA/wOgWXW9SXFEJrUaGHFlHxBv7FzNjsArdfg8cr0bUzwsYr8CsD+Ibj8K03xQOCPQ6XVx54RhecMUmK6xC7JnbKy+88quUwvatE8iEwKmZHo5MtVFWgFsi9sVpYrFBiCRFVRYYGWnhfe95g/3hf7z/wG/84nPRKOdwbM+TOHnkMOZn59Hp5MgLF6OrygJlmaPTLnDPE9PYeaR9sSvEbSGNtciyFIW2+Nbtj2LvoWmMrBl1K3tCuHTReYGyLFCWFYqiwMryMuZPTQHdBbzl5mfgts/c+rHffP2zLYxCpRSSLI1ZOGEhpdt8dniy/a2ZhQ4m1o7gorM3eqJQ7MZXq7QWWmmsXzuy8TUveyaKuSmovISuSpf1gq06Wmvd+SwA/VyFyY0fYgw+4aLORFyQ2PWASrz4DMaOgoUU9H3EbnxPj9vnYmr9gLVsMyzq3wVBEQPtx+9idSUbBKXuGg2Mn8ZGKAR8zPX3U1tS0NGcGLcgneYsqQnjBuufsQZW2Ci0wtteJnhcgYSeknKArc1B1CCiRhNyGyFE6LsQdbRUi2GCtekvcoRE6YprsUgR0csgfQKEG0BEhN6IFwTjQYARMXDWaiMY84Ah8kMgVICGrB+E4IiZUP9JyArAcqcPpbTLQQ8T8nBRdhBrTSzQazReev0ODDeTVUkhrbWotAGyBJdeuBnNzOLY9Apmlortxm99gUCo3JVmGaSQUFWJl7/4avv9f/sf9n/+1gvRyidxcu8uzEydwuLCItrLHZT9wp8IsNCqQq/bhtEKTx5YwE8envyUsgJZkrj4qLWA1hZDrSZ+8shx8Z07dsNoF/PQqoIrQlsh77oziw79OMVRlh0snDqCNVkHf/Hem/Dlv32rveTsiW/2um1k0vrySBrCGkghMTPbuWXnU5MYHclwyQVOgRWlDrnYifmqssTl558xc+6ODViemYJSJYwuobXbwEYcY10RYGgNLHXK4F/DRObgcZlotL01ZEyzWpGxGIZnXHcAlwSEVUQiQbDeAhsurJ6NReyPO+Hg2d1XHyK3oobQwFwAOFRJ7glZ2Sg41N+6kMTVRyYwNU8jjj/E3Kxf7ZO8/bgqGSsWIc7FAOLjgm5jB2J71E0LHwOlP7gSETWaROTB87zVzzjS89aysRGNhQiCKAhxA7X5iqhShHmpG7aBGBYbc8gxZhEFXvBooV/k8hvJo3KkGWRxS9+H8DPwBMWgVs+fe19E5sQ7nKaLi50X9/PSnzt1HTXGQPvq20ppL2MCnW4fF52zFts2DX1fG+fhGGOgjTsx0S9KnLVubN2528ZRVQX2HpnBckcdd5uODCTcHrNms4GyKLBmrIW//ZNftp//2Dtw/kaFyT2PY2byOJbabbRX2sh7XWhVQVt3mqfICywvLCLvtrGyVOC+nbPYd6r3zjTLwnlnSQKXZQkqA3znxzvx9KEprJkYdWXCQ2FTjbIoUZQFjFGwcIUutQW6nQ4WZydxw7O34Ct//9ab33nL1bYse4BVyFLnxaeJxHKnMg/sOoGWtLjsnI04Y6KxvVLKM4+z1BQLu+6qcyEzi7zbdcu9xgXqrT+iEnJgCYmiMphZ6MV00IiMF2MndQtOnxrSCQJn/fYQKjfnmVTCW/xYIYUEPwiIP/zOXhARAoTjXEsWs94XsPe7wG5EbtbasLoW0SHIeA+4SfQdFw7ep/iDW25SyPydADzDsmukuAmdkUvtEYeolV6jDAL1vtHBXKpdYLnSp7FwoQSiQDLkQV/XMqoGUlI8i90byBbdRiHqfBDI5wldQ8B8PgiVDVyP70dtTPX31/Q54xFvuMAWSgZQ4+D8xFsEM5bxurWUwUFgabnz5FK7hzRNgnEA3Bxr46qAGb+tolQKE6MSl5wzfhOsgWaG1MIBhysv2jK/fv0QFjo59hyeR69vIfx2CAlXW6Pb6eDqK86zX//n37e/+dZnon9yD6aOHcRyexntTgfdXhdlWUBbC+Xd0l6ng5W5efQ7y2hkwIETbTzw1OIfKKRIkhTGB8slEUdri7GRIdy385T4xvd3oigN0mYCVZZ+kC5YnncLn/pZwWgDVSloA5TGYm5mFhNpH//7t1+Iv/ztm2wmNFRVhsKlealx/86T6K4sY9vGMZy3ff3RwAieqbQySNIEV156Fvorbbf71hiosoL1KyfGGBh3eAoSAkWhnAKjTbY2xkIiQkDNWobJZ5NIMa2AwIL1ImPFXU4SWhuEmbKvhtEQsICD5ggMioBm6L2DlvR0yNASk7IxDAbLQ/zIRstf+w4xRsbfw+OAYT78M3S0KCAVeo4pKVKqIUmircdo3H11JcP7ICQh1Hg21LAGeCZOl52AjcejVY6UQCPl4Ixow3gjIh2O1hFQOucPUqqD6Id5gQPX2dyxvjn2EeFBft0tggG0p1EI4ZMpsPgiU27WWh82GFwJRuR9/x4pBTor/dmF+TayLPF8HRGf0T6brLYuRZZ2xXYuOXsdEp8XP8TVXHVqXHrOOrQgceLEIg4cWViqtIH0c9FqZFhaaeN1L7vWfvFT78Izz2/h6J6dWFqeR7ffQ6/XQZH3oMoKWluoyqLfV1hZ6qCz3Ebe60HAotvVeODpRRyeyT/SaqWwcYUnOqvWWshEwiQNfPMHuz/2+OOHsW6sCWVKt0/EardR1Vfm7Xb7fjXDbfE3RsNAYrnTQ7ezhDe94hJ8+H/8rF0zLFtVmaPZdFWD9h9ZXLvv6AI2bBzDFRdvBuBrwUknGMporB0fbm3fvg7dlUUXrLd+6dc4BQZjIYSH40Kg21NYXO4/QYetKRYSfACE8UZmlGy1aXDi4dEJuyQE2MoeuZbuC0EFdgnFCY9G4rao4A76F/r72O+8b3WAAQAhphhVor8uKXd7lKKAjBg6oFGR3qFYWBhb+BljZNQ2pxkppJqy8LTmNCQES++subzWujhZbCwKtpCsDVl/d+h3pAkZHGo7zkPsJ/8Qz4gBIoc4nx1c/KAHmRLjNPCtnh7V06M2xPhoHgid8X9uGAPakPU5xNf8LWHYrKt1RI/QFiHhotI4ObWIzJ98kYkgnUjqNDwjhAvnnLV1BMNN6YtLW6QJ3P4xABefvxGtTGDfkTmcnO9caYXLFTbUSLGw0sUv3vIC+4mP/go2JLM4tnc3enmOfj9H3u8jLypUyqDSBkWl0ekVWFlpo9PpoigraKPRaqV48tgK7n968SYjUySJ9HLpERj3wavKYHRoCHuOLr7nS7c9jPnZZbRaGaoqBy23Cu/Dl0WJbqePoqhgLKAKhaqsYCDR61dYWVjATc/Zgb/+vVf1x1qQVVEiazSx3MmXHnt6BmPDLVx7+ZkYSt1ekTSRoTjmpg0Tz9uwZgT9bgfW+DQcsKjKKgTyvZmHlAkWVkrMt6t3hwR6fvaiZaP4zWmsJ/vUkU3kwCh8MdGjY0rHI8YYt0IZBIAEvI6gBAYQguCoICJAy3iYhK1eWZlW5sj14t7W6tVBjjL4vbEPPKNrtOghrheEIvbdePTJxxz665EclX0LhsK/PKDPVSgwJkB074ixrnDGNMzjwPyxdh2Aqa++nR7h1hHXKhpGrFYzfvDzStlaAxE9Qet09osTHu3EOYzt+gY9GqovFMS4G6tgzryE0/Ez8TrRhPoupEClNPYcPOWOCMKFJWgqrHVuIeAqY2ttkPf72LhmBOMj2bvcKqVD5EprnLFxzfD2zRPodAo8uX8WK73qWCKBRiPBwnIbb//Z59sPf+Q30ciXcGzfEeSFQt7P0e/3UVYKlbaoFFBVFp1uieWVmHK6qiqkmcBCx+KunYs4Olf9oNFs+Q3qNqRPlyF7qbcmxgJpq4Vv3rFX/Nfd+zHSymCUL9phLQCDJHEnyauyQreboyyUr9prUFQKRkvkhcbi/BxecPUm/NlvvVwbmwNWo1dqPLpvBlkKXHLuZlxy9vo9Wrs9TfCTtf2sDT8cagmoqgAo5qWV27BqXJAxKIokwfRiD92+ulsmkqBSGBMxUlRI9VUlXjeyFtdgFlf62BO5NWQRSVs6mI+wAhiD96uAlGfywGqrrD5fGBgMiAdjI4LTCghgsOI2DfV0SjoKKN1PKIYp7tA3AYjolgc3jX/P3hfVHP2PX4mWnocMYjt+qZ0JJHcL+YsiXQbHHM0X68mqe2rIaNV37G8INn/1hYT/7p00PXWXlFpyY3JoOq72EppAjR5RqZNcgM0bGYr/f4iTkCuEQ2BlpfH4U8chBZAkmfceaFUbXgeQMRBQSmO0lWDLuqGP0YxRdo5rLt/WXb+mgdnlDvYfmUNVupjX8soKbnnxs+xff/zdGC4mcergHhTaIi808qKANi7wohWQ5xorK310PBjS2kAbDW0NkqyBB/a0cf9TyyJNU58Vh3sMAtKC0lk4jlBKo9XIMN9T+MK3nsCT+2axZnwEeb+PEBfQBkJYZI0M1hr0uj23Z8MYmEojL0pobVGWFZYX5vDiqzbjt9/0fFtVJYyxeOTJybump5ewaf0orrls20VEbG1codztZ6xDmmjovPRnLq1LiqaUQ2PGbYgz2gA2wdHJZfRL7Sqn0EQLEaq9ELcHhhJ1NqfvSbDjJYrnOA1IlozHwuJ/vugtIR2BUCJslWsSkBmxbHRHrEX0PUAsQ1/EzlNMreZ2goSSoxpRux5//2+UAL3XMwWNvyaUDGFwtBkJG+NH1AeO5ohudWGjOGHsh3tf/ZzqoJKt6WiOOr3SpL/jTxGrSEmeI5+/k9GHPcfbonG5tkRAYQFdhjGgthLo5I1MALVLMS73VEg5FGjiFRqbK2MirU7XP6dofCoqMqjeYO/ac/JTK8s9DI2MwRoXAnFi4t6ttRuT0UClXCKCLetH/N5D4VEa8NxnbEIrtTg+2cah4533i7SBbr+Hay86e/HDn/gDrBdzOPLUE+gVJcqiQFUW7piadrUlizx3uiMvUCntcn1Zp2SbjRT7Jgvc/vDMVxc6Bo1G5kJZXHKtZS6klx4p3Ia20eFh3PvUjPjcN3ejkwOykUFVFchaU+6wNE0BIdDvl8h7lV+hUFCmgoErdtvvLuJVzz8br3n++dZaYGq6/eKHd57A+JpRXHP5NiRwNSUtXNzkrM3jkMKtOAo419UY7Sp/++NDNGllpbH/2KLf8U8xMLfS18gkEmH8aurpLSu5AmTZuSUjS0hKRgoBKRN3DjQIH7OgTB55LGEQh/H3RMaKlpIrx5DPnjXBrXwYD7NO3BWia8TUtQwTIeWxb4UsPKKiIawH5roMjgU+fmPpvGUQYHoP63Mo8yXDO+vowRBRAFCML5LXIfXw8qAEhHArwNEgyFq7tfikrfebxhoWMJiSDciYEZ8rOF4TNBhPILTL0SZVl44K3XrX0Pi5F6G/TufxVWRR60ctBjnAX+RJlVUJbYxTZJ5vs1YDUwuddz59YBbDY2v8O2XtaWsBpS0MBfihsX5iOGRXKSqF8bEmLjlnAjI12H98Bku5/YtKK6wfbuLT//xHE+eMdLH/sQfR7eeu9oWqAGgY6xb2+r0c/V4OrSs3h9aCtnQkiUSvlLjj4Rk8dXjlja1mBmsUBNEJXpxdfYp6XMYa46tvCyDJ8KXvPy2+/uODWDO+BqrSsMpE5OAHKFMJKYGirNDNS79KWKHMc1hj0On0kKCLt/7spTh/25p3LawU5u7Hp9BAhcvO3YTzto6+rygVvE+LtaNNWGVh2GZapWLKauuPQwghMTnXxf6Tyx9DkvqJcmmAqrLC+3715fbNr7jWSgmouFU5TFK0vmQZBzOaBrsWkBc1Yb1F5EiHt8cRSJ2+JH0MITEkwxmUEEH8MHRno4KsuytR0dTjOgD8+EhYYzsI7bjuiFrbbCg1xFNHRvCLK7EtasZ6heRiQKKmyKIxivMS3WWn5PgWiVrMMNCdlYsCF26uLNx3xFN1pBVR7CACY+An8IM4Ld2iUpLChxQik0W+EB5VBeTlW2UGozaYwbm3tsYXfA7oPVobZClwxflb7twy0RzT2iBJEkgINKREL9e4++HDaDSbAERIFaW1k23a1Kt8sR5jgOFWw7u/EsYYXLJjnd0w2kSn3cG+gwvoVBpaa3z2//2+veKcUTz9yP1or3RglIKuCsC474tejn5eoCpK3984VgtXqLrZzPDg3iXc+cSsAFUkMw7MkDInZnTrRBYBk5DCL7VCM0vRrww+8x+PvO2BJ6awfuM4yqoKikL4VSZYH1STBqoskfdyGKVgrcvnU1YW3V4PW9YDt77+io9VRuCux0/tnVlcwbata3H9FWd+ELChOEDWyBwaE3EVrPIrneHsFpxl2bV/GtML+XscKgKSNIHWFmvXNPBzr78Or3zB+WhlEpoEZsC9CowKKt7JEUJ9/xhZZLKYVMFp0NKH+JyIWI8EhfKkW49gRXgO7N0MLQZlWkcLJAABnFlCPDHdNbUblVi9EDt3K8PcB4HmK5k2uCP8fmN8AkmCSNRu8OX82FiK5hB3C/2i5yIi4/Qi5ST4rb6fJMikUGrzSTQNrpu7R7I5JhoMUKDGEwIR/XJXNCJoHp/kSI0mN/4LeDkonQH+QeyagGArzPF7GxAeJwZDhMKlfV8/1pz4y9948Q0///IrVoyqkHkDn/jFsu/fcwCdXu6UmCSjYAPvhs3T1sIKIMsEUgEknoWuungLxoYamJxaxIETHfQKhT9+95vsS150IfY9dieWF+fg3M0K1mgUeY5up+uUV1mF9wm4vKsSgFIVRkczHDhV4Hv3Td3U6Sk0GimM9q5jKMGHwNSSOmpEFE4qBa+1RquZ4dBk5wv/9OXHcGquxMjEGpS5AqwEbVy01mfIBCCEhSpL9Lp9FHmJqqygtEJZavRWOrj6/HG86cYL7Z7D0xc/secUJsaH8OLrz0Mq3YASr21pSwSdaaS6k4CFrhRgDDp9hQd3z6Ko/OFq4Vy8qqzwyuddYNeuyXD52eNYM9JaR0uc1B63qCRHFDgmOCtQX+khupEQ1mlJ1ywgLNcDYcuGjXQPQkeZFuzA5BBqqMeucNr+xN8tqDw9R0J1tOB/oRU0G++DEMGdJleIt03jq7UpfKzRRGQDuDEHd5jOuNoYk6T+GROID0qQaUx9zLTplfYp1WgUxjQAk4JV5zHKgZjhKtrUkVTQUYwOhqNw9iwPN/CCwYG5QkcDJ4ByiwUEK1zSdjpLaQzvx+mULl/xdAjF+HeMT4xd/JwrzsALrzoT460UpVKwcHKaJBmeOjwrHt99HGvWjIa4Mjx6s9btBaNVUUC6YrRCQFuLoWaCZ11+JiQs9h1awO7jy+KKczd//9d/81WY3vc4lmam3b4x1YeqcnR7PfS6OUp/tlG4FwQ+FVZAaY3hoQZmVyy++dMTDxyd6f0gy1K3ed24fWcUq+fGgh0WIVjOrlgNazSyLMXdT0yKj33pMWiTIhkaRqU1BCQgaSIo4GogpIuB9fMCeV6iVBW0NegrA2NK3PTcM7Fjy8jf/+iBY2gkJa55xpl47mWbrVIKSSKgVYEkja4CIS+SPivcWa79x5ex+8jSWitdNW7aIW8bCd5887PRquawdW0T1160Zd4diaK9TTIyrxBsj1UsRkHU5egqQgBCP/WVQvpOWLZCBL7fKq4w/v/+kCvHBQSn/53as37bAhCEoZ5RdeATgAVDWgzFEHNFlHD64HtEkFGYqI6B9YJYR1VRGYIY2I+ZFFmMTwlwY0HZFTgNam0HI8Q8CkdIf/Z0oHq5iA3VaVQn9mnnGLFvgTMs6sbL/yDDGFFb/T2uGZptG15PzQSHU4hVPBHH75ASuchXXbz1von1w9i6LsPVF2y0pVKQfgd7miXo9it8+Xu7IBqpz+3n+2BNkAG3gOCyTnT7FZLEAYorz9loLzx7A3pFF48/NYV2X+G9v/u6m9brKcxPHfU7BRR6eYF2u4t+v4eqKkMGZWM1XHzXoS9jFbKmRKElvnn3STxxcPl6lwzBu41+JTxab08FIagqEVl7BpNh498CMCLF1358SHziy7uQNIaQNBowSnvg7w5i01EEayyENTDKIC8qtLu5Q1BGYKWdY+N4ilc8/4J379w7iSPH57H1/+PrvwMlu6o7Ufi39wlVdfO9nXOrW1K3UreEUEBCElECG4lgggNpPCYYg589Fm88z/CNZ8Ce+QaYhGfmG8ObZwPjscEe2wIMiCQkIRRRt7pbnbtv6JtT5Tpp7/X9seOpbr+Sbt9bVefss8Paa/1W2GttGsaDr7sJRISQcbRaHVChpZmAjgpWxntRFBAFoZABnjwyi7VmWjeMKwgDZGmC+27eTa+4eZ+K5hUZ3nz31RgeCJFrKaI8m2WiNGMtoSDpbEgOCZmjQ1S63zEAaHlviICcGqPnsowA+7xe3jX9/XPPcX/79/ib0ETN++2Q3w/DPYzaAMeciMh66owKap8BZmOyTDycDwMZPGRpdzDsXJgrjcQHUPLK2e9L6MiMxf+ub849yWzHQ1T6DFdqm5w91Kmi3txrdOfWyDBmj/FaYQjAGr6dbc9X4wmOwVrkpRk36WShZg4t8/PW0Kdbd79BqkBRSIwNVXD/bXvRbieIeYr7btsFUUgbtwgCGA/wvZ9drB19eRaDo0OQModJryOFdGtCBBIS9VYPICAE4Y137UeN5Virp/jZieWH7731KnrtfddjfuYc2s0uslSg1eqi2Wqj101QZIUFIepMpYpiUGMWCDkgwPHIU3N46viqSgUQACZTrCEiIjKlW+ycczWVzjZipS8YwJWaSEIiDhmIhfi/v/ky+69/+SIiHiGqcIgiQ0AA10cfpD4Uaioeg6kjCK1ugm43U+l1igx3HdqCw9dM4KkXzoNx4J7b9uGG3SNfyQuB5ZU2wFVBD5WL33hqdGAkC3B6ah3Pnlh6t2QMZE7HEiAZw4fe/SoMxYReKrGy3sSdt+zG1bvGThGpoFsVL4bLXmrN+iL5PUnuq01uYwHlxjRDMwRqvidc9jKy26E7H+G59XBYCR5C8Z5lkYBDC1xvhBKy4szbiO4pZqMalMLs2C9HZOYzc7axpCoCmmbKiEFtWtUG1+dJDcO1I2VlG5bVBSyK8+fN+9cikDIDN/zEzaj6yy+DVp5j/yot1JljqgZNq+eQZdLMTUzpfvveoklYoQDGHeUwwGSLMFlMLNO1DN1VXUffuHwaJGIgSGzbNnbba+4+gJW1NRCTuOPGbTiwvfYZIVOEoZr7MI6w1sySP//7Ywh5pFAzEVQBRQVICCqnnRAC6w2VLmvv1uHPvfKW7QjDDGcnV9DqZl/+p+99M3iyirXlBSRphlari0ajhV4nRZ4LdZZW5+1jWpNSzgYBHhAQcvzDzxbxw+eWmCSm8u6bvQjfq2uo3PEpbqSOL4EsV9cBZyZbahwHYCzA1759gn3hKy8gSSUGBgIUeQ+QyjsoiVQusdykfCZ9OoQhSVL0uina7Q4qPMdtN+7G5GwDS0sN7No4gLe9/ob3JWmO2bk1FFkBBIqBFoXQaEgFy7YSwjefnML8Su8bjIW67wHSNMOha7b94r2v2o9et46sEGh3exioSbzxtj0HapUAolCbyXrBtORzjMGTikx7uDxJ7tQ1H3g4taY0dw5OWOlpkhM6LcM8px/JOQ+VjxiMpDWE7uhaI1bpe+RMVlfdlqEE+xw/At+9TH1IkNcevKwN8NQpQy/MVNZ2j7fZFogsg7GHKMxcWuZk8YyHfPQnmjkaBm6GcTkKMfPkIVOCDu0p27v6UZlDyM4baG1hXh57swYG+UlyDM5sIr9tv2/qTLDJbGuuM1H5zEO9pkanRrkGxgLoz8Sh1lxpJ1khEQUcr7v92me3bhnB+uo6kkJiw3iM19+251NZlqoEmlB1GIMwxA9+Nskee+YCBkYGIUSm7c8EmKSFDOh0UzS6OUgS7rt198PbxmOkRYGfHp3Bq2/dU3/dvQexemkazfUGut0MjWaCXpIjz1XJNiEIRaFsrlIoGsjzAlEE5Izjb55YwqPPLrOCOKJIO8/g6ETtN8O23XpLg8A8ii+9StJXpyyOoxDgMf7mJ+fZZ778LM5f6mBgIEaeq0BTKfXRGiKQPhQKAqKQIwxDFIVEmhZIux1sHg0xPlLB2QvL4JzwwH0HsXE82nJ2eg2tbgoWVlWKj0wzR6mK5z59fBnPnlhi0nZfEZoQAu9586FvjQ1wJL0eRCHBeYB6q4V7b9mFTSO1e0wUf8kO0o+0vM1g5sAUmTXqoI9+rNpir4dFGP41Zj1Ks23Vln7U5SED7xkeICs1pJiBH2pgsUNpgzqU5r7vHwPn3G5Wxlhf2hf3PIdOYOsoWtRCfp1GZoN/zZlXFfOj4vvc8+EJEuYPrjw/cNcZyUyl++xtVi327WpGKNhzs/AYskcDdq371ogxczrD2Dm9zea1ZdfaX19Caa79sRpGrkCa6afL/gv9uY2UN1Ou75NSYNPEyMB7fuFWNNZWkOU58gIQIsVrbt+NHROVdwkpdDyXKpPWTgr8128cPbqw3ENUiZXpQxpmLxGGHGmao9HOvzgxGB16w6v2YyASWJhrYWa2jl97532o5KtYWbyEZjNBs5Wil+bIMn0gXBLMESQiFc6U5gUqlRDzTYk/+/YcfvjsCpMUKN5iECbzhAZzkWpmzYnUkSbuLPoOlRjdXdMJPOAGIkIUhgjCATx+dI394X8/8tVvPrUIGcYIA4ksV/auQnszRKH0cin0EaRIIaZOJ0WSdjAxOojTFxbQ6nWxf+cQ3nLn/oWLs2vBwuI6qrUB5IUAmDovmUuG6dUUf//4xYdbXWdU5ABkkWFibIi//q6DEFkXeSZU+loE6LTa2LF1ADdfPf44RwGho5it9LbISzMoow4xL2bKMImSPcST0oA3d26uHFKxoAg2DMPnCPb+yz6CgU9mVUoow/ZBP6OE3jxvnjSfy74xOUTh3uv2PQRqdotBKfbhesMZAnU2P2fI1/W2wSzKcP03gakWETM3Ce4y8h5XnjPXd4N6+hmDZqgmP3zf9eWxl9fMF2bwfrvFdH/611imKh2DcZlS++daN2IYLDT9SbLr55siDDoEU2heITUO0ijs0HU7Oq84tBPz83MoJCHPVZLR7Rtj3HNo+9fTNFMl/kjZOYMwxMnJ+s3/7a+OQwY1BEEIoVNoSZKIONDqFlhuZr990zVbjl6zdwwgiedemsQ1+7fiVfdci0tTZ7G63EC3m6Pby5BnKmNyIYAsFwqJCUI3USmieRTi2TMdfOnvZz7/3KkmoyBGGIVKEPKysFL8i1kEbWIC9aQrCKOmStpI5rIXyHA9rqWsqv8YcI4gquHCYvL+//bXJ4P//JencGamizAIAUAdFchUtSBDkyQkAkYqmyIRkk4PY8MR8iLD7ILK+3P/a65DN83lCy9No1apqK4b1bEb4JHHLuL8pdYXEEYW7jIGFFmCOw/vFnv3TCBLEuTC2c6EFCDKcPfNOzAyGCEvNDw3aEATh8luAOYObTtJ4AjPpAdym8jblMR0BZg+KcId8nFb0uAgp8L7qlF5r/r2GYv/+mwuDnUY9FNGfmaDS8tgfCZXRljmIR5BkbE59F3kodLyMx392Pglk6ITismZtmzhX804LXoz31tBC3j/2Of0//YPkVuoogfho2TnNijPteFV/YLGtEteQRDT5uUo1e87SmvhMy93jwrVlPYzXnoGzGfePCg0COSFxMhQDQ++4WYw6qJVX4cEQYAhl0AYStx183YMxABgItq1CsoC/PDZGfb//O8z4OEgwoAj4MpLGMcRFlYzJFmO19xxFcYHA6zXuzh7cRlveuBesLSD+elpdFopkkyo+E9RgKRAXhQoComsKFAUGThnWG9L/P1ji/jL713aMzmff5KFFQTGbsrdfrM/OgTJag5WSOu9aL0BZKC9Z7vxFk8xPWdMFTpcKAxjtBPIHz6/wD73tRPv/tp3pzC3UiCMKwgiDiGl4siFUBkKhFIjAh6iyAVElmAg5jhxYgaFKHDLDdtwYMfQ/Pd+egEBUzawPCuQixg//vkcnjq6xIgpJmFiqJS3QuD+u65GHKrcYSZrhTovydButXHT1Ruxc2P16ySVMb+UdQHOS1aSpmBu07G+EAxzLWO2HaNWOTuOd52eZ4NoiQjaU60Z9RXQQN/f3hZzn5U2or/pzRhgF95eY1NP+5se9nnSS03tkIr+3jzbIlivY0SuMo9pF26+fKRoDGKk7ykhILsufr99xl2ejfJ1/hxaQOe1BwNqVX89xFxmVmXmZtcGZiPZtKsl1KeBlhNEBiTYWD99DXOo0IZZkDUSAnBxc3Yt9fWadC2aJiJs3zJ682vvuAZLs/PIMgFRSF0zQkKIDPt2DOCabUO9NM3Adf+kFrap5PjrH11gX/n2OQTRoAp6BSFkMY6cXcfmsep7bzu0FYwIR16ew5YtG/GaN9yGi2fOo7nahhBAmkukmUBeENJUIE8V8JAENLuEnx5r4svfvPTFH/x8lbUSTIdxpDIcm+3lpcOyP2auvfVWZg0YBGY+hJ14bw8AcLCOMbP1mOKAOmaEBwxgAS6tZt/4myem2ef+4vj9//PRSZybSwEWI45UiXBVhDaDJJVXCJyhKHJsnKhicXUFFy+tYcumMbz19TdsPTm5/HCj1UKtWgFjIU6dX8e3n5qJOwJgQeCYFwCRF9gwOog7bt0PZInyfAgV1lHowp29NMWGsRA37Bt7VxR66ZfdTlOSzaAmTwS7RIVqzGrh3fEWo6z0Sw/TgNXbvbl2zy1vkrIdh8FnBOVrSnfZ/8z3zHoUDcImuPOHsKpMP8IwjPVKdj1nO7O9c0TmtQDGtFPYbeDL29NMXyPeEjvyEEbZhgWPUNXvK9kZFZr2z1r2/5jekz/TDuv4zNcKDnOtD7G8MfatieVBFm65/hF5c66Zl+HsbhzG3mmSTLp7bEkEuAPpAHDLwV0vXrVjCCvLSwALYD33OsB1aDDCoWs2VYUQlnmDSDk5GCEhjr95fJL9w+NTqMYVbB4fQDcP8OzZ1Xvvv33vV6/aNYaVdg+zi2t4x9vuQXvlIqbOT6KX5MrelmUgWWh1VoJYjtVmiidfquP//oe5L37j8QV2cSn7bckjsDDUY1Q/SuOBHWc/klfz5o5pMSjGxx1NeJZ/8o53MiOV3YKqxSRAA16pc/SoRGchppbT73/7Z3PsP/yvl9l//7szeOZkHZ0uUIk5atUAAScwpu7tJRnCQGB0uILnXjiLTtrDA2+8GRM1/vnZ2TnU4hDzix383ZMXsFhP8oAzfajTeQvTLMNNB3bRrp0bkHTaquxaIZCmOQqhzmCJvICkAjddPYGhSog815WupYpJKUtbg1rKSEsS2TTDltnBIRTGypLXqI0WvZg57pP+BrGZe2HH5tbmcrsbSsiqzAbLKLIfybg1hH22+c55Mcluah9NGpQJ5pidP3XWUkdQqrQhtr4eqq8vRziWxqyK5dCReaf62T8mwF3dPyfl9VV9lqX3JiWRogf9DIsEywU/HNAzTAcOngIl9Gj3lmWajlkZJOajUkNeXvMwtkQfAZq154whzyWGByq44+a9oCJBt9MDUaDqPGp7a5apDC7XXb0JQQBrYCchbaoszghpDnzzZ5ceWlrvYePEMC7MLiMKxIF3/OIhiDzFqdPncd01W7F/Vw0vP/8c2ustiFxAyhwBKxAwlTJncr6D7z63ji99d+nA3/x0mZ2+1PvtpAgQhIEXzqNoTEXWGGHK0c/ofeEgPfoDAaEjJzvbetZstmkrQc0SWOamd6ZKg6EmIgCBBQyFBNbbGZ45tcaOXmhg21j03oN7hr+6f8cQdm8ZwMRwhMFqjCgEIi6wfVMF8wtNTF2cxtXX34jf/OXDaDfWEG4awdEzqzhyocGiONSLQnb7MSg4fdvN+zBQI7TWuiDKUeQpiqxQKXikBDEgSRJcvXMEWyaqn1vvJJ909Q89acgNxzaE6AhKTZEXV+U+9UCTY6xeRBQAlZaE7BxfqS3PAO99Zq51L9LfO2+ZeZSPHktM2d7vvjN2PDMPJRXT9EWvMwE2/7itOgTvPnLPcNNXmiHdP684pQ9L7XwYrxu8TW/Wwkdceo7s/eQ0CJTbNI/rf5kx+MzYjb4PJTHXnqU+s8HMrJYgnEbBZm4Vh7L0ppg0uTqgKAsoa/+zv83M6rV3eheIBLZu3nDwzpuvQmN9BQSmot2N/VkSJDjyosBV24exbaL2G5eW8y+bmg+q84pxx1GAuXr6zWNnW7j5wDg2TkT41x++60t7NseYmZ4ELxLccGA3Lp46juZqA4UkrLcS1LsFFtczzK7mmF5KPz+3ln+ymwsUAgA4wpDbSlcSym5nQgI9CrF0wxnTldW9F3kODD0PYb/Nxf/blYovE4PU/5CeHNIxKwTYVN8BA0jHcfUyiQtLydemVpKvVV9aw+hQPLBhJPpfe7cNPnTN1iHs3hRgx9YBbN0wgPlLS9i+YwW3H96Fpbk5SBbg0nqKXBIqAQcxHTejN4Ap5HHTwa1A3obMM4g8VwZEWSDPc0ASSKrjEBvHKti1aeDh0zOdT0rJEQYuD7wlHkODRDZ5m9v4sNdZumIOifjw39ynP7osXYvPHUub07bv3puH9SMHcz9jsHOhmDo5hgy9RpzbazhnOgdUH7Njjrn57MwiXqYW2RnI9f1ev22HzGf2GQrNmBQ5NqjUY0LMXuczVY+hlpDqlRmPmVfrTbbzBUvXBlFbMeHNfz9DZ3oxzaZRz5SWyfjMTkhzfEvtDW1sUs/x0RiDPuPpIVjm99Uzcdj9WO4rh5vDLRPDJ3dtH8Ta3KxGV6osmfL6cnUuJC8wNhDh4K7RL12YnftypVKx6JOIVLwmqTjOcwsddFPC5rEhjI1PoL6yiFa9hSis4NjLszg/WcfkpQ4urSWYXcseXusUX+gkErlQ9nEtrcADBs4IAVMONwkOTlzTkHu5OXEfMDiNoMTKLCMDQivx4eAaeReCcZumXG0pDtLYwkhmc4ZKC0VdwABaakNHZ6uFSgtgqZF3l5vFWy8sJXj6xCrGBsPf27u19vkt41VsHmlh155tGBysYGJiA5549iyOnFp+NI4iizBcX3Sqj1qMvbvGIXotgJGqYlTkELkK5+CkSqYXokBlIMaebcOohCvIpQAFgR6qb+dxU0ZGpfLRgH3rCEpJXHXfZfYQ8z03DgBX5cfQKDy0w+wm6WvLbmbTA9LQ30dyBhl5/dWMzNmj9HfMa8lnCCBlWPU2p4/OmMdMTC4/wNGRmRoqbW6jBnP4KrFpVwVYmnV162AYoGEiruuu/xYh9aMss/+9r/w8+yYLMPrm2KmxBD+PnI8CzakF440kPYdmjQGAlZr3VW2NHJn05sg83gMRcELoisifcajMLAw7t45gtAbMdro6vk6q4HLdbymlCigOQ1y9axT0s1kvMacGH+Tm/8xC8sz5ZX7HaEVgcDRDKnLMLaZ49IUFTK0kUytr2Yfqnfz7vQLIhRFgislGIbPB627EZiHMeV1lyCOmzjM6niPL68WUZ5Z5AdV2cgGEZuPZDI+mSrAmKONRYjZmlOxglZSX9niATzeWGRjOrlZbXRYEAFeMo5tLJA36wkK9+YWAtTA+wN51/YFLX3/VHfsxODqGtcYCJudbD0RhiEKoE/WGaYIBopAYHR8a2DRRQdpbBYPKIyaKAkUu1N9S5Q7LhUQmJSZGKohCjiQRiEIGwBB13y6wxKTeGmOqxUZ90tfflMp7qRCTrxY5Zlc2atu5KzELTxKbTce8QEbvveuDYbiGwfWtu8dMDIFdyWhv1SDAxlCB+ejErbWPUJlGGSZ3ujeNZVXKzkUf+veI3qDU/s1r7HAMLqrdpvXRneifQ/jI11tei3I8JAmvL5YxWaTrMzv3h2P0+os+pu8jdIMiNa711sFca5CiRm2mXqcn1AySk5JQjUJctXMDuBTo9VKVVTVXhZ5ZwKCChgGAIy9ybJqoIg6YPp+oPeekVDshFFI/M9u989tPztBH33kQkB0UaYEnjy3hJy+tsQwcIA6BEEFAAJNmpqwh3gl3N1WkM7wYm57iaQaK6J3NGZiERc9WqMMAI3JB5dAAyUgJo81bDEZ+Z5TUieIQcaiMcWEQINDHI2zmUN0Vt6xmCQ3Csb0C51BthAFYECGnAIvN4hvf/uk0sjxELgrcfusBbJuofsYciWGwzBecc0gqsHFi4G8HB0IUeQYidXBU6DgwKUnXm1OnBEQhMDQQwZQmNwRj+6Y6q1GI5w0poVNmbzBuXhj1xzThmXp8onTIQrVnzr8575j+1n+22bweKtG7qcRAXd/L7dh+eO07sirdWlLb7PppGvA3oFEhrUOAeZ5P07qlncuFm4FS5WpLztPtJhLlFxEMEveZEfNstq4/rITmoP/2UbYNjPQe5lC+u6ffKWIyNhjacO3jsjXzhZZt32NkjLm5V3RmBKVr02S56KefvJAYG61Fh6/bgTzvqcI3ZI70KQZXFAr1FIVEURAGahFqVQ5h7F8eSlT9DJAmOSZGBrB1Yw1FL8XFi+v4+bnGlxLi4EEExtXet8P3kSicEFNzBRUdQkwjdpWXLAg4wlBF4FeiEGFYzr5r50NPgqVPuO89L6QjRp9YNVkBTHn7Go02Wp0OOt0OOt0eur0MSVYgLQiCOBgPEYYRoriCKIoRxjECrpKp2U3P1HilZBCkDP4SDDzkAA/x1PGl4KWT88gziU1jHO9/8BWfSrIMQGCLFDiGCQwPVe8PuQR08Vt1mLxAXgidIUPl9pYSyFKJWiVEFGp0oHPuM494zagNl5eSvLOTeq3IeLIUSrCmKQ+hSJ31glmJC0u0lkmQ+9zsT7cP1XpYovA31eUXwxjTWakJD0VS+RaLuExbzDBTPVBDE+xyJGjmxW5MzcQ1O4PK5dZ3eNrMm/c45QDyLpGGBsn2we+v9P62M1K6Rpbn1Gfu3r1OWMPSO+wYzfx613sI1a6ARr9GBywxVM2ELdIlgxzN5pYg/3yfWTVyTiAYuiO/LW8JiAASGKjFO/ZsGkG32VTpm3Nhc2gVmu5FIXV0vEQIoBIF1jxix0qKyRRCYGg4xC+98SB6rSbW11P84IU5zKyJDxMLIYhDEocgZU5SXVGxWeooIUCkYro4D9VPEIDzAFJyZIVAr5eh00nQbHWx1mhhZb2FZqOFLOlA5pnXL8uu3GcApAYZYf/iOimqF5mr+IwkzXDVjtGDB68aP9lpd9HuiiRNsmc73ewb3TR/pJ3k071ehh71twhEYYg4ChHrYpoSqnyTSeIPbdwFA1gQot7uyq9/72Vcf3AHRNHEg2+4Bt/44UtPn5hs3Kmqk0gQ4+BaDa1UIjCm4bAge6hcmgIFIDvBWSExWA0wVOPvXarja5K0s4Ip+4wheEbQtgfS/SsbW00GD83iLPqymT2c3mS/s8zrMnWGWdXLV6FUO9bX6D6ya2XQlWM6JrrdsD5fHSxzN8esSoZsT9U16o2xN9lCs57qZ9GMRWMeSvhHEF/JfmUEpqE3cxOp68weVyqFQ5MG7as3TsA4JHsFQzxcHw0CLKNex3Ccqn05gvN/m7aYnQOTsFHTgQkIdkRghfhl95NDcKWUT2Zcdu6MYFXPGqyG/6lakWi3Wgp5CamCWDW9CT0OzjiKQoBzQhiy3URs2nTTsHPFhAQ++OYbae/OCKdO1PH8y8t46mTz/lQG4DyElMbOZzts0ZDqO5CLQp2D7nuFDBgfqWJitPaZ0eHw4Y3jteqWiSFs3TyIV91+Ay6cX8V//LOfPHRptfvNWjVWe9dm8Sg7bAAgtJIb/ZPq3MU8CFHkHbz6jqtP/sc/+lWs1BugVrfKCtybpvm9GfEvJr0c7W6G1UYXq/UOFpbbmJ6v4/zFJVycWx1fXG3XO70UAFCNQ1QrFYRhhEK40vX68CLAQjx5ZI49/sx5es0rdwLUxf/xq3ff8dF/8y0IqbxYftZOdXZM2rgXSQRRqHEVwoUDFJKQiwLVSohqHNwL4GtO/HhECkBnWusjbG8DwqxhX451rhmeackDCG7POuXaMJ/LUIOnXvjqp5WafRLf/9tnJv7o/E1piE71rw8laekGzcTLyEIROnnjdgjMIA/H+uDNnbquj5GY9YPDIVJ/b0r++YzdoSFHr2pOjIpP9nozrlI/zTAl2bH5qnGJ0dn5cu247B7k5rB/PLofFlqa+eifb41auc84SzThGe2JAM+m6D8vDII9JAW6Waq1D67DF3TCQCh7ofRsaSHYHoCmHWcFNNFj97bRTR951/VYuDSLuaUuvvf8EhbqxfcpqGh+bNYTCFkAHnAUUiBJUou4a1GIg1dvO3LN/k2Ht2wYxKaJAWwcH8aWDcPYPF7F6HCEaiwQBwxVTiggUI0rmDk7hTzPT9uKSsRssRin6rrxh2piOZiOX/LWzXlR1KU48tKFo6dOXjh826EdmFyZASMgogKcGKoVho01hr0bY/BgEIxtA2MhsozQSrL1xbUOpmYbePHEDJ4/OXf61PnFg720h0qlgkqtAiEUzJVCRfY3kwx/9u1jj9y4b+NDA1WBW2/chHfedy395Y9OM16pgmt3PABkeQESquPC5iFzAs9Cb6mMlMpTEtpybhaeMiAOA0gCcin68tWWGbyZF1MYlJFBEpYyLRKwG9BTtUrETs5Fru/QNzsJbASKFfWGs1n605u9JJBMm87Opz73NrZhVIYJO/jmNk9ftzkI0qjaJWbpIStPJtjnWiTnzaqHeI0wYUba6nm1tkcq30Ouo7a/UPKjRMdmhfsN4CVjOEl3vtV7ZonpwyC8K4RzXIE5+YwO3t4yHmaAvJg3Zvefq7xEVgNiZh29vhi7RRjyPQxSVSESEkJok7h06X44V2aOwEyJsSPr9SCNnIgIv/+B25cGgy4uLrfxzLFlHL/YYqYfRAKMc0Q8QBiEyNIemr0eAGDn5vGx2w7tWb/j0G7cev02bN88hOFBDipSiDxFJ0mRphlE0UbSEOhSDiYJTBIE53jh6AL+7JGzC+ttcaYaxxAkAEZgmomZ5fbpKoQ0g2GlRYX9gpAXBYaGqjhyavnmP/jsN+iPf/9t2DYxhtnzZ0BUqBLhmSm5xsHDCIwFiMIAlShEpRJh73gFN+zcjLfctRP1XnHg9OQSPfnsRXz3qcnPn55Z+2QcRYjjispiISTCIMTJs6tv/eZjZ+hX33QdOu01fODth/HE0el75tezJ8JIV1RhDO1O72iWisMAU5kmFA3CeF6lXUiFyEpoxf6piKPdbaMSVxAGkS715iEvs3FsaIULfUAf8Vu4y8qbwKo+cKir1ASDPgxuGJYhXX8Dljej2ui6P14aG3dom2x/+p/PmApxMR5WNV+Kyfub1qJG0s4NO3d9c2NQg8fY+r/z77GfMYe6wBwTdgLU9UVKCb+8mmWMGlUZpmvRE8F+bp1BBs2aeUK5vz4S1lNr57OM8PpUVfShPSNATVvke6Sh88OZBURp3gzCY0xlWxFCIoxivYelN35ZlUWOvNBngMkwIyPfVGxXoB0dUhKkRMN3SkniYJC4+eCWIw/cswvT0xcxM5fiRy+ufrGTEsIwQEECQRAhCgMUWYpWK8HmDaN46+sO0xtfex0OXbsVm0YDhKKLNO2g217AcqOHXjdFN0nR7iY2MoAxgOt1juIKZpZ6+F/fO4cT0+1tYaUKT4rCeC+tsPSEVajZquLSOjUzWHkhFCyUqFQr+OEzl9hn/uP36N/8s1/E+MZNWJy5CAYGUeR68wSQeQGSDOAhwoApjwMPUK1WUAk5BgZi3Lwnxq37bsB7Hjjw8PefnXn4q48cf/jspbUvhGGIWhyBcYleIfA3Pz5bu+fmnb1tGzi2bw7x3jdd//jn/uIIY1yVcuNBhHozebCbyOlBHji4DafWSVMsggicE/JcQBLVDWdgTJWQGqrFeN0r99P5meXPn59rfTKOInWui8Hwck9l8lmb2+RaxJpPcdkOvMJGYaxMuMYOVUIcfSpQWX0rP8NVHyp7Dn3vm8/I+jeOy3XV1y9NFyCC9MboI1Ofkdt+alTFGCunJtIohgHOOG8Qqzk0r6fBV9NNLJdvByOQq35kGbmh5X+cmcq+eTXMybc/WWTYP48+kvTvt0i7vFb9fxtV3dhNWWkN4QnCAnffeg1tGBvB33z3ORZU4hISEZIW87zYUwipPO6CQFrTAOBSKXGtopOEkLQYhkq4Eec6OwPh//r1Vx1G0sTaeo7vPzuHiwvd34auQBYiQJZn6HXa2LNj09b3/MI987/0xsPYs7kKsASt1goai220Wx10e6kqgygk0iRHlheqMhgDSKgIBGIKgdbXevj2k5dw9EKT8bgCcFYq4GJQYpm81LxxQ/yMmfNgZDeqsQ8QVFKygAFxHOLbj59ln/1vjyLJGeLBIXS7PRu4RqT07iBgCLnCxFIShJRot3uot7tYXlnH8uIyWvUVDEcJ3vX6q/Df/+CNn//td72CRmocrW4PoiDE1RrmV7vJtx4/gyiqobW2jrfeuw/X7Rr5nsgzgDjiKMR6ozez1kgQhLGqY0fG4EmlM3OkM1PoU/PPGioKwhBFIbBtNP7Pn/vjD+J97371w7xIQUQIAoYSp/JeROSqHHk/xmvkq5D+PSVC1puwbIthVpDYNj01xG0atVF9dcZXRUzHS2jNY+7w++y16Y+1PC5yiM8qNWaM5n7XXztGDWFMBgWbksdsUOO6Ql8UvEEgQMn2Z1CU3z+LdAA4Q7q7prxu7lnusz5GCc1MoTe97NsTfpu+duMxKBcD6wRMPwM0CNhMoGGYjCnBn/QybByN7/noO1+JN73qWhTGs+2ZHJIse7zTTUBChUqY6toKaRlORxbZpykhyWhRrZYTZA/dcw3ddXgzZufW8dLZJp45sXI4KQgsCCAKgU6ni00bhgb+xW++hf7ui++b/+fvvwV7RrtorU5h+sI5TE/NYH5uFaurTXTbCbJM1XLNdUFsAqmkp5AqsWmWo5cRfvjcPJ46tsQkBarsm2FehpD9YGJnMwHBZmQ16kJJbDjprlGCymEdgPEAf/39k+yLX3kSLBoAj2sqxxZz8J1zAmMCBJ0fiHIwJiCKHFmRIxGElVaKpdUmVheXMBT18Gu/eDX+y//1Bnrrq/dTlmfI0xQ8ruLbT0+zqfk6ZEGoVnN84MEb7o9ChQrjaox2L8f8YgthFMHmG/f2oUFfqnAt0E0Eklw8roeJgDOABHZtHfnE+ECG33jbnTh0/a71bq+NKNAVng0c0VLTzKlvEzHvja3KKRVeZ/QEGUbix8+Zf61dyPvb3MuY95ntg+uL+dBK8D7Oaz7z7TBmYxk0al4EA2aNgRxw9O4bvF1f7L0eenTz43l6NTJiXvuAOW/pVFCXDdZholJWUjMmZlCTudahKHOcyoyKc2fg9wbkwy0PCTL3DLse3rMd9rL3wcyVGRuYRqAotccDNVrOVJ1VNQFcRadzDlEQahXCe37h8ONvvns/kuYSBmuRdyRN3dJLikebnRQmdMWspcrIQo45c4WuWx2BJCcwrkw9JAQmxir4/3zkbrTXVzG/JvDY8zNYaucvRXGMXi8FAo7f+aevo0f+6wc7n3jXQUxUmpibuoDz07OYmV9DvdFFUQjkWQ5JEgVUPrCsEDofBqnjTZIgpUAmMoBHePLFZXz/uQXWLRiCKHJRA3CmCuVNhyfQ3ZrZnPjmFLhFAoao9UJJqQLSCiEQRQEKCXz1H06y//GNlxAPDINFkUJwgZGqiopV5ohCVxPKIIoceVogTXOkmUSSSTSTDMsrTdRXV7F9FPid996CP/6d19OmsQgyy7Dekfjqd04hrtTQbLTw+jt24I2v2EF5loLzCEIynJ1aAkMAAvSiOeRkThlIoQy19VaKJCmesFV/tcq1ZcMI0uU6Nk+E+IPfeO3Y/m0jv1FvdhBFIQB2eSUdMpv1coTlz51DLShtMj3J3jVM59ov21Xs924PWjRkOCV5fTHePoPo/A2n+Igz2DvGwoyQLvXfGqf9+/UG7GcDKLV3OfIx6Mn8bdR7229/fOU/bH/9vjkTgZlKZxciIucx9BBieQx+n8voy3mXy3Pb1y13rwFZ3rW2f3a+dPsm4aURID7/JCimQgxJ0sNbXn+IPvEr96K1sgASKWpx6MM0AEAvKf660eoBTJlCSO9VoWxdNr27abveypHmBPAQQhJ4APyLD76ato8FuDDXwvPH5/DyTHer5CHyLMHt1+/u/fV/+hX6vV8+hBGsYG76As5enMXcagfNToZuT9V+zdNM14DNVSYYnb69EIQsV3VdpSRkaYEoivHCyTV862dzbK0rEUahZXROsGpeREboOjutNSeYhVOzyHXuL3jE728kNQlCCIRhgDQn/Pk/vMz++gfnMDo8gjAOVYyJB28Dpox1gNBHFwQAgSxXqW4yIZAmOXJJ6CUFFlca6LTW8OobJ/DHv/t6unbP0B+QKPDES4vsZy9NY3CgCira+Mg7DmPHRPRxkSeIwwAnzsxDyAAcXMNm0lRFalpI5TwCB1aaKZJc2Qg4C6wM3b1jAhOjg1iYmcFr7tiFT33oDV/aPl4ba3USqCOTpDetmgeLwmCMre4HZkb7DRu+VAdcJlJ7L0ovf3PZDcYMWjJZZNllFYcMfV/eN787Hvpjl1/n0EIZ+dl9zJi1bRG8cVgU6IWXeGqhf615bxm67rtl+gxWXbKVkPz+arTmG+fd+I23sOyR9cfev2ZmgH4Vcx81WbWyb536Pyg90zJaz2GhkaRFxEytIeNAFHF0Oh3cecte+sNP/CJi3sXC8gpGhmsYqvIHSaNIzhgY58hzkTTaGThz4UUm1IF0jntAggeKmS6sda0aypnEvTfvol/7xatwbnoaF2ZW8cyxZTR6crHIM/z622+jL/+7h6r7NuaYuXgak9NzWFhtotfLkaQpsiyBkBnyIkMuMhRC1X8Uea5LqAmQLtnGGJCJHIMDMY6fa+Bvn5gdW2lJhGGo5kf4oAAuOJxZRfAyWuVOqhCMPYVMYltd0sy8SnYAKRFHAZJM4H9++2X2nSensWF0BFGoTp+HQQiwwN7DiaCKywoVLU+ELM1V5LCQSNMcvTRHLoBWJ8HS7Bz2b2D4w4+++rO3XDtxpN0p8OffuTi12lTVvndtr+Kj77zliwHliEOGk2cWFtabXQ2jBRiTViIyBp19FRCCsLiaIBNaddRZXwFg88YxRGGANC1waXYG73rz9fjEr9y5PhgS0lwgDLmHTFSbqnyc3qR6HqXJKcU00XLu7Dge6nLzfiWkdPnfdqm8OAR772XXemjF0+8UcNSMxBAFc6cGAC9Lgw8/7LMsH7ZqEYjAXPlV3baiJ5d11LO22A2tPaawYBnQKE1pAUzTHenPXTyYUxidzc2KWY2OraAxawNNEH67HqqzXkUdGmPGeyUkaT9iZj69C6hME4xcDQJ/HSU5RqeuDBCGIbqtDq7atmHX73/sl3DVVRtx5txFCMZQiQKMDEYfJ6k0CdJH+LJcYHmtAy1jbYYYM0blxGJgxNBNCZcWGggDDlbk2DQWD/yfH7wbayurWFhcx5FjSzgz14u7aY5//bsP0h/+7muQrszgwvkZrNQ76CU50l6KPEtQZBlIFJCFikLIM4EsLVBkOUgIyEIVuIVQabbSLMNoLcSZqRa+/tjcHQvreSMMdAiX1m78NfP/Y456vHUkcJ/4y0TgozDNhBhTDIKYLe0VxyEa7Rxf/vsT7LtPXcLGkUGrTnB9hIgz2B9D5FIScp10MM0LFAKQjKsKJgJIUomluWVsHyrwB//01sM3Xzt+6uR0c+/f/GASYWUIzWYLD9y9D790705iJDC72L5qYaUJrsMrjBrDGGxfQ87RTSUW11MUkoOHgU4xwwAWYHR0UB1xEhJpr8Dc3AI+8s478fbXXU95kugDylql0qloFKNy6IgxnVmBDGR3aMJUrLazYNFPeXOY+S7bX9TziKjkMCHNcMqFRzxU7aEgvW1KaMGoiLZIrd5Q1sDtbWBWug+2beh1NczM3qhRPRErPcva2wwb6kMvKt1OH0LyxwZYYetQmLObOWTnmJ1DTd4YXGI7u0kY+uZGj5U0SuIm5bFnCui3gfrjMXDAfGdmhRlHE9cIkzPwMEJRSAzEDB/54Jum3/LAbTj38mmkaQYpCYO1ABOjtfsFAZzrY3VRgFRILKx1AM4QBorgDQIzckiZHjnWGxlmF7uHwQCOAh95xys6N+2vYXJqHpMzLbx4vrGQ5Fn+5f/vr9NH330Yc2eOYX5+GXkGpKlEt5urBKGmSliuQUimfvJCF7GFBJEAIwIHQ5ZnGBuMcG42wdd+MPvumZXk2TAIbCiFrzKaNdPEooVu30tPsUNgMMhCMSnG1KS6jWhsCX62A0WwcRRhab3Af//bk3d892fzGB8dBOMEkkJ1kGmkIggB9/IPaeif9DK0ewl6SQYpGXKhvCiFZFicr2PLEOGfv/+mAwd2Dh/5ztOz9//0yAJ4UEWStPGBhw7hxr3D1GgnybkLK+BxRenRUhOTthlLqaoirTZTLNeT9wHMbhSShCAKUKtGIFkgzwqEQQXrq010kjp+53134fYbt/e63QSMB1AAXcIwFPLGA2j7HzxVCY7IlVDgJcYAuI3nq5O+zcW36aj30lO7pEWEph9lb5mHgryc/u4Z/rPKxmtLLbYtpq+HzpLgGK7PME2qYNLZc5m5hlmOYJotbX4fQbrP8Y98bnanN4fc2SoN+/JtZyVmTm6elH3KVavy1eXyezfH1qZl2vc2oEN2KK2/nT+Y+9W6cShnUdJp48E33kq/9cFfwMrcRawtzoEDyNIUcUiYGFE5vEjv0yAIkOWEyfkWklwijiKAhKJF6RiZShsdYnqxhdWefImTwL037aR/8vYbcWHyPOqtFM+cqGN+pX3ff/ncx+gt9+3CyZ8/g6WVdRCpo4RJkunjeRJFLpBlGXpJgiRJkecqeSh0UWuVvkcx+jzPMDwY4fxchq9+f+7hi0vpNxgPFH1YVVfPGPl7ylAf2bklQ/t6/rhdGCMaHJZ39o2SFNb5wSxwU5Ivrsa4tCae/c9/c3rkbx+bwlCtioDraryMay+Erg8ntQQ124NxCKEZWaeLXpoilwI5ETLJsDC3jj0bOH73164/PFhj7/qL753B4lqCtJdibDTCBx46BB5wPPPiDLheVFscwCAxKMk+Nd9Go519zUl5FUlSiQMMVULAVjFShsaZ6UXs3lLFR95+uLplrMKTVFVXcRYSArQ0NZLCVC2ydhD9fKZzjZBWO0uI2Ns4Rm337TnmvZXghlFAjcE8RGuiHnNzDajmyijRqK72ZmNbYL5dyKEss4kdabnnWbWJGSbnNqvb1+ShKaMg+NNgUKkXziDN+jFvLmzPPGTmIx+DEt31lyNa77l6vC5Ew3dIqL3gq8G25x6KZhruK6ZlzhT32dn0GljMobWZMODotdu45bpdR/7Zhx/EUDXFpfMvQxQZqChQ5BkCVmB8JNZnd9WeCgIGFnBcWu58fmEtw+BgDUT6c2ZoUq2fLAjnZ5pI8gI7Jmof/8NP3IOku4y19R6OnW3i6LnlT/3Rv3j/6Te8cguOPfMEGq02hAzQ7eYqtgyqSncvydDtJeglKbKssN5OaRJkktoTREBe5BgejHB6JsWfPTrz8Nn55AtBGHoJMxVKt9LsH3m5tTWCV9EbJ8Amr2OWw8FKIzsLFoI7O4T1munLojjG/Hre+tLfn4m/9p1z4CFHXONI0hRCSghSdeKEVKfk80xoGxEhDDkCrqv2ZgK9NEcnSZAWBdKcMD2zhqt3VPBb777pQ4168qW/+8EpMB5hbb2JV960FW+6bQv98JkL756cXcHg4AA4Ux5JrvscBkCaSZydaaOXEoIA2q2sJG8lDhHHyn6mqhmpYrpMAlPTl/CGO3fh9XfsEQY+Kxo3yMsnSKU02EIMetOq7zTxmkR5Hnowi2ftN1dAZ/Z7i5jKP85Q7gipfB+8944JGjqy9j1zfYkBOhXNNODbnwwB9qvAJVTlzRGgPZ5k2aD93ChdBm0a2jYVdIwN6vJU2HBuVLhMGOZ6M6aSfVAP0yAxzpg9W+kzbXmF/pv+WeFldR0qq+DezjToCUQOMfMARZFhKJZ47y/dc/jWV16Dcy8fR7vdABUZZJEhz3NwCAzGKhezMqcqNhmHAVbqySePXVjH8FCsaAEEFujtq22vrU6GU1Nrj8QB8IlfveOLm8eAc+dnsLRG+NGTU8mHf/3tn33HQ4dw5OnH0OslEAVDr5ujEEBeAGkm0E1y9JICSVogyySEAArhUvaYuDMiQiEL1AZjHLnYw9cenX34wnzyhSgKwRlB1cTwJIz3MtNIejltXCRM20bo6v1t1smQj294NTaXfqnl2yX8PPK1SgXrXZn/xfcvsv/xt6fRbOUYqKnaj7JQbm5T7kySYmRFof4GVyloLTSXEgUJ5IwhKYCZmWXccs0Qfv2XDn/o+ZOLjz51ZAYsiNDttfFP3n4LAIm//tYRVKqDiKqqZBPTUb1RGGF+NcWlleQTgilvqxGgRIRqNRqIYw4hcxW3JiSEyAEONFsd9NI23v2Gg7h258Qf5HlhvbVWypU2rNvsUqs1vjfSRz32P5/R9KGFku3JVKEx++Py9bdCiPU9s+yhg/e3QTCqwfJGN2jK77vH7AwS6mO4/YzZf75TZ5mtQG3btv1xpgzbVe7FoqE8R+a5jDuboptnOwswXst/3GbVj27LzzL9t0ixBAn9tjxsqZmYs9mZKwxICNDpdPHGV99IH3jnq9FansbK/KzyzheqGI3y3ktUQoYw4BBwaxSEHK2E8PPTyyAobQJQ5x65VuUDMCzWBU5NN976trv30Zvu24XjL53AeoPh0SfP4M1vvr36Gx98E448/SNkeQqiAElSIM0E0lyhLuV1LFAUQmeTUbn2hJSKR2ghUOio/tpAjOdfbuMbP154eHo5+0JcifT+9uiBMSvozZ43DMmEppglMnZOZgWL54Ukw7VNQz6lkJ1x26BZGIPKABh2iSiK0c05/v6JBfYnf3UOF2ZTDAwMQJBAVgjFtIQ6nyUE2YPcJgUIqVOoYDokIhNCobeMMDu7iNtvHMbbH7jh/kceu4Czk3VAEDZtDPHx97zy64/9dOqrL59dwNDwgDrGxJgOVOU4O93CejP7kxIxQh2tiMNgJOBMl34rIEmgEAXSPAcDw9zsEg7uGcBD9+z9bMgUmmMsMLDKIQGDssyfzMQ7uWscY/AXzNso5Oa0bKvymIO+Rxpbn0VlZvN5Asgsn0lLQv53ZSO//9swQr8vigg87unlry8Zsy1KL6PA8txbqemuJucNtTURzQ0+SvWQpLNLGUbrM4ny9eYec5X53m4ogk4TTX1zYICtnmN/LbxGS2jQojKCUVV8NMoICBhHknSwd9v49l//1ddhw8YQF0+eQJp2IfIURSFQ6OBPKgoEjMCs91TNURAEkGA4O9P80ORCBwO1CqgowEFgJBFHHGFcxTPHpnBwx+Dff+y9d2Dy7Fn0UoafPT+Nvfv34fc+/Vs49fMn0FhvgSNAmibI8hxZocKb8rxAngkUQuqcXxKFlMgFgUhpTkIoL38YBsiJ4dFnVvH1H8/fcWm1+EIUV5QDxFsL9y/zQDyz0Nww+37h6Nswed9+8WAz6+N8mk1ywzWZ1xGTuF/AGLd5ECFFjMeOr7P/8Jenv/TDZ1eAIEZcCZQHQ+gzW9oeJKREoW1kkgGSmcK1irNLADKI0EkIS/NLuO/WTXjdXVfj+0+cw+xiB71uB6++bSvuv2vX+5589iwAoBKqUIlqJUSa5bi40EIvIwR+sRJNXAyMqyNhOaROjFiIAqJIIUWBLMlRb63j/ju34RUHNpHQ6Xh9oWulhf7NmWKgav6otFGsDGDaeAynctqFtZu5tH/tQjk10Ekpn2Gwvv1VOpGBy1GeJ6fMPvWeqhmEURW588T5xOW3229w9w3Zvt3Kt9eVkD4zOa+YC20w95ixMa+vdhOYTWKliGXktnWffn01lDF9MLNPZTa3cWZRnvre84b6tNAv3PWCGOYFKPOFlCrU4B1vvm32jfdci0unT6BRryNPU5DMIaWyLxVCgCA87UgqBqW7G0QBVjvFl49ebGJ0MAZBgjGBAAIjlRgL9R6W1+v4l7/7uodksYa55TZevriETVs24mOf+BBOPvcTLM5PgwccSdJDLiRyISCkgCRVmtAo0YIKSCgPI5M6cLaQIE6IqxEW1zP8zQ8X8M2nlthSh55lUQxiusoQL6Mvv8alNRcwJ3gMCLAzaXiSnk+bYMiqAuYif9UMIVqJ4j4vEZ3+TgjFkXkQIAhDnJntfPjP/uEi++q3pzC/nCGqhuARKTXNLo4iAuGl+DUpac2PEATiEZodgbWlVbz+zh244xV78eyRS5id6yHNOnjbA9diIADOnlvAwHANkAUicKw2c8ytpg8V2uBniIs0ohAyT0SeQQoVgFcUBUQhdKhHCgKwvNzGxhGGN9y2HUNVdX4y8JCXlRbMbG7nbfJ2qEMKxErz6uxarp0SE7DTfjlisnvEIipNDB46KT9Hj9+bXwM3fAnnnmH66mwX1gb2j7wul5xXYG5eH8l/HqGvn/bP0n2Wdr3rHeNx5ggQ7PEjGwoDx7wcejMouO8cLflI0v2Un+feu/UwffOuIbImkzRLsXfbxPYH7rsO1FvD7NQMZF6gyFKIotDhRjqzqnCxmEy4ORMkwDhDJyUcObeOPJeIOUMYEKoxB6IBHH95Dr/6tldix+Yqzp2fx9R8A4OjG/HBj/wTLEydwvTpU2BgyHo9ZLlAmhY6uaHUAeg6115RKKomFW4khQCJAmEMFER4+sQa/vzRS1994kSDdQqOIAxVPi+zEy4jF08NNzSnJaj1Ufr06V1HpDOyGllIMATBzG50DM3wLTIQW39uEIBZSP3boCcOhigKsdaW+M5zi+zkTOMzr7ph/FOH9o9gbKgKxiWKVBXisMQMFTti8pGRnizSsSycBVhd7aIQ87jl0FZs3FDFmTMLEBjBtfs34DWvugbPH72IjZsGEFUCFKnE/EoXrYS+aeLSjPPB/Jtleb3byyAEhxTqGEQhFHMtCgFihCKXWFtv444bNuDGq8fp6ePLTJK3mWFyepOu26d+yCor7qW8MBbmuA3JVFI5yzCg2uo3Vvt2K4OYnPrpNtWVbJeO+fUTk73xsueZhp23zhdeGpVpTtKPxPw2yBCRnivvwWVGYAZmeL+BmT7zYuV59ZkRY1f+3ArdK8zJZXOl19VssPL3/rPcp6qQCdmkjGY/GI5JTCUUAGOaORBefcc1szdduwlTFy4i6SXI8wJCameXUKmgY86RCUI3VfUeWGDKCwKQAA+U7XV6oXP1fF2cG62EWGu1sHn7djx/agE7t27AXbdejSd+ehSLK23s3Lkdr33D6zE/dQbT508iDDjSXqIdBoUDDEKoRCyMbMk4KQGQBAdDXOMgyXBqpoPnTjZw4mKHNRIgDEOEnEOUJY9bLWN+gEFULo6yhNr1BWb5Td4S0veE/TYW47WTmtB8CWKgvyUe+zACWGA7KqXQi23KPhGiiKMoCKdnOp++tNT79FMn1v7gpqvGP3vT/hFsGa8CsUSemuh/QOiASyYZpK2Q5CSuZBwrax0UcgE7dm5CHG7H+YuLICFw3XU7cd21W3Hh3DJ2bBtBdaiCi4ttdFMJxkPtBZSKKQtCAKDVzmSj0UGRB6qikRDICyX9hGZkHBzrjS62bhnBvTdvwfHza+gkElEU6jkx86I8qgSVu9sulNk5kmz9TIOyFAPgOlMot1kufHTbjxZ002UEoRmJUaMuRxmanUq67DvLKKAEUGAyJcD0z3TFY2weoiq5umGYmR60ZToO4ZQEqkVoPnNwyMXRqGuTGUbsoVaLgu1vZumYwZtvg8BtH1xn7Bz1CR2bh0y96wtY9pxPRoWRKu4uYAwCppyYsluFPESWFhisBLj75t0Y4gnOz8+hyNWZQllIVdNBEARJZIyhKCQaHZXzK4o8xE6qZBoPAqy38vOn59p4/aERnJyqY7lXR1EQ3vymW3Dk6HnMzrexe882HDp0LS6dP4aFuWnEkToWKESuA8n1GUqhPPIqJlPamqIBZwgixVBPzSQ4cr6NM7OtYK1ZSEKg6k0w2Nx8ZnZL2psnHHzk67QNh5ItqHLkaekk5F6CNjAqne/z5LtZD68xrhfOqWO+VFLEITR0dwseRyE6mcSZmd4fTS0kf/T0idVrr989dPrA7iFs31DD4ABHpEEIkTJyi5wBTIIHABFX8k2q/s3ONtBqpdi7ZwK7d41jbr6OgdlV7NuzBa1GD4uLTQxMbMDUcv5MWjBUqwEAlePLHLngAUOvl2Gl3kMhhkBa5y+EOrxuDJSkS7K3Wl3ccvUortk5fOTFs/WbjawGYDMlcMZUEjjJUBDZkwhEWnp40shXqzjjl+WoUkgDfZ+TRcS+fcnZYMreUJWG2wWelsCfXi9jB2OG+ZHzpNnU0iV05TEvD31Z75929UsPDfWfDe1HlYaJle1l5nkmuNHZEX31GFot8z9XvMqhpJL6aSjdATOvb2YP+OjAMT8zj9wwK4uIFYOTUiAIAxABvSQB11V8zIOUFiBx0zU76NZrN2JtcQFptwshGIpcCVAVX6VS5AQcSApgtZloQaXCddS0SIBLBDxEKxE4PtXGg/dchWa6gG6jg7c9eBhzly5hcWkV1x3YhVrMMXnyBHq9JqIoRC+FrbKkkBesg82sAQ8AEEchGFYbOaZWejgz3T06tZjcvN7OQeAIowChzslmEzV6NGLm1chEX2Pwr+n3Ll/+vWvXITCNumz5eM2cDAHYW4xKRGRd4E4t8B+kBm7TnnjQPQo4BAFpLjG7mpxZWEvY82fq2DYW/+nWjdUP7dhSw7axCsaGQ1RjjihgqpQkV21JEDJRqIK1xLCw1EKa9bBl6xiiiOHSZB0ikdh71WZcutTA95+ZwkI9vSeOQ7XwDDCBcIIEAh6AiLC02kaej4NIohAESczmVSKmSlhxcLQ6OUaHarhu79jhF8/W1eH2QAUXEhhCBlCRo5fnqNQGwYmgSis4QveWxTEio4qaDJTwNqK7vKT/ONtN2RZkDiObRZeyzxvIVbyTQWEmSaCTgF4YAIyjwT4VRlj5a+7brCwCM8RWQpAoMa9+VZX6mDJsUChsf5U6ZmCoRr6lPnk026e6lPKFUX8/yp4vk4HVXwum58OMw6o4hlESIY4j5FmONE1x6Nod31tf7/7KpZX6WhCokBqTleNVt1yFvVsGcP78ORSCociFimrXKmSeSwghEEcc7V6OtUai+yKtoOQMWhCr+bk423pmZjG5Y/euMVQqNXQaLZx9eRbbN29CFBZorTVQpBmCGChYriQqt3wFEgwFAUku0cskWj2JeifDUj3H4lqB+eXevSvt7IluIqBMARxhxHWlcMW5uJkvOM5wxfVmrETr/ssIMzIagBOndq1CuxuotC8c9/N74H0ETwIzU2G4j5FdtlfhMm8COlkgAkhJWO8IrHe6Hz491/vwYK2J0Vp4+/hQ+JnhgfD+kVqEWpWhVgEirjxSaaoSo/VSplRDSRgbb0GkAjdfuwmj7Ryrq3XcdP1OnLnUQZbN5AGPwQAIYlBWNmWDCALV54WVNjKd10wICSKFhqTut9QphbM8B0nCvh3DmBiOsNbKEUUV8CBAr5fgqn2bb/3wO+58/qcvnMdf//AltmnDBLJc6viYQEt3oeeK24O3Vl2z817OlW8+J7uyHtrxhZkPxY066alsZQmnnmnQvZ9KWl1jGJuHhLwu+itu7EGuLZfbnXkpoAFfvStLWp/JGqRlkJ1lbCg1dTmS02NQctSLK7LPsazQkb8nqMl+UFZlodVsgwCY969BbIwT4ihGmqVI0xQff+/r6PaD2/Fvv/Tdf0tEHw64ikFMUoHx4SpecWgHGE/QajZQ6JJjhRAotPfR2GoJDM1egfV2/nk7P1KCgsDKtJATZADUm90/SrvJI7feuB3Tcys4c3oKAa/ixPl1NNIMXGZArvLyEeeQkkEydRxfSkKeSXRSgXonR7srH212ij9pJOKbvUwizSTIrpupBwtnFnGiy/4uEYulcU/A9CnrRmMwf1tBQe56s5S6KhGzRGfW1EkjcotaphkYtaNMmB59wPde6lYMUbhCigiDwKo8koB2Suik+bOLjeKBgCumFYRMITGGLQSsFYXMc2I2YZssJDhvg0jg/Fz36Y+886Y7sk6KtcUFvO8t1+PUxTX6u59OMV4dAGMBhCyUDUWSjd6eW2yi2c3BuFIVpVRBoyp+SuhalgpiJ1mBLeMD2Lph8E/XWvUPG4WCJEPMxL9//WsO4sEHX4mllTV6/OgltmliFIxx5IVjNqxvg5RVMS9PVt8GNRNdNj47uG/nHh5a8Rmaactc7qEWD1MBYDY9i9J+tIoIh0oMwjHwTzkpubfpZUkFK6M5z57FfCpzxG3tVZ5KqL7UdOXkOxwyLI/pSigAYLYyUWlPle71vjBVkPQzjSpsugeoBIWVOMRao4mJwQi//88eoo+89RY8+v1nUW92fsfspzAIQVRg387xyau2DKFRbyLLc+QyQpoJS2OFcMJFCEK9VaDeyT8LaERNpgOKkRRphuEqx2+87eZHDh3YjIX5OawvrSHLJE7O1vG9ny0eSImfCThxIVTovEqqyDjn2CQlLQNAXkiZCYmsIOQmQaKeW6UKG1ujQoJqDtxxNsNT7EXlFfDIRaF8U5TY4SsnRNTfzPubnENRwxDAujnt83VnzOo4Sem8LuQIQquVBB0m5vik6bIev2kH9mU8Rkznxw5DhkocolqJEFUi8DACBSEKGSARHJ2cL3YynrcLjm7O0M0ZegWQSKCTS/REgKPT7Tv/9JGTRxcbQLuTodet41/+5h14w63bKE8Txzyk6Z0ay9Ri6/H1Vo6AhyAJCDKuXINQSDMzhiQtMDYUY9umwQ9ZQmYM4AGKQk6tLK1h/1Xj+NzvvxUPvfpqWl1vgDGJKFJeqiuhUzsncHN4RZRi+l/aaP68O+/x/9tDrMTUKqQN/fCYk7GhldQ69AWuesiGvIPqZFLskGfe9zaD7WCpn76a2Y8W4T63zWjRocfgM2TfQ3i5RxSXXWvmzsxJyXBs2zFzrxpQebkIUaiK2KysruPQwW1P//fPf4A++Iv70Vx4GefOT6GXiq5tVz9+366JPVs3VNBstlAIUqqj9joKofplEvzlgrDaylHv5g2txIJIB0hzIM8LDFXA//k/uZ0++NYDWFqcxdz8OtqJxMmpFn7484X751v5mZVOhsVmLld7QD1laKYM7YzJVs4WOwWTnYLLRAYoWAgEIcIoRBTHiOIQcRwgDM05WYKxf3vKGHxGVRJsBkmSt5ZwdGzVc9OgVRecWCV4aEx/yUs369UifZPlsqZT/TDMUz8YyB4lYKSM1hrDX3GzOmaoloMx7pWiV2gMYFCQO0AQBggC9cNDjjBQtrE4IIScEIUMccgQhUBcjfDiufrNX3n0bH16Kcf8fAMh6+Ff/9bduO/QFkp7HQUGtWFa6gII56bX75tb6QEIFUogE//ipGCh56ebFohDhv3bh1CLgTyXqtAuAXEcHIoihtbSArZtCPHvHn4QH3vXrZQlbaRZimocamSkSseYM3Egd5bMzdOV5r3swi97dxxq8W1Cl21gck+x1zGUCMkYdf219+0YVngZSQpVcg19zzQM9R+zmTH7tx/uwOw9vqeqhKg0QOp3KHgPsRjKG4L9zmkI6sf2x9N2fSbo9gHZZ4MIURSBM4m19ToefNOr6L987mN33HPTFsydfxmrS4uodzKkuVDHaBhHngsAwJ5dGzBQDdBs9pBnAnmewxjRFXMiyELNa5ITFtYTpBkQhHqv6s2e5YRKQPiNd9wk3v/Qdbhw+ixm51bRaOd4eaqFn56sf3ahXny/EgWoRgxxCMQBEIZK7eRcBYRynVCR6xJqnKtAbAtKmPfjFSJhzKelEol5tGBoroReSnRYfjmzgW2MAHcuUr1sSDrTLZksm0oTcQyIGaRm1QizlmSZnbnHSA3FoZ3U8QfrJJz6ULmbAzCm0tWYc3DS0Is+rlD+UWEXjAQYJDiT4EwVHxmohnjp/Pr4V75zFmcvpbh4cR2DUYHP/tZdeO3hrVQkPSgJqk7GxlGATpLj9HQdiVTFOiWkqiKuJ1JaBmPSVgvs3TaErRsH3qUK7gaAypB5Js0zFIXAwvwyqmGOh3/9Nfjsbz9AW0bCB+utFqLAZRQwcXVGwijEykob063TFTmaQxNWGJWN0yUE5VGAdRCQYV5wZgFPWsIXiqzPIeBJTjMSxViNpCWrAlhq9BAW9Q3TCXNH3T4C8x0b5nOVQrkviwc8KY8rTVsZaZWEqofOTJ8NO1bLYrKYxChEjjTp4vc+/nb69//qfdg7lOHiiWPoNBtgYGj2chQgdaQNDEkuUKlE2LdzAxiT6HR7ir6kdKEH2oFEJMFCjnpPYHqxfZQICAONmhlTwa15jtfcupM+8ks34cyJs5ieWUO7TThxromfnmg8Mt8Unw7CEIxJmGhY0gkLCv1MU9FbCvNeWlWf2XniYGaPato0/5UWrjRvl6NtH0SVNT+D2tSPi3CA5i3+mhjkbTidWXjyfU+Gc5prlDmbWZZrNpzpjJNYJclnJTUsrFQC1xAPh0ncZQhODZQj4CGCMEQYBoiiEFEcqt9RiCjkCAIN440CRFAeGQYEYYgXJ+vsaz84h7OzCaZn6tg4KPCZ37wDd1+/kdJeT2UG0PcDwLGzK1jvEMIoQpEXeiA664Y0bmYVJ5NlOcZHYmwcG/hTxQGAMAqw2ui+/8y5BaTdHFkmML+0jG5rBe95w9X4T5980yN3HNxM642mPmbEQcKsHZV+3NmfssBw81ZGNGYTmvdl43h5jUq2NfKQiLeW7l4D86VlTJchO48BWugOZ+OCR1sERzSlcRK5xIoeI3UIsz+ezUdyLv/wFb1dPuICwdQWgQde3X394y4LAvW3RFyJ0U0zcJnjM596L/3+R9+AausCZs8eQ6/TQABCkhWod3MIUlWGjFNkx6aRvXu3DqPTaqOXJCAGrT7qfPb6uVJKSOKYXU0wNd++GRaNKmeWKHLs2zXy8X/2gTuxMreAc+fm0epIHLnQwFNnGo9Or6Rv1TWfYc00EUcUBYjCEFGoCtQGgcoGa/ZaGIQIg1DZyBgrVUHyKMOt7RUQvvrl0LcVCna5+9C8bpL0nlMk6fKCOSI2aynByfBQw3WYpUa7iI5IfelkGlTvfSe76SHrO3xXgvrmM84RaEYURRxxRdm/4ihEGKhAylyfhu90U7Q7CTq9VKX1yCRyAVWUkwcIgkipmDyAIO1VYQGOXlhnf/mjizg11cH0pXVsHef4zMfvxj03baU0ySDAITXTfPrEArs430UUqcRx+mgnJAkPYaqNnOc5qhFhw0g8ptCiyvra6BbJzGJD5XAKGcAIa+sNzM/N4+arR/Fvf+u1eNt911Kz3VHIJFBpfMySGzRsM6YxE/Tn8TR/Qb35LamAPmFYwnKQ/krqpWIK0ssHVqYFXwlwzNZtEKPygZW9lkTWIlZSXU3ogbnHV2UNlVhPqs9WmXmGhWi2v1bm/yNz4PqkEYAnFCwT9qbL8k/N7YQgVOII3W6Kakj4d//qffTrbz+E9vSLmJ88iSxpI0u7ICbQyQVaSQEiraIFqvF9O8cvbhmPsL62rg9JOxiQC3X+UOWxZ+jmEmemW1hvF2qvScW8kjTH5rEa/vVH7v3ixmqO46dmsN4Bnj61hp+cWPv89Fr2gESAIAhVZHwYQfIASSbR6eXo9DK0OimanR4arS4arS6arS5a7Z7eZzmkIARBgEoUoRqHqEQh4jDUDI4rpuwrhv4e9/Q/ZvgK84BWSTvzzUkeoreM0Fs7y3+AkGmY5exgDC4Jrk7d4qkEjlhRlqiW+MkSOREBHLbYgKEszjmikNtqyYyruJg8F8h1BWIAqMYBapUQg8PRxFA1/sNKHN7OORsrhJzq9opvdtPsf7S7abeTFEizwidRRKEyOpqSWi+eX2ckL9B7xB6EYYjt2yfwRx+/G//y//cU/fjFeRZGMaIoRr3Zw4sn57B/y1WIowp6aWqyU8EkYTSbQgqJkEkMV0MEOikjDzh6icDsShe9VBU/SZIcjAK0Wim63QVMjAzj937tdtQGQvpf//Ayq1QqYAGHFIWef46+ECczLBsMazennXnAVo627A5W4Sx5Ib0MGCVDvN7Q/Z5KCZNyWrWjirRozKqZRhnsmGdpV7jPiHxm2A+Q4ElpTVdlVVg9zg/o9ftpmbynYpo5kN5EOjtbmbG5edXjtp5gAIJ0cWOBKK6g3e5ibDTCv/uXH6F3vn4PFs79HKtLS6A8R9JLkGU9RLUY9XaBZjdLOANYwK0E2rF1DNUYmJtrQUgGSUJXEyK7wYUQiKsR5hYSnJys30GkjgyBM/SSDFs3D0X//nceyF65p4LnjryMxfUCPz+7jufO1D+x0pZ/wsIQDFxVCcoKkCBUKxzbxqvXjg9XPzs0EL5roBqiEqp6jGZ+0kyg2cmwsNq5f7WZfb/d6cIgrYCrUyYOkam/A66DvT19zMdEVxIizuZoaIFZorcU5hXnBQDj3FQ/XMeBUZmQnQBy0lS5jh2MdlLKyFFp+2AklZLI5onMElKaZKXBBAHH0ECI8bHqg5vGal/ZuWV4bMemIWyZqGFsuILRoRjDAxEGYpUMTUocSLLi/m6SfbHVzlHvZFisJ5hb6WJmvoHJucbhS8u9l/IiBwAMDtYQxjFevtRiX//RBcrkXhwqgK1bR/GZj9+HT3/xSfrxkUssqtbAOcNjz01vvuvG7UvbxiO0ul0EQQijfujtatm8srcp7wxJQhgppr+03kOrp9SMTrujz5OpAgyzCysYHRnAR99+EwLG6WvfPs4qlRg8MBWS/YU2jMlDG1cgAvPeciyDd/RGdfeSTahnKzd7z+pX0xw9KM8TiCDNJzbq3S68145pmEqo0ZopyNFr6dkoq77+e6fawTJvBpPVoRxWUpLYfu9MW/puHyXquAQtRPrnV9F0GIVI0hQToxE+/8e/QW+/by9mT7yA1ZVlVQex14EQuTpOxznW2l20usWXOFdhFiKXADi2bhoEJ4FWJwEYU8d3SJk+iBEKUYBxoJNKHDtfx9xy71nOlc02z3Ic2Dvxmf/wfz7wqYNbq3j6Z8dwbraL45N1PHe++dBqS3wzySXyIgfnwNaJwYH9OzZ1Duwexf6dQ9gyWsFILUAlJBWATSbOUTtuJCEjoNWTj67WEyyudLHS7GFxtYfl9XRhud57f7tXfL+TFuqkiQYcPFCeWLJz6DMzH9a6tXGOIke7DAZl9SM4BmImSFo1UzoLqS5y0dn+wgF+jJAvvMrSF+QIzNd1ObgKBCWBnZtqh67dO3J080QNOzeOYtP4AMaGQkwMVxWjqgWIAsUcQLAR1wETamIkIAcDEGrIsgoEAYWEzl0ksdrJj04ttnF2so6jZ5Y+e3Zm/dOdLsPYyABOL/WCv/rRRdFLJV6RF9i9YwM+89F78On/8hP68bE5FkQVzCy1lp8/OYe33L0LURShEEq940wb8Q381RI/DBhCro4MKR7CsbjUPjq70Dh89fYK8qJAwNSxpCJTB2UXl+oYHB7AB37xOlBB9D+/d4JV4whSR8S7vElXQA7e34zBxmr5kLsfeRkm5o6D8csElmvfEJZ5tPnbMD/zAMeIbFtGLTNEYs0PjnLVv+pQc59ctuMtGWu9Nv1snExntvURaak1pmPOFEHbjUOMdG0TsuTtq5U+NPSmD0EQIC8IMRf4N5/6AL3t7u24dPxnWFlaUzFTqTqIDZDOmMqxup6h3Su+FoSBqiBEhCgOMD4Yo8gypKmwNlDGVAB1UShDehhFmJ7t4aWz64eFZKhUIqRphoN7xz/35T9828P7NjL85KfHcGqqjhcv1HF0snXv7Fr2hJCEkRrHPYe20a0HN+KanaPYvrGKkYo60SKkUPn3pIQsVOr2Qp95NEtbjQMMjQfYs2EQbP8AGBMoJEOeya2dXvFoK8nQ7KRodQg5Rbgw18E/PDPD6h19KsXyArLrp1bOOUgYY2CaaULzHuhr+ggDhplwx1QAAKFvQ/AozS66JUbD+chwR3jX+5Lea85Td5jC5GAg3HFo29F/9sG7MBKkaDbaqMURGAmtRqpFbSQ5ckEopJPwNie6VGhGEplIBFWgkzOEQYAtwyG2jI3hlfvH8aZX7f7UhfnGp554fg7PvDzPZBTJyZU0+OvHLv5cQByWEti2eRx/8JG7MfS1n9E3n77EGGP45hPTwQ37N4g9mypYXmshDgJIpgxiAVNs3owx4EAYAAUp6RoGIZbXOq+5tLi+fsOerSCSKIhUskSp4nwkASsrdYyMFnjvm65GL83ofz92llXiqFySHtyJDh9NWAnlPIe+Kqj1nZI9x8yRasrJR8so/ZfHvFw4hCIcZomQacGpmQ4cobqOkh6BseE5ROi3p640VjKHyAzjK6EykxJJjxH+8zTdmqKxTEttnzEaCa/6Q5fPpVVbNeqEO9qVZRn+9e+/ld56307MvPwslpfqKCRH0u0hzxM3L8SRC4aVRo4klc8GAYPyOjNUqzEGKqFNl2OYBkgdWxNECMIAnRQ4enYdS+vFS9VqBUmS4NrdY3/wXz719of3beJ47MkjeHmyiaMXmnhxsnX40kr6UrXC8JY7dtPrXrkT+zZXMVQDQBKFTNDuFEhzqc85Gk86RyHVKRE11WrsQQCEmq6rIUO1osKUhisBxgcYOK9AUAxQgOGBYTz63DJ+9PzMbilp2uZ1MHPpRFYJcZv5dyJUrSuVyJ1pQeevk2s7LEm3Mv0CdlHLHNGX7P0uZx8BWPEMj5GxAM+dXLr3v/3VC4+/4+5d2L11ACsrq8iyDASOojCbXdeyYwxcSy8D6jhXKMxUIC4K0pWMVMZIxpSdbaASYWKggm3XjuKV+8bw1IkJ+ovvnjncyfHSbD2/+RuPzfx9IdlDt0qGjROD+L33vxJbxqr0/3z3HFtcb8nv/nQK7/+FfRgZitFtpwg0vFeI0kl44/VkUsHvgHOst5L69Nw6SGwGkXJZSyEhzFERISElw9pqCyNDOd73pn1odrv0g2dnWaUSW57ihzYQ+esCO//9nrLypvfimxTFWElo//XQnKMHKrXP/OfpLpjzbgDTWYB0H0qpdjRTs0jM2bmModZXKRz1uL73e03dXLj+u771xQ7Bp0sfWZHdBOYbYxaziECrpSpWPUAvzfCx976W3vPmm3DpzEtYX1lBITh63UTljCN1PE5KQhRwpDmwWE/RKwgs5Ip5g2mBp7xoRqhIQZamocv8nZmu4+RMt4YoQpIkOHTt1u994ZNvvn/nuMQPfvIizs40cOR8Gy9Ntu6dXc1e2jhWwUd/6QZ69XUbwZEhTTtYWs2QF2pFAy9LCplQJFJnLU0Fb5CpCwAUOjNqrwC6mdSx9spcxDkQxyGSBHj62Cy++8LK51eaYjqKzNGmMj9wjKfPRAHHf7RFHCYVkgEuVicgj6ZIhR+FEuqAsuNuJgxCQx0YH4On0RqVBSYcosz6+m01log5AxBgeqH7xNe+dZIdO7Xwk3e/4Zp7X3XTBhBrodNJ9USqvqjfElyomBCVkhbKGCoV+RZCovDCELheICEI7V6GdjdDJeIYHYrwi3dsBSCP/vl3LgRJxuTMWvbWr//44ucE2MOH9wtsHKvg199xA7ZtGaT//I3j7IcvzLDr943Ta28ZU3Y7obxzUhN/ECgCKHSuf1WgUyIIA3STDJNzTXQyiSjkaOeZNcwSlMtc6i24Vu9idLTA++6/Guv1dPKFMyt7BwZrkIW0zMuFTXjIxaApMOsIsWi8tAZKZbTCxKIcd78hCuZt5JJNjZXkpF57skwD5BiIf6URojA2K0/NtYRtQLwn7DT39pjcFTyqhma9sfrmkCup3JbZeW2Y+y4LTdEIMoxCtDsp3vDqG+kjv3YPmrNnsTi3DElAqsuNEUmVNkd7E8OIo9EtsLiWIC8kKlGoFRUvckrHWnGuqsMb2g/DALMrKZ4/0zq61MgTIQq87XUH6eF/chcG0cHjj5/C+dkGTk63cXyy/dBiI39ioBrgl994Nb3u5k2Yn1tEN80gSR0xCrgK4QAnfXJOzY/Qwl/qikLmWF7AlTDmduoNeiYwUuYSYhGOT7bxk5+v4pnTddZMpArB0GXtrKqol7If5DuhZiyOHsI30gQK/cJe5y29XtfQbAhDuCXC0xDdSToXKGjtblpSWfXGEgmVCNfrOapxBAmGYxcb9y1//aXdZ2d2Tb3lVdsxVI3RaHegy8uBNIOUQhUNCALdTymtmiUlqZQjuYSEkn4SsFWjOWNIBcPSWoJ6vYNDu6q47eC4+OnxdSZ4hMnl9JP/83tnH89eu++RVx4cx/hwhre+5ipsHB+gz3/lxTv+/JGX2f6dr6R9m2tYWGyC64IgpoKULCQyU5SEVJBFwNQiXpyt49JiG2O1CGv1NjhTCd6ENtTLQgCkmPF6o4uRoQo+8MD+PQurnWsX6vmZSqWi1CrdtoHjhkE5gePKgfl04ja8Yl4lD+AVNji8dn1Go/42Tze2C1iV0VGVohzj8TNR0tbgbtCi4YuaeZk+lw3m5Xivy1AYtLXWMGw7bodEnWbAUJL4nqmj5DU3Y4PzWgY8QJrl2LVldOKff+x+oH0Js5dmIIREXhRIegWENP2RiGKVMj0IAiyuJVheT79kmJYq8ALkUiITAiAJlVDAIEqBICTU2wLPneng2MXGzUwK/M6v3Uq//s6b0V6ax1NHJnF+vovj0x2cmmndu96RT+RCYv/O0T+986bNmJyaw+p6C5U4BhhHwDlCziBDE/vmCswocwazsWdSqLURkhAygAUMeU4IQIBQ91fCGOttgefPreDxoysPTy4mXxCMo1KNFf17VaHscjJmGZqFuvZ7I1yh5sMCIx/Fe/GEBq1pz2Wofkto841+gFlUt/DSQ2clTuptAsesnBNfEQUskZiNzjlHHMdYaOTTX//heTY1X6cHbt2Cq3cOQFKBLC9grBzgDLIASBTggcmoapIuAiQUkytIp6E2PF3qk/N5AQag0esCosB4jaMSh9F6V+ZhFGF2tffNv/r+mXu73d2P3379RuQ5cO8t27BlYuiZf//nzyffeuwC/unbrsWGsQpW1ruqeKh+jpAMWS4tDycpQVxJqemFZu3kxbXevYfHUeQSYagZrJC2OosQQktjoN1uY9emQbzzvr2nv/j3pxizB/6sLDBcAsYbbJPqeZvRFxolBsWMvHN2IPsqrauBJSWWoO1+zBJe2Ut0hRg0+y2sGcLhH4OuDG2ob4yTgWupa8S3r4YqG5VBvT5i9FWWclxXiVl7fXc2YIfCzJMD3bc8L/DxD7xudddohslTF9HpFcpTVxTIiwJGmgUBQ6A1ASEZpubbWGvnvxUE3KILJVAFemkGSVXVH6mYCWcCSRHhuTMt/PCFWTYxEuF333svPfSanZi+eBbHTyzg3HyGly40MLXQ3dpOxSIYQ8AAIeTi/HIDPOuhEAFYBvBAQnICcXVMLyDtvGFM7xMCScXAikJalE0gCM6hsq5KEGOIqgGEAI5fbOPpl9dwdLLF1jsqmWfMzXpTHx15ggce6mKOHrmfGKDE2Dwg5NMkDDhTvIgboyZjrByNqm+2xk2YRhXF+HDbdEAaN7S1k3jIzGtLLZpiZNVqhIICPHF0mX352xc+8chPF7DYJARRBCIgKxQzUylGCFkukBeqMnBRCKS5ylxZSJM5lZAXOqeSUGmgi1Sg18tQqVWRyhiziymk5Hk1jhFHEUYGa1huySe+/vg0+87Ts5ia7WDm0joO7B7CZ/+Pu6sHdg7jsacm0csZNozXQDIHg/JKCqkQWOHNlygEgoBhpd5Ljp5dRidTTC3LhE1+YQmGqyBZpomp0+3i1gOjuP3aTdRLMlWkl3PHlPs2n7MjGETTtzHJ27zkEJNBP0b1tiqgJiwi2MrKtk1NF6yvD5ehGzDLkqiPoZn2pHTxTiX7qWbCFv1pr6yhY7NRHKLzEdXlCMuhMG8vlJClv0nM1wyMKWdMkiR47W1X0RtetRtLUxfQbnWR5xLdXoakV6AozMkMBoCrM7GModUtcH62jXYicpvIkAicCFIQur0cslBjzQuBgEuEYQ0vnGvjB89Os5v2TTz97x5+Az306u04ffwMnn3hEo6e7+CJYytfPDvbYVlBi2Ecqoj6KMTyevrpF46vIAoildO+IGQ5Ic9J7Red3VVKUgkTC7WPMl37QUi1j/JCeSizrECWFQAHBGeYXkrwD08v4q8em33f06cbrNkjVKJAZynRxhCLhqm8pj69me8YLP3ZdQJZ+rmcCfoI3TwDXj4wQ/TmrS+djbR2mND+a3JTl5CYIVTWTzPeNVpySqHS6UjOMbmU/cnyTxf+5NSlTu/W/SPV/dsHMFQBSBaQpDJOgqnakRzagC9V/Epe6CSE0qAAjkIQsrRALiQarQTdRGJuPcdLF9fZSjsHmKrEbTh3LwW+9bM5Vm8Let3N2yCEwLYtNfzqgwfw2DNT+NEzczh87Qbs2FBFvZlCJaOGQmASCALPqB8wpEmGUxdW6nMrO8dqlRCtXg9hyCGlgIHOnDMIKwsYskKgGmd4461bcWJqHapMPLfSyzAqE0/VP98GCpaRcXlNDa5zSqGHbowUNMV3LWYy4QqGefjE6RpX/ZNWzbVqJNy6G2bp6M7rIjMon5XVWZSJ1x93eZjOeXEZbdu5c/11ti9D/3pmmKqQPlAN8OFfvQssWcHa2hrStEAuJdJc1Q5lTHvHiWlELhAHIWYWEkwtdB8VUqk5RBKM1DpyI+iIIGSBMOBgQQVPn1zB0dMLR9/1hqvpfW87jNFagWPHX8aJM+s4PtnFianOw6vd4gsKF0lkaaEEtCB0E8JTx5bv3b0heHywAhAV+km6WHSuIvi5qfFKQCYUE3DFadUMBlyVRiMC5lZTnJvt4sRk+9HJ5fSBXsbAgxBRoIS3Vx6j/LIA2oEaK5yMBgCCDZ3Qy+U7DEtrY8+leNoB2XxggD3X3W8fMLDSpwdPSpfa1PeQT6BXUGcc5tcbQzsF4kqMREgcOVevzSy0tly7fXjhut1D2LW5gloMMMqt5FU0ruvRSaCQEiCOggjdpEC9laLVyYACqA3VMDJcw6aRCGObgJtu3EmFjJFIiXYnQzcrMDffwOSl+sjscqv13edm2fnZ1u/90uv2fP42AFs3Ctx3105UKhF++sICbrxmFPt3VZFkOYpMoSmSPqIBuFTqwsWZ9fGXL6zRq24aQ1a0AESW4Rtpw3XxXeNpybMM+7bXcNuBCXri+Cqr1QaUqUy48mu+bcioZiUbEffjvBx5lWxdQEnSWelnnqHDB5yAglWFfDuGz8wYTBI+34HuDLpEZNNpE7MhozDqoAFhzO+r7qdl4rbjzpFB3v1l5qUdO8YzWponeBvEkbaxHXU7Pbz99TfQ9VeNYnHqLLoacWUapdgtKAhRoDznYIRcMLw82cTCavpAYGohQoV2CCJ9fpeQFwkqEUMhYxw7v4x2J8Vvvuf2w6+5bRda9TW88NwUTk91cWy6hyMXmrX59SQx0zE+FGLjcHRooBY9GHF2IIrDa2PODl+c72AkFogrQCViqMYhqpUQAwMVOw+FkBBkarMyZJmq8QiNPIUktHo5ZlYSTM51n5lfze5rZiwlFiGMACKhq6T326rcmnHznZkkchOsHG3GllsiJ7u2bl313HGVgNSaSXT7oS8JzYIbiVrWSWE3gjIswxnfTEf0b9+rZQbn06JdeGlPCqiNL1WwIA+AtY5YfP5sk52f7xzau7V2dPemKjaNhhiuMoSBlryBIgpiIbqpQKOVodlNEYYRtm7dgOtumEAlUKlDhmoBRocriAKgWo3BuUppk+cShWDo5kC9J5ovT67i6KkVnD6z8Kknfj6LdiPBTdeMYv++Qdz9ii2IWIQzk8sYHGDYvjlGKnIduwOEWrKaVM1BGGCtneKFlxfwyoMTSqoVAix0TIdxgBOBuPpAGXslKlGB2w+O4/nTKwBU6l43l8or6ycW9De7r947sOFCEqyE01eVaIB5CM3aoZwq5qMX9YURneQ9UYd+gJUN9oam+qS2+k6Pj0in/Hb988ddVl3NmDj8KkRG6JqRGEZF3hyUvJIa9dlpYAxSCFQrId7xxushumtoNdpK/YIKh4EEWKAdFiCAcwgpEEQcS2s5Xp5soZUSojhUbFyvmcp8wlCrMAxUQ2S5xKWFVYwOVfHGe2/Cri2DOHfmAo6dWsDZSwmeO9V8/KXZ9n0EYN+O4ffefcvOrx66ZgJbJqoYiEkdl5Mq/jEXDK1Ogk47Qa+botVqoRACaZIhzVNwKVGtBgijAIwR0kwgFwx5AaQFodMTWGvlWFzPsVDPP7Hezv8kyaDOGUcqDTxJCa949hXQtKcloExXJURsNAagRFMGfBusVgJTHq0agRQ6uifXmJFwPrb3rrGPI3JS1FC9kZQqMgNeYZIy0ejLTaUT82CSBHCGOA4hJGGpLV9au9BmZy51MD4UfWbDCPvU+HCA0TjCQC1EnhVYa+cQgrBx4yiu2bcHhw7vw+hAhLTXQNJrQxYFpMjRbqZ2gzAAEYNyYXN1En/rQIzNN4zj7us2YbV51WfXWj3MTq3i/HQTnV6Oq3dmuO3wBHZuH8Cl6WV0OwJAABYoia3SCCnXuBBAGHDkBBw7szJyZqrevHbnIFYX1xHxAOAELhRBGBRG0iBjBpEX2LW5hmt2DE6emE72RlEVZKuCkFWvAFMtR5c6s4jZqFZkmYGPSsySOS7m1rgk0si5xNVNzBKXEVX+upIlSL8vhrb6Iw4NpTLXT+Y6ZoJeHeIqv8hc6iCbJzz76dagPEfTTprDomcw5RjJkhy3XL+V9u8cQWPlAvJU5eoiHSbBuPXJIuDKG10IgSCKcfzCKi7MdxkxDmJK3WO6s1JIjIxUB8bHhtDtAisrXWzbOoFr920HkxmefvYkzlys49RUHaenG1+t1AZu/5UHrqObDm7BDXvHsWdziCgoIESOPM+UTThjyIsMIQ9QGQkxNjgIIQYgilEYBi6KFOv1DpZWGphfbIECgLEAvZxhcS3DYiPHciN7X71VfK2bqwwYQRAgjFQYciFN2nhyyNoIBsvE7MQ6QGNoz9JGHzLTVOR7133+o/6UjnI9tAZA1YU0EhNgMNl++93oFpw7kahvdd4LwHBPLxLI3xhMMzcrH8nVTyR9SJjp6DOpbg7DCEQSa90Cq53k09Mr+PTwQIRKmN+e99LTm8birxy+bvtDhw9uwYGrt2MoZggiQmNtESsra0iTDIwFOlEbR8iV5GRgyj2sC3FkmSqjxhhQq8Wo1CrYPMiw+cYNqLcyTE2uo1Hv4ZqOwN5dExi5bgvanR7mFjtoNNN6mhcYGajpVNR6PqUq6z6/2m099sIcrt11AEHIlI2MK9TCNHoJWIBCFBb9FjkwUAlw474Ne45NTkOlLVMqs0FGJjv5lTyAZWBNYCzQRVDKn3MEcHYwt2iW8Rgm4h3GZ/DrQtpLFCmaUBubW98gL0PcPu04aiyroobhlAWeedlYPK2WaUmIy7UJ9zxTz8A3aYCU4LBOLI0KAqig6Ptu34dK0MNSq6OrxiuEGAQMudCplLVNSeQCPAyx3Mjwwpm1xxvtHFG1AkEErrtYiSMUSY7hgehfBFKi182we8cmbNqyAc1GHZNTyzg33cTUXAu1oQF87AO3vO+ma7dieEClQE87LSwvrqDbTVEIqY3zhEKSrmFKtk9xFCEIOCpRgGocY3iogg1jNezaNorZpRZePLWIZ46vLKx28NudhL7RSATSTK1dGAcII6WhKKHooXlfSFkJ6OjGFjvp1w4MyvJhtX5JGIODJTGz/LpZ7xkGK+nPQudm9i62f7uWVF/7YpCY+brfgH95FRxuRqwRmn2WkbhWwptBMS0VlW7OAw7oYw9L6wkAPHvXjdvpnW8+gFsOTKDCAZGnWF9voF5vI+llYAEHD8ISHJVE4PZku0F9ChPzEMgyiW6jA7naRlEIjIzEqA5UMDoSYGm1wHPHlnBpsYV9eycwMhBi7+4xPHDX3rHJpdNYbnQQRSqHEvQpgTBgyMDws5cW2M3XbKDbD4xieXkdNa7Kv4MDJNTYmUFROg85kwX2bh/GWI2jJwtAJ3kkHSF92Xb1pJwlHJRVJgDa5migvkdXVsV0BOevlUU8tk1zWsKvgKTlqa8y+uor08/XxOO84JpOOEDEy+ouc32GNxbfy+3Rd3mDePRJZHKokwt7sUJUjVEx5wJDAxHuuH4L0vY6siy1qoQptgyDSsmF8FR4iBdOLuL8pfZ94BxEDEIALFTZUZqtBFlW4Pabtn9q37ZBxKKNMB7E0tIKZmZXsdLooTZYwZvfcBMOXrMdY6MVJO0WZmfW0Gh1kGcFwiBAHGpjPEHnwXOOC5XkEyiKFIwBCWdo8w6qlRi1OEStFmHvjmGMjNQQDQxu/dsfT9WXmqliBmGk5p/p4rU2oaBbQ8eAmKcae/RWslF66Nu24dGnRWzmH2O/7addBgOASiol0+l0LPryILU0hKWoF/4jraD2CNw3DlvY6BG7u8MRlaUwDRdNmSh7Jxk1QW2UPE0BEG6+ZvzpB19z3R2vvXUHNowA3U4TK0ttdDo9K4WCMNSxYorwBKRKz8sIAZjNDgEmrfogheprFIZAwBBVCEkvR95rYWKkgoFqFeuNDFlBmJquY6QKbNpUxWtfuRXbtk7QXz16Go8fmWcAUI0V4xRCIgo46u0M33py6pH92294aHCwhqSboRKb85WwRGiWm0iCywIbhivYsal25PRcenMQhZBMzYebI3IbzyYcvByNmBJ5PoNTa+Gjsn6WSI5e9dclE4BHuFZttEzLrbFDd300YmSa4p5WkJbo0dznoUtffXbCyY9v8+xlvmBlOkZQbyIlP5k9j0ekMqNkaYqD+zY9vWMiRHutAZErFYYzgmAECFXkBKQcSHkhUBuIce5SCz87vnJHJyPEEUchBcI4BAdhfb2DjeM1/B/vu5d+4VXbwHvrWFxuY3GtifVmF4MDg7jjFbuwY9soqlGIZrOD48cuoNnugkGnUA8DFbqjj/4QlBc+16FDKimEzswBdRogCLgq8yclur0USZYgCgIM1Cp40x1bcGDP6KM/fG4BPzmyyJbrmpFFERiXICguySSVScNDPP0mIQNQShqcp5FZKiBH7858WXauOCbmAJYjIX1dHEfuG8Od9KJq7Qb2YLDVVG3PTFIBp0LCH1yZIB3RexLZl75euACYVmd1twpRYDAGPvbOV9KDr96B8WGObifB8modnV4KIqndxSqmxcaF2XLoUqtbugBE4BwI0MSrYLg50sHAuJLOnBHCUCBgDEEYAQFH2hOQQiAKgOGhGjZs3IhMxvjZ8UX8xfdefvfFufY3wDjikOtU1AKcAQ/etYt+5f59aLWaCKCyA5hMr9L8CJ0qmwGCV/DIU/P40c9XWKU6gLwowLSKY/Ji+ajJGcSVWmgynHIVkuhWyRzKd5i8REQetcLGl3nXuGzkLhOqrwJaIE/QBFKGRYxBnf3z4FLZjlJG576KYUfhSemSZDXilhxCcHPhGCbgotIZY2BcxVR1u2285d4D9PvvP4iVuSm0mkq1L0gi9+qFkiSkuUAYMTS6DF//0cwzRy+07uScIQg5wihCN8kBIfCaV11DH/vl23H9jipmpy9ganIejWaGuBJhx44N2LxhHMO1GGnRxfzCKtbrXRBUPQiSKoiY68PVZpgSBCmA3FMjfRUr5AxhqKt6cYZA5+QXpKL/KzHD2FgNkgWYWkjx2IvLeOz5+WClLWTAA4d4XBkgNa9Gg0H5pezLTjgaG6H1wuq2FKkyu8wODpPSMmCuM55RT1Dq/6SqmqxsYOZeY44yEt1kB2BMkb7U7gGbR8rYQXRhTGY+KzEsH2I60695TlnVgKcySPc9AVIUGKzVqjs3DaEKoLHWwMp6C2mWAUzXViQCYxKcKXuaBNmCEeb8F5MMkhNCCbv5CS5NjoG5kghM6EnhQJETiAOiSBBFDCPDA1hvMVyYb2OoSlirL2JkqIZ7btiAA1fd9fXvP3sJ//sHZ1gnKVRBkihAkQn84LlZtm3zEL32lg2orzfAWKjlgITxqJFGB4IAxgkToxWLYJjduM6uZBGQTyilrc7KxOZvdntESLfD+2P6PElr8Y5eVzDrpOH9qhVKZADNhWybit5ciMblL3WNOo/n6ksaYu1HmaTPyqowDYcC/L672WB2I9n7PZAhJWHrRA1FliDPhNM7yFUWlyDkokAQcrR6HN95egHHJ1t3Ms4QRSqGqttJsHnDID70njvpra/djzhr4vTx41hcaSKOIuzZM4bBWoyhgRgi62FyeQmdXg+CgCiIdNYIHeKgz8ZJYlY8qTAIfXbYO0MMQB1nIxUcTdoIJ3U2GGiab3YLdJMOhodj7N8WY//m/RgAF1/58QXnPraAxBMKFjp75ol+GkMf8jIOHE9YEpE+6qjfm9qhzFupPvXUtqiZYKiX2uqZRnRq+aTVN/QRmlEBPCjvQztobgxmice3c1hi7mvD3u+3SVDqVBBitZUlf/RnT9X2bKj03nzbDhw+OIFqFUjSDEVRwGwuIrgDoYzp+CnDQAlMMggCEBgcQd4aucUSEgq3SAahzmKAc6AoOM7NdPDMyXVMXup+aWy09qEb9o5hx1iGxZUWtm8bwy+/dj9uvnYLfeuJc/jxczNMFEClEqFTSPzdTyYHRweCzuH9g2g0u6rAB8weVR4r51EkDFVVIkeDKPrja9QiqwIkKkOEjt8yMNssmR8LpRfZGq/7MHpZxXfvbfoTj0ko76NivuYe8jxHfhtlW6mxrZp1NnYOZvvnP0epyTocgby2rQpoVEg7DPs8rldaehvPV7fN3yYH+8gQR55lKHIBIq6dWwqNgwhSFAjDAK0swA9eWMAzp9aYYAEqoSq5BwBvuu9G+vC7bseNu2LMTJ7HhQtz6OUMM8s5Gp0e7rplDBsHqlhYXEKa5mA8hCmRXRSqsIYwa2KYlBuaQmY6DlIQtO3UIG6AuLe0msCJCEJKEAfiKEQ74XjxxTqmFlsoCobZld7jpNG6rvfsqfIehRgS9FR5s38UkGLemnq2VMPoLArz9r7VIuzWdXRollXfbNoMjfpB3hVek5oISu/g9g+5Lz0Vw9qX4B5Kbrfpy7XtwU4Sg6F/qz/bPaSGnRfA/Go3mV/tsosLHX7r2Qlx53UTuGb3MAaHOIqsQJLk+ryhmWjViDSnrxnAyR17Is6sg4GZDcQlmNDskEgTh/qukAynL7Xx9In1o5OLyc0ZhZhcb3744nKvemDbUO/gjgHUOwlGBuvYuX0DfvOXDuGuQzvpW0+effzo6ZX7AIblRt7928enPz9Y2fvwvm0V1JtdhGEATsqORdKcTVVUWYm5TnHi1kZF/Bs07KEJZpi3h4ZLUtKo6P46OxTumJojnpJNysgfj+dZGrKL7aR8uR1nF7HUZFAnXCZaI+R4HxokGALXg9RjNMjLUJl5vnF4qJAez1XvDdw4FvQDrPOpFjMUOl8X0yo+5yrLSZYLxFGEdgY8eWQJz52uMwkOEgKJAA7s33rT+952x0uvvW07eHcVT/30HJZWWlhqEk5MdXBypv7QejP75ovnW+tvvnP72NXbYuQyh8hzu54Ag7R2SydUjBZk9yxBZ3PVt5HRXJw3EOpjgKmSbJwCtFOB0xcb+Pn5Nk5OtYP1ViGzQjFeHgYATBizowe1an1eblN5qo8eLBOyq+Ls3yVrgglq9e1QdgZ8XGe0N2fEYmBglUpkmZbjkXCSDwRXqt2PLTJckGmJBg+Ge700KMuJxBIBGW5q7/FQARFsUKgxtnF9LCPTtfV2bqgcumn/xNFbrh7B1dtrGBlUjDFNBXpJgSzXUFurRwaCqkKoSkUJTEAsKUkmhLJ1kFCTpbJPEFYbAscmWzh6vnH/alN+n4URWBhACIkkzcFEgW3j1dtv3DfyzDXbBjA+EGHbliHs2L4RSRDhySOz+NZj5z90/lLry4xxHL5q9On3vH73HXu3R1ivdyEl05kslMrAGMDDCGfnMnz5kfOsQKxizYTQMWdqrtSpn7LYMVIOzHzgqVN2vbx7Suvi0LOBQeRDfXIeU8364exVXmyYQV6+SLRMyiEn208HnS0d2q/MwODoqkSvUExdfcI1kzWMmwAbQkEoEatHb0zny+r1evhXH72NXrkvQn21Dlkoji1IoCgkwihEoyvx45fW8fiRVbasvXg7Ng0Pv/0Xbm3ef+dV2DyQYfrCJM5PLmCunuL0XIaTU+075la6zwqpmASDxK4NlQdfd3jzI4euHsZgFTbJIQ9c4LI0aqGZGeXkhpQqar6QpFLhGO+uFvhhAMQBQxxzJQQ5R7MrcPZSBy+db+HYZHvP/Fo2bRhMEChh7nADswzeTL0jJUd/5NEN/FVzjMTxhRKRUulZqs0S1ALX5gOCEZC6LoTpTyWO/l8kpUtvwZiBp+XPyRKAa8NkkDDqGhnC9dCetdmUOLf5bdzy0GliYPVlgsuRJYhBFCrLw9bR+NC+7QNHr95Rw56tA9gyHqFSCQB9ADzLChRSSVAwxcCCQLUTcGVXUB4eslAdIKQ5Yame49xcF2cudb8xvZK+O82BOApAPFT2RyjUlOUSRZ6hEjLs2z78n2/YO/yJPRtjbJ2oYt/eCWzcPIaFRoEfPTeNx56d/+zpycan920eeO8v37/3qzftr6Hd6qHVyRDwQBn3SeWGml6R+NNHzrNURJBQBnwrRIycKlUEUlTmtENydiS7+GXPoeULRNqe6U4xKr7iNj55ar5xEpAhQm8xnaR2EtkP22HMs7/pPhibKRmOZVC65XwuDJy8c59OgfBVWTg60wzZOTLcPjK0rYQVRzdN8ce/eSvdtCtAq95GkXNIWSgDOg8wu1rgh0dX8ZOjK6yXCezYNDT80P03Nt/86gPYOsKxND+LUycvYm6piwuLOY7PtD8xudz7E3XWUJU0C0PlSMqyAqNVhlv2j9HNV49h5+YYtQg64l34x1EtQ1GzppmXICt0jVMnICCKVOHnSqwyYTR6AhcXejg51cWZ6da9C+v5E5lQeewZ00qj4yZ2TxvG0u8o8Z1w7j28NfezTGjspNeJQwkTm0DaMi+UBCAYAzdpxw3ThCfQQJqBOZQGwzENzShbBLPnl8ioYpbRGFHI7GbhzH9vNgtzRG73jYHGboHMLHngAKY6toKv0m0AHQEPqFzijAGDMbBhJPr45rHKF7durGDreAUbRysYqjFUAg59uTb0q2NJjoEpL2QvJaw2C1xaS3FxoYeL891PzK8mf9LLVHK7MOAAV1HWAAMMsemCoIXOgz1UDbB/x8hPbt43fO+1O2vYs3UQe3aOIx6s4vxSDz95dhE/fHLmE6ut5E/eeNsWuu/QKIYHOZqNBGkuEAQB4kqI+TrhS49ciBs9ljPGlA3D5Hq36+bNIUEzNfd1ee7dxjdLRWS8Q3DMwq0A3GJ6QI0xrQKW1UXThmMsqk/U580CXAanUv88WtCsx7XtE7s3FnUaAbAnBZyO4+bE0JcmIOM/5dagzwAeICty/NGHbqbrdoSorzch8gKVMEK3AI5eaONHP1/+4slLnd++asfIu37xNdd+/U13X41rdtSwtryOl05M4cyFZUwu9HB6Lv3G5GL33e1M6W+hLqkGrvZTEHCEnEOIAlxKbB2vfPyanYNfvGbHILZtrGBskCGKmI3iN+NWb1WMmSCtQnr7hhFBgKHVE1hpFphbSzG9nCzMriRXrbWKRAiFtgCddVXbXRm0wd9kIbGAwjfGu3UgTWeWuVgmZpifowl495sUOh7bsGYDx9DcZ4ZGLTUafZkzFUZh3JJG4+RaCjtzhmYo2oDJjepo+uRJZX+TMHP0BXDXW+TlOsktd2dwhSxd3I+NYTIcHY5nBoyr2pJBCMbUCXkpJAopEHNgIGYYG4p+Y3wo/MyGkXjr+HCEgWqASqxKu4UB08VDCGkh0OwUWGnkuLSSPTO3mt+51spRCAHGgDjkMCEe4CFIQTiVYFEUkEVuEwsCTNf6I2waqeLGfcN0y75BXLW5gu1bBrFz+yiiShVnZ7v4ztNzeO7I4lfjCIduv27D4RuvGsDgAEen1YOUQDMN8T9/eOnzU0vZJzkPIEThopfNvOj55FpCw7cflYiljJbNb2ZQmzG+wo/J0fYWE5LSt87wnmGI3Q9q9NVV32vl3POsRKAG8ds+Wr5jDMCmv3AbwQ0KZFzx+hs/2p68kyMEh/DVxuGQxBAEhD/6yGHaPirQbXZQSI6p+QSPH1vF6ZlWdcPY4BffcNfVH7r/rr3Yv3MQSa+F4y/P4NyFNVyYTfHypc7Uubn23kbiMy6LMwHGwYIAnCuBGjElpLOCEHNgw1D4rq0bKl/ftjHG1g01TAxFGKoFGIiVtsCYiossCkJeEJJcIMkleqlAu0eotzMstwos1/NHVlvFrzQT0U0KZSs0VYhI7xOhN7lRsy2GcL9gnByWiQJw6OsKHmFLjh5k8+jNU8lgdB0/4sBs8v7IBABWC7O0FUexvkZnOuAmtlcjsRLzNIuv0ZjmwIZAySM882QD/52aYWdFS2Vo7m9TqrsRlN6Siz/RBGyKr6poewbGFUNiUHFXRSGRpoUiWqgo7GqsvC9hyBCFvBoG/FDAsIWApBByKsnkmSSTSAqV48mEZDDdB0YMxAMVtq9r6XEiMCnAtAHeSgcWgDhHmhOqgcRVW6tfuXH3yPv2bIyxfUMFe7cNYsumGhDXcHaxh8eeX8T5s+uIK4QbrxrC3s0hxker6CUMf/GDGfzsTIdVohB5UdiNLfXJZyMDuInWt+RlGIq03xtj+5W8v8wQsZ1nVqIfZZ/z21dtGceNFUhwWU3Rz7y8TXI52vMEpqHYflqwIyszMNIbzD1HXcc1TTPujcVsRilt0Y8oCNHu5jh8zejTn/rQzXeE1MGFC2v42bE1nL3UfGZkeOSOu27diXtu2oF9OwdRFAnOXFjF8XNLmJ7rYnKpwKmZxoGFenpG8gBRwFVCG+YxXOhTJppeOVNzpyIIGEDqIDlIIIoYhmrRoZGB8ONDleB9A7WgWokChRgBiEIizSW6qVzoZfL73VR8s5PIb3QSgW6mRFykK3HzMNDP16nHpbTxhw79QO9v4+n27aCwjKS8PnYyL5t3X7OiEr0x95tBpReCT6tO8Bj133oxtY3MBKizShRrWOjOsCko6nro6FCnLSZ3Ds+H64zBOyPnBs4IkPqtkYaG8Ewgm0fnFvKXNon5l5xHyGw2zkObOE/3XpG+lCAdKyPILJh3upwx8CBAwJRBX0k3hwakVPYmksLrG8B4APAAQRQhDAMwCYgiR5qmKAqBy1/aW0AStQrHjg21j+/aPPDF/ZsrOLhrEJsnati6pYbaQA0zKwWOnKtjdbEJRil2bR/Ewb3j+PmZDr7wly+zoVoNuRAQQhWEUPFMzIIYzo2pF4qJ6mBRG1rB3TxbZGaEkCUhfx2otMYmo64lTN2OMf76SAv/yHvldTTzxOz+8OnIzrelAudBtXJb2SdK6ByWVvRIuELpxinBuW5Vj8Mg/IAHyEUBEjm+8Ae/QDdsZ3jh52fw8tkVdLIYN1y3E3fesBXbN1aQpT2cm1zG8TPLOHG+h/OLyTOXljt3rvSutPblVxBwxJVIoS8j+DUzAdP2WO5CDYQem1HxVPEUJeyFFPYMpBu3Gp8Kpg0QBYYwDFr31l7q9DTSLYPBpi4m0CAwz5HDYD/3EZhV+UywKvPmGldyqEAzMIeXPWUCDPrIl0HrblXtqRNWqRgbmBu8GYQJ/lTj9eJmDJV5KMwSnsd5fQOvkYQEaMOccxFbQyGcx+VyVeRyqMqYuY6BBaowglETFGHoMlUmyNXeRBq5BeDMVBrm2sPJIKQ5UyasbctKhYAjCAMwFuoMsYU6z8EYhmoRRoej4ZGh6h+Nj9Q+MTpcxfBAjChUzyyKAkmao9nuodvLkKfF6Y2jlQN7Nw9i18YIE4Mc27YMYWB0BDlxLKx0sL7WwubhAOMbNuAzf/bCwvMn17eFQaizBChCF8KUB1GFT5Xk5HptXNyYQz9OovoMzK6hx1CYfmPYvmFYJUxk73E0Yu4viR/y0Z3wpFMf0/TW10lPZq/XlGf/AzkkZoIlmAmf4FzZXJhjYExvcMOgCyGQpDmEEPjt999N73/wACZfPo6ZhRaCyiCu2rkRG0ditJoNTE4v4OJsAwsrKZYbEotroi54tDi+ceDA5g0xKpwB4MglkGWEXibR7OZYb/YeWa33fqXeSrvdTNgBRnGIOAwsxiCpz2sGXK9lYCbMi5OSuiyaSu1j4vDMXCgM4tRmpitpK1MRLKcwdlSCYebeknJWpgPDtDyBRnaNTJOuAT/VuWrD2MtNbINDKEwzPSkNDfmMsUxP/QKRxZVIx9IYsvApVUt2I+U9AjYLYOA4wbd5OVXCDEyFY2jxr8CIY7W6Zcc41XfckqST/MYTY+ia6ckycJcx2HgpMowI6jdgFkDHfnFFJDwMdGUm5d1R9xaAFIA06hoDGEeWC60mAsNDMa7aNf69A1dtun/f9hFsHoswOhShVglQCwNUAo6ASZUDjCvbXiEEslygnQlMLrQxNddC3i0wNhJiKAKqIQcLCbt2DGPLxkGAh5BZjvHRKs4tCHzlH87gpVOrbLmVGtJAFIcIjdvS4E/GtfTSjJeRQ8eGAViJCTunPjPrVwcZ0+qHQbqeFFVLxe3844qEZ2wsCjk6mdln2yoRsSVDOJ+loUUvkaRF3ZrWmEfknANMp4fhHGHIIYRAr5sg04h5w0gF737rbfSRd96M1amzWFtdR3VwAIUAWs0OFhdW0Gr3IEAIogEEUQW1gRgD1RCDAzWMDEaoxZredHZWIgaSDAUB3VSi3S3QaGVYqCeYWWzh3KXGoxfnGg+0uoqeoihEHAf62BeDZAZMqB+jjhphTkKgkMKpZ+StL2PKnKBPzXDOHYqWJrDbzR1BITG3lGZvevterzkMEoTmCx4QcTF83tY2KKxvzX1h5Ikei+AsavO8mIqheQI3jiPDldRkcdjBGDlrOqMRO4yyof43BGUYk3NjGwRlOLbuEpQ9yxP5dprUQ8iiBWdvK58ndUZFxYccAzOqkgRAwiAn0kzNqJ9KSjLGwMMQjAXqb8YgoTcyFeAkwbnyKvZ0dHUUcNx+aCddv38TDuwexYE9I9gwonI0ZalCVr1ejiTJkfUyVfSBlKMgABCFyo3OKwwSHL2exMp6ik5RIOsW4EEIHnKQLBBCYGy8grHhKqoRYWJ0HDmv4ORkB8cn13HizDLOT9cH59Z7XTMvA7WqYmacqcO9RJBCgCA1AzOLT5bRlIUCc8Rt1sV+ptcHjrEZxkNM29dg2naCz6E6hUTJoAQHAbVE9xmeQ9OGg3EPMSp52sfACDbBIIMyWvOAq1AB7X4u8hxpmgMg7N4+vOnA7s1Lh67bghv3bsShg1uwPD+FlaVlpAXQ7aaor6ukgNW4hsHRAQyPDGBksKZjCAUYCeS5UKmmc6HRsGP4Ieeo1iLUqjEGa7Eur8aR5gxrrQIXF1p46dwajp1ee/TMpfoDSS4AMAwO1sB4AOMdtoIGCjkp4azXlcicIzJkoK9XpgtGiiH5GlHZROTQm9tl2knkYLK3T40WA099Zw7QmPs9gGK0LdMHoz0wkM0K41VQc4BJMzDNdkqYRxLAKpXY6tgAQNx1wgQq9ukVHnMxhlqjx+qJsIe/NbcswUmyA7Cw1Cm9Fj0xN492Tp2x0Symut/a1Zjro84HoiUiAF14wG4eg754AFgG5m7nnCHPMnR7CulsHBvEa++6nu47vAsHdsUYqgowmaLIEjSabTTaCbpJjixTh35NUGoQGEmjKnpzAEIWyIVAnkuEDAjjEAXn6PUIuYTKLaWjFcMwR8QkRkeqiAKGjRvHMFAdAK9WkGYBFtcyPH92CS+dWcGJsytsqdHTgwgQhQHiKFTFTIl0MV0d1GuJ1KHngAeOoA2x2Pn3DPCSQFwfziFlaiCzUfRNLm8ZWcZpVHdjhiihfmYT3YAzrhG3ksZmbzE4WjGmBmPTdBWuTY4vtYaqeEVhiX7DSAU3HthJd92yF3fetAWbhxkGqgK9VgdTUwtYW2uhgEQnKZBmhFo1xsjwIGq1KsJqgCxJUKQZ8rwA6XqkPOBWTeNMRcuro2AqoJbrnyhkiANVELZaqWCwGiOqxEhyhuW1AufnO3jx7CKePbYwfmmlU2c8xPBgVZOzs1cSSUAKCIPEyLdlGaTrwkkYYLUjxQgc4DAakdkrzFIGwdug/ZfCbVKfEer1MRfDAyKe1mT6oUEYbJNGheQ+DTr7mxGOPjp3DMx023BvTTR+LE9J/9T3kOmY4RveNb7qaRiSlMar5MIxDPM0rn8qz52dCP1AtwksCvOeYWCsrUCtC3dqZGaj/TUDC4LAIkbOVNxNUQg0WwrUXLt70w333Lb/+Ktv2Y3r9o4hkh0sL85idb2OJCs0Aw10RlZdQKGQJWeG5pc6Tkkz1kIiLZQhPklz5IUEC0IAinHGYQAOiWotRJoRuqlyAAxVOSIGDA/XMDhYw+aJYcS1AfRkiNk1gZfOL+PY6XlMzjYfubTQfOt6O4dKOMYQBiGiKLTEI3U8mXHOmAKrHklCi0NYD7NdFKb3ijGi25s8VUWjX0/4OSnqhJhRIa31lUFrAGRvM+tcQg76O7fSHEWRa0eKu27ntrGxA1dtXr9x/0bcsG8jDu6bwIZhgmivY2lhGSv1OtYaPQiKIUSAlWaCai3G5g1jkEIiDDnyvICQBRhUGbwgCGy2FMWnpCVWAreZhU10f6D9OGGo7JSmShCBUIljjA8PolapIJEMM8sJnjmxhB8/P/Wh83OtL1eiEIO1CogYcgEQCQBSF6IlDxlDayDuJIJhDmoZDVNxe1jjATe/uhSh1WaYEXPMJkaw+epN267REtYp26uYu85jUvD4h0keYYz6hpfY5BFe/w0jY5WKDqPQ6WZ0GL3rBBR1lmJw4HuEtHqnYariHT7CKge3WT5qUZhDdE7GeC54lD1jPnMz1xqUaDMpQKuBJn7MSC+thyvvJddMJdDxMcqQ2ux0wUji8IFtkw/cfe2eWw9uwc7NFYi8h/9/X18WpNdxnfd13+XfZl+AmcEAIEgCXCQCpCnJWopMOY6oKsehk0qkSqriVKpi5yn2S+SnyE+2nixXpew82X5I2X6xlKqU5ZdItssWFdmkZYsiBYokCJAAZoDZ93+/93bnoc/S94ecUUkiZ/7/3u7T53znO6dPn97YfIi9g2MAQJamSGxC1dlhQCV1DnDckodKKjQUdsy54bxHQuUfJV0o6isA3iDNDaytYD1wNHD423eOcPdh/xvT7fSLa8stnJtrYHk6Qyf3mJlK0cpzLC9PY2FhFlNTUyhcgqOexcO9Ph7sneHt97Zw887Ot9+/e/iFUcFsxCCxKfI8sAduae291zsDiUwbCi2CMtN6cEgQOuCRPkSNLL1udde9NHtkRGGEkd1v8c6kA7KdD65xI+djgh4UpcNwPJa8JABMdxq4sr7wrWeeXH3l+lOreOaJBZyfMZjOS4z7fZydHuNgfw/d3gD9ITCsgKOex/6px9bhCJu7ve1mZlb+5c88g4VOgl6/iyRLA2P3nD8KoD8aj+FdKSkIa3kuVG/lg+NKUoOENopsEvTPOYPSVYEZlw4WBrMzTawszSJLGrizfYbvvvUQf/n6/V/+aKf/B+1WE1mWoyxLVJ5zX8RWHOg0BmrHgeJUlIcCgJAQYWpB6uzo6+SB1h8xgEV2K6cjoLrOYCfRFa1tpEswvM6kI0SKmK0xxkBQgHQjGpzJG3RLDp05DIplqWq6Tg8hD/dkmHpcQIRlosR9jWLW8DrSaUak+p9F4NF7Gb3B1DP6m0ahitaeqCd/ThtuBOBMSJGy1IZzk+Mhblw9951//bNPv/zy8xdxfj7H8ckR7m1uY/+4CxiLLE0DiXOc93FIaKMolDYEw3XOhDyF52Z4FGbwQiWh5UrwwqF/VJKkKAqH0WiINDU4OavwxvvH+JsfH5jeMMyxkRt0Gtaem2v975XFxqvn5nPMNYCluRRzLYvzC20szXewsDiHqc4MpjotHPc97u90cfPDA9y6f4gP7h1hY/v0Fze2z/64EMM3SJIUjUYabpRBSEhzmMIsRz13okyM9ZMuexF5x+wLwehj+RtjKP9hdQ2Dx0Fc32XJ8AGD8TiE33DKsjrtDJdX537v6uXlX3728XO4cqGN1cU2VhbbyE2FQf8UB4d76J2d4uxsiHHhMCosTgYeG/tjbOwN8XB/9M2DbvXvTntlvz+u4CuH64/Pf+fffv7ay2tLFoPBEGmeoyrIKSGcyijLAuNxAe+qEKpDw2NHumoRnFyaBjYWDNaSk1OjtomlcgmP+ZkWVpenYGyCd+8d4/+8voFvvbFtjnsOM1N5uFKwqlTXIwYc24+Buv+43MGzTUEjwpqtyrV2EZBxuRNbmkRJ/H6tI5TmCaQbk+xZQAzE1JmVe2hOzOtmTnCI/A5N9Js8y2r0Ms5HBcSNQIjmxaQyPrbha+gZC4iRGOR1nHho9gnSTSDKiRh5HzMqHV+ciHfcDlrGoOxQAA/MDEDgF4ScGIskMej2Brh4rv2pf/PK02+8+rkncHV9CkcHR7h9bwfHvRFKD3gXvFNVVsJQDCg05J5nxEBCrimWKW0Y2LDYiaEEKwKIOg+My3AAHT4czt3eH+Jvbx7iRxtnpnAGWZaBbhREVZYkPod202Kunb60stj69uVzzeaF+QyzjRILszlmOw3Mz7TRbrcwM9NBnmWokOJ4AOyfVvhw6wzvbhzi7sYxtve6X364c/bbvVEhChbO7KUSDsM5ObJibAIgUeAxrGFaeMr5KQ92JE4+L62oaYeQ9SdNQmqB31k5h/G4oLs0w8/8TAuri+3fe2x95pefWp/Hs4/NYW25haW5Npq2RFkNcXzSx/FJF0fHXfRGFXqDEqPC46hXYfe0xIPdAXaPR7951Kt+vTsEioqaWBI4AUBRlnju8fk//fnPrr16aSlF2Oo3aDRCE1DnHSpHiXtXhSJLUGrEcLvtmDlyjVc4BhR6eDFQWyQm7JBmeeiiauAw20lxbimw6r+9eYj/9Vcf4vUfH5osy5GlNnQvIdORnXZjYtVHfF8A26JjRxIBCgWhwb5oTXwEIJAoy+uzxWwJDImlP0Iw6F85KgNL2Qf7ASC6xcwwjFdxhHXCGmX8Jo9yIkoLg9Fx+KgdNQ20IigIXZBXRu/rB1AB+a7SQR8Wmz4r3UElfFAAFFkJnaVJCI3lscQkUwVHdFBuuIFRQElsgtF4hJ/7zGX/S//qabx4dQbd4z5ub+zj+GwI54NiD8fhxuKQS/N06j9Ml3NbCV3SEezUyGfD0AyNmag6ydjaBHBA5TwK5wFvUVQe72908fqPDr52e2v4a1WSIM8teJvEWKpbQzht4Hw4EOy9RzMFFqbz60uz2e+dW2j+9NJ0itWFBpZnMszP5GinHlPtHK12CzMz08gaLVR5iv44welZgc2dM7xz9wDvfLCHOx/tzzw46J/JStsEeZZoqAcD58J50MAwmJmAlI0YmWMb0nCaNcOYUOcUboYySKynQ/FjjEdjWcdGbvHkpaU/fPbJ5V/8+OVFXD7fwvlZg+XZFFOJgy9HOOkOcXDcx9FpD72iwkm3xOkQODgD9nsVdg6HODge/9HB6eg/9ca+GBeOjqDxRg6IEYdOu8ywi6LE+kLj+j/7xPm3rj8xizz1cKULZy8TG4yKSpwMQA0CUFPaAGIcsQR1qCqgLCnhDw/rDZ3NNXQZh0UzT2BM2HGcnW7h/NwUTrol/uSvH+Drr901/bFDapMAYgIbDEpk5BE7U8ZEHDImHYxTXhP54LROjd1pKkGCJ0+VBxFD4hSEEgmIk+ewV3SLfxcxNrV7rgqAYAQ7A+89TJ6n9CLq8xixhnB0JkjcMeJxfOq5fZ4OmgFG6KKRJZxQXkTVv54Avv6M8F2jwpOvxq5FZBZ2tIz+mZOodeHzWAFjQu5rNBrgv3/5C/4XPncOd+7cwc7eGUqXoKgcRuMSo4LaCIO6j7I0fQDRxIR2PJbPu5FyuCoU0JJPBte3GCq2kXxhpc88PHX4we0T/P0Hx2bvpAJsAktnNcN6WLmuzkoeiY9Dg/qih06hBh6N1GBhNm+fn2/9zfpS+8babILzcxbzHYupVoo8zzE100a71cT0dAfT022YPMfRmcX97T7eurOLH9/ex527e795e+Pw1yuni9FoNJBnGZ+Bgfel5D14YSovvB/eeLq8l+SWpEiSMKeydBgXBaoygFaaAOsri2tXLp17cOXSAq4/sYin1jtYX8pgxwOM+130e10MhgOcnQ1xNhiiN/ToDQwOug6bxyPc3etje2/85YPT8W+f9IrQ0w2hCDnPM2SptpNmZ+OkgNnD+UrytmVZYqZh8OIzC/4zH1vGylwOT/WBHgae8oRSGmI8UnYyweQh3XMRDuOHQtRwmLoqqeQioZ1ra5GmBonxcugb3qCRGDxxYR4Pjzx+44/eeu2tu0f/pNNs0qW0qugxa+G8Uy3XzJhkwo1J5NXhuSswot/5ut3G9h1HWBISesUIbUwXIajYr48pmdg7n1WNU1ZgwGO8AEdcgMnyTP6FeaIXxiApWxmE58kBtYHHsTJ/kI+tKKuLe0jVgYjh3PCr6B9q5+owycp4pySO9KMnToCfvJHCUmssjHd46srSD9dmcOPxcxmurE1hdjpDYoJRjQqPUelpZ5F4HmGlMeHa+HA1vM7fg2pg+S49aBI/tC4J8kgSgyyx6A8dPtzu4/vvnh7fvNubH5Q+tCUGwKUEgSUYafooh7ahITuDWkjEh+RwWYV8jk0s5loJlufy3zg/n3/lwnIbS7MNrM5kmO0YNBsJkhRoNproTM9iZmEOzXYHZWWxvT/Au/cO8M7tPdy5fzC8u3nU2j0a0ExTNPIEjUbY1PCgI1iuCmFSuHIJnORm5S/KEkXB4SqwNN/B45dWBh+7utb82JNLeGJtGitLLeSZQ9U/Rf/0CCcnJzg57WM4KjAuHCpncNKrsHs2woODMbb3CmwdDF/dPRv9WX+oIae1BmmahEuTjQmHvdlBkh6z/jvnqauIF2NOEoNRUcEaj6trnd/65LX5L19bb2FmKvSNryojKQprgt2E+Uagoiodjv84KJB5Vn8TymoSiyShXvZJcJyDAtg7HuLedh93twa4uzfO97tFkaZWWRXb6IQtxrdQ8WAkBBM7CRFETGBCqkZ9NjMSqc2L7KlOKqK/yW8U1OLwNfyqTnqE9PEHaGzMVnge1hiYvJHXXqRxtHr2OGcVJhAjMmiwsdQ0nHsEpgQohZcB4KRcXXj8E45/qfdg1fOIWF4EViY6NcC5qvA1rXJhFgYAw+EIBsD52Xx2bbH5xtpy86nVhRxLMzlmp3LqqeRQlhXGhQM7vNBVx5CBGEriMvOgnJn3VLRrYOCQ2HBTeJpYDMYeDw7GePfuGW7e7z61e1TdcsYgSQ15TvZyYd5h9ypM2HIIBnYSqpReclG0Y+TDhkJZVbT1Hkoyppspzs83//TicuvV1aUmlmcM5loJstTDphZ5lmN+ZgoLC7OYnpuGsRnOeh6buwPc2TzAB/f3sfHwGPe2Tltbh6Mh4JGk4R7CNE2pV7uDNaE0ZTgays5kYi0eW1964plr67efu7aOp6+cw5OXZrE8Z+GHxzjZ28HBwQEOT7vo9YYoxg7DwuC053HQK7F7NMDO0Rg7B4OvHfaKXzsZVBgVhhxDyCcZMbYQRYRFt9QsUI81sabyLmwAMMAYx8ki2CQAxWhcYKGT4MmV9uDpy1PNx1abmJ9pIktCR9ZwRo9PkyCwZ1Di3oe2N447SVSO6puohgyhUDpLgsMejBwOzko8OBhhY2+Ah3uDV3dPyj/rjyvAJGhkCeSMYMRamBVZYsds08JsTIgJvNcoRW0PEYBQbSTv4gt5YByAfkdCRs1nm4moS07ImLhulEmLlkXxfHgDLO7uLPhE45Y6MB6I450ivqVDUYdYJZ1XjOE8YmHyY2LU1Q1zLatQQNLdSsHW2kII7DBY8eRJSRgeAIjweBW8eNr6+xkYDDEo78MFCkXpkRiHTtNgYSr/pXPzzd9fW2zg/HyG2U6CJjWjSyykhxhXOcdXl3kXjJcbkDFwOgecDko8PCxwZ2uIj7aGr+wcjf68dECepnAmVM7L3COQ4vOagf3ZiK57kZ6xdAcA5UU4t5nAwiaqGFXlUVTh5iY4h3bDYHk6/fy5+cbXzy/kcysLORbaFtNtgzw3aDWamGo3sTA3g8X5aUzPdACToDus8NFWF2/e2sN7dw9x+97hVz7cOP5q6YEkzWEMUBYhNJyb6+Da42tfevrxlT+5fm0FT19ewMWVNjotg2HvFKeHezjc38HZyQmGwwLF2KA/DhsOG3sD3N8Z4cH+8CsHp+Ovno0cxnwNXh6OCCXUKsYhDgc1Z8thOJ8XlUJZNkAXAE9zNF4aDYASntYYFEWBsnSYaydYX8q//viFqS9eWZ3C6kKOdtOEy5PJyMHtwWVcYS2dD10pwsUdgZENxhV6/Qqn/QKH3SIA9FHxpb1u8Y3+MOhWSuUYYWhObC9Ov2iemMN7rhEjZ84AQkYbm60aDdM6JUJMPjQSZDtjGRp42gjhv2neGxDjiO2TQSYCVbYWZ6SpdQ03RO/h42vVoAPxhhxWmAxTO97p44/qADUhyIPz0DgV3tNRDt4NjONmBiNlX8Z7uEAlwkLwjkiNhTENjcasXBpaoySpweid0btI2Ia8rCXAKcoSZengqwqt1GC2k1xbnE5/d34me2VuOsPcVIqpVoqZZoJ2K1w2GvIWAa4q5zEuHcYF0B8Bg2GJ494IeycFNvdH3354WHzhuOfgjUEjC72huKsmM6h6voGOZ1nONRhhY8GRap1eWGOnumVCEl5ux4YJbZNo7ZxzKIoSxXgMzrrPdxKcn2/81upi48uriw2szOdYmLaYblu0cotOu4lOq4OFuWksL08jy5s4HQCbu0P88NYeXr+5hR/d3l/s9cvDyxeWfviZF6/e+MT1dTy+NovFGcAUZ+gfH+HwcB/Hp8cYDsPlsa4ATocGW0cV7u2O8NHDHrb2ey9vHxffHUvFR7j+LM+4TY7YQ+3IGIBw2Fn0VNs0CzPwPtyLgABejHeeaa1RgwryDvJ3DigqB1eWyDOD5ens2sXl1vurSw0szWaYayeYaidoZjacwOA6qwoYVQ6jkUNv7HDcK3HYLXB0VuCkV7510i2/dtZ3f9yn3CtMgjS14oSdr1CVSihiAOPQbjJvJQxLbA2iO3wvJmfx43SQ7BYymJuILdGOuG64WX02D47aFClJIVfuqWQ1Ij3Bxh1iIBaWR6xRpiw4aCgHxvOM8ky8o8ZFjABTRXIsQrc8vLdyDId+A8VtGnQN/GRUUezrxSjrz+fvx8CpP3IJAreepfdzYa2MyUfJTCKutZIMzilZC2MTckAe4L5i4wJcFtBIgXYzxUw7/fxsO/3yVDt5pd20aGVWlK0sPfqFw+mgGnYH7o96/eobp/3xn3dHFYrKIE3CUR854iEdOrxMko2R10TYApUgxN4tBjA+D8jV7JZOHRgYOmcKcDJNdaOS7htlyamE8O52arA0n790Yan52uNrLawtZlidyzA7lSPLLIwDmu025uemsbw0g5nZGZz0K7z94Sn6Q4Nrl5dxeW0aRf8UDza3sH+wj96gi8R4uMpiOPI4HTjsnRS4u9XDnYf9tzb2hs/vd7XoFlSvl3Dvby7DYL3kPmZSwU/GXHHpR6zHsUdHBAC+ZrS1Y0xR/k70ksCsch7jcQn4oBvTLYupVvovZjrpf5lup6+0cm3QXTlgXHh0B+Vbp4Pqf5wMqj84G1QYFY4pNBIT+tinaQoYQzcPVXJ1oG586W58mDWnboIeGG5bw45Q7FUBRUEJAKKrDJkZsTMEJGyLO4PwZSy1i1XoFAwEBMmKJaILNu24zx5MLY0W58LoFxAYUmIYvicA5qPShbCEgq+m9jR9CWG2qoZR9K8VNBBtlJwEjyZCYPV0kWeM3hd7hFiRJBYG09x6iMqMy7PQJD4XuQqYGWMAm0D2xeGCbJwLCVcf6L7jrCu0zofOT+shZwcUzqP0nmwpVP6nmZXPyAAiCh6iDqEB0VlTvbknjFfZROxxDYJBMQMLtk0nD5g9CGtWb+dd6IXF3SYCjlJVlHMA9e9qWYNzc+nnL55rf/vi+Q6uXW5jfbGNNAkMoNFI0GnlWJhtoTPVQZI2MOwNsLO7h5NuH4XzSOgugc29ET7YHGD/aIyto8EbDw+Hn9490To0YxPe5AR8aFVuABgqQI7XzZsAEixZJ8YULL1yThj3hGZNpDRisPM1u4i+IWGZsVE4BoOyCi1uKmrnkxjq+MvjcgEO4gJWaTFtIP3AwuusHNVz3kHiT3BIyPPnp3sWFs1QzyTzOsvUIjsinyjfjT5Ef/cyP2VA4XdcqmGsFQdgRKZsJQIBwvqUhRl9L4+LdN4JrYY43xhxQgiZZfDRJAV6qGpcOxhECTwSUXifjSaqAzUCUDHiewGYGMX5c7WcmHO1Joj6d4JNhniQ8UZHKeR3UA/LRYUhMuUF0c+G/1JuhK9UpwdwLsWhPh9rDay3upjyHUbmEJ7w5bFAYHV6uDliruxdoEBMd6vVnIi+gyr7YwAzgOGTAAjf52NT2vyRwAsMYpDeZ94VCB0eqGEeKY6xBlmaILXAcFzSpSJA2wI//9l1/89/5jIWZzOMByOMhmP0uwNUxRicRzHOI00TNDot2DRBmll0uwW+9/YevvXG/sv3j8bfZRPM8gxpklB5QSUtnwNJpgP4zCYItDjPaa2NulR7ZVRsB470V3bC1FBDmiPejZ9w2hFDYAATBgeoPhmwkom+Kj/y8kgDyol5SEdiBkrLIS1HBcbQrmh0FA3syOh5xkjHYqYpNbyC2llMKCDapYjjwbIgkJa5G2J2RnWUpx7Fg0wW4jIK0dPouB+/3U+IW6MwJ/KOEEfnA0SFrPRCDhlZ4Gz8/GOjhQo2GnsofpKP/ikGEeV0Ahye7b0uWC4kDPU1Jiqf1e96RH3MdGeX/s6UNvIkUgAa5QjE+AnELOXFxAOTkJnGy3xJ0HThCQQk+bmOiTcgff51jMw2w3Poj3xQHQCo/Y2xoStFXEvMOQh5luHr5mjI3lGFtpc+UHoagMcYPF/lKbHsynCmj5ib84FzJTaBd06OrWQp8NQTy1+/8ezaFz9+eQ5PrnXQbjj0T0/QO+1hNCgAVyFJE1Qu7MxOtRIkiUNvMMZo5NBsNtCeaqNKcjw4LHF7o4t37x7j/XtHra2D/jAoWoLUajQQwptU5iBMwwOeuq5aE3EwzrP6kOKQ3mFg8AigKMdTYs01mlqI69p0w8TTu5TZw7JjnDBsOZhF8+B0gUeo1jcMrNxVxQpT0RIi1kXN77FN8for8zFRcp90n0+/GMgGXO2ANEckPhp7RBrCxh7nXhlY2dzVoYvzJbsxBnrfozgWIL5Oj/Nv4ghioKphBsRe4ujM5Hk42+cIwCZPgv+k0I0nHzmUehhj9N/FcHnC0EWWPBTUU5pgx6qIiMKy8CJRMKHPXoUWcj7KLvQrNB4uoJX5cfxtJEGuxXMQ2graoZLckMQ2PD7NwbFHru+AafDC7/tHAcx7UQz1bJqkBY3LwtB5TBq7MI1K6ph4U4KBrH7BRZBDRfPyVRlq1Ag4RoXu4q2em21+/Km1wed+6iKef2oBK4spfL+Lvd1D7O6eYjQcwXgHGIv+uMLW/hDbhwUGY4fl+QYurzSxMB2aPII2clqdJmamp5A1mzgbGny43cP3f7yHt9/f+/337x39Z+6UnKYpstTAw6qiRwf1YQOgJ5aZZqRTCEZU0a6sxjXqwLzIUxarrvvkOES+AmCslUYcDN89EOzMiL6zQQNRY8mJLgt8HwXhnvxz+Lgm6ONcsrUaAcEY6XasOm4FOJ2Vx0j1ey3npSiioZ2BdKiIhFIjAEHnjTxCowTI57z3Anz6VWY2NVFGeMO/VBJUk5cxfLFt1LpCvAzkqYaorLa30Bf6eOLCqQ0NXpUjdBuJdjRo0t5ozCseoOZZaCENtzvSLYI6m4F4R81XmEeFEYGuPiLMz1uqmY+/bwA+XAyq2OYCXW7T66OQkL15WHieK9UkiVHxeOL8xWQuRmXvotBA6XYEtoA2rKM6L1F0w5+zUYfOYOiM0txWB/B0lKeUtb7xzNp3PvncpZc//dwqrj42i3Za4Gh3H9sPd9Dr9lB6j8olGI4Ndo+G2NjrY3N/hO3D8ZeOutU3hpVHu2Fxfi7/nUvnWr9y+VwLFxabmJtOkFoPVA5JYtFsNbG0PIM8b2DnqMQP7xzizQ/28e6tvZWto9EOADSbOdIkDTVtxIbZI4QQMqFLS2jOhPR8CiCAewhJnRcNFH0XVgVE6wLy+AInqt+MAswaxEEz0JBZ0Od0GbkuS/WcnZIxRpoiRB9RmyQnrSwnHqhR3RPvzbwI2nTSafcIfhWbZchl8QUwmiODASJ/zEooOsrjmtRdNjaWeQxotR1HmTKnkSZ+7xmUTX3sDGAiW8qbIBKWpQfrdVrRrsZEs7r4WdIPTIx5YmIx6DOAGVWq2tYrfHSRQwwy8rbapMNHFSB0J4YXXlY66u8WXJMySQmCQ71U7UfzcLz3E4eQzPoEdASs9No4/m8U0WmrEC8PAedbHG0LC3u1RmQTjlIR0DtltA5ejrkYGzqTekqAW/6eBcqiQH8QyiiajQw3nrngX3rhIl5+8SJW51N0jw+w9XALh4dH8M6j3Wph7BJsHQ9x50EPdzb62Nwf3Njrlm+PxuHkQJqlSNLQpbUqS/iywkzLYnWh9Yeri41fvHi+hdXFJmaaCR1ZK9BILc6vLGBxcQaVSfDBxgn+/sd7+P47e7/7wcbJr5YOyLI8nFRwHmVVCiNIktDtlNcgyCTIQhpb0uIwIHheQQ94DvcMH5COjIVQLe5dxwAIZuiRo1VDUOfJHRoMIYa4YmrmGN6NGoBJBw9xphAd5txfDGEQHdc8U3wNXmw3PrJntiEmJCyX+nd0WlI5UDeJMB0mDuRoAzyo3QoY8zrxeFjlhc2RA46Oo7HlgPDH5HnKv6IFjpKPZHABjrUoTssTdJG8V6Cj10UIHDyUsC8DjY3JAIMwmQ5LwY+EiGLkjiZH0jI8jkhwYuyPgBovIksb0bxZYU0NYC08deulvBoATdBG85SfyKsIC4DmDQjALPWsVwDz9HsK7SJPwHNQyu/CBSnCwlQ5uOMHG6kjDyqMzya0uxeS8lVZoDcYwnuH5YUOPnnjkv/sx1bx4sdXsNAxONjaxv37mxiNh2g2Gmi2mjgbeNzd7uHmhyd4b+Ps1e3j4s+GdPbaJBZZYgNTooZ+hs9zunCaoSxCO5xO22JxtvFfLyxPfe3ySgcrszmmcw+LCknisbA4g4urc5iZamFzb4y/e3cP//eHD/HOnSNzNizB1ei6xobmRmGzyNULg65YXShH6bxHIgbDTEG7OuiaqvEYBHuQDSlAjuvA6+6a97EjE00lu4kcoKce8gwc/FDjo7yd6pjoYnTHJfQVyiCdl11Mfp6kO+j9k0wuIrVBt6X7BL9Hc1S1G77iHxGXif5FIzl+Htsl5zQdz0fmwo7ccT8EebzMM8/TCdbEQlJxx1u1cXudes2Ij8cajFdCSkQtholLRaAhT/DqreqLZQSVa2yRBsrji8Mzx0zf18da80RRqMwLKvVVLOTaCxl0RQ1p3AxW9pH38bDjd7A6CjsVZQp/s8SieD10x4vptQIWr6icM2TlcuE8JAMZDDXcSwKAlaXDeDQC4PD4+uJjn3nh0kcvPb+K69fmkJZDbD7YwYOtffiqwFQ7R95oYP+0xO3NHt756Ay3NrpP7ZyOb5UVABt6v7NsDKgKnKverSW2xweew8+4DLcBwTlMtRKsL7d/54nVqV+5ttbCymKOVsPC+Aqz022sryxgfr6DnaMx/u6dA/zFDx7grff2zHFvDMAgzzJkaaodhY2Rs/wBSAKoV9LOyWueMHJAMS+LAUy2tTyE7YY1rSA8iB1PBBq+pp+iCOqATcQ4ak7LgBvMxAn04OwNfZdZi4Z54OJs0gFWwMkwLdYt1dDwXu6kG2/YydzA8zAwkwyspucC9YAaEORIlxqP2hkosqCwP0QR9J4aSYjmE7pR1Hcbg0DrYRxq81Tmwzwozl356H3xOIVtANBQCoLuwjDICFToNn5SjXvVXvaPClL/OVYowVtPTElQ30SAoq8JYwlvl2ezx4o8OIN/YAKU+5CHPZqji3QqGIjVw8FBoeItVh99Tr/ISXrPY4pyYfCeEsTAqCjhXYU8T3H96srWSy+sr3z6uQu4dmUaZe8Ed+5uYHfvFMYYtJo5vEmwezjErY0zvHuvO7y7PWod9ip4AyraBVxV0e1PYTw2oYPyhtpUC6gg5DANr3kwtbKsQqFwVcJaYH2x+dJTl6dfe/7JeTx1oY1GnmA0GiFvZFien8HS4jSOBgZvvneIv3prEzff35/f3O0dAwZ5o4FmQ52ypwJnXzl4Ce6cpKEUTFS8eocDA4curCSiuYJdkusQphvsLqyDdqEAuC7I2FAao7eBMfCpLfGz+FQMELExG7Eq0Sm1sdoPO1ED6SsfO/xHLRkSZXnnpc6Ss4CA1mfVnkEIW8MMflaNFdUBzEdjlL+jbqvxc2SzjzyhybM0Mh4K43xYZBOFU3G8zFMRBgQQihIoSbjE7CT+d/67GqJhadTmMAmqqli1kG/yR0CR/6WeFOSxgukqewoSYoTDdU8Rz4eHG7+flcdAqHW8Q1QPJ9RJRION3hG8L8tfE7LhxdzBkiUT7yyG0CaaKwJAFMUYgMdUK8NPfWzd/9NPXcFLz6/i6kqCw/0jvP/RQ+wdnMFmCdI0wXAMPNwf4r37fby/cfa7m3vDX+2PqZV2aiUx7ioqLZEDw1aAlTupBjFRcj1S3AAsALj3unMYlxVcFSrwLyw2rt14fPb9F68t4cmLbWSZR+9sBG9SzM11cGFlAWOkuHnvDN/74TZ+cHPzK7fuH38VANqtJhqNHJULtzN5F/rIw4cD1Z6dgveQHd943cWJxr+OvDJQ/94jqmhET4RZsZ1yT6RIlzxtcUqkISDBOqUAhgm9EDWMddVDiqANjT1mhXLrNXtf48EX14pDZj0T+qcOm8GK5yrFIuLIJzbsaoOMdk5F3EYEFEcx/DlhqS76mwHXgbFRBbbDuxxGTERROt7xUw4DATD46FhL9DnxEHUiUQvzxCTN5LuUHLEEPY81EoLsiPLTaouscT9TcUQ0NwY4XexaBQrUTzEwx7Lh8QAh11BXfs9HXExcfzSp9/pvGjpqnzbx7j60auHHM9thxbbWhmZ845LCRI/F2RY+ef2y/8JPX8GnXziPhQ6w+3AbWw+2EcKwBFme4WxY4oPNM/z4o1N8sNF7+cFh+V0Hg2YzRcqHpQkEXBWqw1nG0jHTgjq2GupYG+TsOcT1kJ1cV3nIXQGhqlOcZlGFFjaXz7V+6RPXFn7/xtU5rC+34CvgtD8EYDHdauHc+gJmZ+awudvHd9/cxPd/tIl37+yZ7ghoNhtIszSUAjgnYXVFq6vOINbraEU4IiCjdDEzEyPWzi0RatVAg1lF0F1+Fzu66N1GtS3WA1Wkuh09AmRiG4G5a0s8ZVeCWWQvHrQetTSPFzYIIGKlAKRUw4c7LCNnGdUIaBTm6VJrr7vwrO3GWglZDRELGa+Jnin2UpdVLYREfIaJpaX/IotJNspPBHiijPbRcorcvQonXjxWHkZZr4/U99dQL0ZBXQD5ffRR8RyC8CBB/YTxiLdhMelCCjU3gDLH2Etw0EszkDlBFs3USiyM0HBrJudgRX4G0W6vsMnYIWgegjssJHTjzXA0RmKBJy7M/bcXnl37zZdffAw/fX0NnWSIzYebePBgB4NeCZNmSLIM1ia4v9PH6+/s483bJ2b3KLCgZjNHmpHHrLi/mcogZl/BLxjAcrsfyH2MLDuVE83bhzo00qJa2+CEQtRxWSG1HlcvTH3rE9fmX3nusRnMzTUwKjyG/TG8AabaLVy5soqlpVnsHPTxvTfv4zv/sIm3b+2bk6FDag0aWUq7kdotV1qcy/hZf+PwRXtjivZNGAE7v7ATyQYXuScJsSD6J87Rg0Ii0jXSFy/6xn9Tpw4T6QKPzEOSjPo3GaLoOCINU2f8/4uaFPRUE+mxnMdlQdU+wzvz8TvVsSvbhMqGflcjJrww8uDIlvMsFRQX1EX0hUgAAgL01BjxAV7keHosAAUGeDZ3z/hDjzRyxGdym9mYmP/wkk0Iw3h4X8+VyTv5ebSooUmFfDGMhY7HC0uKaa5RgFXhRvLh8ekjZYzx9WoyT5JH7Ln4XXo/AEQOzBS9rx+2jbfAefPBVRVamcPHry76Tz67js++cAmPXZxH4oa4e38Lu9t7qMoSeZYGj5sn6I0Mbn54itfe3P3KrQfdrwIWjUYW2gxF4+WQg7fpJ5mXgaR5YBBAVbCf2IcUGXNXEiDqv2XAZelckmItX4QR6tOmGgbPXZn1n3l2EZfWpsMt26VHURQw8Og0M6xfWsby4gx2D4f463/YwOvv7OD92wf5Ya8qUsrJVXKJDTllPlvExiKGMrHLLCTE16oI2MnxdWEsLgNEO/gTu3ZGP0u1EzBOwYK1w0Shar1OU51mLdKAginrY0xSWKcjJEEN7AicI8JVQ3fjY5qi+TQGfX18HQsEAB1vWsVnNWM9h+o6CVfZHM2JD1M1cq4D4wHw+I1MTJBTHsaVrA5x7ZPYmwgFwkLqyTh5ZA3rZMKGm3Ww9yMl8z6qfdLnR1KPHuoh29dEeWt4UHun+jETCTJ+hzGT8wogRnyBcjs6BmMg1FiFg5oxCNSKptBI6q+nr0cUXlyNMmZ2AMvT9lP/8eeefuPzn7uMpdkmjrtDfHh/GweHJ/DOo5E1wro5D5uk2O9X+N7NA7z25q7pDSrkeRb6aglbsORUaHzMuiIHImvu9fxqbefY8Doi0h0CCdoi93J+NMIRhHdbBkA4jIsKVVlifbHxqc/eOP/G808uYrqdwFVFOHJWljDGoZEmWF1dwPRsC/unQ9z84BR/8XcbePvWoSl9IuWLLE0Jn8R4AK7rYgXQ0ggyZEDq9njHzFPtHzNwANo+nHQ/OnhRD/+gMBL0NSoripwqvJcOG9xxQnUSWuHPpR1GlAtwUa4KzPd5jdQW+HkaAURga3SUvLg8F07rMIxqSVKUuyaRqm6QXPgqOni1HwJdUwv5vK5BliV1ZsHsgV5qEAlRHhD9L9NlVnL6cZzPAKNqvLOgSi/ehheVwY69McTHiDBruxETOYAa24s9BhnAo6FstLvBMCZehIUVPU7a3+hWcT3PxiBIakgeT/McKqPaxCOFiBnmT9yoYKhlYDVh168sx/jZF9f8r/+HF/FgdxdbuyeovEejEXpnFSVQFAWtc4aN/QJ/+YOtt9784Oh5A4tQE4jovXQuj+ZsojXi/3fROipz0XWPd8xq/cjA8mG3wd+NxaObLMz6QGxpNC6QZ8ALTy75zz53DldW20h8iTT1SFOL8bhEVTmMS4ep6RY60x1s7Q7xP7/53jfubA2+ZJKwU+ki9qJ00Yu9P7IOpLDqiHXQAd+1TEMNgtde68t0FxN1mYkBW303/48PkAOjffWC46KHMBZN6HOYlhEHFKcl+Fib5JwN6sl7EjuDioHRyCEWVaTKsd0Q/sjaxg6bPxeXWPFQWb8iv4naEpBkUon1I8NncCB1EZ3SThAKKPrACUWMfmo9tIWWq7mKfP3E2a7oh51IHMrEn+PDzLptrdmWIFzOuSkl4P+EtTe6CGxUtAA1gGVWFdFdlY/TVQqjCnKJc7zxEtSofAzCvvZOlUAdKKUVFPMVm2DvZLz99b94b2XQPUSWZshaDTSbDXQ6KfX7cqicxcZ+D3/9/Qdf+mhn8I3QZytB5SoCDVtjT3BK52MmCxhMNqeU3lH8eTlIrDqmecVYuJEDNJPr78E1ANxqqJGnKMoKb7y7bx7snV3/3PW1tz7+2DSmOh62dOgNCoxHFc66Q5TbZzA2hUlbSFN7ia+0E1CIDEzYTAyoNdbsoVEIW+ykUZJsoP8cX/YMF+sIz49+bYLeiBpNOnY4PZIkiBXVBQi41h2m6KjRQl35bfR5PSll5CMxeeH15zER0uk8QCAerWe8I641bDoHE4vjESDkaelELIycaTZZlkZGowBk4glEk2QDN9Fb4/wQDYm8fKSoE0DFA1RDgPyE3/nauOQ9k/GVyJABIXqIUZYyybR0OeJxqLfzIgP9TDwGL++AeraIZekzfU0ZPepzQvQcXfA4D1iXXY1xRgrFoGNNiYtLrd95Ym3qV8qiwtZh77X+yH2z08m+mCfmxtxU3hwWDu/cPTGHJwXSLIX1jnYIQWwukfFpTkXzpDxGROxFxmXooLOfWOf4M6ivqeCAOMRJMAgy8p6NiQHfUH/5Es0MeP7qor90PtzS0z0bIwHQbKVodnKMR8Ct+8ffvLcz+IXShUaBYS3obCSjArMNTKwxeIwK3qqAOn7dtKk7bGX0JoB6sMTwWe8p1xiA0Rgel9EGjTXAC+8XFsjDUJPVX9V03uv8DKDdT3xghDW5e51ZjU3+BLAmeahzi+6VjJndhK5ISE6Dtyx/o8zrkVmTgUreNQAYMw7d5YhDuVjptJhO2/JDDNXowvPMBEFAz3K1gcSyjRWhLuz66gUhmQnBKhvQuJuEZmhU3LXVoNaaRtmDF5bwiMYIY0BNWZjJhXHZWBQTXwyAo0WAKmeeo8DqI3PQz0+IovZsrlj2rkQrT5BYg/6gxLAMcnHOoZMlcHAYO6MHn31Fa82td+L8Gm25iJNiIOG51T1+3IKZk7UwURLbRIttEF3AoooQe2f+X66aB0LYE+5CNKKjzjkY59DOQ2twVwHNRoqpqca/T1J7/uR08Nsn3ZLuFfjJN/nwejk2umjN//E18Tp+2emWitFontD+XuKYfKROmk+VZ0xIQYHVTzhuHSNEjyLsJUAUp2xYpuH/a86Ehs33qNZzr3UH6j03cwzzj3U/ToPITyRjHpintaxltrlA+xFWG8mKDPn/AVBhmOstQnHqAAAAAElFTkSuQmCC';
  const html=`<!doctype html><html><head><meta charset="utf-8"><title>ForgeLab · Bilan ${esc(block.name||'Bloc')}</title><style>
  @page{size:A4;margin:10mm}*{box-sizing:border-box}body{margin:0;background:#070809;color:#f0f0ee;font-family:Arial,Helvetica,sans-serif;-webkit-print-color-adjust:exact;print-color-adjust:exact}.sheet{background:radial-gradient(circle at 50% 0,#242016 0,#111315 28%,#070809 72%);padding:22px;border:1px solid #7c6232;min-height:277mm}.cover{page-break-after:always}.brand{text-align:center;padding:8px 0 18px;border-bottom:1px solid #6e582f}.laurel{height:62px;display:flex;align-items:center;justify-content:center;margin:0 auto 5px}.laurel img{display:block;max-height:62px;max-width:118px;object-fit:contain;filter:drop-shadow(0 2px 7px rgba(0,0,0,.65))}.brand-name{font-size:25px;font-weight:900;letter-spacing:6px;color:#e4c47b}.motto{font-size:8px;color:#8e8778;letter-spacing:2px;margin-top:5px}.hero{padding:26px 0 18px}.hero small{color:#9b8a65;letter-spacing:2px}.hero h1{margin:5px 0;font-size:30px;text-transform:uppercase}.hero p{margin:0;color:#aaa}.date-pill{display:inline-block;margin-top:12px;border:1px solid #8d7039;padding:7px 11px;color:#e5c982;font-size:11px}.kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:10px 0 22px}.kpi{background:linear-gradient(145deg,#17191b,#0d0e0f);border:1px solid #443a27;padding:12px}.kpi b{display:block;color:#e4c47b;font-size:24px}.kpi span{font-size:8px;color:#999;text-transform:uppercase;letter-spacing:.8px}.section-title{margin:20px 0 10px;font-size:11px;letter-spacing:2px;color:#d8b86d;border-bottom:1px solid #4b402b;padding-bottom:7px}.muscle-bar{display:grid;grid-template-columns:125px 1fr 28px;gap:8px;align-items:center;margin:7px 0;font-size:9px}.muscle-bar>div{height:7px;background:#242424;border-radius:6px;overflow:hidden}.muscle-bar i{display:block;height:100%;background:linear-gradient(90deg,#8b6a2d,#e3c06b);border-radius:6px}.muscle-bar b{text-align:right;color:#e6ca86}.notes{white-space:pre-wrap;background:#111315;border-left:3px solid #b58e46;padding:12px;font-size:10px;line-height:1.5}.week-card{page-break-inside:avoid;margin:0 0 14px;padding:17px;background:linear-gradient(145deg,#151719,#0a0b0c);border:1px solid #5b4929;box-shadow:inset 0 0 0 1px #1f2020}.week-head{display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid #3d3526;padding-bottom:10px}.week-head small{font-size:7px;color:#8d816a;letter-spacing:1.5px}.week-head h2{display:inline-block;margin:2px 10px 0 0;color:#e4c47b;font-size:24px}.week-head span{font-size:9px;color:#aaa}.week-head em{font-style:normal;font-size:8px;text-transform:uppercase;padding:5px 8px;border:1px solid}.ok{color:#9fc59f}.warn{color:#e3bd6c}.high{color:#e58d78}.week-kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin:12px 0 7px}.week-kpis>div{background:#0c0d0e;padding:8px;border:1px solid #292823}.week-kpis b{display:block;font-size:16px;color:#e6c77e}.week-kpis span{font-size:7px;color:#8f8f8f}.week-progress{height:5px;background:#272727}.week-progress i{display:block;height:100%;background:linear-gradient(90deg,#8c6b2f,#e4c36f)}.status-row{display:flex;gap:12px;flex-wrap:wrap;margin:8px 0;font-size:8px}.trend{background:#0d0f10;border-left:2px solid #b38c46;padding:9px;margin:9px 0}.trend small{font-size:7px;color:#b49b69;letter-spacing:1px}.trend p{margin:4px 0 0;font-size:9px;line-height:1.4}.week-card details summary{font-size:8px;color:#a99670;margin:8px 0}.mini-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:4px}.mini-muscle{display:grid;grid-template-columns:1fr auto;gap:2px;background:#0b0c0d;border:1px solid #282724;padding:5px;font-size:7px}.mini-muscle b{color:#e5c57b}.mini-muscle small{grid-column:1/-1;color:#777}.mini-muscle.low{border-color:#5e4e2d}.mini-muscle.high{border-color:#633d34}.cardio-week{margin-top:10px;padding-top:8px;border-top:1px solid #343027;display:grid;grid-template-columns:80px 1fr;gap:3px;font-size:8px}.cardio-week strong{color:#d9b86d}.cardio-week small{grid-column:2;color:#8d8d8d}.footer{text-align:center;color:#b8924b;letter-spacing:3px;font-size:8px;margin-top:18px}@media print{body{background:#070809}.sheet{min-height:auto}}
  </style></head><body><main class="sheet cover"><header class="brand"><div class="laurel"><img src="${pdfLaurelUrl}" alt="Couronne de laurier ForgeLab"></div><div class="brand-name">FORGELAB</div><div class="motto">DISCIPLINA · CONSTANTIA · PROGRESSUS</div></header><section class="hero"><small>RAPPORT DE FIN DE BLOC</small><h1>${esc(block.name||'Bloc')}</h1><p>${esc(fp.name||'Programme ForgeLab')} · S${period.from}${period.to!==period.from?' à S'+period.to:''}</p><div class="date-pill">${period.label}</div></section><section class="kpis"><div class="kpi"><b>${muscleTotal}</b><span>Séries réalisées</span></div><div class="kpi"><b>${muscleSessions}</b><span>Séances muscu</span></div><div class="kpi"><b>${cardioCount}</b><span>Séances cardio</span></div><div class="kpi"><b>${weekData.length}</b><span>Semaines analysées</span></div></section><div class="section-title">VOLUME MUSCULAIRE · BLOC COMPLET</div>${muscleBars||'<p>Aucune série renseignée.</p>'}${notes?`<div class="section-title">NOTES DU BLOC</div><div class="notes">${esc(notes)}</div>`:''}<div class="footer">DAILY WINS.</div></main><main class="sheet"><div class="section-title">COMPTES RENDUS HEBDOMADAIRES · SOURCE : SUIVI</div>${weeklyCards}<div class="footer">FORGELAB · DAILY WINS.</div></main><script>const flPrint=()=>setTimeout(()=>{try{window.focus();window.print()}catch(e){}},350);if(document.readyState==='complete')flPrint();else{window.addEventListener('load',flPrint,{once:true});setTimeout(flPrint,1200)}<\/script></body></html>`;
  const w=window.open('','_blank');if(!w){alert('Autorise les fenêtres pop-up pour exporter le PDF.');return}w.document.write(html);w.document.close();
}
function exportProgramPdf(){const fp=flActiveProgram(),b=selectedFullBlock();if(fp&&b)return exportBlockPdf(b.id);alert('Aucun bloc actif à exporter.');}

function drawProgramming(){
  ensureDraftProgramCardio();
  const v=document.querySelector('#view'),p=programmingData(),totals=programTotals(p),presets=programmingPresets(),pc=programCardioData();
  const allSets=DAYS.reduce((a,d)=>a+(p[d]||[]).reduce((s,x)=>s+Number(x.sets||0),0),0);
  const daysUsed=DAYS.filter(d=>(p[d]||[]).some(x=>Number(x.sets||0)>0)).length;
  const rows=DAYS.map(day=>{
    const entries=p[day]||[],totalSets=entries.reduce((s,x)=>s+Number(x.sets||0),0),minutes=programDayMinutes(entries),durationClass=minutes>60?'over':minutes>50?'near':'';
    const items=entries.length?entries.map(x=>{
      const pr=programPriority(x.muscle_key),[mi,ma]=programRange(x.muscle_key),programmed=totals[x.muscle_key]?.sets||0,[label,klass]=programStatus(programmed,mi,ma);
      return `<div class="mobile-program-entry" data-id="${esc(x.id)}" data-muscle-name="${esc(x.muscle_name)}">
        <button type="button" class="mobile-program-drag" aria-label="Réordonner ${esc(x.muscle_name)}">⠿</button>
        <span class="mobile-program-badge ${pr.toLowerCase()}">${pr}</span>
        <div class="mobile-program-muscle"><strong>${esc(x.muscle_name)}</strong><small class="${klass}">${label}</small></div>
        <input class="mobile-program-sets" type="text" inputmode="numeric" pattern="[0-9]*" value="${Number(x.sets||0)}" data-program-sets aria-label="Séries ${esc(x.muscle_name)}">
        <button type="button" class="mobile-program-remove" data-program-remove aria-label="Retirer ${esc(x.muscle_name)}">×</button>
        <div class="program-exercises" data-program-exercises ${programOpenExerciseId()===x.id?'':'hidden'}>
          ${(()=>{const ex=x.exercises||[],used=ex.reduce((a,e)=>a+Number(e.sets||0),0),diff=Number(x.sets||0)-used,cl=diff===0?'ok':diff>0?'warn':'over';return `<div class="program-exercise-status ${cl}"><b>${used}/${Number(x.sets||0)} séries attribuées</b><span>${diff===0?'Complet':diff>0?diff+' à programmer':Math.abs(diff)+' en trop'}</span></div>${ex.length?`<div class="program-exercise-list">${ex.map(e=>`<article class="program-exercise-card" data-exercise-id="${esc(e.id)}"><div class="program-exercise-card-head"><strong title="${esc(e.name)}">${esc(e.name)}</strong><button type="button" data-ex-remove aria-label="Supprimer ${esc(e.name)}">×</button></div><div class="program-exercise-card-fields"><label><span>Séries</span><input data-ex-sets type="number" min="1" max="20" value="${Number(e.sets||1)}" aria-label="Séries"></label><label><span>Repos</span><select data-ex-rest aria-label="Repos">${[30,45,60,75,90,120,150,180,240].map(r=>`<option value="${r}" ${Number(e.rest||90)===r?'selected':''}>${r+' s'}</option>`).join('')}</select></label></div><input data-ex-name type="hidden" value="${esc(e.name)}"></article>`).join('')}</div>`:'<div class="program-exercise-empty">Aucun exercice programmé pour ce groupe.</div>'}<div class="program-exercise-add-shell"><button type="button" class="program-exercise-plus" data-ex-add-trigger aria-label="Ajouter un exercice">＋</button><div class="program-exercise-add" data-ex-add-panel hidden><label class="program-exercise-picker"><span>Exercice</span><select data-ex-new-name aria-label="Exercice"><option value="">Choisir dans la bibliothèque…</option>${exerciseOptionsFor(x.muscle_name).map(n=>`<option value="${esc(n)}">${esc(n)}</option>`).join('')}<option value="__custom__">＋ Nouvel exercice…</option></select></label><input data-ex-custom-name placeholder="Nom du nouvel exercice" hidden><div class="program-exercise-add-fields"><label><span>Séries</span><input data-ex-new-sets type="number" min="1" max="20" value="1" aria-label="Séries"></label><label><span>Repos</span><select data-ex-new-rest>${[60,90,120,150,180].map(r=>`<option value="${r}" ${r===90?'selected':''}>${r} s</option>`).join('')}</select></label></div><button type="button" data-ex-add>Ajouter</button></div></div>`})()}
        </div>
      </div>`;
    }).join(''):`<div class="mobile-program-empty">Aucun groupe programmé.</div>`;
    return `<article class="mobile-program-day" data-program-day="${day}">
      <header class="mobile-program-day-head">
        <button type="button" class="mobile-session-drag" aria-label="Déplacer la séance du ${day}">⠿</button>
        <div><strong>${({Lun:'Lundi',Mar:'Mardi',Mer:'Mercredi',Jeu:'Jeudi',Ven:'Vendredi',Sam:'Samedi',Dim:'Dimanche'})[day]}</strong><span>${totalSets} séries</span></div>
        <b class="mobile-program-duration ${durationClass}">≈ ${minutes} min</b>
      </header>
      <div class="mobile-program-list">${items}</div>
      <div class="mobile-program-add">
        <button type="button" data-program-add-trigger>＋ Ajouter un groupe</button>
        <div class="mobile-program-add-panel" hidden>
          <select data-program-muscle><option value="">Groupe musculaire</option>${programOptions()}</select>
          <select data-program-add-sets><option value="">Séries</option>${Array.from({length:20},(_,i)=>`<option value="${i+1}">${i+1}</option>`).join('')}</select>
          <button type="button" data-program-add-confirm disabled>Ajouter</button>
        </div>
      </div>
      <div class="program-cardio-day" data-program-cardio-day="${day}"><div class="program-cardio-head"><strong>♥ CARDIO</strong><button type="button" data-program-cardio-add>＋</button></div>${(pc[day]||[]).map(c=>`<div class="program-cardio-entry" data-cardio-id="${esc(c.id)}"><select data-cardio-quality>${CARDIO_QUALITIES.map(x=>`<option ${x===c.quality?'selected':''}>${esc(x)}</option>`).join('')}</select><select data-cardio-engine>${CARDIO_ENGINES.map(x=>`<option ${x===c.engine?'selected':''}>${esc(x)}</option>`).join('')}</select><select data-cardio-format>${CARDIO_FORMATS.map(x=>`<option ${x===c.format?'selected':''}>${esc(x)}</option>`).join('')}</select><label><input data-cardio-duration type="number" min="0" max="300" value="${Number(c.duration||0)}"><span>min</span></label><button type="button" data-program-cardio-remove>×</button></div>`).join('')||'<small class="program-cardio-empty">Aucune séance cardio programmée.</small>'}</div>
    </article>`;
  }).join('');
  const summary=activePriorities().map(m=>{const t=totals[m.muscle_key]||{sets:0,freq:0},mi=+m.target_min||0,ma=+m.target_max||0,[label,klass]=programStatus(t.sets,mi,ma);return `<div class="program-summary-row"><div><strong>${esc(m.muscle_name)}</strong><span>${m.priority} · cible ${mi}–${ma}</span></div><b>${t.sets}</b><em class="${klass}">${label}</em><i>${t.freq}×</i></div>`}).join('');
  const mode=programmingMode(),hasDraft=hasProgrammingDraft(),meta=programmingMeta(mode),phases=ensurePhaseProgramming(meta,mode),selectedPhase=selectedPhaseId(meta,mode);
  v.innerHTML=title('Programmation des séances')+
   `<section class="program-workspace program-workspace-clear program-mode-${mode}">
      <article class="program-status-card ${mode==='active'?'current':''}">
        <div><small>PROGRAMME ACTIF</small><strong>${esc(state.blockName||'Bloc actif')}</strong><span>${state.blockDuration} semaine${state.blockDuration>1?'s':''} · ${nutritionLabel()}</span></div>
        ${mode==='draft'?`<button type="button" class="secondary" data-program-mode="active">Voir</button>`:'<em>En cours</em>'}
      </article>
      <article class="program-status-card draft ${mode==='draft'?'current':''}">
        <div><small>PROCHAIN PROGRAMME</small><strong>${hasDraft?esc(programmingMeta('draft').name||'Brouillon en préparation'):'Aucun brouillon'}</strong><span>${hasDraft?'Modifiable sans toucher au programme actif':'Prépare ton prochain bloc séparément'}</span></div>
        ${hasDraft?(mode==='draft'?'<em>Ouvert</em>':'<button type="button" data-program-mode="draft">Ouvrir</button>'):'<button type="button" data-program-create-draft>Créer</button>'}
      </article>
      ${mode==='draft'?`<div class="program-draft-actions"><button type="button" data-program-activate-draft>Activer ce programme</button><button type="button" class="danger" data-program-delete-draft>Supprimer le brouillon</button></div>`:''}
      <div class="program-current-banner"><b>${mode==='draft'?'BROUILLON · EN PRÉPARATION':'PROGRAMME ACTIF · EN COURS'}</b><span>${esc(meta.name)} · ${meta.duration} semaines · ${meta.rhythm} + deload</span></div>
      ${mode==='draft'?`<div class="program-meta-edit"><label>Nom du bloc<input data-program-meta-name value="${esc(meta.name)}"></label><label>Durée<input data-program-meta-duration type="number" min="1" max="52" value="${meta.duration}"></label><label>Trame<select data-program-meta-rhythm>${[3,4,5,6].map(n=>`<option value="${n}" ${n===meta.rhythm?'selected':''}>${n} + deload</option>`).join('')}</select></label></div>`:''}
      <div class="program-export-actions"><button type="button" data-program-image>Générer le programme</button></div>
      <div class="program-phase-strip">${phases.map(q=>`<span data-program-phase="${phaseId(q)}" class="${q.deload?'deload ':''}${phaseId(q)===selectedPhase?'selected':''}">${q.label}<b>S${q.from}${q.to!==q.from?'–S'+q.to:''}</b></span>`).join('')}</div><div class="program-phase-toolbar"><small>Chaque phase possède maintenant sa propre programmation.</small>${phases.findIndex(q=>phaseId(q)===selectedPhase)>0?'<button type="button" class="secondary" data-copy-prev-phase>Copier la phase précédente</button>':''}</div>
      <p class="program-workspace-help">La durée du bloc et l'organisation du programme se gèrent ici. L'onglet Priorités reste consacré aux P0 / P1 / P2.</p>
    </section>`+
   `<section class="program-mobile-steps"><div class="active"><b>1</b><span>Répartition musculaire</span></div><div><b>2</b><span>Programmation des exercices</span></div></section>`+
   `<p class="program-mobile-intro">Répartis les séries hebdomadaires sur tes séances. ForgeLab affiche les totaux, la fréquence et une estimation simple de la durée.</p>`+
   `<div class="program-mobile-actions"><button type="button" data-program-auto>Répartir selon les priorités</button><button type="button" class="secondary" data-program-clear>Vider</button></div>`+
   `<section class="program-mobile-library"><div><small>BIBLIOTHÈQUE DE BLOCS</small><strong>Enregistrer puis réutiliser une structure</strong></div><button type="button" data-program-save-preset>Enregistrer</button>${presets.length?`<select data-program-preset><option value="">Choisir un bloc enregistré</option>${presets.map((x,i)=>`<option value="${i}">${esc(x.name)}</option>`).join('')}</select><div class="program-preset-actions"><button type="button" data-program-restore-preset>Réintégrer</button><button type="button" class="danger" data-program-delete-preset>Supprimer</button></div>`:'<p>Aucun bloc enregistré.</p>'}</section>`+
   `<section class="program-mobile-note">Répartition automatique : P0 sur lundi / mercredi / vendredi, P1 sur deux séances, P2 sur une séance. Les séries proposées utilisent la borne basse de la fourchette actuelle.</section>`+
   `<div class="program-mobile-kpis"><div><b>${allSets}</b><span>séries programmées</span></div><div><b>${daysUsed}</b><span>séances utilisées</span></div></div>`+
   `<div class="program-mobile-days">${rows}</div>`+
   `<details class="program-mobile-summary"><summary>Bilan de la programmation</summary><div>${summary}</div></details>`;

  v.querySelectorAll('[data-program-mode]').forEach(b=>b.onclick=()=>{if(b.dataset.programMode==='draft'&&!hasProgrammingDraft())return;setProgrammingMode(b.dataset.programMode)});
  v.querySelector('[data-program-create-draft]')?.addEventListener('click',()=>hasProgrammingDraft()?setProgrammingMode('draft'):createProgrammingDraft(true));
  v.querySelector('[data-program-activate-draft]')?.addEventListener('click',activateProgrammingDraft);
  v.querySelector('[data-program-delete-draft]')?.addEventListener('click',deleteProgrammingDraft);
v.querySelector('[data-program-image]')?.addEventListener('click',generateProgramImage);
  const saveMeta=()=>{const n=v.querySelector('[data-program-meta-name]'),d=v.querySelector('[data-program-meta-duration]'),r=v.querySelector('[data-program-meta-rhythm]');if(!n)return;saveProgrammingMeta({name:(n.value||'Nouveau bloc').trim()||'Nouveau bloc',duration:Math.max(1,Math.min(52,+d.value||14)),rhythm:Math.max(3,Math.min(6,+r.value||4))},'draft');drawProgramming()};
  v.querySelector('[data-program-meta-name]')?.addEventListener('change',saveMeta);v.querySelector('[data-program-meta-duration]')?.addEventListener('change',saveMeta);v.querySelector('[data-program-meta-rhythm]')?.addEventListener('change',saveMeta);
    v.querySelector('[data-program-auto]').onclick=()=>autoProgramming();
  v.querySelector('[data-program-clear]').onclick=()=>{if(confirm('Vider toute la programmation ?'))saveProgramming(blankProgramming())};
  v.querySelector('[data-program-save-preset]').onclick=()=>{const name=(prompt('Nom du bloc à enregistrer :','Bloc ForgeLab')||'').trim();if(!name)return;const list=programmingPresets();list.push({name,programming:p,createdAt:new Date().toISOString()});saveProgrammingPresets(list);drawProgramming()};
  const presetSelect=v.querySelector('[data-program-preset]');
  v.querySelector('[data-program-restore-preset]')?.addEventListener('click',()=>{const i=Number(presetSelect?.value);if(!Number.isInteger(i)||!programmingPresets()[i])return;saveProgramming(structuredClone(programmingPresets()[i].programming))});
  v.querySelector('[data-program-delete-preset]')?.addEventListener('click',()=>{const i=Number(presetSelect?.value),list=programmingPresets();if(!Number.isInteger(i)||!list[i])return;list.splice(i,1);saveProgrammingPresets(list);drawProgramming()});
  v.querySelectorAll('[data-program-phase]').forEach(el=>el.addEventListener('click',()=>setSelectedPhase(el.dataset.programPhase)));
  v.querySelector('[data-copy-prev-phase]')?.addEventListener('click',copyPreviousPhase);

  v.querySelectorAll('[data-program-cardio-day]').forEach(box=>{const day=box.dataset.programCardioDay;box.querySelector('[data-program-cardio-add]')?.addEventListener('click',()=>{const d=programCardioData();d[day].push({id:cardioModalityId(),quality:CARDIO_QUALITIES[0],engine:CARDIO_ENGINES[0],format:CARDIO_FORMATS[0],duration:40});saveProgramCardio(d)});box.querySelectorAll('[data-cardio-id]').forEach(row=>{const id=row.dataset.cardioId,save=()=>{const d=programCardioData(),c=d[day].find(x=>x.id===id);if(!c)return;c.quality=row.querySelector('[data-cardio-quality]').value;c.engine=row.querySelector('[data-cardio-engine]').value;c.format=row.querySelector('[data-cardio-format]').value;c.duration=Math.max(0,Number(row.querySelector('[data-cardio-duration]').value||0));saveProgramCardio(d,false)};row.querySelectorAll('select,input').forEach(el=>el.addEventListener('change',save));row.querySelector('[data-program-cardio-remove]').onclick=()=>{const d=programCardioData();d[day]=d[day].filter(x=>x.id!==id);saveProgramCardio(d)}})});

  v.querySelectorAll('.mobile-program-day').forEach(card=>{
    const day=card.dataset.programDay,list=card.querySelector('.mobile-program-list');
    card.querySelectorAll('.mobile-program-entry').forEach(row=>{
      const id=row.dataset.id,input=row.querySelector('[data-program-sets]');
      row.querySelector('.mobile-program-muscle')?.addEventListener('click',()=>{const box=row.querySelector('[data-program-exercises]');const opening=box.hidden;box.hidden=!opening;setProgramOpenExerciseId(opening?id:'')});
      const mutateExercises=(fn,redraw=true)=>{const d=programmingData(),item=d[day].find(z=>z.id===id);if(!item)return;item.exercises=Array.isArray(item.exercises)?item.exercises:[];fn(item.exercises);saveProgramming(d,redraw)};
      row.querySelectorAll('[data-exercise-id]').forEach(er=>{const eid=er.dataset.exerciseId;const saveEx=()=>mutateExercises(ex=>{const e=ex.find(a=>a.id===eid);if(e){e.name=er.querySelector('[data-ex-name]').value.trim();e.sets=Math.max(1,+er.querySelector('[data-ex-sets]').value||1);e.rest=Math.max(15,+er.querySelector('[data-ex-rest]').value||90)}});er.querySelector('[data-ex-name]').addEventListener('change',saveEx);er.querySelector('[data-ex-sets]').addEventListener('change',saveEx);er.querySelector('[data-ex-rest]').addEventListener('change',saveEx);er.querySelector('[data-ex-remove]').addEventListener('click',()=>mutateExercises(ex=>{const i=ex.findIndex(a=>a.id===eid);if(i>=0)ex.splice(i,1)}))});
      const addTrigger=row.querySelector('[data-ex-add-trigger]'),addPanel=row.querySelector('[data-ex-add-panel]');addTrigger?.addEventListener('click',()=>{if(addPanel){addPanel.hidden=!addPanel.hidden;addTrigger.classList.toggle('open',!addPanel.hidden);if(!addPanel.hidden)setTimeout(()=>row.querySelector('[data-ex-new-name]')?.focus(),0)}});const exPicker=row.querySelector('[data-ex-new-name]'),customName=row.querySelector('[data-ex-custom-name]');exPicker?.addEventListener('change',()=>{if(customName)customName.hidden=exPicker.value!=='__custom__'});row.querySelector('[data-ex-add]')?.addEventListener('click',()=>{let name=(exPicker?.value||'').trim();if(name==='__custom__')name=(customName?.value||'').trim();if(!name)return;const sets=Math.max(1,+row.querySelector('[data-ex-new-sets]').value||1),rest=Math.max(15,+row.querySelector('[data-ex-new-rest]').value||90);if(exPicker?.value==='__custom__')rememberExercise(row.dataset.muscleName||'',name);setProgramOpenExerciseId(id);mutateExercises(ex=>ex.push({id:newProgramId(),name,sets,rest}))});
      input.oninput=()=>{const n=Math.max(0,Math.min(30,parseInt((input.value||'').replace(/\D/g,''),10)||0));input.value=String(n);const d=programmingData(),item=d[day].find(x=>x.id===id);if(item)item.sets=n;saveProgramming(d,false)};
      input.onblur=()=>drawProgramming();
      row.querySelector('[data-program-remove]').onclick=()=>{const d=programmingData();d[day]=d[day].filter(x=>x.id!==id);saveProgramming(d)};
    });
    const trigger=card.querySelector('[data-program-add-trigger]'),panel=card.querySelector('.mobile-program-add-panel'),muscle=card.querySelector('[data-program-muscle]'),sets=card.querySelector('[data-program-add-sets]'),confirmBtn=card.querySelector('[data-program-add-confirm]');
    trigger.onclick=()=>{panel.hidden=!panel.hidden};
    const sync=()=>confirmBtn.disabled=!(muscle.value&&sets.value);muscle.onchange=sync;sets.onchange=sync;
    confirmBtn.onclick=()=>{if(!muscle.value||!sets.value)return;const d=programmingData(),pr=state.priorities.find(x=>x.muscle_key===muscle.value),existing=d[day].find(x=>x.muscle_key===muscle.value);if(existing)existing.sets+=Number(sets.value);else d[day].push({id:newProgramId(),muscle_key:muscle.value,muscle_name:pr?.muscle_name||muscle.value,sets:Number(sets.value)});saveProgramming(d)};
  });
  wireProgramRowReorder(v);
  wireSessionMove(v);
}
function wireProgramRowReorder(root){
  root.querySelectorAll('.mobile-program-day').forEach(card=>{
    const day=card.dataset.programDay,list=card.querySelector('.mobile-program-list');let active=null,pointerId=null,startY=0,timer=null;
    const finish=()=>{if(timer)clearTimeout(timer);timer=null;if(active){const d=programmingData(),ids=[...list.querySelectorAll('.mobile-program-entry')].map(x=>x.dataset.id),map=new Map(d[day].map(x=>[x.id,x]));d[day]=ids.map(id=>map.get(id)).filter(Boolean);saveProgramming(d,false);active.classList.remove('program-touch-dragging');active=null;drawProgramming()}pointerId=null};
    card.querySelectorAll('.mobile-program-entry').forEach(row=>{const h=row.querySelector('.mobile-program-drag');h.onpointerdown=e=>{e.preventDefault();pointerId=e.pointerId;startY=e.clientY;timer=setTimeout(()=>{active=row;row.classList.add('program-touch-dragging');try{h.setPointerCapture(pointerId)}catch(_){}},220)};h.onpointermove=e=>{if(e.pointerId!==pointerId)return;if(!active){if(Math.abs(e.clientY-startY)>12){clearTimeout(timer);timer=null}return}e.preventDefault();const siblings=[...list.querySelectorAll('.mobile-program-entry:not(.program-touch-dragging)')],next=siblings.find(el=>e.clientY<el.getBoundingClientRect().top+el.getBoundingClientRect().height/2);if(next)list.insertBefore(active,next);else list.appendChild(active)};h.onpointerup=finish;h.onpointercancel=finish});
  });
}
function wireSessionMove(root){
  let from=null,activeCard=null,pointerId=null,timer=null,startY=0,targetDay=null;
  const clearTargets=()=>root.querySelectorAll('.mobile-program-day').forEach(x=>x.classList.remove('session-drop-target','session-dragging'));
  const finish=()=>{if(timer)clearTimeout(timer);timer=null;if(from&&targetDay&&from!==targetDay){const d=programmingData(),a=d[from],b=d[targetDay];d[from]=b;d[targetDay]=a;saveProgramming(d,false)}clearTargets();from=null;targetDay=null;activeCard=null;pointerId=null;drawProgramming()};
  root.querySelectorAll('.mobile-program-day').forEach(card=>{const h=card.querySelector('.mobile-session-drag');h.onpointerdown=e=>{e.preventDefault();from=card.dataset.programDay;pointerId=e.pointerId;startY=e.clientY;timer=setTimeout(()=>{activeCard=card;card.classList.add('session-dragging');try{h.setPointerCapture(pointerId)}catch(_){}},260)};h.onpointermove=e=>{if(e.pointerId!==pointerId)return;if(!activeCard){if(Math.abs(e.clientY-startY)>13){clearTimeout(timer);timer=null}return}e.preventDefault();clearTargets();activeCard.classList.add('session-dragging');const hit=document.elementFromPoint(e.clientX,e.clientY)?.closest('.mobile-program-day');if(hit&&hit!==activeCard){hit.classList.add('session-drop-target');targetDay=hit.dataset.programDay}else targetDay=null};h.onpointerup=finish;h.onpointercancel=finish});
}

function currentWeekdayIndex(){const d=new Date().getDay();return d===0?7:d}
function drawSeries(){
  let v=document.querySelector('#view');
  const seriesPriorities=[...activePriorities()].sort((a,b)=>({P0:0,P1:1,P2:2}[a.priority]??9)-({P0:0,P1:1,P2:2}[b.priority]??9));
  v.innerHTML=title('Séries / semaine')+seriesPriorities.map(p=>{
    let map=Object.fromEntries(rows(p.muscle_key).map(x=>[+x.day,+x.series]));
    return`<article class="card ${p.priority.toLowerCase()} muscle-order-card" data-card="${esc(p.muscle_key)}" data-muscle-order="${esc(p.muscle_key)}">
      <div class="cardhead"><div><div class="muscle">${esc(p.muscle_name)}</div><div class="range">Cible ${p.target_min}–${p.target_max}</div></div><span class="badge">${p.priority}</span></div>
      <div class="days">${DAYS.map((d,i)=>`<div class="day ${i+1===currentWeekdayIndex()?'is-today':''}"><label>${d}</label><input class="series-input" type="text" inputmode="numeric" pattern="[0-9]*" enterkeyhint="done" value="${map[i+1]||0}" data-m="${esc(p.muscle_key)}" data-d="${i+1}" aria-label="${d} ${esc(p.muscle_name)}"></div>`).join('')}</div>
      <div class="totalrow"><span>Total semaine</span><b data-total="${esc(p.muscle_key)}">${total(p.muscle_key)} séries</b></div>
    </article>`
  }).join('')+cardioSeriesHtml();

  wireSeriesInputs(v);
  wireCardioSeries(v);
  wireMuscleReorder(v);
}

let editingSeries = new Set();

function seriesEditKey(el){
  return `${state.week}|${el.dataset.m}|${el.dataset.d}`;
}

function wireSeriesInputs(v){
  v.querySelectorAll('.series-input').forEach(i=>{
    i.dataset.lastValid = i.value || '0';

    i.addEventListener('focus',()=>{
      editingSeries.add(seriesEditKey(i));
      i.dataset.lastValid = i.value || '0';
      // Select the current value for fast replacement, but do not modify it.
      try{i.select()}catch(_){}
    });

    i.addEventListener('input',()=>{
      const raw=(i.value||'').replace(/[^0-9]/g,'');

      // Safari/iOS may transiently emit an empty string during replacement.
      // Ignore it completely: no local update and no cloud request.
      if(raw==='') return;

      const n=Math.max(0,Math.min(99,parseInt(raw,10)||0));
      i.dataset.lastValid=String(n);

      // Optimistic UI/state: instant.
      updateSeriesLocal(i.dataset.m,+i.dataset.d,n);

      // Cloud is background-only and serialized per cell.
      queueSeriesSave(i.dataset.m,+i.dataset.d,n);
    });

    i.addEventListener('blur',()=>{
      const key=seriesEditKey(i);

      // If the field visually ended empty, restore the last actual value.
      if((i.value||'')==='') i.value=i.dataset.lastValid || '0';

      setTimeout(()=>editingSeries.delete(key),250);
    });
  });
}

function renderAfterCloudLoad(){
  if(state.view==='series' && editingSeries.size>0) return;
  if(typeof render==='function') render();
}

function updateSeriesLocal(m,d,n){
  let r=state.series.find(x=>+x.week===+state.week&&x.muscle_key===m&&+x.day===+d);
  const before=+(r?.series||0);
  if(r){
    r.series=n;
    if(before<=0 && n>0)r.journalEnteredAt=Date.now();
  }else{
    r={block_key:'main',week:state.week,muscle_key:m,day:d,series:n,journalEnteredAt:n>0?Date.now():0};
    state.series.push(r);
  }
  const totalEl=document.querySelector(`[data-total="${CSS.escape(m)}"]`);
  if(totalEl) totalEl.textContent=total(m)+' séries';
  syncJournalDraftFromSeries(state.week,d);
}
function seriesPendingKey(){return `forgelabSeriesPending:${currentUser?.id||'guest'}`}
function saveSeriesPending(){
  try{
    const pending=Object.entries(saveState).filter(([,s])=>s&&s.wanted!==s.lastSent).map(([k,s])=>({k,week:s.week,m:s.m,d:s.d,wanted:s.wanted}));
    localStorage.setItem(seriesPendingKey(),JSON.stringify(pending));
  }catch(_){}
}
function restoreSeriesPending(){
  try{
    const pending=JSON.parse(localStorage.getItem(seriesPendingKey())||'[]');
    pending.forEach(x=>{
      if(!x?.k||!x.week||!x.m||!x.d)return;
      saveState[x.k]={week:+x.week,m:x.m,d:+x.d,wanted:+x.wanted||0,sending:false,lastSent:null};
      flushSeriesSave(x.k);
    });
  }catch(_){}
}
function queueSeriesSave(m,d,n){
  const week=+state.week;
  const k=`${week}|${m}|${d}`;
  if(!saveState[k]) saveState[k]={week,m,d,wanted:n,sending:false,lastSent:null};
  Object.assign(saveState[k],{week,m,d,wanted:n});

  clearTimeout(saveTimers[k]);
  saveSeriesPending();
  cloud('ENREGISTREMENT…');

  // Tiny debounce only to coalesce very fast keystrokes.
  saveTimers[k]=setTimeout(()=>flushSeriesSave(k),180);
}

async function flushSeriesSave(k){
  const slot=saveState[k];
  if(!slot || slot.sending) return;

  const {week,m,d}=slot;
  const n=Math.max(0,Math.round(slot.wanted||0));
  slot.sending=true;
  slot.lastSent=n;
  saveSeriesPending();

  try{
    const path=`/forgelab_series?user_id=eq.${encodeURIComponent(uid())}&block_key=eq.main&week=eq.${week}&muscle_key=eq.${encodeURIComponent(m)}&day=eq.${d}`;

    if(n===0){
      await req(path,{method:'DELETE',headers:{Prefer:'return=minimal'}});
    }else{
      await req('/forgelab_series?on_conflict=user_id,block_key,week,muscle_key,day',{
        method:'POST',
        headers:{Prefer:'resolution=merge-duplicates,return=minimal'},
        body:JSON.stringify([{
          user_id:uid(),
          block_key:'main',
          week,
          muscle_key:m,
          day:d,
          series:n,
          updated_at:new Date().toISOString()
        }])
      });
    }

    slot.sending=false;
    if(slot.wanted!==slot.lastSent){
      saveSeriesPending();
      flushSeriesSave(k);
    }else{
      delete saveState[k];
      clearTimeout(saveTimers[k]);
      saveSeriesPending();
      cloud('SYNCHRONISÉ','ok');
    }
  }catch(e){
    console.error(e);
    slot.sending=false;
    saveSeriesPending();
    cloud('HORS LIGNE','err');
    clearTimeout(saveTimers[k]);
    saveTimers[k]=setTimeout(()=>flushSeriesSave(k),1200);
  }
}
function weeklyTodoRecap(){
  const active=activePriorities();
  const notStarted=active.filter(p=>total(p.muscle_key)===0);
  const partial=active.filter(p=>{
    const t=total(p.muscle_key);
    return t>0 && t<(+p.target_min||0);
  });
  const completed=active.filter(p=>total(p.muscle_key)>=(+p.target_min||0)).length;
  const c=cardioData(),cardioOn=!!c.enabled,cardioDone=cardioOn?cardioTotalDone():0,cardioTarget=cardioOn?trackingCardioProgramTarget():0;
  const cardioLeft=Math.max(0,cardioTarget-cardioDone);

  const todo=[
    ...notStarted.map(p=>`<div class="weekly-action ${p.priority.toLowerCase()}"><span class="weekly-action-dot"></span><div><b>${esc(p.muscle_name)}</b><small>À commencer · cible ${p.target_min}–${p.target_max} séries</small></div><strong>${p.target_min}</strong></div>`),
    ...partial.map(p=>{
      const t=total(p.muscle_key),left=Math.max(0,(+p.target_min||0)-t);
      return `<div class="weekly-action ${p.priority.toLowerCase()}"><span class="weekly-action-dot"></span><div><b>${esc(p.muscle_name)}</b><small>${t} réalisées · cible ${p.target_min}–${p.target_max}</small></div><strong>+${left}</strong></div>`;
    }),
    ...(cardioOn&&cardioLeft>0?[`<div class="weekly-action cardio"><span class="weekly-action-dot"></span><div><b>Cardio</b><small>${cardioDone} réalisée${cardioDone>1?'s':''} · objectif ${cardioTarget}</small></div><strong>+${cardioLeft}</strong></div>`]:[])
  ];

  return `<section class="weekly-dashboard">
    <div class="weekly-dashboard-top">
      <div><small>BILAN · SEMAINE ${state.week}</small><h3>Suivi hebdomadaire</h3><p>${todo.length?'Encore quelques objectifs à compléter.':'Objectifs de la semaine atteints.'}</p></div>
      <div class="weekly-score"><b>${completed}</b><span>/ ${active.length}</span><small>GROUPES OK</small></div>
    </div>
    ${cardioOn?`<div class="weekly-cardio-mini"><div><span>◆</span><div><b>Cardio</b><small>${c.modalities.length} modalité${c.modalities.length>1?'s':''}</small></div></div><strong>${cardioDone} / ${cardioTarget}</strong></div>`:''}
    <div class="weekly-actions-head"><span>À faire</span><b>${todo.length}</b></div>
    <div class="weekly-actions">${todo.join('')||`<div class="weekly-complete"><b>SEMAINE VALIDÉE</b><span>Minimums musculaires${cardioOn?' et cardio':''} atteints.</span></div>`}</div>
  </section>`;
}

function cardioTrackingHtml(){
  const d=cardioData();if(!d.enabled)return'';
  const target=trackingCardioProgramTarget(),done=cardioTotalDone(),left=Math.max(0,target-done);
  const pct=target?Math.min(100,Math.round(done/target*100)):100;
  const status=done<target?['À compléter','low']:done===target?['Objectif atteint','ok']:['Objectif dépassé','ok'];
  const sessions=cardioBaseRunSessions();
  const benchmark=sessions.find(s=>s.benchmark)||sessions[0];
  const latest=sessions.at(-1);
  const chain=sessions.slice(-5).map(s=>`<span class="${benchmark&&cardioComparable(s,benchmark)?'comparable':''}">${esc(s.pace)}/km${s.distanceKm?` · ${Number(s.distanceKm).toFixed(2)} km`:''}</span>`).join('<i>→</i>');
  const delta=benchmark&&latest&&paceToSeconds(benchmark.pace)&&paceToSeconds(latest.pace)?paceToSeconds(latest.pace)-paceToSeconds(benchmark.pace):0;
  const deltaTxt=latest&&benchmark&&latest.id!==benchmark.id?(delta<0?`${Math.abs(delta)} s/km plus vite`:delta>0?`${delta} s/km plus lent`:'allure identique'):'Référence initiale';
  return `<section class="card cardio-tracking-card ${d.priority.toLowerCase()}">
    <div class="cardio-track-head">
      <div><small>CARDIO</small><div class="muscle">Qualité · Engine · Format</div><div class="range">Objectif issu de la programmation · ${target}/sem.</div></div>
      <span class="status ${status[1]}">${status[0]}</span>
    </div>
    <div class="cardio-track-score"><div><b>${done}</b><span>/ ${target}</span><small>séances réalisées</small></div><strong>${pct}%</strong></div>
    <div class="progress ${done>=target?'target':'under'}"><i style="width:${pct}%"></i></div>
    <div class="cardio-quality-list">${d.modalities.map(m=>`<div><span>${esc(m.quality)}</span><b>${esc(m.engine)} · ${esc(m.format)}</b></div>`).join('')}</div>
    <section class="base-run-tracking">
      <div class="base-run-track-head"><div><small>🟢 BASE AÉROBIE</small><strong>Run</strong></div><span>${sessions.length} point${sessions.length>1?'s':''}</span></div>
      ${benchmark?`<div class="base-run-benchmark"><small>RÉFÉRENCE · ${jDate(benchmark.date)}</small><b>${benchmark.duration} min · ${benchmark.distanceKm?Number(benchmark.distanceKm).toFixed(2)+' km · ':''}${esc(benchmark.pace)}/km · ${benchmark.avgHr} bpm · RPE ${benchmark.rpe}</b></div>`:''}
      <div class="base-run-chain">${chain||'<span>Aucune séance</span>'}</div>
      ${latest?`<div class="base-run-latest"><span>Dernière : <b>${esc(latest.pace)}/km</b>${latest.distanceKm?' · '+Number(latest.distanceKm).toFixed(2)+' km':''} · ${latest.avgHr} bpm · RPE ${latest.rpe}</span><strong>${deltaTxt}</strong></div>`:''}
      <p>Comparer l’allure uniquement quand FC et RPE restent proches de la référence.</p>
    </section>
    <div class="trackline"><span>${left?`${left} séance${left>1?'s':''} restante${left>1?'s':''}`:'Objectif cardio atteint'}</span><strong>${done} réalisée${done>1?'s':''}</strong></div>
  </section>`;
}

function flAnalysisHistoryKey(){return `forgelabProgramAnalysisHistory:${currentUser?.id||'guest'}`}
function flAnalysisHistoryLoad(){try{return JSON.parse(localStorage.getItem(flAnalysisHistoryKey())||'[]').filter(x=>x&&x.id)}catch(_){return[]}}
function flAnalysisHistorySave(x){localStorage.setItem(flAnalysisHistoryKey(),JSON.stringify(Array.isArray(x)?x:[]))}
function flAnalysisProgramId(fp){return `${String(fp?.startDate||'sans-date')}|${jNormName(fp?.name||'Programme ForgeLab')}`}
function flAnalysisSnapshot(fp,current=false){
  if(!fp||!Array.isArray(fp.blocks))return null;
  const maxTo=Math.max(1,...fp.blocks.map(b=>+b.to||+b.from||1));
  return {id:flAnalysisProgramId(fp),name:fp.name||'Programme ForgeLab',startDate:fp.startDate||'',totalDuration:+fp.totalDuration||maxTo,blocks:fp.blocks.map((b,i)=>({id:b.id||`bloc-${i+1}`,name:flActiveBlockDisplayName(b,i),from:+b.from||1,to:+b.to||+b.from||1,deload:!!b.deload})),current:!!current,savedAt:new Date().toISOString()};
}
function flAnalysisArchiveActiveProgram(){
  const fp=flActiveProgram(),snap=flAnalysisSnapshot(fp,false);if(!snap||!snap.startDate)return;
  const all=flAnalysisHistoryLoad(),i=all.findIndex(x=>x.id===snap.id);if(i>=0)all[i]={...all[i],...snap};else all.push(snap);flAnalysisHistorySave(all);
}
function flAnalysisPrograms(){
  const history=flAnalysisHistoryLoad(),cur=flAnalysisSnapshot(flActiveProgram(),true),all=[...history];
  if(cur?.startDate){const i=all.findIndex(x=>x.id===cur.id);if(i>=0)all[i]={...all[i],...cur,current:true};else all.push(cur)}
  return all.sort((a,b)=>String(a.startDate||'').localeCompare(String(b.startDate||'')));
}
function flDateAdd(dateStr,days){if(!/^\d{4}-\d{2}-\d{2}$/.test(String(dateStr||'')))return '';const [y,m,d]=dateStr.split('-').map(Number),x=new Date(y,m-1,d,12);x.setDate(x.getDate()+days);return `${x.getFullYear()}-${String(x.getMonth()+1).padStart(2,'0')}-${String(x.getDate()).padStart(2,'0')}`}
function flAnalysisProgramBounds(p){const dur=Math.max(1,+p?.totalDuration||Math.max(1,...(p?.blocks||[]).map(b=>+b.to||1)));return {from:p?.startDate||'',to:p?.startDate?flDateAdd(p.startDate,dur*7-1):''}}
function flAnalysisBlockBounds(p,b){return {from:p?.startDate?flDateAdd(p.startDate,(Math.max(1,+b?.from||1)-1)*7):'',to:p?.startDate?flDateAdd(p.startDate,Math.max(1,+b?.to||+b?.from||1)*7-1):''}}
function flJournalContextForDate(date){
  const matches=flAnalysisPrograms().map(p=>({p,bounds:flAnalysisProgramBounds(p)})).filter(x=>x.bounds.from&&date>=x.bounds.from&&date<=x.bounds.to).sort((a,b)=>String(b.bounds.from).localeCompare(String(a.bounds.from)));
  const hit=matches[0];if(!hit)return null;const p=hit.p,days=Math.floor((new Date(date+'T12:00:00')-new Date(p.startDate+'T12:00:00'))/86400000),week=Math.floor(days/7)+1,b=(p.blocks||[]).find(x=>week>=+x.from&&week<=+x.to)||null;
  return {programId:p.id,programName:p.name,programStartDate:p.startDate,blockId:b?.id||'',blockName:b?.name||'',week};
}

let trackingAnalysisState={from:'',to:'',muscle:'',scopes:[]};
function trackingScopeCatalog(){
  const out=[];flAnalysisPrograms().forEach(p=>{const pb=flAnalysisProgramBounds(p);out.push({id:`program:${p.id}`,type:'program',label:p.name,sub:p.current?'Programme actif':'Programme archivé',from:pb.from,to:pb.to,programId:p.id});(p.blocks||[]).forEach(b=>{const bb=flAnalysisBlockBounds(p,b);out.push({id:`block:${p.id}:${b.id}`,type:'block',label:`${p.name} · ${b.name}`,sub:`${b.from===b.to?'S'+b.from:`S${b.from}–S${b.to}`}`,from:bb.from,to:bb.to,programId:p.id,blockId:b.id})})});return out;
}
function trackingAnalysisDateBounds(){
  const dates=[...jLoad().map(x=>x.date),...(cardioData().sessions||[]).map(x=>x.date)].filter(x=>/^\d{4}-\d{2}-\d{2}$/.test(String(x||''))).sort();
  const fp=flActiveProgram(),pb=flAnalysisProgramBounds(fp||{});return {from:dates[0]||pb.from||jToday(),to:dates.at(-1)||pb.to||jToday()};
}
function trackingAnalysisMuscles(){return [...new Set(jLoad().flatMap(s=>(s.exercises||[]).map(e=>e.muscle||e.muscleKey||'').filter(Boolean)))].sort((a,b)=>a.localeCompare(b,'fr'))}
function trackingAnalysisMuscuRows(){return jLoad().map(s=>({id:`m:${s.id}`,kind:'muscu',date:s.date||'',duration:+s.duration||0,session:s}))}
function trackingAnalysisCardioRows(){
  const d=cardioData(),detailed=(d.sessions||[]).filter(x=>x.date).map(x=>({id:`c:${x.id||x.date+Math.random()}`,kind:'cardio',date:x.date,duration:+x.duration||0,session:x}));
  const counters=[];Object.entries(d.weeks||{}).forEach(([wk,mods])=>Object.values(mods||{}).forEach(days=>Object.entries(days||{}).forEach(([day,n])=>{for(let i=0;i<(+n||0);i++)counters.push({id:`cw:${wk}:${day}:${i}:${counters.length}`,kind:'cardio',date:jCalendarDateForDay(+day,+wk),duration:0,session:{}})})));
  if(!counters.length)return detailed;
  // Les séances détaillées servent au temps, les compteurs au nombre de séances : rattache la durée à une séance du même jour sans doubler le compte.
  const byDate=new Map();detailed.forEach(x=>{if(!byDate.has(x.date))byDate.set(x.date,[]);byDate.get(x.date).push(x)});
  counters.forEach(x=>{const q=byDate.get(x.date);if(q?.length){const det=q.shift();x.duration=det.duration;x.session=det.session}});
  const unmatched=[...byDate.values()].flat();return [...counters,...unmatched];
}
function trackingSessionHasMuscle(row,muscle){if(!muscle)return true;if(row.kind!=='muscu')return false;return (row.session.exercises||[]).some(e=>(e.muscle||e.muscleKey||'')===muscle)}
function trackingMetrics(rows,muscle=''){
  const filtered=rows.filter(r=>trackingSessionHasMuscle(r,muscle));let sets=0,tonnage=0;const muscles=new Map();
  filtered.filter(r=>r.kind==='muscu').forEach(r=>(r.session.exercises||[]).forEach(e=>{const m=e.muscle||e.muscleKey||'Autre';if(muscle&&m!==muscle)return;const es=(e.sets||[]).filter(x=>(+x.kg||0)||(+x.reps||0)).length,et=jExerciseTon(e);sets+=es;tonnage+=et;const z=muscles.get(m)||{sets:0,tonnage:0,sessions:new Set()};z.sets+=es;z.tonnage+=et;z.sessions.add(r.id);muscles.set(m,z)}));
  const duration=filtered.reduce((n,r)=>n+(+r.duration||0),0),muscu=filtered.filter(r=>r.kind==='muscu').length,cardio=filtered.filter(r=>r.kind==='cardio').length;
  return {sessions:filtered.length,muscu,cardio,duration,sets,tonnage,muscles:[...muscles.entries()].map(([name,z])=>({name,sets:z.sets,tonnage:z.tonnage,sessions:z.sessions.size})).sort((a,b)=>b.sets-a.sets||a.name.localeCompare(b.name,'fr'))};
}
function trackingFormatMinutes(n){n=Math.max(0,Math.round(+n||0));return `${Math.floor(n/60)} h ${String(n%60).padStart(2,'0')}`}
function trackingAnalysisGroups(){
  const bounds=trackingAnalysisDateBounds();if(!trackingAnalysisState.from)trackingAnalysisState.from=bounds.from;if(!trackingAnalysisState.to)trackingAnalysisState.to=bounds.to;
  const all=[...trackingAnalysisMuscuRows(),...trackingAnalysisCardioRows()],catalog=trackingScopeCatalog(),selected=trackingAnalysisState.scopes.map(id=>catalog.find(x=>x.id===id)).filter(Boolean),scopes=selected.length?selected:[{id:'period',type:'period',label:'Période sélectionnée',sub:'Toutes les données',from:trackingAnalysisState.from,to:trackingAnalysisState.to}];
  return scopes.map(sc=>{const from=[trackingAnalysisState.from,sc.from].filter(Boolean).sort().at(-1)||'',to=[trackingAnalysisState.to,sc.to].filter(Boolean).sort()[0]||'';const rows=all.filter(r=>(!from||r.date>=from)&&(!to||r.date<=to));return {...sc,from,to,metrics:trackingMetrics(rows,trackingAnalysisState.muscle)}});
}
function trackingAnalysisResultsHtml(){
  const groups=trackingAnalysisGroups(),base=groups[0]?.metrics;
  const cards=groups.map((g,i)=>{const m=g.metrics,ds=i&&base?m.sessions-base.sessions:0,dt=i&&base?m.duration-base.duration:0;return `<article class="tracking-analysis-card"><div><small>${esc(g.sub||'')}</small><strong>${esc(g.label)}</strong><span>${g.from&&g.to?`${jDate(g.from)} → ${jDate(g.to)}`:'Toutes dates'}</span></div><div class="tracking-analysis-kpis"><b>${m.sessions}<span>séances${i?` · ${ds>0?'+':''}${ds}`:''}</span></b><b>${trackingFormatMinutes(m.duration)}<span>temps${i?` · ${dt>0?'+':''}${dt} min`:''}</span></b><b>${m.sets}<span>séries</span></b></div><small class="tracking-analysis-split">${m.muscu} muscu · ${m.cardio} cardio${trackingAnalysisState.muscle?` · filtre ${esc(trackingAnalysisState.muscle)}`:''}</small></article>`}).join('');
  const muscles=[...new Set(groups.flatMap(g=>g.metrics.muscles.map(x=>x.name)))].sort((a,b)=>groups.reduce((n,g)=>n+(g.metrics.muscles.find(x=>x.name===b)?.sets||0)-(g.metrics.muscles.find(x=>x.name===a)?.sets||0),0));
  const table=muscles.length?`<div class="tracking-muscle-compare"><table><thead><tr><th>Groupe musculaire</th>${groups.map(g=>`<th>${esc(g.label)}</th>`).join('')}</tr></thead><tbody>${muscles.map(m=>`<tr><td>${esc(m)}</td>${groups.map(g=>{const x=g.metrics.muscles.find(z=>z.name===m);return `<td><b>${x?.sets||0}</b><small>séries</small></td>`}).join('')}</tr>`).join('')}</tbody></table></div>`:'<div class="j-muted">Aucune série sur cette sélection.</div>';
  return `<div class="tracking-analysis-cards">${cards}</div>${groups.length>1?'<p class="tracking-analysis-baseline">Les écarts affichés utilisent la première sélection comme référence.</p>':''}<div class="tracking-section-label"><span>TRI PAR GROUPE MUSCULAIRE</span><b>${muscles.length}</b></div>${table}`;
}
function trackingAnalysisHtml(){
  const bounds=trackingAnalysisDateBounds();if(!trackingAnalysisState.from)trackingAnalysisState.from=bounds.from;if(!trackingAnalysisState.to)trackingAnalysisState.to=bounds.to;
  const catalog=trackingScopeCatalog(),muscles=trackingAnalysisMuscles();
  return `<section class="tracking-analysis"><div class="tracking-analysis-head"><div><small>ANALYSE GLOBALE</small><strong>Programmes · blocs · périodes</strong><span>Lecture seule : aucune donnée Séries / Archives / Suivi n’est modifiée.</span></div></div><div class="tracking-analysis-filters"><label>Du<input id="trackingAnalysisFrom" type="date" value="${esc(trackingAnalysisState.from)}"></label><label>Au<input id="trackingAnalysisTo" type="date" value="${esc(trackingAnalysisState.to)}"></label><label class="wide">Groupe musculaire<select id="trackingAnalysisMuscle"><option value="">Tous les groupes</option>${muscles.map(m=>`<option value="${esc(m)}" ${m===trackingAnalysisState.muscle?'selected':''}>${esc(m)}</option>`).join('')}</select></label></div><details class="tracking-analysis-scopes" open><summary>Programmes / blocs à comparer <span>${trackingAnalysisState.scopes.length||'tous'}</span></summary><div>${catalog.map(x=>`<label class="tracking-scope-option"><input type="checkbox" value="${esc(x.id)}" ${trackingAnalysisState.scopes.includes(x.id)?'checked':''}><span><b>${esc(x.label)}</b><small>${esc(x.sub||'')}</small></span></label>`).join('')||'<div class="j-muted">Le programme actif apparaîtra ici dès qu’une date de début est renseignée.</div>'}</div></details><div class="tracking-analysis-actions"><button type="button" id="trackingAnalysisApply">Actualiser</button><button type="button" id="trackingAnalysisExport">Exporter le suivi global</button></div><div id="trackingAnalysisResults">${trackingAnalysisResultsHtml()}</div></section>`;
}
function trackingReadAnalysisControls(v){trackingAnalysisState.from=v.querySelector('#trackingAnalysisFrom')?.value||'';trackingAnalysisState.to=v.querySelector('#trackingAnalysisTo')?.value||'';trackingAnalysisState.muscle=v.querySelector('#trackingAnalysisMuscle')?.value||'';trackingAnalysisState.scopes=[...v.querySelectorAll('.tracking-scope-option input:checked')].map(x=>x.value)}
function trackingWireAnalysisControls(v){
  const from=v.querySelector('#trackingAnalysisFrom'),to=v.querySelector('#trackingAnalysisTo'),muscle=v.querySelector('#trackingAnalysisMuscle');
  const syncDates=()=>{if(from)trackingAnalysisState.from=from.value||'';if(to)trackingAnalysisState.to=to.value||''};
  [from,to].filter(Boolean).forEach(el=>{el.addEventListener('input',syncDates);el.addEventListener('change',syncDates)});
  if(muscle){const syncMuscle=()=>{trackingAnalysisState.muscle=muscle.value||'';const b=v.querySelector('#trackingAnalysisExportSelection');if(b)b.disabled=!trackingAnalysisState.muscle};muscle.addEventListener('input',syncMuscle);muscle.addEventListener('change',syncMuscle)}
  v.querySelectorAll('.tracking-scope-option input').forEach(el=>{const syncScopes=()=>trackingAnalysisState.scopes=[...v.querySelectorAll('.tracking-scope-option input:checked')].map(x=>x.value);el.addEventListener('input',syncScopes);el.addEventListener('change',syncScopes)});
}
function trackingExportAnalysisPdf(){
  const groups=trackingAnalysisGroups();if(!groups.length)return alert('Aucune donnée à exporter.');const muscles=[...new Set(groups.flatMap(g=>g.metrics.muscles.map(x=>x.name)))];
  const cards=groups.map(g=>`<section class="scope"><h2>${esc(g.label)}</h2><small>${jDate(g.from)} → ${jDate(g.to)}</small><div class="k"><b>${g.metrics.sessions}<i>séances</i></b><b>${trackingFormatMinutes(g.metrics.duration)}<i>temps cumulé</i></b><b>${g.metrics.sets}<i>séries</i></b><b>${jFmt(g.metrics.tonnage)} kg<i>tonnage</i></b></div></section>`).join('');
  const rows=muscles.map(m=>`<tr><td>${esc(m)}</td>${groups.map(g=>`<td>${g.metrics.muscles.find(x=>x.name===m)?.sets||0}</td>`).join('')}</tr>`).join('');
  const html=`<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>ForgeLab · Suivi global</title><style>@page{size:A4;margin:14mm}*{box-sizing:border-box}body{font-family:Arial,sans-serif;background:#090807;color:#eee4d2;margin:0;padding:22px}.brand{text-align:center;color:#e2bd70;letter-spacing:4px;border-bottom:1px solid #6b5430;padding:12px}.brand h1{margin:4px;font-size:24px}.sub{text-align:center;color:#aaa;margin:12px}.scope{border:1px solid #5b472b;padding:14px;margin:10px 0;break-inside:avoid}.scope h2{margin:0 0 4px;color:#e4c47b}.scope small{color:#9c927f}.k{display:grid;grid-template-columns:repeat(4,1fr);gap:7px;margin-top:10px}.k b{border:1px solid #30291f;padding:8px;text-align:center}.k i{display:block;color:#999;font:8px Arial;text-transform:uppercase;margin-top:4px}table{width:100%;border-collapse:collapse;margin-top:16px;font-size:10px}th,td{border-bottom:1px solid #30291f;padding:7px;text-align:right}th:first-child,td:first-child{text-align:left}th{color:#d9b86d}.foot{text-align:center;margin-top:18px;color:#9b8153;letter-spacing:2px;font-size:8px}@media print{body{padding:0;background:#090807;-webkit-print-color-adjust:exact;print-color-adjust:exact}}</style></head><body><div class="brand"><h1>FORGELAB</h1><div>DISCIPLINA · CONSTANTIA · PROGRESSUS</div></div><p class="sub">Suivi global${trackingAnalysisState.muscle?` · ${esc(trackingAnalysisState.muscle)}`:''}</p>${cards}<table><thead><tr><th>Groupe musculaire</th>${groups.map(g=>`<th>${esc(g.label)}</th>`).join('')}</tr></thead><tbody>${rows}</tbody></table><div class="foot">DAILY WINS.</div><script>window.onload=()=>setTimeout(()=>window.print(),250)<\/script></body></html>`;
  const w=window.open('','_blank');if(!w)return alert('Autorise les fenêtres pop-up pour exporter le suivi.');w.document.open();w.document.write(html);w.document.close();
}

let trackingMode='global';

function trackingWeekDates(){
  const fp=flActiveProgram();let start;
  if(fp?.startDate&&/^\d{4}-\d{2}-\d{2}$/.test(fp.startDate)){const [y,m,d]=fp.startDate.split('-').map(Number);start=new Date(y,m-1,d,12)}
  else start=new Date(2026,7,31,12,0,0,0);
  start.setDate(start.getDate()+(Math.max(1,+state.week||1)-1)*7);
  const end=new Date(start);end.setDate(start.getDate()+6);
  return `${flPdfDate(start)} – ${flPdfDate(end)}`;
}
function trackingMuscuWeekStats(week=state.week){
  week=Math.max(1,+week||1);
  const from=jCalendarDateForDay(1,week),to=jCalendarDateForDay(7,week);
  const sessions=jLoad().filter(x=>String(x.date||'')>=from&&String(x.date||'')<=to);
  const dates=new Set(sessions.map(x=>x.date).filter(Boolean));
  const splitBases=new Set();let logical=0;
  sessions.forEach(x=>{
    const raw=String(x.sessionName||'').trim();
    const m=raw.match(/^(.*?)(?:\s*\((?:partie|part)\s*\d+\))\s*$/i);
    if(m&&m[1]?.trim())splitBases.add(jNormName(m[1].trim()));
    else logical++;
  });
  logical+=splitBases.size;
  // Compatibilité : une journée avec des séries saisies mais pas encore archivée
  // reste comptée comme une séance. Les jours déjà présents dans le Carnet ne sont
  // jamais ajoutés une seconde fois.
  const activeKeys=new Set(activePriorities().map(p=>p.muscle_key));
  const seriesDays=new Set(state.series.filter(r=>+r.week===week&&activeKeys.has(r.muscle_key)&&(+r.series||0)>0).map(r=>+r.day).filter(d=>d>=1&&d<=7));
  seriesDays.forEach(d=>{const date=jCalendarDateForDay(d,week);dates.add(date);if(!sessions.some(x=>x.date===date))logical++});
  return {count:logical,sessions,dates};
}
function trackingSeriesSessionCount(){
  // v1.30.8 : compteur basé sur les séances réelles du Carnet, pas sur les jours uniques.
  // Deux séances différentes le même jour comptent donc deux fois. Une séance explicitement
  // découpée en « partie 1 / partie 2 » reste une seule séance logique.
  return trackingMuscuWeekStats(state.week).count;
}
function trackingMuscuTrend(done,minimum,inTarget,under,over,totalGroups,overNames=[]){
  const pct=minimum?Math.round(done/minimum*100):0;
  const overDetail=overNames.length
    ? ` ${overNames.length} groupe${overNames.length>1?'s':''} musculaire${overNames.length>1?'s':''} avec volume dépassé (${overNames.join(', ')}).`
    : '';
  if(under===0&&over===0)return `Semaine complète : ${pct}% du volume minimum réalisé et ${inTarget}/${totalGroups} objectifs musculaires atteints.`;
  if(under===0)return `Semaine complète : ${inTarget}/${totalGroups} objectifs musculaires atteints.${overDetail}`;
  if(pct>=90)return `Semaine presque complète : ${pct}% du volume minimum réalisé. Il reste ${under} groupe${under>1?'s':''} musculaire${under>1?'s':''} à compléter.${overDetail}`;
  if(pct>=70)return `Bonne progression : ${pct}% du volume minimum réalisé. ${under} groupe${under>1?'s':''} reste${under>1?'nt':''} à compléter.${overDetail}`;
  return `Semaine en cours : ${pct}% du volume minimum réalisé. Priorité aux ${under} groupe${under>1?'s':''} encore sous leur cible.${overDetail}`;
}
function trackingMuscuSummary(){
  const active=activePriorities();
  const minimum=active.reduce((a,p)=>a+(+p.target_min||0),0);
  const done=active.reduce((a,p)=>a+total(p.muscle_key),0);
  const remain=active.reduce((a,p)=>a+Math.max(0,(+p.target_min||0)-total(p.muscle_key)),0);
  const pct=minimum?Math.round(done/minimum*100):0;
  const sessions=trackingSeriesSessionCount();
  const barPct=Math.min(100,pct);
  // Pour le récap global : objectif atteint = minimum hebdomadaire atteint.
  // Un groupe au-dessus du maximum reste donc compté comme objectif atteint,
  // tout en étant signalé séparément dans "volume dépassé".
  const inTarget=active.filter(p=>total(p.muscle_key)>=pRange(p)[0]).length;
  const under=active.filter(p=>total(p.muscle_key)<pRange(p)[0]).length;
  const overPriorities=active.filter(p=>total(p.muscle_key)>pRange(p)[1]);
  const over=overPriorities.length;
  const overNames=overPriorities.map(p=>p.muscle_key);
  const complete=under===0;
  const trend=trackingMuscuTrend(done,minimum,inTarget,under,over,active.length,overNames);

  return `<section class="track-muscu-recap story-recap ${complete?'week-complete':''}">
    <div class="story-forgelab-brand"><img src="auth-laurel-realistic-v1225.png" alt=""><strong>ForgeLab</strong></div>
    <div class="story-recap-head">
      <div><small>BILAN MUSCULATION</small><strong>SEMAINE ${state.week}</strong></div>
      <span>${trackingWeekDates()}</span>
    </div>

    <div class="story-volume">
      <div class="story-volume-main"><b>${done}</b><span>/ ${minimum}</span><small>SÉRIES<br>RÉALISÉES</small></div>
      <div class="story-volume-pct"><b>${pct}%</b><span>${complete?'VOLUME MINIMUM ATTEINT':'DU MINIMUM PRÉVU'}</span><div class="track-recap-bar"><i style="width:${barPct}%"></i></div></div>
    </div>

    <div class="story-session-line"><b>${sessions}</b><div><strong>SÉANCE${sessions>1?'S':''} MUSCULATION</strong><span>détectée${sessions>1?'s':''} depuis les séries saisies</span></div></div>

    <div class="story-status-grid">
      <div class="ok"><b>${inTarget}</b><strong>GROUPE${inTarget>1?'S':''} MUSCULAIRE${inTarget>1?'S':''} TRAVAILLÉ${inTarget>1?'S':''}</strong><span>objectif${inTarget>1?'s':''} atteint${inTarget>1?'s':''}</span></div>
      <div class="low"><b>${under}</b><strong>GROUPE${under>1?'S':''} MUSCULAIRE${under>1?'S':''}</strong><span>à compléter</span></div>
      <div class="high"><b>${over}</b><strong>GROUPE${over>1?'S':''} MUSCULAIRE${over>1?'S':''}</strong><span>volume dépassé</span></div>
    </div>

    <button type="button" class="story-remaining ${complete?'done':''}" data-remaining-toggle aria-expanded="false">
      <b>${remain}</b><div><strong>SÉRIE${remain>1?'S':''} RESTANTE${remain>1?'S':''}</strong><span>${complete?'Tous les minimums hebdomadaires sont atteints.':'Appuie pour voir le détail par groupe musculaire.'}</span></div><em>›</em>
    </button>
    <div class="story-remaining-detail" data-remaining-detail hidden>${active.filter(p=>Math.max(0,(+p.target_min||0)-total(p.muscle_key))>0).map(p=>{const t=total(p.muscle_key),mi=+p.target_min||0,left=Math.max(0,mi-t);return `<div><span><b>${esc(p.muscle_name)}</b><small>${t} / ${mi} séries réalisées</small></span><strong>+${left}</strong></div>`}).join('')||'<div class="complete"><span><b>Tous les minimums sont atteints</b><small>Aucune série restante.</small></span><strong>✓</strong></div>'}</div>

    <div class="story-trend ${complete?'done':''}">
      <small>TENDANCE DE LA SEMAINE</small>
      <p>${esc(trend)}</p>
    </div>
  </section>`;
}

function trackingMuscleDetails(){
  const active=activePriorities();
  return `<div class="tracking-section-label"><span>DÉTAIL MUSCULAIRE</span><b>${active.filter(p=>total(p.muscle_key)>=pRange(p)[0]).length}/${active.length} au minimum</b></div>`+
  active.map(p=>{
    const t=total(p.muscle_key),[mi,ma]=pRange(p),left=Math.max(0,mi-t);
    const pc=mi?Math.min(100,Math.round(t/mi*100)):100;
    const st=t<mi?['Sous la cible','low']:t>ma?['Maximum dépassé','high']:['Dans la cible','ok'];
    const barClass=t>ma?'over':t>=mi?'target':'under';
    return`<article class="card ${p.priority.toLowerCase()} tracking-card muscle-order-card" data-muscle-order="${esc(p.muscle_key)}">
      <div class="cardhead"><div><div class="muscle">${esc(p.muscle_name)}</div><div class="range">Priorité ${p.priority} · cible ${mi}–${ma}</div></div><span class="status ${st[1]}">${st[0]}</span></div>
      <div class="tracking-numbers"><div><span>Prévu</span><b>${mi}–${ma}</b></div><div><span>Réalisé</span><b>${t}</b></div><div><span>Reste</span><b>${left}</b></div></div>
      <div class="progress ${barClass}"><i style="width:${pc}%"></i></div>
      <div class="trackline">${t<mi?`<span>${pc}% du minimum</span><strong>${t} / ${mi}</strong>`:t>ma?`<span>Maximum dépassé</span><strong>${t} séries · max ${ma}</strong>`:`<span>Dans la cible</span><strong>${t} séries · cible ${mi}–${ma}</strong>`}</div>
    </article>`
  }).join('');
}
function trackingWeekBounds(){
  const start=forgeActiveProgramStartDate();start.setHours(12,0,0,0);start.setDate(start.getDate()+(Math.max(1,+state.week||1)-1)*7);const end=new Date(start);end.setDate(start.getDate()+6);
  const fmt=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;return {from:fmt(start),to:fmt(end)}
}
function trackingProgramCardioForWeek(){
  const uidKey=currentUser?.id||'guest',ctx=jActiveProgramForWeek(state.week),blockId=ctx.block?.id||'bloc-1';let daily={},tpl=null,legacy={};
  const dailyKey=`forgelabCardioDayPlan:${uidKey}:active:${blockId}`,tplKey=`forgelabCardioTemplate:${uidKey}:active:${blockId}`,legacyKey=`forgelabProgrammingCardio:${uidKey}:active`;
  try{daily=JSON.parse(localStorage.getItem(dailyKey)||'{}')||{}}catch(_){daily={}}
  try{tpl=JSON.parse(localStorage.getItem(tplKey)||'null')}catch(_){tpl=null}
  try{legacy=JSON.parse(localStorage.getItem(legacyKey)||'{}')||{}}catch(_){legacy={}}

  // v1.30.8 — la Programmation est la source de vérité, y compris lorsque la trame visible
  // n'a jamais été modifiée. flCardioTemplate() affiche alors une valeur calculée (par défaut 1/sem.)
  // sans forcément avoir encore créé de clé localStorage. Séries doit lire exactement cette même valeur
  // au lieu de retomber sur l'ancien objectif cardio historique (ex. 2/sem.). Lecture seule : aucun stockage n'est réécrit.
  if(!tpl||!Array.isArray(tpl.items)){
    const seen=new Set(),items=[];
    DAYS.forEach(day=>(Array.isArray(legacy[day])?legacy[day]:[]).forEach(c=>{
      const quality=String(c?.quality||CARDIO_QUALITIES[0]),engine=String(c?.engine||'Run'),format=String(c?.format||'Continu'),key=[quality,engine,format].join('|');
      if(!seen.has(key)){seen.add(key);items.push({id:c?.id||('tracking_'+items.length),quality,engine,format,target:1})}
    }));
    tpl={items:items.length?items:[{id:'tracking_cardio_default',quality:CARDIO_QUALITIES[0],engine:'Run',format:'Continu',target:1}]};
  }

  const dailyItems=[];DAYS.forEach(d=>(Array.isArray(daily[d])?daily[d]:[]).forEach(x=>dailyItems.push({day:d,...x})));
  const dailyCount=dailyItems.length;
  const freeItems=Array.isArray(tpl?.items)?tpl.items.filter(x=>Math.max(0,+x.target||0)>0):[];
  const rawFreeCount=freeItems.reduce((n,x)=>n+Math.max(0,+x.target||0),0);

  // v1.28.4 — source de vérité du Suivi cardio.
  // Lors de la migration v1.28.x, une ancienne séance jour-par-jour a pu créer :
  // 1) une séance dans le nouveau plan journalier (ID conservé), et
  // 2) une ligne dans "Cardio libre" (une seule ligne par modalité).
  // Ce second élément est un reflet de migration, pas une séance supplémentaire.
  // On le neutralise uniquement dans le calcul du Suivi, sans modifier le stockage utilisateur.
  const legacyItems=[];DAYS.forEach(d=>(Array.isArray(legacy[d])?legacy[d]:[]).forEach(x=>legacyItems.push({day:d,...x})));
  const sig=x=>[String(x.quality||''),String(x.engine||''),String(x.format||'')].join('|');
  const dailyQuality=x=>String(x.quality||flDayCardioType(x.type).quality||'');
  const dailyEngine=x=>String(x.engine||flDayCardioType(x.type).defaultEngine||'');

  // Détection principale : l'ID de l'ancienne séance est conservé dans le plan journalier.
  const legacyById=new Map(legacyItems.filter(x=>x?.id).map(x=>[String(x.id),x]));
  const migratedTemplateSigs=new Set();
  const matchedDaily=new Set();
  dailyItems.forEach((x,i)=>{
    const old=x?.id?legacyById.get(String(x.id)):null;
    if(old){migratedTemplateSigs.add(sig(old));matchedDaily.add(i)}
  });

  // Compatibilité avec les toutes premières données migrées qui n'avaient pas toujours un ID stable.
  // On matche alors une fois seulement sur jour + qualité + engine, sans exiger le format supprimé du nouveau modèle journalier.
  const fallbackPool=legacyItems.map((x,i)=>({x,i,used:false}));
  dailyItems.forEach((x,i)=>{
    if(matchedDaily.has(i))return;
    const q=dailyQuality(x),e=dailyEngine(x);
    const hit=fallbackPool.find(o=>!o.used&&o.x.day===x.day&&String(o.x.quality||'')===q&&String(o.x.engine||'')===e);
    if(hit){hit.used=true;migratedTemplateSigs.add(sig(hit.x))}
  });

  // La migration de la trame libre créait au maximum UNE ligne par signature de modalité.
  // Si l'utilisateur a ensuite augmenté volontairement sa fréquence (target > 1), on ne retire que l'unité héritée.
  const shadowRemoved=new Set();
  let freeCount=0,duplicateCount=0;
  const freeEffective=[];
  freeItems.forEach(x=>{
    const target=Math.max(0,+x.target||0),k=sig(x);
    let effective=target;
    if(target>0&&migratedTemplateSigs.has(k)&&!shadowRemoved.has(k)){
      effective=target-1;duplicateCount++;shadowRemoved.add(k);
    }
    effective=Math.max(0,effective);
    freeCount+=effective;
    freeEffective.push({item:x,effective});
  });

  // La trame calculée ci-dessus est celle réellement affichée dans Programmation, même sans clé persistée.
  // Elle constitue donc toujours la source du compteur Séries pour le programme actif.
  const hasProgramKeys=true;
  const target=Math.max(0,dailyCount+freeCount);
  return {daily,template:tpl,dailyItems,freeItems,freeEffective,dailyCount,rawFreeCount,freeCount,duplicateCount,hasProgramKeys,target}
}
function trackingCardioProgramTarget(){return trackingProgramCardioForWeek().target}
function cardioSeriesPlanTargets(d=cardioData()){
  const stored=Object.fromEntries((d.modalities||[]).map(m=>[m.id,Math.max(0,+m.target||0)]));
  let plan=null;try{plan=trackingProgramCardioForWeek()}catch(_){plan=null}
  if(!plan?.hasProgramKeys)return {total:cardioTotalTarget(),byId:stored,source:'legacy'};
  const byId=Object.fromEntries((d.modalities||[]).map(m=>[m.id,0]));
  const same=(m,q,e,f,strictFormat=true)=>String(m.quality||'')===String(q||'')&&String(m.engine||'')===String(e||'')&&(!strictFormat||!f||String(m.format||'')===String(f||''));
  const pick=(q,e,f)=>{
    let m=(d.modalities||[]).find(x=>same(x,q,e,f,true));
    if(!m)m=(d.modalities||[]).find(x=>same(x,q,e,f,false));
    return m||null;
  };
  (plan.freeEffective||[]).forEach(row=>{
    const x=row.item||{},m=pick(x.quality,x.engine,x.format);
    if(m)byId[m.id]=(byId[m.id]||0)+Math.max(0,+row.effective||0);
  });
  (plan.dailyItems||[]).forEach(x=>{
    const t=flDayCardioType(x.type),q=x.quality||t.quality,e=x.engine||t.defaultEngine,m=pick(q,e,'');
    if(m)byId[m.id]=(byId[m.id]||0)+1;
  });
  const assigned=Object.values(byId).reduce((a,n)=>a+(+n||0),0),missing=Math.max(0,(+plan.target||0)-assigned);
  if(missing&&(d.modalities||[])[0])byId[d.modalities[0].id]=(byId[d.modalities[0].id]||0)+missing;
  return {total:Math.max(0,+plan.target||0),byId,source:'program'};
}
function trackingGlobalSummary(){
  const bounds=trackingWeekBounds(),ctx=jActiveProgramForWeek(state.week),plannedMuscu=DAYS.filter(d=>(ctx.data?.[d]||[]).length>0).length;
  const cardioPlan=trackingProgramCardioForWeek(),plannedCardio=cardioPlan.target;
  const muscuStats=trackingMuscuWeekStats(state.week),sessions=muscuStats.sessions,muscuDates=muscuStats.dates;
  const muscuDone=muscuStats.count,muscuMin=sessions.reduce((n,x)=>n+(+x.duration||0),0);
  const cd=cardioData(),cardioDone=cardioTotalDone();
  const cardioSessions=(cd.sessions||[]).filter(x=>String(x.date||'')>=bounds.from&&String(x.date||'')<=bounds.to),cardioMin=cardioSessions.reduce((n,x)=>n+(+x.duration||0),0);
  const cardioDates=new Set(cardioSessions.map(x=>x.date));const cw=cardioWeek().week||{};Object.values(cw).forEach(days=>Object.entries(days||{}).forEach(([day,n])=>{if((+n||0)>0)cardioDates.add(jCalendarDateForDay(+day,state.week))}));
  const totalPlanned=plannedMuscu+plannedCardio,totalDone=muscuDone+cardioDone,totalMin=muscuMin+cardioMin,pct=totalPlanned?Math.min(100,Math.round(totalDone/totalPlanned*100)):0;
  const dayRows=DAYS.map((day,i)=>{const date=jCalendarDateForDay(i+1,state.week),m=muscuDates.has(date),c=cardioDates.has(date);return `<div class="tracking-global-day ${m||c?'done':''}"><b>${day}</b><span>${m?'M':''}${m&&c?' + ':''}${c?'C':''}${!m&&!c?'—':''}</span></div>`}).join('');
  return `<section class="track-global-recap"><div class="track-global-hero"><small>BILAN GLOBAL · SEMAINE ${state.week}</small><strong>${totalDone} / ${totalPlanned}</strong><span>SÉANCES RÉALISÉES</span><div class="track-recap-bar"><i style="width:${pct}%"></i></div></div><div class="track-global-time"><div><b>${Math.floor(totalMin/60)} h ${String(totalMin%60).padStart(2,'0')}</b><span>Temps total</span></div><div><b>${Math.floor(muscuMin/60)} h ${String(muscuMin%60).padStart(2,'0')}</b><span>Musculation</span><small>${muscuDone}/${plannedMuscu} séances</small></div><div><b>${Math.floor(cardioMin/60)} h ${String(cardioMin%60).padStart(2,'0')}</b><span>Cardio</span><small>${cardioDone}/${plannedCardio} séances</small></div></div><div class="tracking-global-days">${dayRows}</div><p class="tracking-global-note">Le temps correspond aux durées réellement enregistrées dans le Carnet et dans les séances cardio détaillées.</p></section>`
}
function drawTracking(){
  let v=document.querySelector('#view');
  const cardioOn=cardioData().enabled;
  v.innerHTML=title('Suivi')+
  `<div class="tracking-date">Semaine ${state.week} · ${trackingWeekDates()}</div>
   <div class="tracking-mode-switch tracking-mode-three">
     <button type="button" data-track-mode="global" class="${trackingMode==='global'?'active':''}">GLOBAL</button>
     <button type="button" data-track-mode="muscu" class="${trackingMode==='muscu'?'active':''}">MUSCULATION</button>
     <button type="button" data-track-mode="cardio" class="${trackingMode==='cardio'?'active':''}">CARDIO</button>
   </div>
   <div id="trackingModeContent">${trackingMode==='global'
     ? trackingGlobalSummary()+trackingAnalysisHtml()
     : trackingMode==='muscu'
       ? trackingMuscuSummary()+`<details class="tracking-details"><summary>Voir le détail par groupe</summary>${trackingMuscleDetails()}</details>`
       : (cardioOn?cardioTrackingHtml():`<section class="card cardio-tracking-card"><div class="muscle">Cardio</div><div class="range">Cardio non activé dans les priorités.</div></section>`)
   }</div>`;
  v.querySelectorAll('[data-track-mode]').forEach(b=>b.onclick=()=>{trackingMode=b.dataset.trackMode;drawTracking()});
  if(trackingMode==='muscu'){
    wireMuscleReorder(v);
    const toggle=v.querySelector('[data-remaining-toggle]'),detail=v.querySelector('[data-remaining-detail]');if(toggle&&detail)toggle.onclick=()=>{const open=detail.hidden;detail.hidden=!open;toggle.setAttribute('aria-expanded',open?'true':'false');toggle.classList.toggle('open',open)};
  }
  if(trackingMode==='global'){
    // v1.29.1 : mémorise immédiatement les filtres d'analyse.
    // Un rafraîchissement cloud ne peut donc plus rétablir la date par défaut pendant la saisie.
    trackingWireAnalysisControls(v);
    v.querySelector('#trackingAnalysisApply')?.addEventListener('click',()=>{trackingReadAnalysisControls(v);drawTracking()});
    v.querySelector('#trackingAnalysisExport')?.addEventListener('click',()=>{trackingReadAnalysisControls(v);trackingExportAnalysisPdf()});
  }
}

function cardioSeriesHtml(){
  const d=cardioData();if(!d.enabled)return'';
  const planTargets=cardioSeriesPlanTargets(d),target=planTargets.total,done=cardioTotalDone();
  return `<article class="card ${d.priority.toLowerCase()} cardio-series-card">
    <div class="cardhead"><div><div class="muscle">♥ Cardio</div><div class="range">Qualité · Engine · Format</div></div><span class="badge">${d.priority}</span></div>
    <div class="cardio-series-progress"><span>S${state.week}</span><strong>${done} / ${target} réalisée${done>1?'s':''}</strong></div>
    <div class="cardio-series-modalities">${d.modalities.map(m=>{const {week}=cardioWeek(),days=week[m.id]||{},mt=cardioModalityTotal(m.id),expected=planTargets.byId[m.id]??m.target;return`<div class="cardio-series-modality">
      <div class="cardio-series-modality-head"><div><strong>${esc(m.quality)}</strong><small>${esc(m.engine)} · ${esc(m.format)}</small></div><span>${mt}/${expected}</span></div>
      <div class="days cardio-days">${DAYS.map((day,i)=>`<div class="day ${i+1===currentWeekdayIndex()?'is-today':''}"><label>${day}</label><input class="cardio-day-input" type="text" inputmode="numeric" pattern="[0-9]*" enterkeyhint="done" value="${+days[i+1]||0}" data-cardio-modality="${esc(m.id)}" data-cardio-day="${i+1}" aria-label="${day} ${esc(m.quality)} ${esc(m.engine)}"></div>`).join('')}</div>
    </div>`}).join('')}</div>
    <div class="totalrow"><span>Total cardio semaine</span><b data-cardio-total>${done} séance${done>1?'s':''}</b></div>
    <section class="base-run-entry">
      <div class="base-run-entry-head"><div><small>🟢 BASE AÉROBIE · RUN</small><strong>Enregistrer une séance</strong></div><span>5 données</span></div>
      <div class="base-run-fields">
        <label>Date<input id="baseRunDate" type="date" value="${new Date().toISOString().slice(0,10)}"></label>
        <label>Durée<input id="baseRunDuration" type="number" min="1" inputmode="numeric" placeholder="40"><i>min</i></label>
        <label>Distance<input id="baseRunDistance" type="number" min="0" step="0.01" inputmode="decimal" placeholder="5.50"><i>km</i></label>
        <label class="pace-field">Allure moy.
  <div class="pace-inputs">
    <input id="baseRunPaceMin" type="number" min="0" max="20" inputmode="numeric" placeholder="7">
    <span>:</span>
    <input id="baseRunPaceSec" type="number" min="0" max="59" inputmode="numeric" placeholder="13">
    <i>/km</i>
  </div>
</label>
        <label>FC moy.<input id="baseRunHr" type="number" min="1" inputmode="numeric" placeholder="145"><i>bpm</i></label>
        <label>RPE<input id="baseRunRpe" type="number" min="1" max="10" inputmode="numeric" placeholder="2"><i>/10</i></label>
      </div>
      <button type="button" class="base-run-save" id="baseRunSave">Enregistrer la séance 🟢</button>
      <p class="base-run-note">Suivi Base aérobie : durée, distance, allure, FC et RPE. Les anciennes séances sans distance restent conservées.</p>
    </section>
  </article>`
}
function wireCardioSeries(v){
  v.querySelectorAll('.cardio-day-input').forEach(i=>{
    i.addEventListener('focus',()=>{try{i.select()}catch(_){}});
    i.addEventListener('input',()=>{
      const raw=(i.value||'').replace(/[^0-9]/g,'');if(raw==='')return;
      const n=Math.max(0,Math.min(9,parseInt(raw,10)||0)),d=cardioData(),k=String(state.week),mid=i.dataset.cardioModality,day=String(+i.dataset.cardioDay);
      if(!d.weeks[k]||Array.isArray(d.weeks[k]))d.weeks[k]={};if(!d.weeks[k][mid])d.weeks[k][mid]={};d.weeks[k][mid][day]=n;saveCardio(d);i.value=String(n);
      const modality=d.modalities.find(x=>x.id===mid),row=i.closest('.cardio-series-modality'),mt=Object.values(d.weeks[k][mid]).reduce((a,x)=>a+(+x||0),0),targets=cardioSeriesPlanTargets(d);if(row)row.querySelector('.cardio-series-modality-head span').textContent=`${mt}/${targets.byId[mid]??modality?.target??0}`;
      const total=d.modalities.reduce((a,m)=>a+Object.values(d.weeks[k][m.id]||{}).reduce((s,x)=>s+(+x||0),0),0),tot=v.querySelector('[data-cardio-total]');if(tot)tot.textContent=`${total} séance${total>1?'s':''}`;const prog=v.querySelector('.cardio-series-progress strong');if(prog)prog.textContent=`${total} / ${targets.total} réalisée${total>1?'s':''}`;
    });
    i.addEventListener('blur',()=>{if((i.value||'')==='')i.value='0'});
  });
  const save=v.querySelector('#baseRunSave');
  if(save)save.onclick=()=>{
    const date=v.querySelector('#baseRunDate')?.value;
    const duration=+v.querySelector('#baseRunDuration')?.value||0;
    const distanceKm=Math.max(0,+v.querySelector('#baseRunDistance')?.value||0);
    const paceMin=Math.max(0,+v.querySelector('#baseRunPaceMin')?.value||0);
    const paceSec=Math.max(0,Math.min(59,+v.querySelector('#baseRunPaceSec')?.value||0));
    const pace=`${paceMin}:${String(paceSec).padStart(2,'0')}`;
    const avgHr=+v.querySelector('#baseRunHr')?.value||0;
    const rpe=+v.querySelector('#baseRunRpe')?.value||0;
    if(!date||duration<=0||distanceKm<=0||paceMin<=0||avgHr<=0||rpe<1||rpe>10){alert('Renseigne : date, durée, distance, allure (minutes + secondes), FC moyenne et RPE /10.');return}
    cardioSaveBaseRunSession({date,duration,distanceKm,pace,avgHr,rpe});
    alert('Séance Base aérobie · Run enregistrée.');
    drawSeries();
  };
}

document.querySelectorAll('nav button').forEach(b=>b.onclick=async()=>{
  state.tab=b.dataset.tab;
  if(state.tab==='programming') programmingScreen='chooser';
  if(state.tab==='priorities') prioritiesScreen='chooser';
  if(state.tab==='journal'&&!journalDraft)await syncJournalCloud();
  await load(false);
  draw();
});
document.querySelector('#prevWeek').onclick=()=>setWeek(state.week-1);
document.querySelector('#nextWeek').onclick=()=>setWeek(state.week+1);


// v1.21.9 : aucun nettoyage automatique de Séries.
 // Une mise à jour de ForgeLab ne doit jamais supprimer des données utilisateur.


/* ===== ForgeLab v1.28.0 — passerelle Programmation iPhone ↔ PC =====
   Le programme avancé reste dans localStorage comme auparavant.
   Une copie JSON complète est transportée dans forgelab_cardio.payload.advancedProgrammingV1.
   Aucun volume Séries / Carnet n'est inclus dans cette passerelle. */
function flProgrammingSyncPrefixes(uidKey=currentUser?.id||'guest'){
  return [
    `forgelabProgrammingDraftRegistry:${uidKey}`,
    `forgelabProgrammingSelectedDraft:${uidKey}`,
    `forgelabMobileProgramming:${uidKey}`,
    `forgelabMobileProgrammingDraft:${uidKey}`,
    `forgelabMobileProgrammingMeta:${uidKey}`,
    `forgelabMobileProgrammingMode:${uidKey}`,
    `forgelabMobileProgrammingSelectedPhase:${uidKey}`,
    `forgelabMobileProgrammingOpenExercise:${uidKey}`,
    `forgelabMobileProgrammingPresets:${uidKey}`,
    `forgelabFullProgram:${uidKey}`,
    `forgelabProgramBlock:${uidKey}`,
    `forgelabProgrammingCardio:${uidKey}`,
    `forgelabCardioTemplate:${uidKey}`,
    `forgelabCardioWeeks:${uidKey}`,
    `forgelabCardioWeekSelected:${uidKey}`,
    `forgelabCardioDayPlan:${uidKey}`,
    `forgelabBlockNotes:${uidKey}`
  ];
}
function flProgrammingSyncedKey(key,uidKey=currentUser?.id||'guest'){
  return !!key && flProgrammingSyncPrefixes(uidKey).some(p=>key===p||key.startsWith(p+':'));
}
function flProgrammingLocalSnapshot(){
  const uidKey=currentUser?.id||'guest',values={};
  for(let i=0;i<localStorage.length;i++){
    const k=localStorage.key(i);if(k&&flProgrammingSyncedKey(k,uidKey))values[k]=localStorage.getItem(k);
  }
  return {schema:1,complete:true,updatedAt:new Date().toISOString(),source:'iphone',values};
}
function flProgrammingCloudStampKey(){return `forgelabProgrammingCloudStamp:${currentUser?.id||'guest'}`}
function flProgrammingCloudBackupKey(){return `forgelabProgrammingCloudBackupV1280:${currentUser?.id||'guest'}`}
function flProgrammingStableValues(snapshot){
  const x=snapshot?.values||{};return JSON.stringify(Object.keys(x).sort().map(k=>[k,x[k]]));
}
let flProgrammingCloudTimer=null,flProgrammingCloudBusy=false,flProgrammingCloudApplying=false,flProgrammingCloudLastLocalHash='';
async function flProgrammingCloudRow(){
  const rows=await req(`/forgelab_cardio?select=id,payload,updated_at&user_id=eq.${encodeURIComponent(uid())}&id=eq.main&limit=1`);
  return rows?.[0]||null;
}
async function flProgrammingCloudWrite(snapshot){
  const row=await flProgrammingCloudRow(),payload={...(row?.payload||{}),advancedProgrammingV1:snapshot};
  await req('/forgelab_cardio?on_conflict=user_id,id',{
    method:'POST',headers:{Prefer:'resolution=merge-duplicates,return=minimal'},
    body:JSON.stringify([{user_id:uid(),id:'main',payload,updated_at:new Date().toISOString()}])
  });
  localStorage.setItem(flProgrammingCloudStampKey(),snapshot.updatedAt);
  flProgrammingCloudLastLocalHash=flProgrammingStableValues(snapshot);
}
async function flProgrammingCloudPush(force=false){
  if(!currentUser?.id||flProgrammingCloudBusy||flProgrammingCloudApplying)return;
  const snapshot=flProgrammingLocalSnapshot(),hash=flProgrammingStableValues(snapshot);
  if(!force&&hash===flProgrammingCloudLastLocalHash)return;
  flProgrammingCloudBusy=true;
  try{await flProgrammingCloudWrite(snapshot)}catch(e){console.warn('Sync programmation indisponible',e)}finally{flProgrammingCloudBusy=false}
}
function flProgrammingCloudQueue(force=false){
  if(!currentUser?.id||flProgrammingCloudApplying)return;
  clearTimeout(flProgrammingCloudTimer);
  flProgrammingCloudTimer=setTimeout(()=>flProgrammingCloudPush(force),500);
}
function flProgrammingApplyRemote(snapshot){
  if(!snapshot?.values||typeof snapshot.values!=='object')return false;
  const uidKey=currentUser?.id||'guest',local=flProgrammingLocalSnapshot();
  try{localStorage.setItem(flProgrammingCloudBackupKey(),JSON.stringify({savedAt:new Date().toISOString(),snapshot:local}))}catch(_){ }
  flProgrammingCloudApplying=true;
  try{
    if(snapshot.complete){
      const keep=new Set(Object.keys(snapshot.values));
      const remove=[];for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k&&flProgrammingSyncedKey(k,uidKey)&&!keep.has(k))remove.push(k)}
      remove.forEach(k=>localStorage.removeItem(k));
    }
    Object.entries(snapshot.values).forEach(([k,v])=>{if(flProgrammingSyncedKey(k,uidKey)&&v!=null)localStorage.setItem(k,String(v))});
    localStorage.setItem(flProgrammingCloudStampKey(),snapshot.updatedAt||new Date().toISOString());
    flProgrammingCloudLastLocalHash=flProgrammingStableValues(snapshot);
    recoverOrphanProgrammingDrafts();
  }finally{flProgrammingCloudApplying=false}
  return true;
}
async function flProgrammingCloudPull(){
  if(!currentUser?.id||flProgrammingCloudBusy)return false;
  flProgrammingCloudBusy=true;
  try{
    const row=await flProgrammingCloudRow(),remote=row?.payload?.advancedProgrammingV1||null;
    if(!remote){
      const local=flProgrammingLocalSnapshot();
      if(Object.keys(local.values).length)await flProgrammingCloudWrite(local);
      return true;
    }
    const stampRaw=localStorage.getItem(flProgrammingCloudStampKey());
    const stamp=Date.parse(stampRaw||0)||0;
    const remoteTime=Date.parse(remote.updatedAt||row?.updated_at||0)||0;
    const localNow=flProgrammingLocalSnapshot(),localHash=flProgrammingStableValues(localNow);
    if(!flProgrammingCloudLastLocalHash)flProgrammingCloudLastLocalHash=localHash;

    // Migration initiale v1.28 : l'iPhone est la source de vérité demandée.
    // Si cet appareil possède déjà une programmation locale mais n'a encore jamais
    // synchronisé la passerelle, on publie d'abord cette copie au lieu d'importer
    // un éventuel miroir PC plus ancien. Les Séries / Carnet ne font pas partie du snapshot.
    if(!stampRaw && Object.keys(localNow.values).length){
      await flProgrammingCloudWrite(localNow);
      return true;
    }
    if(remoteTime>stamp){
      flProgrammingApplyRemote(remote);
      if(state.tab==='programming')drawProgramming();
      return true;
    }
    return true;
  }catch(e){console.warn('Lecture programmation cloud indisponible',e);return false}finally{flProgrammingCloudBusy=false}
}
async function flProgrammingCloudBootSync(){
  if(!currentUser?.id)return;
  await flProgrammingCloudPull();
  flProgrammingCloudLastLocalHash=flProgrammingStableValues(flProgrammingLocalSnapshot());
  // Si aucun miroir n'existait, le pull l'a créé. Sinon on n'écrase jamais
  // automatiquement une copie cloud plus récente au démarrage.
}

async function boot(){
  importPcProgrammingV169();
  journalCloudAvailable=true;
  await syncJournalCloud();
  await flProgrammingCloudBootSync();
  // v1.29.0 — sécurité données : aucune mise à jour de l'application ne peut déclencher
  // un reset automatique de Séries. Les resets restent réservés à l'activation explicite
  // d'un nouveau programme par l'utilisateur.
  restoreSeriesPending();
  await load();
  clearInterval(poll);
  poll=setInterval(()=>load(!['series','programming','journal','tracking'].includes(state.tab)),12000)
}
document.addEventListener('visibilitychange',async()=>{
  if(!document.hidden&&currentUser){
    if(!journalDraft)await syncJournalCloud();
    await flProgrammingCloudPull();
    await load(!journalDraft)
  }
});
window.addEventListener('online',()=>{if(currentUser){syncJournalCloud();flProgrammingCloudPull()}});
(async()=>{if(await restoreAuth()){hideAuth();await boot()}else showAuth()})();

/* v1.21.9 — splash d'ouverture */
(function(){
  const splash=document.getElementById('forgeSplash');
  if(!splash)return;
  const reduce=window.matchMedia&&window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(reduce){
    setTimeout(()=>splash.remove(),350);
    return;
  }
  requestAnimationFrame(()=>{
    const target=splash.querySelector('.forge-splash-laurel-wrap');
    if(target){
      const r=target.getBoundingClientRect();
      const tx=r.left+r.width/2, ty=r.top+r.height/2;
    }
    splash.classList.add('is-leaving');
  });
  setTimeout(()=>{try{splash.remove()}catch(_){}},6025);
})();


/* ===== ForgeLab v1.17.0 — Programme complet / multi-blocs ===== */
function fullProgramKey(){return `forgelabFullProgram:${currentUser?.id||'guest'}${programmingMode()==='draft'?':draft:'+(selectedDraftId()||'default'):':active'}`}
function fullProgram(){
  try{const x=JSON.parse(localStorage.getItem(fullProgramKey())||'null');if(x&&Array.isArray(x.blocks)&&x.blocks.length)return x}catch(_){}
  const x={name:'Programme ForgeLab',selected:'bloc-1',blocks:[{id:'bloc-1',name:programmingMeta('draft').name||programmingMeta('active').name||'Bloc 1'}]};
  localStorage.setItem(fullProgramKey(),JSON.stringify(x));return x
}
function saveFullProgram(x){localStorage.setItem(fullProgramKey(),JSON.stringify(x))}
function selectedFullBlock(){const x=fullProgram();return x.blocks.find(b=>b.id===x.selected)||x.blocks[0]}
function blockPrefix(id=selectedFullBlock().id){return `forgelabProgramBlock:${currentUser?.id||'guest'}${programmingMode()==='draft'?':draft:'+(selectedDraftId()||'default'):':active'}:${id}`}
function blockSnapshot(id=selectedFullBlock().id){
 const pre=blockPrefix(id),o={};
 for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k&&k.startsWith(pre+':'))o[k.slice(pre.length+1)]=localStorage.getItem(k)}
 return o
}
function saveCurrentIntoBlock(id=selectedFullBlock().id){
 const pre=blockPrefix(id), mode=programmingMode();
 localStorage.setItem(pre+':mode',mode);
 ['active','draft'].forEach(m=>{
   const mk=programmingMetaKey(m); const mv=localStorage.getItem(mk); if(mv)localStorage.setItem(pre+':meta:'+m,mv);
   const meta=programmingMeta(m); phaseRanges(meta).forEach(q=>{const pid=phaseId(q),v=localStorage.getItem(phaseProgrammingKey(pid,m));if(v)localStorage.setItem(pre+':phase:'+m+':'+pid,v)})
 })
}
function loadBlockIntoCurrent(id){
 const pre=blockPrefix(id), mode=localStorage.getItem(pre+':mode')||'draft';
 localStorage.setItem(programmingModeKey(),mode);
 ['active','draft'].forEach(m=>{
   const mv=localStorage.getItem(pre+':meta:'+m); if(mv)localStorage.setItem(programmingMetaKey(m),mv);
   const meta=mv?JSON.parse(mv):programmingMeta(m);
   phaseRanges(meta).forEach(q=>{const pid=phaseId(q),v=localStorage.getItem(pre+':phase:'+m+':'+pid);if(v)localStorage.setItem(phaseProgrammingKey(pid,m),v)})
 })
}
function selectFullBlock(id){const x=fullProgram();saveCurrentIntoBlock(x.selected);x.selected=id;saveFullProgram(x);loadBlockIntoCurrent(id);drawProgramming()}
function addFullBlock(){
 const x=fullProgram();saveCurrentIntoBlock(x.selected);const n=x.blocks.length+1,id='bloc-'+Date.now();
 const name=(prompt('Nom du nouveau bloc :',`Bloc ${roman(n)}`)||'').trim();if(!name)return;
 x.blocks.push({id,name});x.selected=id;saveFullProgram(x);
 localStorage.setItem(blockPrefix(id)+':mode','draft');
 localStorage.setItem(blockPrefix(id)+':meta:draft',JSON.stringify({name,duration:4,rhythm:4}));
 localStorage.setItem(programmingModeKey(),'draft');saveProgrammingMeta({name,duration:4,rhythm:4},'draft');
 const ph=phaseRanges({name,duration:4,rhythm:4});localStorage.setItem(phaseProgrammingKey(phaseId(ph[0]),'draft'),JSON.stringify(blankProgramming()));
 saveCurrentIntoBlock(id);drawProgramming()
}
function renameFullBlock(){const x=fullProgram(),b=x.blocks.find(z=>z.id===x.selected);if(!b)return;const n=(prompt('Nom du bloc :',b.name)||'').trim();if(!n)return;b.name=n;saveFullProgram(x);const m=programmingMeta();m.name=n;saveProgrammingMeta(m);saveCurrentIntoBlock(b.id);drawProgramming()}
function deleteFullBlock(){const x=fullProgram();if(x.blocks.length<=1)return alert('Le programme doit contenir au moins un bloc.');const b=x.blocks.find(z=>z.id===x.selected);if(!confirm(`Supprimer ${b?.name||'ce bloc'} ?`))return;x.blocks=x.blocks.filter(z=>z.id!==x.selected);x.selected=x.blocks[0].id;saveFullProgram(x);loadBlockIntoCurrent(x.selected);drawProgramming()}
function blockReadableData(id){
 const pre=blockPrefix(id), mode=localStorage.getItem(pre+':mode')||'draft', ms=localStorage.getItem(pre+':meta:'+mode);const meta=ms?JSON.parse(ms):{name:'Bloc',duration:4,rhythm:4};
 const phases=phaseRanges(meta).map(q=>{const pid=phaseId(q),raw=localStorage.getItem(pre+':phase:'+mode+':'+pid);let data=blankProgramming();try{if(raw)data=JSON.parse(raw)}catch(_){}return {q,data}});return {meta,phases}
}
async function generateCompleteProgram(){
 saveCurrentIntoBlock();const fp=fullProgram();
 const blocks=fp.blocks.map((b,i)=>({b,i,...blockReadableData(b.id)}));
 const W=1600, headerH=220, blockH=420, gap=28, H=headerH+blocks.length*(blockH+gap)+80;
 const c=document.createElement('canvas');c.width=W*2;c.height=H*2;const g=c.getContext('2d');g.scale(2,2);g.imageSmoothingEnabled=true;g.imageSmoothingQuality='high';
 const bg=g.createLinearGradient(0,0,0,H);bg.addColorStop(0,'#070604');bg.addColorStop(1,'#11100b');g.fillStyle=bg;g.fillRect(0,0,W,H);
 const gold='#e2bd70',white='#f7f1e6',muted='#bdb39f';
 const txt=(t,x,y,size,color=white,weight=700,align='left')=>{g.fillStyle=color;g.font=`${weight} ${size}px Arial`;g.textAlign=align;g.textBaseline='middle';g.fillText(String(t),x,y)};
 const fit=(t,x,y,max,size,color=white,weight=800,align='left')=>{let z=size;do{g.font=`${weight} ${z}px Arial`;if(g.measureText(String(t)).width<=max)break;z--}while(z>14);txt(t,x,y,z,color,weight,align)};
 fit((fp.name||'PROGRAMME FORGELAB').toUpperCase(),W/2,72,W-180,44,gold,900,'center');txt(`PROGRAMME COMPLET · ${blocks.length} BLOC${blocks.length>1?'S':''}`,W/2,128,18,muted,700,'center');g.strokeStyle='rgba(226,189,112,.55)';g.beginPath();g.moveTo(120,166);g.lineTo(W-120,166);g.stroke();
 blocks.forEach(({b,i,meta,phases})=>{const y=headerH+i*(blockH+gap);g.fillStyle='rgba(15,14,10,.98)';g.fillRect(55,y,W-110,blockH);g.strokeStyle='rgba(226,189,112,.55)';g.lineWidth=2;g.strokeRect(55,y,W-110,blockH);txt(`BLOC ${roman(i+1)}`,88,y+42,15,gold,900);fit((b.name||meta.name||`Cycle ${i+1}`).toUpperCase(),88,y+82,W-240,30,white,900);txt(`${meta.duration} semaines · trame ${meta.rhythm} + deload`,88,y+118,14,muted,600);
   let yy=y+160;phases.forEach(({q,data})=>{txt(`${q.label} · S${q.from}${q.to!==q.from?'–S'+q.to:''}`,88,yy,15,q.deload?muted:gold,800);yy+=28;const days=DAYS.filter(d=>(data[d]||[]).some(z=>+z.sets>0));const summary=days.map(d=>`${d}: ${(data[d]||[]).filter(z=>+z.sets>0).map(z=>`${z.muscle_name} ${z.sets}`).join(' · ')}`).join('   |   ');fit(summary||'Repos / récupération',88,yy,W-180,13,white,600);yy+=45;});
 });
 txt('DAILY WINS.',W/2,H-35,18,gold,900,'center');
 const blob=await new Promise(r=>c.toBlob(r,'image/png',1));if(!blob)return alert('Impossible de générer le programme complet.');const safe=String(fp.name||'programme_complet').replace(/[^a-z0-9]+/gi,'_'),file=new File([blob],`ForgeLab_${safe}_COMPLET.png`,{type:'image/png'});try{if(navigator.share&&navigator.canShare&&navigator.canShare({files:[file]})){await navigator.share({files:[file],title:`ForgeLab · ${fp.name||'Programme complet'}`});return}}catch(e){if(e?.name==='AbortError')return}const u=URL.createObjectURL(blob),w=window.open(u,'_blank');if(!w){const a=document.createElement('a');a.href=u;a.download=file.name;a.click()}setTimeout(()=>URL.revokeObjectURL(u),120000)
}

let programmingScreen='chooser';
const _drawProgrammingV1162=drawProgramming;
function drawProgrammingChooser(){
 const v=document.querySelector('#view');if(!v)return;ensureLegacyProgrammingDraftRegistered();recoverOrphanProgrammingDrafts();const active=programmingMeta('active'),drafts=draftRegistry();
 v.innerHTML=title('Programmation')+`<section class="program-choice-screen">
   <div class="program-choice-intro"><small>ESPACE PROGRAMMATION</small><strong>Quel programme veux-tu ouvrir ?</strong><span>Programme actif ou l’un de tes programmes en préparation.</span></div>
   <button type="button" class="program-choice-card active" data-program-choice="active"><span class="program-choice-icon">I</span><div><small>PROGRAMME ACTIF</small><strong>${esc(state.blockName||active.name||'Programme actif')}</strong><span>${state.blockDuration||active.duration} semaine${Number(state.blockDuration||active.duration)>1?'s':''} · ${nutritionLabel()}</span></div><b>›</b></button>
   <div class="program-draft-list">${drafts.map((d,i)=>`<div class="draft-choice-row"><button type="button" class="program-choice-card draft" data-program-draft-id="${esc(d.id)}"><span class="program-choice-icon">${roman(i+1)}</span><div><small>BROUILLON ${roman(i+1)}</small><strong>${esc(d.name||'Programme en préparation')}</strong><span>Programme indépendant · modifiable sans toucher à l’actif</span></div><b>›</b></button><button type="button" class="draft-delete-mini" data-program-draft-delete="${esc(d.id)}" aria-label="Supprimer ${esc(d.name||'ce brouillon')}">×</button></div>`).join('')}</div>
   <button type="button" class="program-new-draft" data-program-create-draft>＋ Nouveau brouillon</button>
   <div class="program-choice-foot"><i>DISCIPLINA · CONSTANTIA · PROGRESSUS</i></div>
 </section>`;
 v.querySelector('[data-program-choice="active"]').onclick=()=>{programBlockOpen=false;setSelectedDraftId('');programmingScreen='editor';setProgrammingMode('active')};
 v.querySelectorAll('[data-program-draft-id]').forEach(b=>b.onclick=()=>{programBlockOpen=false;setSelectedDraftId(b.dataset.programDraftId);programmingScreen='editor';setProgrammingMode('draft')});
 v.querySelectorAll('[data-program-draft-delete]').forEach(b=>b.onclick=e=>{e.stopPropagation();deleteProgrammingDraftById(b.dataset.programDraftDelete)});
 v.querySelector('[data-program-create-draft]').onclick=()=>createProgrammingDraft(true);
}
drawProgramming=function(){
 if(programmingScreen==='chooser'){drawProgrammingChooser();return}
 _drawProgrammingV1162();const v=document.querySelector('#view');if(!v)return;const fp=fullProgram(),sel=selectedFullBlock(); v.querySelectorAll('.program-status-card,.program-draft-actions').forEach(x=>x.remove());
 const back=document.createElement('button');back.type='button';back.className='program-back-choice';back.innerHTML='‹ <span>Programmation</span>';back.onclick=()=>{saveCurrentIntoBlock();if(programmingMode()==='draft'){const regs=draftRegistry(),r=regs.find(x=>x.id===selectedDraftId());if(r){r.name=fullProgram().name||r.name;saveDraftRegistry(regs)}}programmingScreen='chooser';drawProgramming()};
 const heading=v.querySelector('.section-title');if(heading)heading.insertAdjacentElement('afterend',back);else v.prepend(back);
 const host=document.createElement('section');host.className='full-program-manager';host.innerHTML=`<div class="full-program-head"><div><small>NOM DU PROGRAMME</small><strong>${esc(fp.name||'Programme ForgeLab')}</strong><input class="full-program-name" data-full-program-name value="${esc(fp.name||'Programme ForgeLab')}" aria-label="Nom du programme complet"></div><button data-full-add>+ Bloc</button></div><div class="full-block-tabs">${fp.blocks.map((b,i)=>`<button class="${b.id===fp.selected?'active':''}" data-full-block="${esc(b.id)}"><small>BLOC ${roman(i+1)}</small><b>${esc(b.name)}</b></button>`).join('')}</div><div class="full-program-actions"><button class="secondary" data-full-rename>Renommer le bloc</button><button class="secondary" data-full-delete>Supprimer</button><button data-full-current>Générer ce bloc</button><button class="gold" data-full-complete>Générer le programme complet</button></div>`;
 const anchor=v.querySelector('.program-mobile-steps')||v.firstChild;v.insertBefore(host,anchor);
 host.querySelector('[data-full-program-name]').addEventListener('change',e=>{const x=fullProgram();x.name=(e.target.value||'').trim()||'Programme ForgeLab';saveFullProgram(x);if(programmingMode()==='draft'){const regs=draftRegistry(),r=regs.find(z=>z.id===selectedDraftId());if(r){r.name=x.name;saveDraftRegistry(regs)}}drawProgramming()});host.querySelector('[data-full-add]').onclick=addFullBlock;host.querySelector('[data-full-rename]').onclick=renameFullBlock;host.querySelector('[data-full-delete]').onclick=deleteFullBlock;host.querySelector('[data-full-current]').onclick=()=>{saveCurrentIntoBlock();generateProgramImage()};host.querySelector('[data-full-complete]').onclick=generateCompleteProgram;host.querySelectorAll('[data-full-block]').forEach(x=>x.onclick=()=>selectFullBlock(x.dataset.fullBlock));
};

/* ===== ForgeLab v1.21.9 — Brouillon structuré : Programme > Trame > Blocs > Génération ===== */
let programBlockOpen=false;
function fl176TrameCount(fp){return Math.max(1,Number(fp?.trameBlocks||4))}
function fl176Schedule(totalDuration,blockLength){
  const length=Math.max(1,Number(blockLength)||4), total=Math.max(1,Number(totalDuration)||14);
  const out=[];let week=1,index=0;
  while(week<=total){
    const from=week,to=Math.min(total,week+length-1);
    out.push({kind:'block',index,from,to});
    week=to+1;
    if(week<=total){out.push({kind:'deload',index,from:week,to:week});week++;}
    index++;
  }
  return {total,items:out};
}
function fl176EnsureStructure(){
  const fp=fullProgram();
  if(!fp.totalDuration) fp.totalDuration=Math.max(1,Number(programmingMeta().duration||14));
  if(!fp.trameBlocks) fp.trameBlocks=Math.max(1,(fp.blocks||[]).filter(b=>!b.deload).length||3);
  const wanted=fl176TrameCount(fp), sched=fl176Schedule(fp.totalDuration,wanted);fp.totalDuration=sched.total;
  const visible=Array.isArray(fp.blocks)?fp.blocks:[], reserve=Array.isArray(fp.archivedBlocks)?fp.archivedBlocks:[], old=[...visible,...reserve.filter(x=>!visible.some(v=>v.id===x.id))], oldBlocks=old.filter(x=>!x.deload), oldDeloads=old.filter(x=>x.deload||/^deload/i.test(x.name||'')), next=[];
  sched.items.forEach(item=>{
    if(item.kind==='block'){
      let b=oldBlocks[item.index];
      if(!b)b={id:'bloc-'+Date.now().toString(36)+'-'+item.index,name:`Bloc ${roman(item.index+1)}`};
      b.deload=false;b.blockIndex=item.index+1;b.from=item.from;b.to=item.to;if(!b.name)b.name=`Bloc ${roman(item.index+1)}`;next.push(b);
    }else{
      let d=oldDeloads[item.index];
      if(!d)d={id:'deload-'+Date.now().toString(36)+'-'+item.index,name:`Deload ${roman(item.index+1)}`,deload:true};
      d.deload=true;d.blockIndex=item.index+1;d.name=`Deload ${roman(item.index+1)}`;d.from=item.from;d.to=item.to;next.push(d);
    }
  });
  const used=new Set(next.map(b=>b.id));fp.archivedBlocks=old.filter(b=>!used.has(b.id));fp.blocks=next;if(!next.some(b=>b.id===fp.selected))fp.selected=next[0].id;saveFullProgram(fp);
  next.forEach(b=>{const pre=blockPrefix(b.id);if(!localStorage.getItem(pre+':meta:draft'))localStorage.setItem(pre+':meta:draft',JSON.stringify({name:b.name,duration:1,rhythm:6}));});
  return fp;
}
function fl176RangeLabel(b){return b.from===b.to?`S${b.from}`:`S${b.from} à S${b.to}`}
function flActiveCurrentWeek(fp=flActiveProgram()){
  const total=Math.max(1,Number(fp?.totalDuration||state.blockDuration||1));
  const raw=String(fp?.startDate||'').trim();
  if(/^\d{4}-\d{2}-\d{2}$/.test(raw)){
    const [y,m,d]=raw.split('-').map(Number),start=new Date(y,m-1,d,12),now=new Date(),today=new Date(now.getFullYear(),now.getMonth(),now.getDate(),12);
    return Math.max(1,Math.min(total,Math.floor((today-start)/604800000)+1));
  }
  return Math.max(1,Math.min(total,Number(state.week)||1));
}
function flActiveCurrentBlock(fp=flActiveProgram()){
  const week=flActiveCurrentWeek(fp);
  return (fp?.blocks||[]).find(b=>week>=Number(b.from||1)&&week<=Number(b.to||b.from||1))||fp?.blocks?.[0]||null;
}
function flActiveBlockDisplayName(b,i=0){
  const n=Number(b?.blockIndex||i+1),raw=String(b?.name||'').trim();
  if(b?.deload)return `Deload ${n}`;
  if(!raw||/^cycle\s*(?:[ivxlcdm]+|\d+)$/i.test(raw)||/^bloc\s*(?:[ivxlcdm]+|\d+)$/i.test(raw))return `Bloc ${n}`;
  return raw;
}
function fl176BlockComplete(id){
  if(id===selectedFullBlock()?.id)saveCurrentIntoBlock(id);
  const r=blockReadableData(id);return r.phases.some(({data})=>DAYS.some(d=>(data[d]||[]).some(x=>Number(x.sets||0)>0)));
}
function fl176SetTrame(n){
  const fp=fullProgram();saveCurrentIntoBlock(fp.selected);fp.trameBlocks=Math.max(1,Math.min(8,Number(n)||3));saveFullProgram(fp);fl176EnsureStructure();const x=fullProgram();x.selected=x.blocks[0].id;saveFullProgram(x);loadBlockIntoCurrent(x.selected);programBlockOpen=false;drawProgramming();
}
function fl176SelectBlock(id){
  const fp=fullProgram();if(fp.selected===id){programBlockOpen=!programBlockOpen;drawProgramming();return}
  saveCurrentIntoBlock(fp.selected);fp.selected=id;saveFullProgram(fp);loadBlockIntoCurrent(id);programBlockOpen=true;drawProgramming();
}
function fl176RenameSelected(value){const fp=fullProgram(),b=fp.blocks.find(x=>x.id===fp.selected);if(!b||b.deload)return;b.name=(value||'').trim()||b.name;saveFullProgram(fp);saveProgrammingMeta({name:b.name,duration:1,rhythm:6},programmingMode());saveCurrentIntoBlock(b.id)}
function fl176GenerateBlock(id){const fp=fullProgram();if(fp.selected!==id){saveCurrentIntoBlock(fp.selected);fp.selected=id;saveFullProgram(fp);loadBlockIntoCurrent(id)}generateProgramImage()}
function forgeSeriesResetPendingKey(){return `forgelabSeriesResetPending:${currentUser?.id||'guest'}`}
function forgeResetActiveCardioWeekProgress(){
  const key=`forgelabMobileCardio:${currentUser?.id||'guest'}`;
  try{const x=JSON.parse(localStorage.getItem(key)||'null');if(x&&typeof x==='object'){x.weeks={};localStorage.setItem(key,JSON.stringify(x))}}catch(_){}
}
async function forgeResetSeriesForNewActiveProgram(){
  // Nouveau programme actif = nouveau compteur Séries. Les Archives / séances validées restent intactes.
  state.series=[];
  Object.values(saveTimers||{}).forEach(t=>clearTimeout(t));saveTimers={};saveState={};
  try{localStorage.removeItem(seriesPendingKey())}catch(_){}
  forgeResetActiveCardioWeekProgress();
  const marker=forgeSeriesResetPendingKey();localStorage.setItem(marker,String(Date.now()));
  try{
    await req(`/forgelab_series?user_id=eq.${encodeURIComponent(uid())}&block_key=eq.main`,{method:'DELETE',headers:{Prefer:'return=minimal'}});
    localStorage.removeItem(marker);
  }catch(e){console.error('Reset Séries différé',e)}
}
async function forgeRetryPendingSeriesReset(){
  const marker=forgeSeriesResetPendingKey();if(!localStorage.getItem(marker))return;
  try{await req(`/forgelab_series?user_id=eq.${encodeURIComponent(uid())}&block_key=eq.main`,{method:'DELETE',headers:{Prefer:'return=minimal'}});state.series=[];localStorage.removeItem(marker)}catch(e){console.error('Reset Séries toujours en attente',e)}
}
function forgeV1268InitialSeriesResetKey(){return `forgelabV1268InitialSeriesReset:${currentUser?.id||'guest'}`}
async function forgeApplyV1268InitialSeriesResetOnce(){
  const key=forgeV1268InitialSeriesResetKey();if(localStorage.getItem(key)==='1')return;
  await forgeResetSeriesForNewActiveProgram();
  localStorage.setItem(key,'1');
}
async function activateFullProgrammingDraft(){
  if(programmingMode()!=='draft'||!selectedDraftId())return;
  saveCurrentIntoBlock();
  const draftId=selectedDraftId(),uidKey=currentUser?.id||'guest',fp=fullProgram();
  const now=new Date();
  const startDate=String(fp.startDate||'').trim();
  if(!/^\d{4}-\d{2}-\d{2}$/.test(startDate)){alert('Renseigne d’abord la date de début du programme dans « Structure du programme ». Cette date correspond au premier jour de S1.');return}
  if(!confirm(`Rendre « ${fp.name||'ce brouillon'} » actif ?\n\nS1 débutera le ${startDate.split('-').reverse().join('/')}. Le programme actif actuel sera remplacé. Ton brouillon et tes paramètres existants sont conservés.`))return;
  // Snapshot analytique additif : conserve le périmètre de l'ancien programme pour les comparaisons futures.
  // Aucune séance, série ou archive n'est modifiée.
  flAnalysisArchiveActiveProgram();
  // Replace the complete active-program namespace with the selected draft.
  const activeFullKey=`forgelabFullProgram:${uidKey}:active`;
  const activeBlockPrefix=`forgelabProgramBlock:${uidKey}:active:`;
  for(let i=localStorage.length-1;i>=0;i--){const k=localStorage.key(i);if(k&&(k===activeFullKey||k.startsWith(activeBlockPrefix)))localStorage.removeItem(k)}
  const activeFp=structuredClone(fp);activeFp.startDate=startDate;activeFp.selected=activeFp.blocks[0]?.id||fp.selected;localStorage.setItem(activeFullKey,JSON.stringify(activeFp));
  fp.blocks.forEach(b=>{
    const src=`forgelabProgramBlock:${uidKey}:draft:${draftId}:${b.id}`;
    const dst=`forgelabProgramBlock:${uidKey}:active:${b.id}`;
    const entries=[];for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k&&k.startsWith(src+':'))entries.push([k,localStorage.getItem(k)])}
    entries.forEach(([k,val])=>{let suffix=k.slice(src.length);suffix=suffix.replace(/:mode$/,':mode').replace(/:meta:draft/g,':meta:active').replace(/:phase:draft:/g,':phase:active:');if(suffix===':mode')val='active';localStorage.setItem(dst+suffix,val)});
    // Canonicalise explicitement le contenu du brouillon vers le bloc actif.
    const draftMeta=localStorage.getItem(src+':meta:draft');if(draftMeta)localStorage.setItem(dst+':meta:active',draftMeta);
    if(draftMeta){try{const dm=JSON.parse(draftMeta);phaseRanges(dm).forEach(q=>{const pid=phaseId(q),raw=localStorage.getItem(src+':phase:draft:'+pid);if(raw)localStorage.setItem(dst+':phase:active:'+pid,raw)})}catch(_){}}
    localStorage.setItem(dst+':mode','active');
  });
  // v1.21.9 : conserver aussi les notes et la trame cardio propres à chaque bloc lors de l'activation.
  fp.blocks.forEach(b=>{
    const draftScope=`${uidKey}:draft:${draftId}:${b.id}`,activeScope=`${uidKey}:active:${b.id}`;
    const notes=localStorage.getItem(`forgelabBlockNotes:${draftScope}`);if(notes!==null)localStorage.setItem(`forgelabBlockNotes:${activeScope}`,notes);
    const tpl=localStorage.getItem(`forgelabCardioTemplate:${draftScope}`);if(tpl!==null)localStorage.setItem(`forgelabCardioTemplate:${activeScope}`,tpl);
  });
  // Load the first block into the active working area so the active screen immediately reflects the new program.
  const first=activeFp.blocks[0];if(first){const src=`forgelabProgramBlock:${uidKey}:active:${first.id}`,metaRaw=localStorage.getItem(src+':meta:active');if(metaRaw){localStorage.setItem(`forgelabMobileProgrammingMeta:${uidKey}:active`,metaRaw);try{const meta=JSON.parse(metaRaw);phaseRanges(meta).forEach(q=>{const pid=phaseId(q),raw=localStorage.getItem(src+':phase:active:'+pid);if(raw)localStorage.setItem(`${programmingKey()}:phase:${pid}`,raw)})}catch(_){}}}
  // Le planning cardio du brouillon est copié séparément, sans effacer le brouillon source.
  const draftCardio=localStorage.getItem(`forgelabProgrammingCardio:${uidKey}:draft:${draftId}`);if(draftCardio)localStorage.setItem(`forgelabProgrammingCardio:${uidKey}:active`,draftCardio);
  state.blockName=fp.name||state.blockName;state.blockDuration=Number(fp.totalDuration||state.blockDuration||14);
  const [sy,sm,sd]=startDate.split('-').map(Number),start=new Date(sy,sm-1,sd,12),diff=Math.floor((new Date(now.getFullYear(),now.getMonth(),now.getDate(),12)-start)/604800000);state.week=Math.max(1,Math.min(state.blockDuration,diff+1));state.userWeek=state.week;
  await forgeResetSeriesForNewActiveProgram();
  req(`/forgelab_state?id=eq.main&user_id=eq.${encodeURIComponent(uid())}`,{method:'PATCH',headers:{Prefer:'return=minimal'},body:JSON.stringify({active_week:state.week,block_duration:state.blockDuration,block_name:state.blockName,updated_at:new Date().toISOString()})}).catch(()=>{});
  localStorage.setItem(programmingModeKey(),'active');setSelectedDraftId('');programBlockOpen=false;programmingScreen='editor';drawProgramming();
}
const _drawProgrammingV1175=drawProgramming;
function fl184ProgrammingWeeks(duration){
  const d=document.querySelector('#weekDots');if(!d)return;
  const count=Math.max(1,Math.min(52,Number(duration)||1));
  if(state.week>count)state.week=count;
  d.style.setProperty('--week-count',String(count));
  d.innerHTML=Array.from({length:count},(_,i)=>`<button class="${state.week===i+1?'active':''}" data-w="${i+1}">${i+1}</button>`).join('');
  d.querySelectorAll('button').forEach(b=>b.onclick=()=>setWeek(+b.dataset.w));
  d.hidden=false;d.style.removeProperty('display');
}
drawProgramming=function(){
  if(programmingScreen==='chooser'){drawProgrammingChooser();return}
  _drawProgrammingV1162();const v=document.querySelector('#view');if(!v)return;
  const mode=programmingMode();if(mode!=='draft'){
    v.querySelectorAll('.program-status-card,.program-draft-actions').forEach(x=>x.remove());
    // Active program: manual programming only.
    v.querySelector('[data-program-auto]')?.closest('.program-mobile-actions')?.remove();
    v.querySelector('.program-mobile-note')?.remove();
    const back=document.createElement('button');back.type='button';back.className='program-back-choice';back.innerHTML='‹ <span>Programmation</span>';back.onclick=()=>{saveCurrentIntoBlock();programmingScreen='chooser';drawProgramming()};const h=v.querySelector('.section-title');h?h.insertAdjacentElement('afterend',back):v.prepend(back);
    const activeFp=fullProgram();fl184ProgrammingWeeks(activeFp?.totalDuration||state.blockDuration||programmingMeta('active').duration);
    // v1.21.9 : le programme actif reprend la même architecture par blocs que le brouillon.
    const sel=selectedFullBlock(),currentBlock=flActiveCurrentBlock(activeFp),currentWeek=flActiveCurrentWeek(activeFp);
    const legacySteps=v.querySelector('.program-mobile-steps');
    const currentBanner=v.querySelector('.program-current-banner span');
    if(currentBanner&&currentBlock)currentBanner.textContent=`${flActiveBlockDisplayName(currentBlock)} · ${fl176RangeLabel(currentBlock)}`;
    const phaseStrip=v.querySelector('.program-phase-strip');
    if(phaseStrip){
      phaseStrip.classList.add('fl-active-block-strip');
      phaseStrip.innerHTML=activeFp.blocks.map((b,i)=>{const current=b.id===currentBlock?.id;return `<span class="${b.deload?'deload ':''}${current?'current':''}"><strong>${b.deload?`DELOAD ${Number(b.blockIndex||i+1)}`:`BLOC ${Number(b.blockIndex||i+1)}`}</strong><b>${fl176RangeLabel(b)}</b>${current?'<em>EN COURS</em>':''}</span>`}).join('');
    }
    v.querySelector('.program-phase-toolbar')?.remove();
    const manager=document.createElement('section');manager.className='fl176-panel fl176-block-manager fl-active-block-manager';
    manager.innerHTML=`<div class="fl176-panel-title fl-active-program-title"><div class="fl-active-program-title-copy"><small>PROGRAMME ACTIF</small><strong>${esc(activeFp.name||'Programme ForgeLab')}</strong>${activeFp.startDate?`<span>Début S1 · ${esc(activeFp.startDate.split('-').reverse().join('/'))} · S${currentWeek} en cours</span>`:''}</div><button type="button" class="fl-antique-edit" data-fl-active-edit aria-label="Modifier le programme actif"><span class="fl-calame" aria-hidden="true"><i></i></span><b>Modifier</b></button></div><div class="fl-active-program-edit" data-fl-active-edit-panel hidden><label><span>Nom du programme</span><input data-fl-active-name value="${esc(activeFp.name||'Programme ForgeLab')}"></label><label><span>Date de début</span><input type="date" data-fl-active-date value="${esc(activeFp.startDate||'')}"></label><label><span>Durée totale</span><div class="fl-active-duration"><input type="number" min="1" max="52" data-fl-active-duration value="${Number(activeFp.totalDuration||state.blockDuration||14)}"><b>semaines</b></div></label><div class="fl-active-edit-actions"><button type="button" data-fl-active-cancel>Annuler</button><button type="button" class="save" data-fl-active-save>Enregistrer</button></div></div><div class="fl176-block-list">${activeFp.blocks.map((b,i)=>{const open=b.id===activeFp.selected&&programBlockOpen,current=b.id===currentBlock?.id,name=flActiveBlockDisplayName(b,i);return `<div class="fl179-block-slot ${open?'open ':''}${current?'fl-active-current':''}" data-fl179-slot="${esc(b.id)}"><button type="button" class="fl176-block-card ${b.deload?'deload ':''}${open?'open ':''}${current?'fl-active-current':''}" data-fl176-block="${esc(b.id)}"><span><small>${b.deload?`DELOAD ${Number(b.blockIndex||i+1)}`:`BLOC ${Number(b.blockIndex||i+1)}`}</small><strong>${fl176RangeLabel(b)}</strong></span><em>${current?'EN COURS':'EN ATTENTE'}</em><b>${open?'⌃':'⌄'}</b></button>${open?`<div class="fl176-open-block ${current?'fl-active-current':''}"><div><small>${fl176RangeLabel(b)}</small><strong>${esc(name)}${current?' · EN COURS':''}</strong></div></div><div class="fl179-inline-program" data-fl179-inline-program></div>`:''}</div>`}).join('')}</div>`;
    const anchor=legacySteps||v.firstChild;v.insertBefore(manager,anchor);
    const dailyNodes=[legacySteps,v.querySelector('.program-mobile-intro'),v.querySelector('.program-mobile-library'),v.querySelector('.program-mobile-kpis'),v.querySelector('.program-mobile-days'),v.querySelector('.program-mobile-summary'),v.querySelector('.program-mobile-grid'),v.querySelector('.program-summary')].filter(Boolean);
    if(!programBlockOpen){dailyNodes.forEach(n=>n.remove())}else{const inline=manager.querySelector('[data-fl179-inline-program]');if(inline)dailyNodes.forEach(n=>inline.appendChild(n))}
    const editBtn=manager.querySelector('[data-fl-active-edit]'),editPanel=manager.querySelector('[data-fl-active-edit-panel]');
    editBtn?.addEventListener('click',()=>{if(editPanel)editPanel.hidden=!editPanel.hidden});
    manager.querySelector('[data-fl-active-cancel]')?.addEventListener('click',()=>{if(editPanel)editPanel.hidden=true});
    manager.querySelector('[data-fl-active-save]')?.addEventListener('click',async()=>{
      const fpNow=flActiveProgram();if(!fpNow)return;
      const name=(manager.querySelector('[data-fl-active-name]')?.value||'').trim()||'Programme ForgeLab';
      const startDate=(manager.querySelector('[data-fl-active-date]')?.value||'').trim();
      const totalDuration=Math.max(1,Math.min(52,Number(manager.querySelector('[data-fl-active-duration]')?.value)||Number(fpNow.totalDuration)||14));
      if(startDate&&!/^\d{4}-\d{2}-\d{2}$/.test(startDate)){alert('Date de début invalide.');return}
      const previousDuration=Math.max(1,Number(fpNow.totalDuration||14));
      if(totalDuration<previousDuration&&!confirm(`Réduire le programme de ${previousDuration} à ${totalDuration} semaines ?\n\nLes blocs hors de la nouvelle durée seront masqués mais leurs données resteront conservées.`))return;
      fpNow.name=name;fpNow.startDate=startDate;fpNow.totalDuration=totalDuration;
      localStorage.setItem(`forgelabFullProgram:${currentUser?.id||'guest'}:active`,JSON.stringify(fpNow));
      const rebuilt=fl176EnsureStructure();
      state.blockName=rebuilt.name||name;state.blockDuration=Math.max(1,Number(rebuilt.totalDuration||totalDuration));state.week=flActiveCurrentWeek(rebuilt);state.userWeek=state.week;
      try{await req(`/forgelab_state?id=eq.main&user_id=eq.${encodeURIComponent(uid())}`,{method:'PATCH',headers:{Prefer:'return=minimal'},body:JSON.stringify({active_week:state.week,block_duration:state.blockDuration,block_name:state.blockName,updated_at:new Date().toISOString()})})}catch(_){ }
      drawProgramming();
    });
    manager.querySelectorAll('[data-fl176-block]').forEach(b=>b.onclick=()=>fl176SelectBlock(b.dataset.fl176Block));
    // v1.27.1 : l'export global est la toute dernière action de la page Programmation active.
    v.querySelectorAll('.fl-program-bottom-export').forEach(x=>x.remove());
    const programBottomExport=document.createElement('section');
    programBottomExport.className='fl-program-bottom-export';
    programBottomExport.innerHTML='<button type="button" data-program-pdf-bottom>Exporter le bilan complet</button>';
    v.appendChild(programBottomExport);
    programBottomExport.querySelector('[data-program-pdf-bottom]').addEventListener('click',exportProgramPdf);
    return;
  }
  let fp=fl176EnsureStructure(),sel=selectedFullBlock();fl184ProgrammingWeeks(fp.totalDuration||programmingMeta('draft').duration);
  // Remove legacy duplicated controls / nested phase UI / exports.
  v.querySelectorAll('.program-status-card,.program-draft-actions,.program-current-banner,.program-meta-edit,.program-export-actions,.program-phase-strip,.program-phase-toolbar').forEach(x=>x.remove());
  const back=document.createElement('button');back.type='button';back.className='program-back-choice';back.innerHTML='‹ <span>Programmation</span>';back.onclick=()=>{saveCurrentIntoBlock();const regs=draftRegistry(),r=regs.find(x=>x.id===selectedDraftId());if(r){r.name=fullProgram().name||r.name;saveDraftRegistry(regs)}programmingScreen='chooser';drawProgramming()};const heading=v.querySelector('.section-title');heading?heading.insertAdjacentElement('afterend',back):v.prepend(back);
  const legacySteps=v.querySelector('.program-mobile-steps');
  const config=document.createElement('section');config.className='fl176-panel fl176-program-config';config.innerHTML=`<div class="fl176-panel-title"><small>I · PROGRAMME COMPLET</small><strong>Structure du programme</strong></div><div class="fl176-config-grid"><label><span>Nom du programme</span><input data-fl176-name value="${esc(fp.name||'Programme ForgeLab')}"></label><label><span>Durée totale</span><div class="fl176-duration"><input type="number" min="1" max="52" data-fl176-duration value="${Number(fp.totalDuration||14)}"><b>semaines</b></div></label><label class="wide fl1218-start-date"><span>Date de début du programme</span><div class="fl1218-date-row"><input type="date" data-fl176-start-date value="${esc(fp.startDate||'')}" aria-label="Date de début du programme"><b>${fp.startDate?`S1 débute le ${esc(fp.startDate.split('-').reverse().join('/'))}`:'À renseigner avant activation'}</b></div><small>Cette date correspond au premier jour de S1 et pilote toutes les dates du programme.</small></label><label class="wide"><span>Trame</span><select data-fl176-trame>${[2,3,4,5,6].map(n=>`<option value="${n}" ${n===fl176TrameCount(fp)?'selected':''}>${n} semaines par bloc + deload</option>`).join('')}</select></label></div><div class="fl176-trame-preview">${fp.blocks.map(b=>`<span class="${b.deload?'deload':''}"><strong>${b.deload?`DELOAD ${roman(b.blockIndex)}`:`BLOC ${roman(b.blockIndex)}`}</strong><b>${fl176RangeLabel(b)}</b></span>`).join('<i>›</i>')}</div>`;
  const blocks=document.createElement('section');blocks.className='fl176-panel fl176-block-manager';blocks.innerHTML=`<div class="fl176-panel-title"><small>II · PARAMÉTRAGE DES BLOCS</small><strong>Choisis un bloc à programmer</strong></div><div class="fl176-block-list">${fp.blocks.map((b,i)=>{const ok=fl176BlockComplete(b.id),active=b.id===fp.selected&&programBlockOpen;return `<div class="fl179-block-slot ${active?'open':''}" data-fl179-slot="${esc(b.id)}"><button type="button" class="fl176-block-card ${b.deload?'deload':''} ${active?'open':''}" data-fl176-block="${esc(b.id)}"><span><small>${b.deload?`DELOAD ${roman(b.blockIndex)}`:`BLOC ${roman(b.blockIndex)}`}</small><strong>${fl176RangeLabel(b)}</strong></span><em class="${ok?'ok':''}">${ok?'Paramétré':'À paramétrer'}</em><b>${active?'⌃':'⌄'}</b></button>${active?`<div class="fl176-open-block"><div><small>${sel.deload?`DELOAD ${roman(sel.blockIndex)}`:`BLOC ${roman(sel.blockIndex)}`} · ${fl176RangeLabel(sel)}</small>${sel.deload?`<strong>Deload</strong>`:`<label>Nom du bloc<input data-fl176-block-name value="${esc(sel.name)}"></label>`}</div></div><div class="fl179-inline-program" data-fl179-inline-program></div>`:''}</div>`}).join('')}</div>`;
  const generation=document.createElement('section');generation.className='fl176-panel fl176-generation fl180-generation';const statuses=fp.blocks.map(b=>fl176BlockComplete(b.id)),allOk=statuses.every(Boolean);generation.innerHTML=`<div class="fl176-panel-title"><small>III · GÉNÉRATION</small><strong>Générer une image</strong></div><div class="fl180-generate-row"><select data-fl180-generation-choice aria-label="Élément à générer">${fp.blocks.map((b,i)=>`<option value="${esc(b.id)}" ${statuses[i]?'':'disabled'}>${b.deload?`Deload ${roman(b.blockIndex)}`:`Bloc ${roman(b.blockIndex)}`} · ${fl176RangeLabel(b)}${statuses[i]?'':' · à paramétrer'}</option>`).join('')}<option value="__complete__" ${allOk?'':'disabled'}>Programme complet${allOk?'':' · incomplet'}</option></select><button type="button" data-fl180-generate>Générer</button></div>${allOk?'':`<p>Les éléments non paramétrés restent indisponibles.</p>`}<div class="fl180-activate-wrap"><button type="button" class="fl180-activate" data-fl180-activate>Rendre ce brouillon actif</button><small>Remplace le programme actif après confirmation.</small></div>`;
  const anchor=legacySteps||v.firstChild;v.insertBefore(config,anchor);v.insertBefore(blocks,anchor);
  // Draft UX: no automatic priority distribution. Keep only the block-save action.
  v.querySelector('.program-mobile-actions')?.remove();
  v.querySelector('.program-mobile-note')?.remove();
  const lib=v.querySelector('.program-mobile-library');
  if(lib){
    lib.classList.add('fl179-save-only');
    lib.querySelector('div:first-child')?.remove();
    lib.querySelector('[data-program-preset]')?.remove();
    lib.querySelector('.program-preset-actions')?.remove();
    lib.querySelector('p')?.remove();
    const saveBtn=lib.querySelector('[data-program-save-preset]');if(saveBtn)saveBtn.textContent='Enregistrer le bloc';
  }
  // Daily programming is injected immediately below the block the user opened.
  const dailyNodes=[legacySteps,v.querySelector('.program-mobile-intro'),lib,v.querySelector('.program-mobile-kpis'),v.querySelector('.program-mobile-days'),v.querySelector('.program-mobile-summary'),v.querySelector('.program-mobile-grid'),v.querySelector('.program-summary')].filter(Boolean);
  if(!programBlockOpen){dailyNodes.forEach(n=>n.remove());v.appendChild(generation)}else{
    const inline=blocks.querySelector('[data-fl179-inline-program]');
    if(inline)dailyNodes.forEach(n=>inline.appendChild(n));
    v.appendChild(generation);
  }
  config.querySelector('[data-fl176-name]').onchange=e=>{fp=fullProgram();fp.name=(e.target.value||'').trim()||'Programme ForgeLab';saveFullProgram(fp);const regs=draftRegistry(),r=regs.find(x=>x.id===selectedDraftId());if(r){r.name=fp.name;saveDraftRegistry(regs)}drawProgramming()};
  config.querySelector('[data-fl176-duration]').onchange=e=>{fp=fullProgram();fp.totalDuration=Math.max(1,Math.min(52,Number(e.target.value)||14));saveFullProgram(fp);fl176EnsureStructure();programBlockOpen=false;drawProgramming()};
  config.querySelector('[data-fl176-start-date]').onchange=e=>{fp=fullProgram();const value=(e.target.value||'').trim();if(value&&!/^\d{4}-\d{2}-\d{2}$/.test(value))return;fp.startDate=value;saveFullProgram(fp)};
  config.querySelector('[data-fl176-trame]').onchange=e=>fl176SetTrame(e.target.value);
  blocks.querySelectorAll('[data-fl176-block]').forEach(b=>b.onclick=()=>fl176SelectBlock(b.dataset.fl176Block));
  blocks.querySelector('[data-fl176-block-name]')?.addEventListener('change',e=>{fl176RenameSelected(e.target.value);drawProgramming()});
  generation.querySelector('[data-fl180-generate]')?.addEventListener('click',()=>{const choice=generation.querySelector('[data-fl180-generation-choice]')?.value;if(!choice)return;if(choice==='__complete__'){saveCurrentIntoBlock();generateCompleteProgram()}else fl176GenerateBlock(choice)});
  generation.querySelector('[data-fl180-activate]')?.addEventListener('click',activateFullProgrammingDraft);
};

/* ===== ForgeLab v1.21.9 — Cardio du bloc : trame uniquement, séance dans Séries ===== */
function flCardioScope(mode=programmingMode()){
  const uidKey=currentUser?.id||'guest',draft=mode==='draft'?':draft:'+(selectedDraftId()||'default'):':active',block=selectedFullBlock()?.id||'bloc-1';
  return `${uidKey}${draft}:${block}`;
}
function flCardioTemplateKey(){return `forgelabCardioTemplate:${flCardioScope()}`}
function flCardioWeeksKey(){return `forgelabCardioWeeks:${flCardioScope()}`}
function flCardioTemplate(){
  try{const x=JSON.parse(localStorage.getItem(flCardioTemplateKey())||'null');if(x&&Array.isArray(x.items))return x}catch(_){}
  // Migration non destructive : si du cardio jour-par-jour existait déjà, on s'en sert seulement pour préremplir la trame.
  const legacy=programCardioData(),seen=new Set(),items=[];
  DAYS.forEach(day=>(legacy[day]||[]).forEach(c=>{const sig=[c.quality,c.engine,c.format].join('|');if(!seen.has(sig)){seen.add(sig);items.push({id:cardioModalityId(),quality:c.quality,engine:c.engine,format:c.format,target:1})}}));
  return {items:items.length?items:[{id:cardioModalityId(),quality:CARDIO_QUALITIES[0],engine:'Run',format:'Continu',target:1}]};
}
function flSaveCardioTemplate(x){localStorage.setItem(flCardioTemplateKey(),JSON.stringify(x))}
function flCardioWeeks(){try{const x=JSON.parse(localStorage.getItem(flCardioWeeksKey())||'{}');return x&&typeof x==='object'?x:{}}catch(_){return {}}}
function flSaveCardioWeeks(x){localStorage.setItem(flCardioWeeksKey(),JSON.stringify(x))}
function flSelectedBlockWeeks(){const b=selectedFullBlock();return {from:Math.max(1,+b?.from||1),to:Math.max(1,+b?.to||+b?.from||1)}}
function flCardioWeekSelectedKey(){return `forgelabCardioWeekSelected:${flCardioScope()}`}
function flCardioWeekSelected(){const r=flSelectedBlockWeeks(),n=+localStorage.getItem(flCardioWeekSelectedKey());return n>=r.from&&n<=r.to?n:r.from}
function flSetCardioWeekSelected(n){localStorage.setItem(flCardioWeekSelectedKey(),String(n));drawProgramming()}
function flCardioPlanFromTemplate(){return flCardioTemplate().items.flatMap(t=>Array.from({length:Math.max(0,+t.target||0)},()=>({id:cardioModalityId(),day:'',quality:t.quality,engine:t.engine,format:t.format,duration:t.quality==='🟢 Base aérobie'?40:0,target:''})))}
function flCardioProgressivePanel(){
  const tpl=flCardioTemplate();
  const rows=tpl.items.map(t=>`<div class="fl-cardio-template-row" data-fl-cardio-template-id="${esc(t.id)}"><select data-flct-quality>${CARDIO_QUALITIES.map(x=>`<option ${x===t.quality?'selected':''}>${esc(x)}</option>`).join('')}</select><select data-flct-engine>${CARDIO_ENGINES.map(x=>`<option ${x===t.engine?'selected':''}>${esc(x)}</option>`).join('')}</select><select data-flct-format>${CARDIO_FORMATS.map(x=>`<option ${x===t.format?'selected':''}>${esc(x)}</option>`).join('')}</select><label class="fl-cardio-frequency"><button type="button" data-flct-minus>−</button><strong>${+t.target||0}</strong><span>/ sem.</span><button type="button" data-flct-plus>+</button></label>${tpl.items.length>1?'<button type="button" class="fl-cardio-x" data-flct-remove>×</button>':''}</div>`).join('');
  return `<section class="fl-cardio-progressive"><div class="fl-cardio-title"><div><small>♥ CARDIO · ${esc(selectedFullBlock()?.name||'BLOC')}</small><strong>Trame du bloc</strong><span>Définis ici uniquement le thème et la fréquence. La séance concrète se paramètre dans Séries.</span></div><button type="button" data-flct-add>＋</button></div><div class="fl-cardio-template-list">${rows}</div></section>`;
}
function flWireCardioProgressive(v){
  v.querySelector('[data-flct-add]')?.addEventListener('click',()=>{const x=flCardioTemplate();x.items.push({id:cardioModalityId(),quality:CARDIO_QUALITIES[0],engine:'Run',format:'Continu',target:1});flSaveCardioTemplate(x);drawProgramming()});
  v.querySelectorAll('[data-fl-cardio-template-id]').forEach(row=>{const id=row.dataset.flCardioTemplateId;const mutate=fn=>{const x=flCardioTemplate(),t=x.items.find(a=>a.id===id);if(t){fn(t,x);flSaveCardioTemplate(x);drawProgramming()}};row.querySelector('[data-flct-quality]').onchange=e=>mutate(t=>t.quality=e.target.value);row.querySelector('[data-flct-engine]').onchange=e=>mutate(t=>t.engine=e.target.value);row.querySelector('[data-flct-format]').onchange=e=>mutate(t=>t.format=e.target.value);row.querySelector('[data-flct-minus]').onclick=()=>mutate(t=>t.target=Math.max(0,(+t.target||0)-1));row.querySelector('[data-flct-plus]').onclick=()=>mutate(t=>t.target=Math.min(7,(+t.target||0)+1));row.querySelector('[data-flct-remove]')?.addEventListener('click',()=>{const x=flCardioTemplate();x.items=x.items.filter(a=>a.id!==id);flSaveCardioTemplate(x);drawProgramming()})});
}
const _drawProgrammingCardioProgressive=drawProgramming;
drawProgramming=function(){
  _drawProgrammingCardioProgressive();
  if(programmingScreen==='chooser')return;
  const v=document.querySelector('#view');if(!v)return;
  // L'ancien cardio jour-par-jour reste en stockage pour compatibilité, mais n'est plus l'interface de programmation.
  v.querySelectorAll('.program-cardio-day').forEach(x=>x.remove());
  const days=v.querySelector('.mobile-program-days')||v.querySelector('.program-mobile-days')||v.querySelector('.fl176-block-editor');
  if(days){const wrap=document.createElement('div');wrap.innerHTML=flCardioProgressivePanel();const panel=wrap.firstElementChild;days.insertAdjacentElement('afterend',panel);flWireCardioProgressive(v)}
}

/* ===== ForgeLab v1.21.9 — Focus bloc + notes libres ===== */
function flBlockNotesKey(){return `forgelabBlockNotes:${flCardioScope()}`}
function flBlockNotes(){return localStorage.getItem(flBlockNotesKey())||''}
function flSaveBlockNotes(value){localStorage.setItem(flBlockNotesKey(),String(value||''))}
const _drawProgrammingBlockFocus=drawProgramming;
drawProgramming=function(){
  _drawProgrammingBlockFocus();
  if(programmingScreen==='chooser'||!programBlockOpen)return;
  const v=document.querySelector('#view');if(!v)return;
  const sel=selectedFullBlock();if(!sel)return;
  // En mode « Paramétrer », l'écran est volontairement consacré au bloc ouvert.
  v.querySelector('.fl176-program-config')?.remove();
  v.querySelector('.fl176-generation')?.remove();
  v.querySelectorAll('.program-mobile-summary,.program-summary,.program-mobile-kpis').forEach(x=>x.remove());
  const manager=v.querySelector('.fl176-block-manager');
  if(manager){
    manager.querySelector('.fl176-panel-title')?.remove();
    manager.querySelectorAll('[data-fl179-slot]').forEach(slot=>{if(slot.dataset.fl179Slot!==sel.id)slot.remove()});
    const card=[...manager.querySelectorAll('[data-fl176-block]')].find(x=>x.dataset.fl176Block===sel.id);if(card){const em=card.querySelector('em');if(em)em.textContent='Paramétrage du bloc';}
  }
  const cardio=v.querySelector('.fl-cardio-progressive');
  const inline=v.querySelector('[data-fl179-inline-program]')||manager;
  if(!inline)return;
  const notes=document.createElement('section');notes.className='fl-block-notes';notes.innerHTML=`<div class="fl-block-notes-head"><small>NOTES DU BLOC</small><strong>Contexte & repères</strong><span>Texte libre · sauvegarde automatique</span></div><textarea data-fl-block-notes maxlength="3000" placeholder="Ex. Maintien calorique · objectif du bloc · récupération · contraintes…">${esc(flBlockNotes())}</textarea>`;
  const activeMode=programmingMode()==='active',activeFp=activeMode?flActiveProgram():null;
  let legacyDate=null;
  // Ancien bloc actif sans date programme : autoriser UNE date locale au bloc pour pouvoir clôturer/exporter ce bilan.
  if(activeMode&&(!activeFp?.startDate||!/^\d{4}-\d{2}-\d{2}$/.test(activeFp.startDate))){
    legacyDate=document.createElement('section');legacyDate.className='fl-block-legacy-date';legacyDate.innerHTML=`<div><small>EXPORT · ANCIEN BLOC</small><strong>Date de début de ce bloc</strong><span>Utilisée uniquement pour calculer la période de ce bilan.</span></div><input type="date" data-fl-legacy-block-date value="${esc(sel.exportStartDate||'')}">`;
  }
  const actions=document.createElement('section');actions.className='fl-block-focus-actions';actions.innerHTML=`<button type="button" class="gold" data-fl-block-generate>Générer l’image de ce bloc</button>${activeMode?'':'<button type="button" class="fl-block-activate" data-fl-block-activate>Rendre ce brouillon actif</button><small class="fl-block-activate-note">Le programme actif sera remplacé après confirmation. Le brouillon reste conservé.</small>'}`;
  (cardio||inline.lastElementChild)?.insertAdjacentElement('afterend',notes);
  if(legacyDate){notes.insertAdjacentElement('afterend',legacyDate);legacyDate.insertAdjacentElement('afterend',actions)}else notes.insertAdjacentElement('afterend',actions);
  notes.querySelector('[data-fl-block-notes]').addEventListener('input',e=>flSaveBlockNotes(e.target.value));
  legacyDate?.querySelector('[data-fl-legacy-block-date]')?.addEventListener('change',e=>{
    const value=(e.target.value||'').trim(),fp=flActiveProgram();if(!fp)return;
    const b=fp.blocks?.find(x=>x.id===sel.id);if(!b)return;
    b.exportStartDate=value;localStorage.setItem(`forgelabFullProgram:${currentUser?.id||'guest'}:active`,JSON.stringify(fp));sel.exportStartDate=value;
  });
  actions.querySelector('[data-fl-block-generate]').onclick=()=>{flSaveBlockNotes(notes.querySelector('[data-fl-block-notes]').value);saveCurrentIntoBlock();fl176GenerateBlock(sel.id)};
  actions.querySelector('[data-fl-block-activate]')?.addEventListener('click',()=>{flSaveBlockNotes(notes.querySelector('[data-fl-block-notes]').value);saveCurrentIntoBlock();activateFullProgrammingDraft()});
}


/* ===== ForgeLab v1.28.0 — Cardio planifié par jour + Cardio libre ===== */
const FL_DAY_CARDIO_TYPES=[
  {id:'low',label:'🟢 Basse intensité',quality:'🟢 Base aérobie',defaultEngine:'Run',defaultDuration:40},
  {id:'threshold',label:'🟠 Seuil',quality:'🟠 Seuil',defaultEngine:'SkiErg',defaultDuration:30},
  {id:'conditioning',label:'⚫ Conditioning',quality:'⚫ Conditioning',defaultEngine:'SkiErg',defaultDuration:20}
];
function flDayCardioType(id){return FL_DAY_CARDIO_TYPES.find(x=>x.id===id)||FL_DAY_CARDIO_TYPES[0]}
function flCardioDayPlanKey(){return `forgelabCardioDayPlan:${flCardioScope()}`}
function flNormalizeDayCardioItem(x={}){
  let type=String(x.type||'');
  if(!FL_DAY_CARDIO_TYPES.some(t=>t.id===type)){
    const q=String(x.quality||'');type=q.includes('Seuil')?'threshold':q.includes('Conditioning')||q.includes('Haute intensité')?'conditioning':'low';
  }
  const t=flDayCardioType(type),engine=CARDIO_ENGINES.includes(String(x.engine||''))?String(x.engine):t.defaultEngine;
  return {id:x.id||cardioModalityId(),type,engine,duration:Math.max(0,Math.min(300,Number(x.duration??t.defaultDuration)||0))};
}
function flCardioDayPlan(){
  try{const raw=JSON.parse(localStorage.getItem(flCardioDayPlanKey())||'null');if(raw&&typeof raw==='object'){const out=Object.fromEntries(DAYS.map(d=>[d,[]]));DAYS.forEach(d=>out[d]=Array.isArray(raw[d])?raw[d].map(flNormalizeDayCardioItem):[]);return out}}catch(_){ }
  // Migration non destructive de l'ancienne programmation cardio quotidienne.
  const legacy=programCardioData(),out=Object.fromEntries(DAYS.map(d=>[d,[]]));
  DAYS.forEach(d=>out[d]=(legacy[d]||[]).map(flNormalizeDayCardioItem));
  if(DAYS.some(d=>out[d].length))localStorage.setItem(flCardioDayPlanKey(),JSON.stringify(out));
  return out;
}
function flSaveCardioDayPlan(plan,redraw=true){localStorage.setItem(flCardioDayPlanKey(),JSON.stringify(plan));flProgrammingCloudQueue();if(redraw&&state.tab==='programming')drawProgramming()}
function flCardioDayPanel(){
  const plan=flCardioDayPlan(),total=DAYS.reduce((n,d)=>n+(plan[d]?.length||0),0);
  return `<section class="fl-cardio-daily"><div class="fl-cardio-title"><div><small>♥ CARDIO · ${esc(selectedFullBlock()?.name||'BLOC')}</small><strong>Cardio planifié par jour</strong><span>Fixe ici les séances qui doivent tomber un jour précis : basse intensité, seuil ou conditioning.</span></div><b class="fl-cardio-daily-total">${total} séance${total>1?'s':''}</b></div><div class="fl-cardio-daily-grid">${DAYS.map(day=>`<article class="fl-cardio-daily-day" data-flcd-day="${day}"><header><strong>${day}</strong><button type="button" data-flcd-add aria-label="Ajouter du cardio le ${day}">＋</button></header><div class="fl-cardio-daily-list">${(plan[day]||[]).map(x=>`<div class="fl-cardio-daily-row" data-flcd-id="${esc(x.id)}"><select data-flcd-type>${FL_DAY_CARDIO_TYPES.map(t=>`<option value="${t.id}" ${t.id===x.type?'selected':''}>${esc(t.label)}</option>`).join('')}</select><select data-flcd-engine>${CARDIO_ENGINES.map(e=>`<option ${e===x.engine?'selected':''}>${esc(e)}</option>`).join('')}</select><label><input type="number" inputmode="numeric" min="0" max="300" value="${+x.duration||0}" data-flcd-duration><span>min</span></label><button type="button" class="fl-cardio-x" data-flcd-remove>×</button></div>`).join('')||'<div class="fl-cardio-daily-empty">Libre / repos</div>'}</div></article>`).join('')}</div></section>`;
}
function flWireCardioDayPanel(v){
  v.querySelectorAll('[data-flcd-day]').forEach(dayBox=>{
    const day=dayBox.dataset.flcdDay;
    dayBox.querySelector('[data-flcd-add]')?.addEventListener('click',()=>{const p=flCardioDayPlan(),t=FL_DAY_CARDIO_TYPES[0];p[day].push({id:cardioModalityId(),type:t.id,engine:t.defaultEngine,duration:t.defaultDuration});flSaveCardioDayPlan(p)});
    dayBox.querySelectorAll('[data-flcd-id]').forEach(row=>{
      const id=row.dataset.flcdId,mutate=fn=>{const p=flCardioDayPlan(),x=p[day].find(a=>a.id===id);if(x){fn(x);flSaveCardioDayPlan(p,false);flProgrammingCloudQueue()}};
      row.querySelector('[data-flcd-type]').onchange=e=>mutate(x=>{x.type=e.target.value;const t=flDayCardioType(x.type);if(!x.engine)x.engine=t.defaultEngine;if(!x.duration)x.duration=t.defaultDuration});
      row.querySelector('[data-flcd-engine]').onchange=e=>mutate(x=>x.engine=e.target.value);
      row.querySelector('[data-flcd-duration]').onchange=e=>mutate(x=>x.duration=Math.max(0,Math.min(300,+e.target.value||0)));
      row.querySelector('[data-flcd-remove]').onclick=()=>{const p=flCardioDayPlan();p[day]=p[day].filter(a=>a.id!==id);flSaveCardioDayPlan(p)};
    });
  });
}
function flDailyCardioInlineHtml(day){
  const rows=flCardioDayPlan()[day]||[];
  return rows.map(x=>{const t=flDayCardioType(x.type);return `<div class="mobile-program-entry fl-program-cardio-inline" data-fl-inline-cardio-id="${esc(x.id)}">
    <span class="mobile-program-badge cardio">C</span>
    <div class="mobile-program-muscle fl-program-cardio-main"><strong>${esc(t.label)}</strong><small>Cardio planifié · ${esc(x.engine)}</small></div>
    <label class="fl-program-cardio-duration"><input type="number" inputmode="numeric" min="0" max="300" value="${+x.duration||0}" data-fl-inline-cardio-duration><span>min</span></label>
    <button type="button" class="mobile-program-remove" data-fl-inline-cardio-remove aria-label="Retirer le cardio">×</button>
    <div class="fl-program-cardio-controls">
      <select data-fl-inline-cardio-type>${FL_DAY_CARDIO_TYPES.map(a=>`<option value="${a.id}" ${a.id===x.type?'selected':''}>${esc(a.label)}</option>`).join('')}</select>
      <select data-fl-inline-cardio-engine>${CARDIO_ENGINES.map(e=>`<option ${e===x.engine?'selected':''}>${esc(e)}</option>`).join('')}</select>
    </div>
  </div>`}).join('');
}
function flWireInlineDailyCardio(v){
  v.querySelectorAll('.mobile-program-day').forEach(card=>{
    const day=card.dataset.programDay;if(!day)return;
    card.querySelector('[data-fl-inline-cardio-add]')?.addEventListener('click',()=>{
      const p=flCardioDayPlan(),t=FL_DAY_CARDIO_TYPES[0];
      p[day].push({id:cardioModalityId(),type:t.id,engine:t.defaultEngine,duration:t.defaultDuration});
      flSaveCardioDayPlan(p);
    });
    card.querySelectorAll('[data-fl-inline-cardio-id]').forEach(row=>{
      const id=row.dataset.flInlineCardioId;
      const mutate=(fn,redraw=false)=>{const p=flCardioDayPlan(),x=p[day].find(a=>a.id===id);if(!x)return;fn(x);flSaveCardioDayPlan(p,redraw)};
      row.querySelector('[data-fl-inline-cardio-type]')?.addEventListener('change',e=>{mutate(x=>{x.type=e.target.value;const t=flDayCardioType(x.type);x.engine=t.defaultEngine;x.duration=t.defaultDuration},true)});
      row.querySelector('[data-fl-inline-cardio-engine]')?.addEventListener('change',e=>mutate(x=>x.engine=e.target.value));
      row.querySelector('[data-fl-inline-cardio-duration]')?.addEventListener('change',e=>mutate(x=>x.duration=Math.max(0,Math.min(300,+e.target.value||0))));
      row.querySelector('[data-fl-inline-cardio-remove]')?.addEventListener('click',()=>{const p=flCardioDayPlan();p[day]=p[day].filter(a=>a.id!==id);flSaveCardioDayPlan(p)});
    });
  });
}
const _drawProgrammingV1281InlineCardio=drawProgramming;
drawProgramming=function(){
  _drawProgrammingV1281InlineCardio();
  if(programmingScreen==='chooser'){flProgrammingCloudQueue();return}
  const v=document.querySelector('#view');if(!v)return;
  // v1.28.1 : le cardio fixé à un jour fait partie de la même programmation que la musculation.
  // Le stockage reste identique à la v1.28.0 pour préserver toutes les données déjà saisies.
  v.querySelectorAll('.fl-cardio-daily').forEach(x=>x.remove());
  const plan=flCardioDayPlan();
  v.querySelectorAll('.mobile-program-day').forEach(card=>{
    const day=card.dataset.programDay,list=card.querySelector('.mobile-program-list');if(!day||!list)return;
    const cardioHtml=flDailyCardioInlineHtml(day);
    if(cardioHtml){const wrap=document.createElement('div');wrap.className='fl-inline-cardio-fragment';wrap.innerHTML=cardioHtml;while(wrap.firstChild)list.appendChild(wrap.firstChild)}
    const add=card.querySelector('.mobile-program-add');
    if(add&&!add.querySelector('[data-fl-inline-cardio-add]')){
      const btn=document.createElement('button');btn.type='button';btn.className='fl-inline-cardio-add';btn.dataset.flInlineCardioAdd='';btn.textContent='＋ Ajouter du cardio';add.appendChild(btn);
    }
    const cardioMinutes=(plan[day]||[]).reduce((n,x)=>n+(+x.duration||0),0);
    if(cardioMinutes){
      const head=card.querySelector('.mobile-program-day-head div');
      if(head&&!head.querySelector('.fl-inline-cardio-summary')){const s=document.createElement('small');s.className='fl-inline-cardio-summary';s.textContent=` · cardio ${cardioMinutes} min`;head.appendChild(s)}
    }
  });
  flWireInlineDailyCardio(v);
  const free=v.querySelector('.fl-cardio-progressive');
  if(free){
    const title=free.querySelector('.fl-cardio-title strong'),desc=free.querySelector('.fl-cardio-title span');
    if(title)title.textContent='Cardio libre';
    if(desc)desc.textContent='Séances non attachées à un jour précis : thème, engine, format et fréquence hebdomadaire.';
  }
  flProgrammingCloudQueue();
};

// Lorsqu'un brouillon devient actif, recopier aussi le cardio fixé à la journée.
const _activateFullProgrammingDraftV1280=activateFullProgrammingDraft;
activateFullProgrammingDraft=async function(){
  const uidKey=currentUser?.id||'guest',draftId=selectedDraftId(),fp=programmingMode()==='draft'?fullProgram():null;
  await _activateFullProgrammingDraftV1280();
  if(draftId&&programmingMode()==='active'&&fp?.blocks?.length){
    fp.blocks.forEach(b=>{const src=`forgelabCardioDayPlan:${uidKey}:draft:${draftId}:${b.id}`,dst=`forgelabCardioDayPlan:${uidKey}:active:${b.id}`,raw=localStorage.getItem(src);if(raw!==null)localStorage.setItem(dst,raw)});
    flProgrammingCloudQueue(true);drawProgramming();
  }
};


/* ===== ForgeLab v1.30.0 — Stories 9:16 + analyses tendancielles + cardio global =====
   IMPORTANT : couche additive uniquement. Aucun localStorage Séries / Carnet / Archives / Suivi n'est supprimé,
   réinitialisé ou réécrit par cette évolution. Les anciennes séances cardio sans distance restent valides. ===== */
const FL_STORY_W=1080,FL_STORY_H=1920;
function flStoryCtx(){const c=document.createElement('canvas');c.width=FL_STORY_W*2;c.height=FL_STORY_H*2;const g=c.getContext('2d');g.scale(2,2);g.imageSmoothingEnabled=true;g.imageSmoothingQuality='high';return {c,g}}
function flStoryBase(g,kicker,title,subtitle=''){
  const bg=g.createLinearGradient(0,0,0,FL_STORY_H);bg.addColorStop(0,'#050505');bg.addColorStop(.48,'#0d0e0e');bg.addColorStop(1,'#030303');g.fillStyle=bg;g.fillRect(0,0,FL_STORY_W,FL_STORY_H);
  const glow=g.createRadialGradient(540,50,10,540,50,650);glow.addColorStop(0,'rgba(228,187,104,.20)');glow.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=glow;g.fillRect(0,0,1080,600);
  g.textAlign='center';g.textBaseline='middle';g.fillStyle='#e7c778';g.font='900 32px Georgia,serif';g.fillText('FORGELAB',540,78);g.fillStyle='#948a79';g.font='700 12px Arial,sans-serif';g.fillText('DISCIPLINA · CONSTANTIA · PROGRESSUS',540,116);
  g.strokeStyle='rgba(231,199,120,.45)';g.beginPath();g.moveTo(84,150);g.lineTo(996,150);g.stroke();
  g.fillStyle='#b49a64';g.font='800 15px Arial,sans-serif';g.fillText(String(kicker||'RAPPORT').toUpperCase(),540,194);
  flStoryFit(g,String(title||'FORGELAB').toUpperCase(),540,252,910,46,'#f5f1e9',900,'center',true);
  if(subtitle){g.fillStyle='#aaa397';g.font='600 17px Arial,sans-serif';g.fillText(String(subtitle),540,302)}
}
function flStoryFit(g,t,x,y,max,size,color='#f5f1e9',weight=800,align='left',serif=false){let z=size;do{g.font=`${weight} ${z}px ${serif?'Georgia,serif':'Arial,sans-serif'}`;if(g.measureText(String(t)).width<=max)break;z--}while(z>12);g.fillStyle=color;g.textAlign=align;g.textBaseline='middle';g.fillText(String(t),x,y);return z}
function flStoryWrap(g,t,x,y,max,size=22,color='#d6d0c4',weight=500,lineH=31,maxLines=8){const words=String(t||'').split(/\s+/).filter(Boolean),lines=[];let cur='';g.font=`${weight} ${size}px Arial,sans-serif`;for(const w of words){const q=cur?cur+' '+w:w;if(g.measureText(q).width<=max)cur=q;else{if(cur)lines.push(cur);cur=w;if(lines.length>=maxLines-1)break}}if(cur&&lines.length<maxLines)lines.push(cur);g.fillStyle=color;g.textAlign='left';g.textBaseline='top';lines.forEach((l,i)=>g.fillText(l,x,y+i*lineH));return lines.length*lineH}
function flStoryKpis(g,items,y=365){const gap=14,x=62,w=(956-gap*(items.length-1))/items.length;items.forEach((it,i)=>{const xx=x+i*(w+gap);g.fillStyle='#111211';g.strokeStyle='rgba(228,187,104,.35)';g.lineWidth=1;g.beginPath();g.roundRect(xx,y,w,112,12);g.fill();g.stroke();flStoryFit(g,it.value,xx+w/2,y+40,w-18,29,'#e8c979',900,'center');g.fillStyle='#999184';g.font='700 11px Arial';g.textAlign='center';g.fillText(String(it.label||'').toUpperCase(),xx+w/2,y+79)})}
function flStorySection(g,label,y){g.fillStyle='#d8b86d';g.font='800 14px Arial';g.textAlign='left';g.fillText(String(label).toUpperCase(),66,y);g.strokeStyle='rgba(216,184,109,.30)';g.beginPath();g.moveTo(66,y+18);g.lineTo(1014,y+18);g.stroke();return y+48}
function flStoryFooter(g,page=''){g.textAlign='center';g.fillStyle='#947b4c';g.font='800 14px Arial';g.fillText(`DAILY WINS.${page?' · '+page:''}`,540,1852)}
async function flStoryShare(canvases,baseName,title='ForgeLab'){
  const files=[];for(let i=0;i<canvases.length;i++){const blob=await new Promise(r=>canvases[i].toBlob(r,'image/png',1));if(blob)files.push(new File([blob],`${baseName}${canvases.length>1?'_'+String(i+1).padStart(2,'0'):''}.png`,{type:'image/png'}))}
  if(!files.length)return alert('Impossible de générer le rapport.');
  try{if(navigator.share&&navigator.canShare&&navigator.canShare({files})){await navigator.share({files,title});return}}catch(e){if(e?.name==='AbortError')return}
  files.forEach((f,i)=>{const u=URL.createObjectURL(f),a=document.createElement('a');a.href=u;a.download=f.name;document.body.appendChild(a);setTimeout(()=>{a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(u),5000)},i*250)});
}
function flPct(oldV,newV){oldV=+oldV||0;newV=+newV||0;return oldV>0?(newV-oldV)/oldV*100:null}
function flTrendWord(pct){return pct==null?'données insuffisantes':pct>3?'progression':pct<-3?'baisse':'stable'}
function flTrendPct(pct){return pct==null?'—':`${pct>0?'+':''}${Math.round(pct)} %`}
function flMean(a){const x=a.filter(Number.isFinite);return x.length?x.reduce((n,v)=>n+v,0)/x.length:0}
function flMedian(a){const x=a.filter(Number.isFinite).sort((a,b)=>a-b);if(!x.length)return null;const m=Math.floor(x.length/2);return x.length%2?x[m]:(x[m-1]+x[m])/2}
function flPdcName(name=''){return /traction|pompe|dips|copenhagen|air squat|relev[eé].*(jambes|genoux)|ab wheel/i.test(String(name))}
function flComparableExerciseTrends(rows,muscle=''){
  const by=new Map();rows.filter(r=>r.kind==='muscu').sort((a,b)=>String(a.date).localeCompare(String(b.date))).forEach(r=>(r.session.exercises||[]).forEach(e=>{
    const m=e.muscle||e.muscleKey||'';if(muscle&&m!==muscle)return;const sets=(e.sets||[]).filter(x=>(+x.reps||0)>0&&(+x.kg||0)>=0);if(!sets.length||!e.name)return;
    const key=jNormName(e.name),pdc=flPdcName(e.name)&&sets.every(x=>(+x.kg||0)<=1.001),avgKg=flMean(sets.map(x=>+x.kg||0)),reps=sets.reduce((n,x)=>n+(+x.reps||0),0),volume=sets.reduce((n,x)=>n+(+x.kg||0)*(+x.reps||0),0);
    if(!by.has(key))by.set(key,{name:e.name,pdc,points:[]});by.get(key).points.push({date:r.date,avgKg,reps,volume});
  }));
  const load=[],volume=[],reps=[];let comparable=0,pdcCount=0;
  by.forEach(x=>{if(x.points.length<2)return;comparable++;const n=Math.max(1,Math.min(2,Math.floor(x.points.length/2))),a=x.points.slice(0,n),b=x.points.slice(-n),ap=x.pdc?flMean(a.map(z=>z.reps)):flMean(a.map(z=>z.avgKg)),bp=x.pdc?flMean(b.map(z=>z.reps)):flMean(b.map(z=>z.avgKg)),av=flMean(a.map(z=>z.volume)),bv=flMean(b.map(z=>z.volume));if(x.pdc){pdcCount++;const q=flPct(ap,bp);if(q!=null)reps.push(q)}else{const q=flPct(ap,bp);if(q!=null)load.push(q)}const qv=flPct(av,bv);if(qv!=null)volume.push(qv)});
  return {comparable,pdcCount,loadPct:flMedian(load),volumePct:flMedian(volume),repsPct:flMedian(reps)};
}
function flCardioTrend(rows){
  const c=rows.filter(r=>r.kind==='cardio'&&r.session),detailed=c.filter(r=>r.session&&Object.keys(r.session).length);const totalDistance=detailed.reduce((n,r)=>n+(+r.session.distanceKm||0),0),base=detailed.filter(r=>r.session.quality==='🟢 Base aérobie'&&r.session.engine==='Run'&&paceToSeconds(r.session.pace));
  let pacePct=null,paceText='';if(base.length>=2){const first=base[0].session,last=base.at(-1).session;if(cardioComparable(first,last)){const a=paceToSeconds(first.pace),b=paceToSeconds(last.pace);pacePct=a?((a-b)/a*100):null;paceText=pacePct!=null?`Allure base aérobie ${flTrendWord(pacePct)} (${flTrendPct(pacePct)}) à FC/RPE comparables.`:''}}
  return {sessions:c.length,duration:c.reduce((n,r)=>n+(+r.duration||0),0),distance:totalDistance,pacePct,paceText};
}
function trackingAnalysisRows(sc){const all=[...trackingAnalysisMuscuRows(),...trackingAnalysisCardioRows()];return all.filter(r=>(!sc.from||r.date>=sc.from)&&(!sc.to||r.date<=sc.to))}
function trackingSessionHasMuscle(row,muscle){if(!muscle)return true;if(muscle==='__cardio__')return row.kind==='cardio';if(row.kind!=='muscu')return false;return (row.session.exercises||[]).some(e=>(e.muscle||e.muscleKey||'')===muscle)}
function trackingMetrics(rows,muscle=''){
  const filtered=rows.filter(r=>trackingSessionHasMuscle(r,muscle));let sets=0,tonnage=0;const muscles=new Map();
  filtered.filter(r=>r.kind==='muscu').forEach(r=>(r.session.exercises||[]).forEach(e=>{const m=e.muscle||e.muscleKey||'Autre';if(muscle&&muscle!=='__cardio__'&&m!==muscle)return;const es=(e.sets||[]).filter(x=>(+x.kg||0)||(+x.reps||0)).length,et=jExerciseTon(e);sets+=es;tonnage+=et;const z=muscles.get(m)||{sets:0,tonnage:0,sessions:new Set()};z.sets+=es;z.tonnage+=et;z.sessions.add(r.id);muscles.set(m,z)}));
  const duration=filtered.reduce((n,r)=>n+(+r.duration||0),0),muscu=filtered.filter(r=>r.kind==='muscu').length,cardio=filtered.filter(r=>r.kind==='cardio').length,ct=flCardioTrend(filtered);
  return {sessions:filtered.length,muscu,cardio,duration,sets,tonnage,cardioDuration:ct.duration,cardioDistance:ct.distance,muscles:[...muscles.entries()].map(([name,z])=>({name,sets:z.sets,tonnage:z.tonnage,sessions:z.sessions.size})).sort((a,b)=>b.sets-a.sets||a.name.localeCompare(b.name,'fr'))};
}
function trackingAnalysisGroups(){
  const bounds=trackingAnalysisDateBounds();if(!trackingAnalysisState.from)trackingAnalysisState.from=bounds.from;if(!trackingAnalysisState.to)trackingAnalysisState.to=bounds.to;
  const catalog=trackingScopeCatalog(),selected=trackingAnalysisState.scopes.map(id=>catalog.find(x=>x.id===id)).filter(Boolean),scopes=selected.length?selected:[{id:'period',type:'period',label:'Période sélectionnée',sub:'Toutes les données',from:trackingAnalysisState.from,to:trackingAnalysisState.to}];
  return scopes.map(sc=>{const from=[trackingAnalysisState.from,sc.from].filter(Boolean).sort().at(-1)||'',to=[trackingAnalysisState.to,sc.to].filter(Boolean).sort()[0]||'',scope={...sc,from,to},rows=trackingAnalysisRows(scope);return {...scope,rows,metrics:trackingMetrics(rows,trackingAnalysisState.muscle)}});
}
function flTrendState(pct){
  if(pct==null)return 'neutral';
  if(pct>3)return 'progression';
  if(pct<-3)return 'regression';
  return 'stable';
}
function flReadableTrend(pct){
  const state=flTrendState(pct);
  if(pct==null)return {state,label:'Données insuffisantes',sentence:'Pas assez de données comparables pour conclure.'};
  const n=Math.abs(Math.round(pct));
  if(state==='progression')return {state,label:'Progression',sentence:`Progression de ${n} % sur les exercices comparables.`};
  if(state==='regression')return {state,label:'Régression',sentence:`Régression de ${n} % sur les exercices comparables.`};
  return {state,label:'Stable',sentence:`Stable, avec une variation de ${pct>0?'+':''}${Math.round(pct)} %.`};
}
function flOverallTrendState(tr){
  const l=tr.loadPct,v=tr.volumePct;
  if(!tr.comparable)return 'neutral';
  const ls=flTrendState(l),vs=flTrendState(v);
  if(ls==='stable'&&vs==='stable')return 'stable';
  if((ls==='progression'&&vs!=='regression')||(vs==='progression'&&ls!=='regression'))return 'progression';
  if((ls==='regression'&&vs!=='progression')||(vs==='regression'&&ls!=='progression'))return 'regression';
  return 'neutral';
}
function flTrendPctFact(pct,noun='La valeur'){
  if(pct==null)return `${noun} ne peut pas être comparée de façon fiable.`;
  const n=Math.abs(Math.round(pct));
  if(pct>3)return `${noun} augmente de ${n} %.`;
  if(pct<-3)return `${noun} diminue de ${n} %.`;
  return `${noun} reste stable (${pct>0?'+':''}${Math.round(pct)} %).`;
}
function flMuscuConclusion(tr,m,muscle=''){
  if(!tr.comparable)return `Aucune conclusion fiable pour cette sélection : aucun exercice n’est présent suffisamment de fois pour comparer le début et la fin de la période.`;
  const parts=[`Sur ${tr.comparable} exercice${tr.comparable>1?'s':''} comparable${tr.comparable>1?'s':''}, ${flTrendPctFact(tr.loadPct,'la charge médiane').replace(/^la/,'la')}`,flTrendPctFact(tr.volumePct,'Le volume médian')];
  if(tr.repsPct!=null)parts.push(flTrendPctFact(tr.repsPct,'Les répétitions sur les exercices au poids du corps'));
  if(!muscle&&m.cardio){let c=`Le cardio représente ${m.cardio} séance${m.cardio>1?'s':''}, pour un temps cumulé de ${trackingFormatMinutes(m.cardioDuration)}`;if(m.cardioDistance)c+=` et ${m.cardioDistance.toFixed(2)} km enregistrés`;parts.push(c+'.');}
  const overall=flOverallTrendState(tr);
  if(overall==='progression')parts.push('La tendance globale de la période est positive.');
  else if(overall==='regression')parts.push('La tendance globale de la période est en régression.');
  else if(overall==='stable')parts.push('La tendance globale de la période est stable.');
  else parts.push('La période est contrastée : la charge et le volume n’évoluent pas dans le même sens.');
  parts.push('La comparaison oppose le début et la fin de la période sur les exercices répétés au moins deux fois.');
  return parts.join(' ');
}
function trackingTrendAnalysis(group,muscle=trackingAnalysisState.muscle){
  const rows=group.rows||trackingAnalysisRows(group),m=group.metrics||trackingMetrics(rows,muscle),filtered=rows.filter(r=>trackingSessionHasMuscle(r,muscle)),card=flCardioTrend(filtered);
  if(muscle==='__cardio__'){
    if(!m.cardio){
      const conclusion='Aucune conclusion factuelle n’est possible : aucune séance cardio n’est enregistrée sur la période sélectionnée.';
      return {title:'CARDIO · AUCUNE DONNÉE',summary:'Aucune séance cardio n’est enregistrée sur la période sélectionnée.',state:'neutral',details:[{label:'Conclusion',text:conclusion,state:'neutral'}],text:`Aucune séance cardio n’est enregistrée sur la période sélectionnée. Conclusion : ${conclusion}`,loadPct:null,volumePct:null};
    }
    const pace=flReadableTrend(card.pacePct);
    let summary='',state=card.pacePct==null?'neutral':pace.state;
    if(card.pacePct==null)summary=`${m.cardio} séance${m.cardio>1?'s':''} cardio enregistrée${m.cardio>1?'s':''}. Il faut au moins deux runs de base aérobie comparables pour mesurer l’évolution de l’allure.`;
    else if(pace.state==='progression')summary='Progression de l’allure en base aérobie sur les runs comparables.';
    else if(pace.state==='regression')summary='Régression de l’allure en base aérobie sur les runs comparables.';
    else summary='Allure globalement stable en base aérobie sur les runs comparables.';
    const details=[
      {label:'Séances',text:`${m.cardio} séance${m.cardio>1?'s':''} sur la période.`,state:'neutral'},
      {label:'Temps',text:`${trackingFormatMinutes(m.cardioDuration)} de cardio cumulé.`,state:'neutral'}
    ];
    if(m.cardioDistance)details.push({label:'Distance',text:`${m.cardioDistance.toFixed(2)} km enregistrés.`,state:'neutral'});
    details.push({label:'Allure',text:card.pacePct==null?'Pas assez de runs comparables pour établir une tendance.':`${pace.label} (${flTrendPct(card.pacePct)}).`,state:card.pacePct==null?'neutral':pace.state});
    let conclusion=`Sur la période, ${m.cardio} séance${m.cardio>1?'s':''} cardio totalise${m.cardio>1?'nt':''} ${trackingFormatMinutes(m.cardioDuration)}`;
    if(m.cardioDistance)conclusion+=` et ${m.cardioDistance.toFixed(2)} km`;
    conclusion+='.';
    if(card.pacePct==null)conclusion+=' Il n’y a pas encore assez de runs de base aérobie réalisés dans des conditions comparables pour conclure sur l’évolution de l’allure.';
    else if(card.pacePct>3)conclusion+=` À FC et RPE comparables, l’allure progresse de ${Math.abs(Math.round(card.pacePct))} %.`;
    else if(card.pacePct<-3)conclusion+=` À FC et RPE comparables, l’allure régresse de ${Math.abs(Math.round(card.pacePct))} %.`;
    else conclusion+=` À FC et RPE comparables, l’allure reste stable (${flTrendPct(card.pacePct)}).`;
    details.push({label:'Conclusion',text:conclusion,state});
    const text=[summary,...details.map(x=>`${x.label} : ${x.text}`)].join(' ');
    return {title:'TENDANCE CARDIO',summary,state,details,text,loadPct:card.pacePct,volumePct:null};
  }
  const tr=flComparableExerciseTrends(rows,muscle||''),charge=flReadableTrend(tr.loadPct),volume=flReadableTrend(tr.volumePct),reps=flReadableTrend(tr.repsPct),state=flOverallTrendState(tr);
  let summary='';
  if(!tr.comparable)summary='Pas encore assez de données comparables pour dégager une tendance fiable.';
  else if((tr.loadPct||0)>3&&(tr.volumePct||0)>3)summary='Progression globale. Les charges et le volume de travail augmentent ensemble.';
  else if((tr.loadPct||0)>3&&(tr.volumePct||0)>=-3)summary='Charge en hausse. Tu travailles plus lourd, tandis que le volume reste globalement stable.';
  else if((tr.loadPct||0)>3)summary='Charge en hausse. Tu travailles plus lourd, mais le volume total est en baisse.';
  else if((tr.volumePct||0)>3&&(tr.loadPct||0)>=-3)summary='Volume en hausse. Tu réalises davantage de travail total, sans hausse nette de la charge.';
  else if((tr.loadPct||0)<-3&&(tr.volumePct||0)<-3)summary='Régression globale. La charge et le volume reculent sur les exercices comparables.';
  else if(Math.abs(tr.loadPct||0)<=3&&Math.abs(tr.volumePct||0)<=3)summary='Situation stable. Les performances restent proches du début de la période.';
  else summary='Évolution contrastée. La charge et le volume n’évoluent pas dans le même sens.';
  const details=[
    {label:'Charge',text:charge.sentence,state:charge.state},
    {label:'Volume',text:volume.sentence,state:volume.state}
  ];
  if(tr.repsPct!=null)details.push({label:'PDC',text:reps.state==='progression'?`Les répétitions progressent de ${Math.abs(Math.round(tr.repsPct))} %.`:reps.state==='regression'?`Les répétitions régressent de ${Math.abs(Math.round(tr.repsPct))} %.`:`Les répétitions sont stables (${flTrendPct(tr.repsPct)}).`,state:reps.state});
  if(!muscle&&m.cardio){let c=`${m.cardio} séance${m.cardio>1?'s':''}, ${trackingFormatMinutes(m.cardioDuration)} de cardio cumulé`;if(m.cardioDistance)c+=` et ${m.cardioDistance.toFixed(2)} km enregistrés`;details.push({label:'Cardio',text:c+'.',state:'neutral'});}
  details.push({label:'Conclusion',text:flMuscuConclusion(tr,m,muscle),state});
  const text=[summary,...details.map(x=>`${x.label} : ${x.text}`)].join(' ');
  return {title:muscle?`TENDANCE · ${muscle}`:'TENDANCE GLOBALE',summary,state,details,text,loadPct:tr.loadPct,volumePct:tr.volumePct,repsPct:tr.repsPct};
}
function trackingTrendHtml(t){
  const state=t.state||'neutral';
  return `<b>${esc(t.title)}</b><p class="trend-summary trend-${state}">${esc(t.summary||t.text||'')}</p><div class="trend-details">${(t.details||[]).map(x=>`<p><strong class="trend-label">${esc(x.label)} :</strong> <span class="trend-detail trend-${x.state||'neutral'}">${esc(x.text)}</span></p>`).join('')}</div>`;
}
function trackingAnalysisTimeDisplay(minutes,muscle=trackingAnalysisState.muscle){return muscle&&muscle!=='__cardio__'?'Non défini':trackingFormatMinutes(minutes)}
function trackingAnalysisResultsHtml(){
  const groups=trackingAnalysisGroups(),base=groups[0]?.metrics;
  const cards=groups.map((g,i)=>{const m=g.metrics,ds=i&&base?m.sessions-base.sessions:0,dt=i&&base?m.duration-base.duration:0,t=trackingTrendAnalysis(g);return `<article class="tracking-analysis-card"><div><small>${esc(g.sub||'')}</small><strong>${esc(g.label)}</strong><span>${g.from&&g.to?`${jDate(g.from)} → ${jDate(g.to)}`:'Toutes dates'}</span></div><div class="tracking-analysis-kpis"><b>${m.sessions}<span>séances${i?` · ${ds>0?'+':''}${ds}`:''}</span></b><b>${trackingAnalysisTimeDisplay(m.duration)}<span>temps${trackingAnalysisState.muscle&&trackingAnalysisState.muscle!=='__cardio__'?' · non attribuable par groupe':i?` · ${dt>0?'+':''}${dt} min`:''}</span></b><b>${m.sets}<span>séries</span></b></div><small class="tracking-analysis-split">${m.muscu} muscu · ${m.cardio} cardio${m.cardioDistance?` · ${m.cardioDistance.toFixed(2)} km`:''}${trackingAnalysisState.muscle?` · filtre ${esc(trackingAnalysisState.muscle==='__cardio__'?'Cardio':trackingAnalysisState.muscle)}`:''}</small><div class="tracking-analysis-trend">${trackingTrendHtml(t)}</div></article>`}).join('');
  if(trackingAnalysisState.muscle==='__cardio__')return `<div class="tracking-analysis-cards">${cards}</div>${groups.length>1?'<p class="tracking-analysis-baseline">Les écarts affichés utilisent la première sélection comme référence.</p>':''}<div class="tracking-section-label"><span>CARDIO · SYNTHÈSE</span><b>♥</b></div>`;
  const muscles=[...new Set(groups.flatMap(g=>g.metrics.muscles.map(x=>x.name)))].sort((a,b)=>groups.reduce((n,g)=>n+(g.metrics.muscles.find(x=>x.name===b)?.sets||0)-(g.metrics.muscles.find(x=>x.name===a)?.sets||0),0));
  const table=muscles.length?`<div class="tracking-muscle-compare"><table><thead><tr><th>Groupe musculaire</th>${groups.map(g=>`<th>${esc(g.label)}</th>`).join('')}</tr></thead><tbody>${muscles.map(m=>`<tr><td>${esc(m)}</td>${groups.map(g=>{const x=g.metrics.muscles.find(z=>z.name===m);return `<td><b>${x?.sets||0}</b><small>séries</small></td>`}).join('')}</tr>`).join('')}</tbody></table></div>`:'<div class="j-muted">Aucune série sur cette sélection.</div>';
  return `<div class="tracking-analysis-cards">${cards}</div>${groups.length>1?'<p class="tracking-analysis-baseline">Les écarts affichés utilisent la première sélection comme référence.</p>':''}<div class="tracking-section-label"><span>TRI PAR GROUPE MUSCULAIRE</span><b>${muscles.length}</b></div>${table}`;
}
function trackingAnalysisHtml(){
  const bounds=trackingAnalysisDateBounds();if(!trackingAnalysisState.from)trackingAnalysisState.from=bounds.from;if(!trackingAnalysisState.to)trackingAnalysisState.to=bounds.to;const catalog=trackingScopeCatalog(),muscles=trackingAnalysisMuscles();
  return `<section class="tracking-analysis"><div class="tracking-analysis-head"><div><small>ANALYSE GLOBALE</small><strong>Programmes · blocs · périodes</strong><span>Lecture seule : aucune donnée Séries / Archives / Suivi n’est modifiée.</span></div></div><div class="tracking-analysis-filters"><label>Du<input id="trackingAnalysisFrom" type="date" value="${esc(trackingAnalysisState.from)}"></label><label>Au<input id="trackingAnalysisTo" type="date" value="${esc(trackingAnalysisState.to)}"></label><label class="wide">Groupe / cardio<select id="trackingAnalysisMuscle"><option value="">Tous · Musculation + Cardio</option><option value="__cardio__" ${trackingAnalysisState.muscle==='__cardio__'?'selected':''}>♥ Cardio</option>${muscles.map(m=>`<option value="${esc(m)}" ${m===trackingAnalysisState.muscle?'selected':''}>${esc(m)}</option>`).join('')}</select></label></div><details class="tracking-analysis-scopes" open><summary>Programmes / blocs à comparer <span>${trackingAnalysisState.scopes.length||'tous'}</span></summary><div>${catalog.map(x=>`<label class="tracking-scope-option"><input type="checkbox" value="${esc(x.id)}" ${trackingAnalysisState.scopes.includes(x.id)?'checked':''}><span><b>${esc(x.label)}</b><small>${esc(x.sub||'')}</small></span></label>`).join('')||'<div class="j-muted">Le programme actif apparaîtra ici dès qu’une date de début est renseignée.</div>'}</div></details><div class="tracking-analysis-actions"><button type="button" id="trackingAnalysisApply">Actualiser</button><button type="button" id="trackingAnalysisExport">Exporter le suivi global</button><button type="button" class="secondary" id="trackingAnalysisExportSelection" ${trackingAnalysisState.muscle?'':'disabled'}>Exporter le groupe / cardio</button></div><div id="trackingAnalysisResults">${trackingAnalysisResultsHtml()}</div></section>`;
}
function flTrendCanvasColor(state){
  if(state==='progression')return '#89d59a';
  if(state==='regression')return '#ef746f';
  if(state==='stable')return '#f3efe7';
  return '#d8d1c5';
}
function flStoryLabeledComment(g,label,text,x,y,maxW,size=16,state='neutral',maxLines=2){
  const labelText=`${label} :`;
  const lineH=label==='Conclusion'?24:23;
  const weight=label==='Conclusion'?750:650;
  g.textAlign='left';g.textBaseline='top';
  g.font=`900 ${size}px Arial,sans-serif`;
  g.fillStyle='#d8b86d';
  g.fillText(labelText,x,y);
  const labelW=Math.min(maxW*.42,g.measureText(labelText).width+10);
  const words=String(text||'').split(/\s+/).filter(Boolean),lines=[];
  g.font=`${weight} ${size}px Arial,sans-serif`;
  let cur='',first=true;
  for(const w of words){
    const q=cur?cur+' '+w:w;
    const lim=first?Math.max(120,maxW-labelW):maxW;
    if(g.measureText(q).width<=lim)cur=q;
    else{
      if(cur){lines.push(cur);first=false;}
      cur=w;
      if(lines.length>=maxLines-1)break;
    }
  }
  if(cur&&lines.length<maxLines)lines.push(cur);
  g.fillStyle=flTrendCanvasColor(state);
  lines.forEach((line,i)=>g.fillText(line,i===0?x+labelW:x,y+i*lineH));
  return Math.max(1,lines.length)*lineH;
}
function flStoryTrendComments(g,trend,x,y,maxW){
  let yy=y;
  yy+=flStoryWrap(g,trend.summary||'',x,yy,maxW,22,flTrendCanvasColor(trend.state),800,31,3)+14;
  (trend.details||[]).forEach(item=>{
    const maxLines=item.label==='Conclusion'?5:2;
    const h=flStoryLabeledComment(g,item.label,item.text,x,yy,maxW,item.label==='Conclusion'?17:16,item.state||'neutral',maxLines);
    yy+=h+10;
  });
  return yy-y;
}
function flDrawTrendStory(group,muscle=''){
  const {c,g}=flStoryCtx(),m=trackingMetrics(group.rows||trackingAnalysisRows(group),muscle),trend=trackingTrendAnalysis({...group,metrics:m},muscle),label=muscle==='__cardio__'?'CARDIO':muscle||'SUIVI GLOBAL';flStoryBase(g,'ANALYSE DE TENDANCE',label,`${jDate(group.from)} → ${jDate(group.to)} · ${group.label}`);
  flStoryKpis(g,[{value:m.sessions,label:'séances'},{value:trackingAnalysisTimeDisplay(m.duration,muscle),label:muscle&&muscle!=='__cardio__'?'temps non attribuable':'temps cumulé'},{value:muscle==='__cardio__'?m.cardio:m.sets,label:muscle==='__cardio__'?'cardio':'séries'}],365);
  let y=530;y=flStorySection(g,trend.title,y);g.fillStyle='#101110';g.strokeStyle='rgba(228,187,104,.32)';g.beginPath();g.roundRect(62,y,956,420,14);g.fill();g.stroke();flStoryTrendComments(g,trend,88,y+30,904);y+=470;
  if(muscle==='__cardio__'||(!muscle&&m.cardio)){y=flStorySection(g,'CARDIO',y);const ct=flCardioTrend((group.rows||[]).filter(r=>trackingSessionHasMuscle(r,muscle||'')));flStoryKpis(g,[{value:String(m.cardio),label:'séances cardio'},{value:trackingFormatMinutes(m.cardioDuration),label:'durée cardio'},{value:m.cardioDistance?m.cardioDistance.toFixed(2)+' km':'—',label:'distance'}],y);y+=150;if(ct.paceText)flStoryWrap(g,ct.paceText,70,y,940,20,'#bfb7aa',500,29,3)}
  if(muscle&&muscle!=='__cardio__'){y=flStorySection(g,'CHARGE & VOLUME',Math.max(y,1080));const tr=flComparableExerciseTrends(group.rows||[],muscle);flStoryKpis(g,[{value:flTrendWord(tr.loadPct),label:`charge ${flTrendPct(tr.loadPct)}`},{value:flTrendWord(tr.volumePct),label:`volume ${flTrendPct(tr.volumePct)}`},{value:tr.repsPct==null?'—':flTrendWord(tr.repsPct),label:'répétitions PDC'}],y)}
  else if(!muscle){y=flStorySection(g,'RÉPARTITION MUSCULAIRE',Math.max(y,1080));const top=m.muscles.slice(0,8),max=Math.max(1,...top.map(x=>x.sets));top.forEach((x,i)=>{const yy=y+i*70;g.fillStyle='#ded8cc';g.font='700 17px Arial';g.textAlign='left';g.fillText(x.name,70,yy);g.fillStyle='#222';g.fillRect(350,yy-8,570,12);g.fillStyle='#d9b86d';g.fillRect(350,yy-8,570*x.sets/max,12);g.fillStyle='#e8c979';g.font='800 17px Arial';g.textAlign='right';g.fillText(String(x.sets),1000,yy)})}
  flStoryFooter(g);return c;
}
function flDrawComparisonStory(groups,muscle=''){
  const {c,g}=flStoryCtx(),ref=groups[0],label=muscle==='__cardio__'?'CARDIO':muscle||'GLOBAL';flStoryBase(g,'COMPARAISON','PROGRAMMES / BLOCS',`${groups.length} sélections · ${label}`);let y=370;groups.slice(0,5).forEach((x,i)=>{const m=trackingMetrics(x.rows||trackingAnalysisRows(x),muscle),rm=trackingMetrics(ref.rows||trackingAnalysisRows(ref),muscle),ds=m.sessions-rm.sessions,dt=m.duration-rm.duration,dset=m.sets-rm.sets;g.fillStyle='#101110';g.strokeStyle=i===0?'rgba(228,187,104,.65)':'rgba(228,187,104,.25)';g.beginPath();g.roundRect(62,y,956,245,14);g.fill();g.stroke();g.fillStyle=i===0?'#e8c979':'#f0eadf';g.font='850 24px Arial';g.textAlign='left';g.fillText(x.label,88,y+42);g.fillStyle='#968e81';g.font='600 13px Arial';g.fillText(`${jDate(x.from)} → ${jDate(x.to)}${i===0?' · RÉFÉRENCE':''}`,88,y+72);const vals=muscle==='__cardio__'?[`${m.cardio} cardio`,trackingFormatMinutes(m.cardioDuration),m.cardioDistance?`${m.cardioDistance.toFixed(2)} km`:'—']:[`${m.sessions} séances`,trackingAnalysisTimeDisplay(m.duration,muscle),`${m.sets} séries`];vals.forEach((v,j)=>{g.fillStyle='#d8b86d';g.font='800 21px Arial';g.textAlign='center';g.fillText(v,230+j*305,y+132);if(i>0){if(!(j===1&&muscle&&muscle!=='__cardio__')){const delta=j===0?ds:j===1?dt:dset;g.fillStyle=delta>0?'#8fc59b':delta<0?'#d99b77':'#aaa';g.font='700 12px Arial';g.fillText(`${delta>0?'+':''}${delta}${j===1?' min':''}`,230+j*305,y+166)}}});const tr=trackingTrendAnalysis({...x,metrics:m},muscle);flStoryWrap(g,tr.summary||tr.text,88,y+190,900,13,flTrendCanvasColor(tr.state),650,18,2);y+=270});if(groups.length>5){g.fillStyle='#9b927f';g.font='600 15px Arial';g.textAlign='center';g.fillText(`+ ${groups.length-5} sélection${groups.length-5>1?'s':''} dans les pages individuelles`,540,1740)}flStoryFooter(g);return c
}
async function trackingExportAnalysisStory(forceSelection=false){const groups=trackingAnalysisGroups();if(!groups.length)return alert('Aucune donnée à exporter.');const muscle=forceSelection?trackingAnalysisState.muscle:'';if(forceSelection&&!muscle)return alert('Choisis un groupe musculaire ou Cardio.');const canvases=[];if(groups.length>1)canvases.push(flDrawComparisonStory(groups,muscle));groups.forEach(g=>canvases.push(flDrawTrendStory(g,muscle)));await flStoryShare(canvases,`ForgeLab_${muscle==='__cardio__'?'Cardio':muscle||'Suivi_Global'}`,'ForgeLab · Suivi')}
function flExportStoryPdf(canvases,baseName,title='ForgeLab'){
  if(!canvases?.length)return alert('Aucune page à exporter.');
  const pages=canvases.map(c=>c.toDataURL('image/jpeg',.96));
  const w=window.open('','_blank');if(!w)return alert('Autorise les fenêtres pop-up pour exporter le PDF.');
  const html=`<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${esc(baseName||title)}</title><style>@page{size:108mm 192mm;margin:0}*{box-sizing:border-box}html,body{margin:0;padding:0;background:#000}.page{width:108mm;height:192mm;margin:0;page-break-after:always;break-after:page;overflow:hidden;background:#000}.page:last-child{page-break-after:auto;break-after:auto}.page img{display:block;width:108mm;height:192mm;object-fit:cover}@media print{html,body{width:108mm;background:#000;-webkit-print-color-adjust:exact;print-color-adjust:exact}.page{margin:0}}</style></head><body>${pages.map((src,i)=>`<section class="page"><img src="${src}" alt="${esc(title)} - page ${i+1}"></section>`).join('')}<script>const p=()=>setTimeout(()=>{try{window.focus();window.print()}catch(e){}},300);if(document.readyState==='complete')p();else window.addEventListener('load',p,{once:true});<\/script></body></html>`;
  w.document.open();w.document.write(html);w.document.close();
}
function trackingExportAnalysisPdf(forceSelection=false){
  const groups=trackingAnalysisGroups();if(!groups.length)return alert('Aucune donnée à exporter.');
  const muscle=forceSelection?trackingAnalysisState.muscle:'';if(forceSelection&&!muscle)return alert('Choisis un groupe musculaire ou Cardio.');
  const canvases=[];if(groups.length>1)canvases.push(flDrawComparisonStory(groups,muscle));groups.forEach(g=>canvases.push(flDrawTrendStory(g,muscle)));
  const name=`ForgeLab_${muscle==='__cardio__'?'Cardio':muscle||'Suivi_Global'}`;flExportStoryPdf(canvases,name,`ForgeLab · ${muscle==='__cardio__'?'Cardio':muscle||'Suivi global'}`);
}

// Carnet : toutes les extractions sont exportées en PDF vertical 9:16.
async function jExportPdf(sessions,from='',to=''){
  const rows=[...(sessions||[])].sort((a,b)=>String(a.date||'').localeCompare(String(b.date||''))||jHistoryTime(a)-jHistoryTime(b));if(!rows.length)return alert('Aucune séance à exporter.');const first=from||rows[0]?.date||'',last=to||rows.at(-1)?.date||'',canvases=[];
  {const {c,g}=flStoryCtx();flStoryBase(g,'CARNET D’ENTRAÎNEMENT','BILAN DE PÉRIODE',`${jDate(first)} → ${jDate(last)}`);flStoryKpis(g,[{value:rows.length,label:'séances'},{value:rows.reduce((n,s)=>n+jSets(s),0),label:'séries'},{value:trackingFormatMinutes(rows.reduce((n,s)=>n+(+s.duration||0),0)),label:'temps'},{value:jFmt(rows.reduce((n,s)=>n+jTon(s),0)),label:'kg tonnage'}],365);let y=555;y=flStorySection(g,'DERNIÈRES SÉANCES',y);rows.slice(-8).reverse().forEach((s,i)=>{const yy=y+i*105;g.fillStyle='#111211';g.strokeStyle='rgba(228,187,104,.22)';g.beginPath();g.roundRect(62,yy,956,84,10);g.fill();g.stroke();flStoryFit(g,s.sessionName||'Séance sans nom',84,yy+28,610,20,'#eee8dc',800);g.fillStyle='#9d9486';g.font='600 14px Arial';g.textAlign='left';g.fillText(`${jDate(s.date)} · ${s.duration||0} min · ${jSets(s)} séries`,84,yy+57);g.fillStyle='#e5c47a';g.font='800 17px Arial';g.textAlign='right';g.fillText(`${jFmt(jTon(s))} kg`,990,yy+42)});flStoryFooter(g,'1');canvases.push(c)}
  const chunks=[];for(let i=0;i<rows.length;i+=4)chunks.push(rows.slice(i,i+4));chunks.forEach((chunk,ci)=>{const {c,g}=flStoryCtx();flStoryBase(g,'CARNET · DÉTAIL',`SÉANCES ${ci*4+1}–${ci*4+chunk.length}`,`${jDate(chunk[0].date)} → ${jDate(chunk.at(-1).date)}`);let y=365;chunk.forEach(s=>{g.fillStyle='#101110';g.strokeStyle='rgba(228,187,104,.30)';g.beginPath();g.roundRect(62,y,956,330,14);g.fill();g.stroke();flStoryFit(g,s.sessionName||'Séance sans nom',88,y+38,650,24,'#efeadf',850);g.fillStyle='#b69a62';g.font='700 14px Arial';g.textAlign='right';g.fillText(`${jDate(s.date)} · ${s.duration||0} min`,990,y+38);let yy=y+82;(s.exercises||[]).slice(0,6).forEach(e=>{flStoryFit(g,`${e.muscle||''} · ${e.name||'Exercice'}`,90,yy,560,15,'#d9d2c6',700);g.fillStyle='#a89f90';g.font='600 13px Arial';g.textAlign='right';g.fillText((e.sets||[]).map(jSetLabel).join(' · ').slice(0,55),990,yy);yy+=36});y+=355});flStoryFooter(g,String(ci+2));canvases.push(c)});flExportStoryPdf(canvases,'ForgeLab_Carnet','ForgeLab · Carnet');
}

// Bilan de bloc : Story 1 = synthèse ; stories suivantes = semaines, sans PDF/A4.
async function exportBlockPdf(blockId){
  const fp=flActiveProgram();if(!fp)return alert('Aucun programme actif.');const block=fp.blocks?.find(b=>b.id===blockId)||fp.blocks?.find(b=>!b.deload);if(!block)return alert('Bloc introuvable.');const period=flBlockPeriod(block,fp);if(!period)return alert('Renseigne la date de début de ce bloc dans le pavé d’export exceptionnel.');
  const ymd=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`,rows=[...trackingAnalysisMuscuRows(),...trackingAnalysisCardioRows()].filter(r=>r.date>=ymd(period.start)&&r.date<=ymd(period.end)),group={label:block.name||'Bloc',from:ymd(period.start),to:ymd(period.end),rows,metrics:trackingMetrics(rows,'')},canvases=[flDrawTrendStory(group,'')];
  for(let wk=period.from;wk<=period.to;wk+=2){const a=new Date(period.start);a.setDate(a.getDate()+(wk-period.from)*7);const b=new Date(a);b.setDate(b.getDate()+13);if(b>period.end)b.setTime(period.end.getTime());const sg={label:`${block.name||'Bloc'} · S${wk}${wk<period.to?'–S'+Math.min(period.to,wk+1):''}`,from:ymd(a),to:ymd(b)};sg.rows=trackingAnalysisRows(sg);sg.metrics=trackingMetrics(sg.rows,'');canvases.push(flDrawTrendStory(sg,''))}
  flExportStoryPdf(canvases,`ForgeLab_${String(block.name||'Bloc').replace(/[^a-z0-9]+/gi,'_')}_Bilan`,'ForgeLab · Bilan de bloc');
}

// Programme complet : résumé vertical, découpé si nécessaire.
async function generateCompleteProgram(){saveCurrentIntoBlock();const fp=fullProgram(),blocks=fp.blocks||[];if(!blocks.length)return alert('Aucun bloc.');const canvases=[];for(let start=0;start<blocks.length;start+=4){const part=blocks.slice(start,start+4),{c,g}=flStoryCtx();flStoryBase(g,'PROGRAMME COMPLET',fp.name||'Programme ForgeLab',`${blocks.length} bloc${blocks.length>1?'s':''}`);let y=365;part.forEach((b,j)=>{const rd=blockReadableData(b.id),sets=rd.phases.reduce((n,p)=>n+DAYS.reduce((a,d)=>a+(p.data[d]||[]).reduce((q,x)=>q+(+x.sets||0),0),0),0);g.fillStyle='#101110';g.strokeStyle='rgba(228,187,104,.35)';g.beginPath();g.roundRect(62,y,956,300,14);g.fill();g.stroke();g.fillStyle='#d8b86d';g.font='800 14px Arial';g.textAlign='left';g.fillText(`BLOC ${roman(start+j+1)}`,88,y+36);flStoryFit(g,b.name||rd.meta.name||'Bloc',88,y+78,720,30,'#f0eadf',850);g.fillStyle='#9e9587';g.font='600 15px Arial';g.fillText(`${rd.meta.duration||4} semaines · ${sets} séries programmées`,88,y+116);let yy=y+160;rd.phases.slice(0,3).forEach(ph=>{const days=DAYS.filter(d=>(ph.data[d]||[]).some(x=>+x.sets>0)).length;g.fillStyle='#c9b98f';g.font='600 14px Arial';g.fillText(`${ph.q.label} · S${ph.q.from}${ph.q.to!==ph.q.from?'–S'+ph.q.to:''} · ${days} jours actifs`,100,yy);yy+=34});y+=325});flStoryFooter(g,String(canvases.length+1));canvases.push(c)}flExportStoryPdf(canvases,`ForgeLab_${String(fp.name||'Programme').replace(/[^a-z0-9]+/gi,'_')}_COMPLET`,'ForgeLab · Programme complet')}

// Rebranche Suivi afin d'offrir l'export global ou la sélection muscle/cardio.
const _drawTrackingV1300=drawTracking;
drawTracking=function(){_drawTrackingV1300();if(trackingMode!=='global')return;const v=document.querySelector('#view');if(!v)return;const old=v.querySelector('#trackingAnalysisExport'),sel=v.querySelector('#trackingAnalysisExportSelection');if(old){const clone=old.cloneNode(true);old.replaceWith(clone);clone.addEventListener('click',()=>{trackingReadAnalysisControls(v);trackingExportAnalysisPdf(false)})}if(sel){const clone=sel.cloneNode(true);sel.replaceWith(clone);clone.disabled=!trackingAnalysisState.muscle;clone.addEventListener('click',()=>{trackingReadAnalysisControls(v);trackingExportAnalysisPdf(true)})}const muscle=v.querySelector('#trackingAnalysisMuscle');if(muscle){muscle.addEventListener('change',()=>{trackingReadAnalysisControls(v);const results=v.querySelector('#trackingAnalysisResults');if(results)results.innerHTML=trackingAnalysisResultsHtml();const b=v.querySelector('#trackingAnalysisExportSelection');if(b)b.disabled=!trackingAnalysisState.muscle})}}


/* v1.30.8 - UI/exports only. No destructive migration, reset, deletion or rewrite of existing Series/Archives/Suivi data. */


/* v1.30.8 - FIX affichage uniquement : poignée carrée retirée des Priorités ; objectif Cardio Séries lu depuis la Programmation. Aucune donnée utilisateur n'est supprimée, migrée ou réécrite. */


/* v1.30.8 - Archives PDF 9:16 + commentaires Suivi simplifiés. UI/export uniquement. Aucune donnée Séries, Archives, Suivi, Programmation ou Priorités n'est supprimée, réinitialisée, migrée ou réécrite. */

/* v1.30.8 - Suivi : Lecture remplacée par Conclusion factuelle détaillée ; commentaires colorés selon progression/régression/stabilité. UI/export uniquement. Aucune donnée utilisateur n’est modifiée. */

/* v1.30.8 - Suivi : libellés Charge / Volume / PDC / Cardio / Conclusion toujours or ; seul le détail est coloré selon la tendance. UI et exports uniquement. Aucune donnée utilisateur n’est modifiée. */

/* v1.30.8 - Comptage séances : plusieurs séances le même jour sont comptées séparément ; les parties 1/2 d’une même séance sont regroupées. Lecture seule, aucune donnée utilisateur modifiée. */

/* v1.30.8 - Priorites par bloc : stockage additif local par bloc actif, Bloc 1 hérite des données existantes, autres blocs indépendants. Aucun reset/suppression/migration destructive. */
